/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80013
Source Host           : localhost:3306
Source Database       : crm

Target Server Type    : MYSQL
Target Server Version : 80013
File Encoding         : 65001

Date: 2019-08-30 18:12:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for crm_bank_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_bank_info`;
CREATE TABLE `crm_bank_info` (
  `BANK_ID` varchar(45) NOT NULL,
  `BANK_NAME` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`BANK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='银行信息表';

-- ----------------------------
-- Records of crm_bank_info
-- ----------------------------
INSERT INTO `crm_bank_info` VALUES ('33e275bb59fd4377a3b91e7f2a3ad809', '工商银行');
INSERT INTO `crm_bank_info` VALUES ('4013794eec7d4367a7846b54078d3211', '中信银行');
INSERT INTO `crm_bank_info` VALUES ('554bd11cea5e47db9580e0f07beffe72', '中国银行');
INSERT INTO `crm_bank_info` VALUES ('61d10b75defd40c4b44e312017a37285', '招商银行');
INSERT INTO `crm_bank_info` VALUES ('74225b1951d54b3e858b5a70de11c4f6', '建设银行');
INSERT INTO `crm_bank_info` VALUES ('9abbbc9f4e434f27ba3dc240cc786aae', '交通银行');
INSERT INTO `crm_bank_info` VALUES ('abdbe742c7d14c378a8794141faf5775', '光大银行');
INSERT INTO `crm_bank_info` VALUES ('dd09938b16554b53925ef5ce0fb760d7', '农业银行');
INSERT INTO `crm_bank_info` VALUES ('e37910cb3cac4e0dbca70184817def54', '民生银行');

-- ----------------------------
-- Table structure for crm_business_dict
-- ----------------------------
DROP TABLE IF EXISTS `crm_business_dict`;
CREATE TABLE `crm_business_dict` (
  `BUSINESS_ID` varchar(45) NOT NULL,
  `BUSINESS_NAME` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`BUSINESS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_business_dict
-- ----------------------------
INSERT INTO `crm_business_dict` VALUES ('biz_1', '代缴公积金');
INSERT INTO `crm_business_dict` VALUES ('biz_2', '代缴社保');
INSERT INTO `crm_business_dict` VALUES ('biz_3', '代理记账');
INSERT INTO `crm_business_dict` VALUES ('biz_4', '公司注册');

-- ----------------------------
-- Table structure for crm_company_bank_rel
-- ----------------------------
DROP TABLE IF EXISTS `crm_company_bank_rel`;
CREATE TABLE `crm_company_bank_rel` (
  `COMPANY_ID` varchar(45) NOT NULL,
  `BANK_ID` varchar(45) NOT NULL,
  PRIMARY KEY (`COMPANY_ID`,`BANK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_company_bank_rel
-- ----------------------------
INSERT INTO `crm_company_bank_rel` VALUES ('9e93aa78df7242b18c980650763973c0', '33e275bb59fd4377a3b91e7f2a3ad809');
INSERT INTO `crm_company_bank_rel` VALUES ('9e93aa78df7242b18c980650763973c0', '4013794eec7d4367a7846b54078d3211');
INSERT INTO `crm_company_bank_rel` VALUES ('9e93aa78df7242b18c980650763973c0', '554bd11cea5e47db9580e0f07beffe72');
INSERT INTO `crm_company_bank_rel` VALUES ('9e93aa78df7242b18c980650763973c0', 'abdbe742c7d14c378a8794141faf5775');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', '33e275bb59fd4377a3b91e7f2a3ad809');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', '4013794eec7d4367a7846b54078d3211');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', '554bd11cea5e47db9580e0f07beffe72');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', '61d10b75defd40c4b44e312017a37285');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', '74225b1951d54b3e858b5a70de11c4f6');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', '9abbbc9f4e434f27ba3dc240cc786aae');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', 'abdbe742c7d14c378a8794141faf5775');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', 'dd09938b16554b53925ef5ce0fb760d7');
INSERT INTO `crm_company_bank_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', 'e37910cb3cac4e0dbca70184817def54');
INSERT INTO `crm_company_bank_rel` VALUES ('edcb87477e24482da98d0acce3bdb341', '4013794eec7d4367a7846b54078d3211');
INSERT INTO `crm_company_bank_rel` VALUES ('edcb87477e24482da98d0acce3bdb341', '61d10b75defd40c4b44e312017a37285');
INSERT INTO `crm_company_bank_rel` VALUES ('edcb87477e24482da98d0acce3bdb341', '74225b1951d54b3e858b5a70de11c4f6');

-- ----------------------------
-- Table structure for crm_company_business
-- ----------------------------
DROP TABLE IF EXISTS `crm_company_business`;
CREATE TABLE `crm_company_business` (
  `COMPANY_ID` varchar(45) NOT NULL,
  `BUSINESS_ID` varchar(45) NOT NULL,
  `BEGIN_DATE` date DEFAULT NULL COMMENT '开始时间',
  `END_DATE` date DEFAULT NULL COMMENT '到期时间',
  `UPDATE_DATE` date DEFAULT NULL,
  `IS_VALID` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`COMPANY_ID`,`BUSINESS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_company_business
-- ----------------------------
INSERT INTO `crm_company_business` VALUES ('a5b24848e32d47fd9472de4323d61da2', 'biz_1', '2019-08-26', '2019-08-30', '2019-08-26', '1');

-- ----------------------------
-- Table structure for crm_company_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_company_info`;
CREATE TABLE `crm_company_info` (
  `COMPANY_ID` varchar(45) NOT NULL,
  `COMPANY_NAME` varchar(255) NOT NULL,
  `TAX_TYPE` varchar(45) NOT NULL COMMENT '纳税类型',
  `PROVINCE` varchar(45) NOT NULL,
  `CITY` varchar(45) NOT NULL COMMENT '所在市',
  `DISTRICT` varchar(45) DEFAULT NULL COMMENT '所在区',
  `FINANCE_DISK_TYPE` varchar(45) DEFAULT NULL COMMENT '金税盘种类',
  `TAX_RATE` decimal(20,5) DEFAULT NULL COMMENT '税率',
  `UPDATE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`COMPANY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_company_info
-- ----------------------------
INSERT INTO `crm_company_info` VALUES ('9e93aa78df7242b18c980650763973c0', '盒马生鲜', '1', '上海市', '上海市', '嘉定区', '1', '12.90000', '2019-08-25 22:03:36');
INSERT INTO `crm_company_info` VALUES ('a5b24848e32d47fd9472de4323d61da2', '阿里妈妈', '0', '海南省', '省直辖县级行政单位', '儋州市', '0', '1111.33400', '2019-08-26 00:13:48');
INSERT INTO `crm_company_info` VALUES ('edcb87477e24482da98d0acce3bdb341', '天猫商城', '0', '浙江省', '杭州市', '拱墅区', '1', '2.00000', '2019-08-25 22:07:13');

-- ----------------------------
-- Table structure for crm_company_staff_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_company_staff_info`;
CREATE TABLE `crm_company_staff_info` (
  `STAFF_ID` varchar(45) NOT NULL,
  `NAME` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ID_CARD` varchar(100) DEFAULT NULL,
  `CONTACT_NUMBER` varchar(45) DEFAULT NULL,
  `NEED_SOCIAL_INS` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0',
  `NEED_HABITATION_INS` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0',
  `NEED_SOCIAL_SERVER` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0',
  `NEED_HABITATION_SERVER` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0',
  `UPDATE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`STAFF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_company_staff_info
-- ----------------------------
INSERT INTO `crm_company_staff_info` VALUES ('d16e6bd1e0884cbca07997ba0e14d80c', '张勇', '23792387598', '32197419847214', '0', '1', '1', '1', '2019-08-26 18:50:40');

-- ----------------------------
-- Table structure for crm_company_staff_rel
-- ----------------------------
DROP TABLE IF EXISTS `crm_company_staff_rel`;
CREATE TABLE `crm_company_staff_rel` (
  `COMPANY_ID` varchar(45) NOT NULL,
  `STAFF_ID` varchar(45) NOT NULL,
  PRIMARY KEY (`COMPANY_ID`,`STAFF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_company_staff_rel
-- ----------------------------
INSERT INTO `crm_company_staff_rel` VALUES ('a5b24848e32d47fd9472de4323d61da2', 'd16e6bd1e0884cbca07997ba0e14d80c');

-- ----------------------------
-- Table structure for crm_custom_bank_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_bank_info`;
CREATE TABLE `crm_custom_bank_info` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `BANK_ID` varchar(45) NOT NULL COMMENT '银行代码',
  `UPDATE_DATE` date DEFAULT NULL,
  PRIMARY KEY (`CUSTOM_ID`,`BANK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户银行信息表';

-- ----------------------------
-- Records of crm_custom_bank_info
-- ----------------------------

-- ----------------------------
-- Table structure for crm_custom_bank_info_old
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_bank_info_old`;
CREATE TABLE `crm_custom_bank_info_old` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `BANK_ID` varchar(45) NOT NULL COMMENT '银行代码',
  `UPDATE_DATE` date DEFAULT NULL,
  PRIMARY KEY (`CUSTOM_ID`,`BANK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户银行信息表';

-- ----------------------------
-- Records of crm_custom_bank_info_old
-- ----------------------------

-- ----------------------------
-- Table structure for crm_custom_basic_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_basic_info`;
CREATE TABLE `crm_custom_basic_info` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `WEIXIN_ACCNT` varchar(45) NOT NULL COMMENT '微信账号',
  `WEIXIN_NAME` varchar(45) DEFAULT NULL,
  `WANGWANG_ACCNT` varchar(45) NOT NULL COMMENT '旺旺账号',
  `CONTACT_PERSON` varchar(45) NOT NULL COMMENT '联系人',
  `CONTACT_NUMBER` varchar(45) NOT NULL COMMENT '联系电话',
  `CORPORATION` varchar(45) DEFAULT NULL COMMENT '法人',
  `CORPORATION_NUMBER` varchar(45) DEFAULT NULL COMMENT '法人电话',
  `CUSTOM_LEVEL` varchar(45) NOT NULL COMMENT '客户等级',
  `CUSTOM_NAME` varchar(45) NOT NULL COMMENT '客户名称',
  `IS_VALID` varchar(45) DEFAULT NULL,
  `UPDATE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`CUSTOM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_custom_basic_info
-- ----------------------------
INSERT INTO `crm_custom_basic_info` VALUES ('3c3478c65dc0403fa68eb0d24c93969b', '马化腾是我小弟', '我对钱没有兴趣', '我是马云', '马爸爸', '888888', '张勇', '8888888', 'VVIP', '张勇', '1', '2019-08-25 00:35:58');

-- ----------------------------
-- Table structure for crm_custom_basic_info_old
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_basic_info_old`;
CREATE TABLE `crm_custom_basic_info_old` (
  `CUSTOM_ID` varchar(20) NOT NULL COMMENT '客户ID',
  `CUSTOM_ACCNT` varchar(45) DEFAULT NULL COMMENT '''客户账户''',
  `CUSTOM_NAME` varchar(45) DEFAULT NULL COMMENT '''客户名称''',
  `PASSWORD` varchar(45) DEFAULT NULL COMMENT '''客户登陆密码''',
  `CONTACT_NAME` varchar(45) DEFAULT NULL COMMENT '''联系人''',
  `CONTACT_TEL` varchar(45) DEFAULT NULL COMMENT '''联系人电话''',
  `IS_VALID` varchar(1) DEFAULT NULL,
  `UPDATE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`CUSTOM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户基本信息表';

-- ----------------------------
-- Records of crm_custom_basic_info_old
-- ----------------------------

-- ----------------------------
-- Table structure for crm_custom_company_rel
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_company_rel`;
CREATE TABLE `crm_custom_company_rel` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `COMPANY_ID` varchar(45) NOT NULL,
  PRIMARY KEY (`CUSTOM_ID`,`COMPANY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_custom_company_rel
-- ----------------------------
INSERT INTO `crm_custom_company_rel` VALUES ('3c3478c65dc0403fa68eb0d24c93969b', 'a5b24848e32d47fd9472de4323d61da2');
INSERT INTO `crm_custom_company_rel` VALUES ('3c3478c65dc0403fa68eb0d24c93969b', 'edcb87477e24482da98d0acce3bdb341');

-- ----------------------------
-- Table structure for crm_custom_finance_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_finance_info`;
CREATE TABLE `crm_custom_finance_info` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `FINANCE_DISK_TYPE` varchar(45) DEFAULT NULL COMMENT '金税盘类型',
  `UPDATE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`CUSTOM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户财务信息表';

-- ----------------------------
-- Records of crm_custom_finance_info
-- ----------------------------

-- ----------------------------
-- Table structure for crm_custom_finance_info_old
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_finance_info_old`;
CREATE TABLE `crm_custom_finance_info_old` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `FINANCE_DISK_TYPE` varchar(45) DEFAULT NULL COMMENT '金税盘类型',
  `UPDATE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`CUSTOM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='客户财务信息表';

-- ----------------------------
-- Records of crm_custom_finance_info_old
-- ----------------------------

-- ----------------------------
-- Table structure for crm_custom_order_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_order_info`;
CREATE TABLE `crm_custom_order_info` (
  `CUSTOM_ID` varchar(45) NOT NULL,
  `ORDER_ID` varchar(45) NOT NULL,
  `ORDER_DATE` varchar(45) NOT NULL COMMENT '订单日期',
  `RECEIVABLE_AMT` decimal(10,0) NOT NULL COMMENT '应收金额',
  `PAYABLE_AMT` decimal(10,0) NOT NULL COMMENT '应付金额',
  PRIMARY KEY (`ORDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_custom_order_info
-- ----------------------------
INSERT INTO `crm_custom_order_info` VALUES ('3c3478c65dc0403fa68eb0d24c93969b', '0001', '2019/08/09 16:00:07', '21190', '21190');
INSERT INTO `crm_custom_order_info` VALUES ('3c3478c65dc0403fa68eb0d24c93969b', '0002', '2019/08/28 00:00:00', '156465', '464654');

-- ----------------------------
-- Table structure for crm_custom_third_party_info
-- ----------------------------
DROP TABLE IF EXISTS `crm_custom_third_party_info`;
CREATE TABLE `crm_custom_third_party_info` (
  `THIRD_PARTY_ID` varchar(45) NOT NULL,
  `THIRD_PARTY_NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`THIRD_PARTY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_custom_third_party_info
-- ----------------------------
INSERT INTO `crm_custom_third_party_info` VALUES ('1', '华为技术有限公司');
INSERT INTO `crm_custom_third_party_info` VALUES ('2', '小米股份有限公司');
INSERT INTO `crm_custom_third_party_info` VALUES ('3', '苹果股份有限公司');
INSERT INTO `crm_custom_third_party_info` VALUES ('4', '阿里巴巴股份有限公司');

-- ----------------------------
-- Table structure for crm_order_business_rel
-- ----------------------------
DROP TABLE IF EXISTS `crm_order_business_rel`;
CREATE TABLE `crm_order_business_rel` (
  `EVENT_ID` varchar(45) NOT NULL COMMENT '事件ID',
  `ORDER_ID` varchar(45) NOT NULL COMMENT '订单ID',
  `BUSINESS_ID` varchar(45) NOT NULL COMMENT '业务类型ID',
  `COMPANY_ID` varchar(45) NOT NULL,
  `OWNER_ID` varchar(45) NOT NULL COMMENT '对接人',
  `NEED_THIRD_PARTY` varchar(1) NOT NULL COMMENT '是否需要合作方',
  `THIRD_PARTY_ID` varchar(45) DEFAULT NULL,
  `THIRD_PARTY_FEE` decimal(10,0) DEFAULT NULL COMMENT '合作方费用',
  `BUSINESS_TAG` varchar(45) NOT NULL,
  `PRE_EVENT_ID` varchar(45) DEFAULT NULL COMMENT '前置任务',
  `REMARK` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_order_business_rel
-- ----------------------------

-- ----------------------------
-- Table structure for crm_order_dljz_detail
-- ----------------------------
DROP TABLE IF EXISTS `crm_order_dljz_detail`;
CREATE TABLE `crm_order_dljz_detail` (
  `EVENT_ID` varchar(45) NOT NULL,
  `ORDER_ID` varchar(45) DEFAULT NULL,
  `BEGIN_DATE` date DEFAULT NULL,
  `END_DATE` date DEFAULT NULL,
  `IS_BEGIN` varchar(1) DEFAULT NULL COMMENT '服务是否开始',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代理记账明细表';

-- ----------------------------
-- Records of crm_order_dljz_detail
-- ----------------------------

-- ----------------------------
-- Table structure for crm_order_gjjsbdj_detail
-- ----------------------------
DROP TABLE IF EXISTS `crm_order_gjjsbdj_detail`;
CREATE TABLE `crm_order_gjjsbdj_detail` (
  `EVENT_ID` varchar(45) NOT NULL,
  `ORDER_ID` varchar(45) DEFAULT NULL,
  `BUSINESS_ID` varchar(45) DEFAULT NULL,
  `BEGIN_DATE` date DEFAULT NULL,
  `END_DATE` date DEFAULT NULL,
  `EMPLOYEE_NUM` int(11) DEFAULT NULL COMMENT '缴款人数',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公积金社保代缴明细表';

-- ----------------------------
-- Records of crm_order_gjjsbdj_detail
-- ----------------------------

-- ----------------------------
-- Table structure for crm_order_gszc_detail
-- ----------------------------
DROP TABLE IF EXISTS `crm_order_gszc_detail`;
CREATE TABLE `crm_order_gszc_detail` (
  `EVENT_ID` varchar(45) NOT NULL,
  `ORDER_ID` varchar(45) DEFAULT NULL,
  `ABSENT` varchar(1) DEFAULT NULL COMMENT '是否需要到场，0：到场，1：缺席',
  `REG_LOCATION_TYPE` varchar(45) DEFAULT NULL COMMENT '注册地类型',
  PRIMARY KEY (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of crm_order_gszc_detail
-- ----------------------------
