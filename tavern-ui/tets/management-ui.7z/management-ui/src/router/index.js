import Vue from 'vue'
import Router from 'vue-router'

// in development-env not use lazy-loading, because lazy-loading too many pages will cause webpack hot update too slow. so only in production use lazy-loading;
// detail: https://panjiachen.github.io/vue-element-admin-site/#/lazy-loading

Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'

/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
*                                if not set alwaysShow, only more than one route under the children
*                                it will becomes nested mode, otherwise not show the root menu
* redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
**/
export const constantRouterMap = [
  { path: '/login', component: () => import('@/views/login/index'), hidden: true },
  { path: '/404', component: () => import('@/views/404'), hidden: true },
  { path: '/401', component: () => import('@/views/401'), hidden: true },
  {
    path: '',
    component: Layout,
    name: 'titleName',
    meta: { title: '互联网中台' },
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      hidden: true,
      component: () => import('@/views/dashboard/index'),
      name: 'dashboard',
      meta: { title: '互联网中台', icon: 'dashboard', noCache: true }
    }]
  }
]

export default new Router({
  base: '/es-opm/',
  mode: 'history', // 后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

export const asyncRouterMap = [{
  path: '/alarm',
  component: Layout,
  name: 'alarm',
  redirect: '/alarm/alarmStatus',
  meta: { title: 'alarm', icon: 'example', roles: ['alarm'] },
  children: [
    {
      path: 'alarmStatus',
      name: 'alarmStatus',
      component: () => import('@/views/monitor/alarmStatus'),
      meta: { title: 'alarmStatus', icon: 'table', roles: ['alarmStatus'] }
    }
  ]

},
{
  path: '/userDIY',
  component: Layout,
  name: 'userDIY',
  redirect: '/userDIY/themeManagement',
  meta: { title: 'userDIY', icon: 'example' },
  children: [
    {
      path: 'bizPrefer',
      name: 'bizPrefer',
      component: () => import('@/views/monitor/ThemeOPs/bizPrefer'),
      meta: { title: 'bizPrefer', icon: 'table' }
    },
    {
      path: 'themeManagement',
      name: 'themeManagement',
      component: () => import('@/views/monitor/ThemeOPs/themeManagement'),
      meta: { title: 'themeManagement', icon: 'table' }
    }
  ]

},
{
  path: '/monitor',
  component: Layout,
  name: 'monitor',
  redirect: '/monitor/moduleStatus',
  meta: { title: 'monitor', icon: 'example', roles: ['monitor'] },
  children: [
    {
      path: 'moduleStatus',
      name: 'moduleStatus',
      component: () => import('@/views/monitor/moduleStatus'),
      meta: { title: 'moduleStatus', icon: 'table', roles: ['moduleStatus'] }
    },
    {
      path: 'instanceStatus/:queryStatus/:instanceId/:alarmStatus',
      name: 'instanceStatus',
      component: () => import('@/views/monitor/instanceStatus'),
      hidden: true,
      meta: { title: 'alarmStatus', icon: 'table', roles: ['instanceStatus'] }
    },
    {
      path: 'moduleDetail/:moduleId/:moduleName',
      name: 'moduleDetail',
      component: () => import('@/views/monitor/moduleDetail'),
      hidden: true,
      meta: { title: 'moduleDetail', icon: 'table', roles: ['moduleDetail'] }
    },
    {
      path: 'instanceDetail/:moduleId/:instanceId/:moduleName',
      name: 'instanceDetail',
      component: () => import('@/views/monitor/instanceDetail'),
      hidden: true,
      meta: { title: 'instanceDetail', icon: 'table', roles: ['instanceDetail'] }
    },
    {
      path: 'instanceDetailButton',
      name: 'instanceDetailButton',
      hidden: true,
      meta: { title: 'instanceDetailButton', icon: 'button', roles: ['instanceDetailButton'] }
    },
    {
      path: 'moduleList',
      name: 'moduleList',
      component: () => import('@/views/monitor/Listope/moduleList'),
      meta: { title: 'moduleList', icon: 'table', roles: ['moduleList'] }
    },
    {
      path: 'moduleListButton',
      name: 'moduleListButton',
      hidden: true,
      meta: { title: 'moduleListButton', icon: 'button', roles: ['moduleListButton'] }
    },
    {
      path: 'serviceLists',
      name: 'serviceLists',
      component: () => import('@/views/monitor/serviceManagement'),
      meta: { title: 'serviceLists', icon: 'table', roles: ['serviceLists'] }
    },
    {
      path: 'serviceListsButton',
      name: 'serviceListsButton',
      hidden: true,
      meta: { title: 'serviceListsButton', icon: 'button', roles: ['serviceListsButton'] }
    },
    {
      path: 'instanceMetrics/:instanceId/:instanceName',
      name: 'instanceMetrics',
      hidden: true,
      component: () => import('@/views/monitor/Listope/instanceMetrics'),
      meta: { title: 'instanceMetrics', icon: 'table', roles: ['instanceMetrics'] }
    },
    {
      path: 'instanceMetricsButton',
      name: 'instanceMetricsButton',
      hidden: true,
      meta: { title: 'instanceMetricsButton', icon: 'button', roles: ['instanceMetricsButton'] }
    },
    {
      path: 'instanceList/:moduleId/:moduleName',
      name: 'instanceList',
      hidden: true,
      component: () => import('@/views/monitor/Listope/instanceList'),
      meta: { title: 'instanceList', icon: 'table', roles: ['instanceList'] }
    },
    {
      path: 'instanceListButton',
      name: 'instanceListButton',
      hidden: true,
      meta: { title: 'instanceListButton', icon: 'button', roles: ['instanceListButton'] }
    },
    {
      path: 'moduleManagement',
      name: 'moduleManagement',
      hidden: true,
      component: () => import('@/views/monitor/moduleManagement'),
      meta: { title: 'moduleManagement', icon: 'table', roles: ['moduleManagement'] }
    },
    {
      path: 'moduleManagementButton',
      name: 'moduleManagementButton',
      hidden: true,
      meta: { title: 'moduleManagementButton', icon: 'button', roles: ['moduleManagementButton'] }
    },
    {
      path: 'templatesListRouter',
      name: 'templatesList',
      hidden: true,
      component: () => import('@/views/monitor/RulesOps/templatesList'),
      meta: { title: 'templatesList', icon: 'zip' }
    },
    {
      path: 'proxyListRouter',
      name: 'proxyList',
      hidden: true,
      component: () => import('@/views/monitor/RulesOps/proxyList'),
      meta: { title: 'proxyList', icon: 'zip' }
    },
    {
      path: 'parserListRouter',
      name: 'parserList',
      hidden: true,
      component: () => import('@/views/monitor/RulesOps/parserList'),
      meta: { title: 'parserList', icon: 'zip' }
    },
    {
      path: 'alarmRulesListRouter/:parserId/:alarmRuleName',
      name: 'alarmRulesList',
      hidden: true,
      component: () => import('@/views/monitor/RulesOps/alarmRulesList'),
      meta: { title: 'alarmRulesList', icon: 'zip' }
    },
    {
      path: 'metricsListRouter/:parserId/:alarmRuleName',
      name: 'metricsLists',
      hidden: true,
      component: () => import('@/views/monitor/RulesOps/metricsList'),
      meta: { title: 'metricsLists', icon: 'zip' }
    },
    {
      path: '/monitor/AlarmRulesManagement',
      name: 'AlarmRulesManagement',
      redirect: '/monitor/AlarmRulesManagement/alarmRulesList',
      component: () => import('@/views/monitor/RulesOps/index'),
      meta: { title: 'AlarmRulesManagement', icon: 'table', roles: ['AlarmRulesManagement'] },
      children: [
        {
          path: 'templatesList',
          name: 'templatesListRouter',
          redirect: '/monitor/templatesListRouter',
          meta: { title: 'templatesListRouter', icon: 'zip', roles: ['templatesListRouter'] }
        },
        {
          path: 'templatesListButton',
          name: 'templatesListButton',
          hidden: true,
          meta: { title: 'templatesListButton', icon: 'button', roles: ['templatesListButton'] }
        },
        {
          path: 'parserList',
          name: 'parserListRouter',
          redirect: '/monitor/parserListRouter',
          meta: { title: 'parserListRouter', icon: 'zip', roles: ['parserListRouter'] }
        },
        {
          path: 'parserListButton',
          name: 'parserListButton',
          hidden: true,
          meta: { title: 'parserListButton', icon: 'button', roles: ['parserListButton'] }
        },
        {
          path: 'alarmRulesList/:parserId/:alarmRuleName',
          name: 'alarmRulesListRouter',
          hidden: true,
          redirect: '/monitor/alarmRulesListRouter/:parserId/:alarmRuleName',
          meta: { title: 'alarmRulesListRouter', icon: 'zip', roles: ['alarmRulesListRouter'] }
        },
        {
          path: 'alarmRulesListButton',
          name: 'alarmRulesListButton',
          hidden: true,
          meta: { title: 'alarmRulesListButton', icon: 'button', roles: ['alarmRulesListButton'] }
        },
        {
          path: 'metricsList/:parserId/:alarmRuleName',
          name: 'metricsListRouter',
          hidden: true,
          redirect: '/monitor/metricsListRouter/:parserId/:alarmRuleName',
          meta: { title: 'metricsListRouter', icon: 'zip', roles: ['metricsListRouter'] }
        },
        {
          path: 'metricsListsButton',
          name: 'metricsListsButton',
          hidden: true,
          meta: { title: 'metricsListsButton', icon: 'button', roles: ['metricsListsButton'] }
        },
        {
          path: 'proxyList',
          name: 'proxyListRouter',
          redirect: '/monitor/proxyListRouter',
          meta: { title: 'proxyListRouter', icon: 'zip', roles: ['proxyListRouter'] }
        },
        {
          path: 'proxyListButton',
          name: 'proxyListButton',
          hidden: true,
          meta: { title: 'proxyListButton', icon: 'button', roles: ['proxyListButton'] }
        }
      ]
    }
  ]
},

{
  path: '/Log',
  component: Layout,
  name: 'Log',
  meta: { title: 'Log', icon: 'example', roles: ['Log'] },
  children: [
    {
      path: 'accesslog',
      name: 'accesslog',
      component: () => import('@/views/log/accesslog'),
      meta: { title: 'accesslog', icon: 'table', roles: ['accesslog'] }
    },
    {
      path: 'traceLog/:traceLog',
      name: 'traceLog',
      component: () => import('@/views/log/traceLogmerge'),
      meta: { title: 'traceLog', icon: 'table', roles: ['traceLog'] }
    },
    {
      path: 'traceLogButton',
      name: 'traceLogButton',
      hidden: true,
      meta: { title: 'traceLogButton', icon: 'button', roles: ['traceLogButton'] }
    },
    {
      path: 'esMapping',
      name: 'esMapping',
      component: () => import('@/views/log/es/CheckFields'),
      meta: { title: 'esMapping', icon: 'table', roles: ['esMapping'] }
    },
    {
      path: 'keywordSearch',
      name: 'keywordSearch',
      component: () => import('@/views/log/es/keywordSearch'),
      meta: { title: 'keywordSearch', icon: 'table', roles: ['keywordSearch'] }
    },
    {
      path: 'FuncStatus',
      name: 'FuncStatus',
      component: () => import('@/views/log/es/FuncStatus'),
      meta: { title: 'FuncStatus', icon: 'table', roles: ['FuncStatus'] }
    },
    {
      path: 'funcDetail/:funcDetail',
      name: 'funcDetail',
      component: () => import('@/views/log/es/funcDetail'),
      meta: { title: 'funcDetail', icon: 'table', roles: ['funcDetail'] }
    }
    // {
    //   path: 'simplegraph',
    //   name: 'simplegraph',
    //   component: () => import('@/views/log/SimpleGraph'),
    //   meta: { title: 'simplegraph', icon: 'table' }
    // }
  ]
},
{
  path: '/configCenter',
  component: Layout,
  name: 'configCenterTitle',
  meta: { title: 'configCenterTitle', icon: 'example', roles: ['configCenterTitle'] },
  children: [
    {
      path: 'configCenter',
      name: 'configCenter',
      component: () => import('@/views/configCenter/NewConfigCenter'),
      meta: { title: 'configCenter', icon: 'table', roles: ['configCenter'] }
    },
    {
      path: 'configCenterButton',
      name: 'configCenterButton',
      hidden: true,
      meta: { title: 'configCenterButton', icon: 'button', roles: ['configCenterButton'] }
    },
    {
      path: ':env/:domainWindow',
      name: 'domainWindow',
      hidden: true,
      component: () => import('@/views/configCenter/domainWindow'),
      meta: { title: 'domainWindow', icon: 'table' }
    },
    {
      path: 'moduleDictionarypageButton',
      name: 'moduleDictionarypageButton',
      hidden: true,
      meta: { title: 'moduleDictionarypageButton', icon: 'button', roles: ['moduleDictionarypageButton'] }
    },
    {
      path: 'moduleDictionarypage',
      name: 'moduleDictionarypage',
      component: () => import('@/views/configCenter/moduleDictionarypage'),
      meta: { title: 'moduleDictionarypage', icon: 'table', roles: ['moduleDictionarypage'] }
    },
    {
      path: 'DictionarypageButton',
      name: 'DictionarypageButton',
      hidden: true,
      meta: { title: 'DictionarypageButton', icon: 'button', roles: ['DictionarypageButton'] }
    },
    {
      path: 'Dictionarypage',
      name: 'Dictionarypage',
      hidden: true,
      component: () => import('@/views/configCenter/Dictionarypage'),
      meta: { title: 'Dictionarypage', icon: 'table', roles: ['Dictionarypage'] }
    },
    {
      path: 'domainWindowButton',
      name: 'domainWindowButton',
      hidden: true,
      meta: { title: 'domainWindowButton', icon: 'button', roles: ['domainWindowButton'] }
    },
    {
      path: 'templatesDomainButton',
      name: 'templatesDomainButton',
      hidden: true,
      meta: { title: 'templatesDomainButton', icon: 'button', roles: ['templatesDomainButton'] }
    },
    {
      path: 'templatesDomain',
      name: 'templatesDomain',
      component: () => import('@/views/configCenter/templatesDomain'),
      meta: { title: 'templatesDomain', icon: 'table', roles: ['templatesDomain'] }
    },
    {
      path: 'moduleGrpcServicepageButton',
      name: 'moduleGrpcServicepageButton',
      hidden: true,
      meta: { title: 'moduleGrpcServicepageButton', icon: 'button', roles: ['moduleGrpcServicepageButton'] }
    },
    {
      path: 'moduleGrpcServicepage',
      name: 'moduleGrpcServicepage',
      component: () => import('@/views/configCenter/grpcServiceConfig/moduleGrpcServicepage'),
      meta: { title: 'moduleGrpcServicepage', icon: 'table', roles: ['moduleGrpcServicepage'] }
    },
    {
      path: 'GrpcServiceNodespageButton',
      name: 'GrpcServiceNodespageButton',
      hidden: true,
      meta: { title: 'GrpcServiceNodespageButton', icon: 'button', roles: ['GrpcServiceNodespageButton'] }
    },
    {
      path: 'GrpcServiceNodespage',
      name: 'GrpcServiceNodespage',
      hidden: true,
      component: () => import('@/views/configCenter/grpcServiceConfig/GrpcServiceNodespage'),
      meta: { title: 'GrpcServiceNodespage', icon: 'table', roles: ['GrpcServiceNodespage'] }
    },
    {
      path: 'nodeConfigPageButton',
      name: 'nodeConfigPageButton',
      hidden: true,
      meta: { title: 'nodeConfigPageButton', icon: 'button', roles: ['nodeConfigPageButton'] }
    },
    {
      path: 'nodeConfigPage',
      name: 'nodeConfigPage',
      hidden: true,
      component: () => import('@/views/configCenter/grpcServiceConfig/nodeConfigPage'),
      meta: { title: 'nodeConfigPage', icon: 'table', roles: ['nodeConfigPage'] }
    },
    {
      path: 'bizConfig',
      name: 'bizConfig',
      component: () => import('@/views/configCenter/bizConfig/bizConfig'),
      meta: { title: 'bizConfig', icon: 'table', roles: ['bizConfig'] }
    },
    {
      path: 'bizConfigButton',
      name: 'bizConfigButton',
      hidden: true,
      meta: { title: 'bizConfigButton', icon: 'button', roles: ['bizConfigButton'] }
    },
    {
      path: 'SystemOfflineControl',
      name: 'SystemOfflineControl',
      component: () => import('@/views/configCenter/SystemOfflineControl'),
      meta: { title: 'SystemOfflineControl', icon: 'table', roles: ['SystemOfflineControl'] }
    },
    {
      path: 'SystemOfflineControlButton',
      name: 'SystemOfflineControlButton',
      hidden: true,
      meta: { title: 'SystemOfflineControlButton', icon: 'button', roles: ['SystemOfflineControlButton'] }
    },
    {
      path: 'historyQuery',
      name: 'historyQuery',
      component: () => import('@/views/configCenter/historyQuery'),
      meta: { title: 'historyQuery', icon: 'table', roles: ['historyQuery'] }
    }
  ]
},
{
  path: '/reverseQuery',
  component: Layout,
  name: 'reverseQuery',
  hidden: true,
  meta: { title: 'reverseQuery', icon: 'example' },
  children: [
    {
      path: 'reverseQuery/:env/:Domname',
      name: 'reverseQuery',
      hidden: true,
      component: () => import('@/views/configCenter/reverseQuery'),
      meta: { title: 'reverseQuery', icon: 'table' }
    }]
},
// {
//   path: '/domainWindow',
//   component: Layout,
//   name: 'domainWindow',
//   hidden: true,
//   meta: { title: 'domainWindow', icon: 'example', roles: ['domainWindow'] },
//   children: [
//     ]
// },
{
  path: '/schedule',
  component: Layout,
  name: 'schedule',
  meta: { title: 'schedule', icon: 'example', roles: ['schedule'] },
  children: [
    {
      path: 'schedule',
      name: 'schedule',
      component: () => import('@/views/schedule/schedule'),
      meta: { title: 'schedule', icon: 'table', roles: ['schedule'] }
    },
    {
      path: 'scheduleButton',
      name: 'scheduleButton',
      hidden: true,
      meta: { title: 'scheduleButton', icon: 'button', roles: ['scheduleButton'] }
    },
    {
      path: 'scheduleMonitor',
      name: 'scheduleMonitor',
      component: () => import('@/views/schedule/scheduleMonitor'),
      meta: { title: 'scheduleMonitor', icon: 'table', roles: ['scheduleMonitor'] }
    },
    {
      path: 'scheduleMonitorButton',
      name: 'scheduleMonitorButton',
      hidden: true,
      meta: { title: 'scheduleMonitorButton', icon: 'button', roles: ['scheduleMonitorButton'] }
    },
    {
      path: 'historyList/:type/:taskId/:taskName',
      name: 'historyList',
      hidden: true,
      component: () => import('@/views/schedule/historyList'),
      meta: { title: 'historyList', icon: 'table', roles: ['historyList'] }
    },
    {
      path: 'arbiterDetail/:taskId/:taskName',
      name: 'arbiterDetail',
      hidden: true,
      component: () => import('@/views/schedule/arbiterDetail'),
      meta: { title: 'arbiterDetail', icon: 'table', roles: ['arbiterDetail'] }
    }]
},
{
  path: '/systemManagement',
  component: Layout,
  name: 'systemManagement',
  meta: { title: 'systemManagement', icon: 'example', roles: ['systemManagement'] },
  children: [
    {
      path: 'roleTemplateManagement',
      name: 'roleTemplateManagement',
      component: () => import('@/views/systemManagement/roleTemplateManagement'),
      meta: { title: 'roleTemplateManagement', icon: 'table', roles: ['roleTemplateManagement'] }
    },
    {
      path: 'userManagement',
      name: 'userManagement',
      component: () => import('@/views/systemManagement/userManagement'),
      meta: { title: 'userManagement', icon: 'table', roles: ['userManagement'] }
    }
  ]
},
{
  path: '/DIYFunctions',
  component: Layout,
  name: 'DIYFunctions',
  meta: { title: 'DIYFunctions', icon: 'example', roles: ['DIYFunctions'] },
  children: [
    {
      path: 'queryUserAccountTree',
      name: 'queryUserAccountTree',
      component: () => import('@/views/DIYFunctions/queryUserAccountTree'),
      meta: { title: 'queryUserAccountTree', icon: 'table', roles: ['queryUserAccountTree'] }
    },
    {
      path: 'userTagList',
      name: 'userTagList',
      component: () => import('@/views/DIYFunctions/userTagList'),
      meta: { title: 'userTagList', icon: 'table', roles: ['userTagList'] }
    }
  ]
},
{ path: '*', redirect: '/404', hidden: true }
]
