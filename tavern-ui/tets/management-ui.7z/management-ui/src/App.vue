<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
  // mounted() {
  //   console.log('reload!')
  //   this.$store.dispatch('delAllViews')
  //   this.$store.dispatch('clearAllTimer')
  //   // this.$router.push('/')
  // }
}
</script>
