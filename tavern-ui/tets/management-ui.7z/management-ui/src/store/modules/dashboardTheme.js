const dashboardTheme = {
  state: {
    themeNameList: [],
    pageNameList: []
  },

  mutations: {
    SET_THEME: (state, themeName) => {
      state.themeNameList = themeName
      console.log('themeNameList', state.themeNameList)
    },
    CLEAR_THEME: (state) => {
      console.log('clearthemeNameList')
      state.themeNameList = []
    },
    SET_PAGE: (state, pageName) => {
      state.pageNameList = pageName
      console.log('pageNameList', state.pageNameList)
    },
    CLEAR_PAGE: (state) => {
      console.log('clearpageNameList')
      state.pageNameList = []
    }
  },

  actions: {
    // 设定主题名称列表
    setThemeNameList({ commit }, themeName) {
      return new Promise((resolve) => {
        console.log('setthemeNameList:', themeName)
        commit('SET_THEME', themeName)
      })
    },

    // 清空主题名称列表
    clearThemeNameList({ commit }) {
      return new Promise((resolve) => {
        console.log('clearthemeNameList。。。')
        commit('CLEAR_THEME')
      })
    },
    // 设定页面名称列表
    setPageNameList({ commit }, pageName) {
      return new Promise((resolve) => {
        console.log('setpageNameList:', pageName)
        commit('SET_PAGE', pageName)
      })
    },

    // 清空页面名称列表
    clearPageNameList({ commit }) {
      return new Promise((resolve) => {
        console.log('clearpageNameList。。。')
        commit('CLEAR_PAGE')
      })
    }
  }
}

export default dashboardTheme

