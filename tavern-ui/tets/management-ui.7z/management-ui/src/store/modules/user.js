import { login, logout, getInfo } from '@/api/login'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { getModuleNameList } from '@/api/config'
import { queryBizPreferByName } from '@/api/monitor'

const user = {
  state: {
    token: getToken(),
    name: '',
    avatar: '',
    roles: [],
    preferModules: []
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_MODULES: (state, preferModules) => {
      state.preferModules = preferModules
    }
  },

  actions: {
    // 登录
    Login({ commit }, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        login(username, userInfo.password).then(response => {
          const data = response.token
          setToken(data)
          commit('SET_TOKEN', data)
          console.log('token:', data)
          resolve()
        }).catch(error => {
          reject(error)
        })
        // if (userInfo.username.trim() === 'admin' & userInfo.password === 'admin') {
        //   setToken('X-Token')
        //   commit('SET_TOKEN', 'X-Token')
        //   resolve()
        // } else {
        //   reject()
        // }
      })
    },

    // 获取用户信息
    GetUserInfo({ commit, state }) {
      return new Promise((resolve, reject) => {
        getInfo(state.token).then(response => {
          const data = response.data.userInfo
          commit('SET_ROLES', data.roles)
          commit('SET_NAME', data.username)
          // commit('SET_AVATAR', data.avatar)
          resolve(response)
        }).catch(error => {
          reject(error)
        })
        // if (state.token === 'X-Token') {
        //   commit('SET_ROLES', 'admin')
        //   commit('SET_NAME', 'admin')
        //   commit('SET_AVATAR', 'admin')
        //   resolve()
        // } else {
        //   reject('登陆失败')
        // }
      })
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout(state.token).then(() => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          removeToken()
          resolve()
        }).catch(error => {
          reject(error)
        })
        // commit('SET_TOKEN', '')
        // commit('SET_ROLES', [])
        // removeToken()
        // resolve()
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        removeToken()
        resolve()
      })
    },

    // 获取模块列表
    fetchModuleNameList({ commit, state }) {
      return new Promise((resolve, reject) => {
        queryBizPreferByName(state.name).then(response => {
          // console.log('queryBizPreferByName', response)
          const data = response.data.bizPreferList
          if (data.length === 0) {
            commit('SET_MODULES', ['ALL'])
          } else {
            getModuleNameList(data[0].bizPrefer.split(',')).then(response1 => {
              // console.log('getModuleNameList', response1)
              if (response1.data.ModuleNames.length === 0) {
                commit('SET_MODULES', ['NONE'])
              } else {
                commit('SET_MODULES', response1.data.ModuleNames)
              }
              resolve(response)
            })
          }
        }).catch(error => {
          reject(error)
        })
        // if (state.token === 'X-Token') {
        //   commit('SET_ROLES', 'admin')
        //   commit('SET_NAME', 'admin')
        //   commit('SET_AVATAR', 'admin')
        //   resolve()
        // } else {
        //   reject('登陆失败')
        // }
      })
    }
  }
}

export default user
