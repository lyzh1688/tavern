const timerControl = {
  state: {
    timerList: {}
  },

  mutations: {
    ADD_TIMER: (state, timer) => {
      if (state.timerList[timer.name] === null || state.timerList[timer.name] === undefined) {
        state.timerList[timer.name] = []
        state.timerList[timer.name].push(timer.timer)
      } else {
        state.timerList[timer.name].push(timer.timer)
      }
      console.log('timerList', state.timerList)
    },
    DEL_TIMER: (state, timerName) => {
      console.log('clear......', timerName)
      for (const i of state.timerList[timerName]) {
        clearInterval(i)
      }
    },
    DEL_OTHER_TIMER: (state, timerName) => {
      for (const i in state.timerList) {
        console.log('clear......', i)
        if (i !== timerName) {
          for (const j of state.timerList[timerName]) {
            clearInterval(j)
          }
        }
      }
      // clearInterval(state.timerList[timerName])
    },
    DEL_ALL_TIMER: (state) => {
      for (const i in state.timerList) {
        console.log('clear......', i)
        for (const j of state.timerList[i]) {
          clearInterval(j)
        }
      }
      // clearInterval(state.timerList[timerName])
    }
  },

  actions: {
    // 添加计时器
    addTimer({ commit }, timer) {
      return new Promise((resolve) => {
        console.log('addTimer:', timer)
        commit('ADD_TIMER', timer)
      })
    },

    // 清除计时器
    clearTimer({ commit }, timerName) {
      return new Promise((resolve) => {
        console.log('clearTimer:', timerName)
        commit('DEL_TIMER', timerName)
      })
    },
    clearOthersTimer({ commit }, timerName) {
      return new Promise((resolve) => {
        console.log('DEL_ALL_TIMER:', timerName)
        commit('DEL_OTHER_TIMER', timerName)
      })
    },
    clearAllTimer({ commit }) {
      return new Promise((resolve) => {
        console.log('DEL_ALL_TIMER:')
        commit('DEL_ALL_TIMER')
      })
    }
  }
}

export default timerControl
