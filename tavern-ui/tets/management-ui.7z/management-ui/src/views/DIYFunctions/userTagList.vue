<template>
    <div class="app-container">
        <el-card>
            <el-form  v-loading.body="listloadingFlag"  @submit.native.prevent :inline="true">
                
                <el-form-item label="账号类型:">
                                                 <el-select v-model="accountType">
                                                            <el-option
                                                                v-for="item in accountTypeTable"
                                                                :key="item.name"
                                                                :label="item.name"
                                                                :value="item.value"
                                                            >
                                                                </el-option>
                                                        </el-select>
                </el-form-item>
                <el-form-item label="账号:">
                    <el-input
                        v-model="accountValue"
                        size="mini"
                         @keyup.enter.native="getTagList"
                        placeholder="请输入账号"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="getTagList"
                        v-loading.body="listloadingFlag"
                        size="mini"
                         :border="true"
		    :stripe="true"
		    resizable
                    >查询</el-button>
                </el-form-item>
        </el-form>
        <el-table
        :data="tagList"
        size="mini">
        <el-table-column type="index" width="40%" header-align="center" align="left" ></el-table-column>
        <el-table-column header-align="center" align="left" prop="tagName" label="标签名"></el-table-column>
        <el-table-column header-align="center" align="left" prop="tagCname" label="标签中文名"></el-table-column>
        <el-table-column header-align="center" align="left" prop="tagValue" label="标签值"></el-table-column>
        <el-table-column header-align="center" align="left" prop="tagCvalue" label="中文值"></el-table-column>
        </el-table>
        </el-card>
    </div>
</template>
<script>
import {
  Message
} from 'element-ui'
import { queryUserTagList } from '@/api/DIYFunctions'
export default {
  name: 'userTagList',
  data() {
    return {
      listloadingFlag: false,
      accountType: '',
      accountValue: '',
      accountTypeTable: [{ value: '2', name: '注册号' }, { value: '3', name: '财富号' }, { value: '4', name: '资金号' }],
      tagList: []
    }
  },
  methods: {
    getTagList() {
      this.listloadingFlag = true
      queryUserTagList(this.accountType, this.accountValue).then(Response => {
        this.listloadingFlag = false
        if (Response.payload.code === 0) {
          Message.info('query success!')
          this.tagList = Response.payload.data.tagPropertiesList
        } else {
          Message.error('query failed,' + Response.payload.code + ':' + Response.payload.info)
        }
        console.log('getTagList', Response)
      })
    }
  }
}
</script>

<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>