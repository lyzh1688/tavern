<template>
<div class="app-container">
    <el-card>
        <el-form  v-loading.body="listLoading"  @submit.native.prevent :inline="true">
            <el-form-item label="资金账号:">
                    <el-input
                        v-model="FundAccount"
                        size="mini"
                         @keyup.enter.native="qetAccountTreeData"
                        placeholder="请输入资金账号"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="qetAccountTreeData"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
        </el-form>
        <div v-if="accountsTree!=null">
    <span  style="fontSize:25px;">财富号：{{accountsTree.cifAccount}}</span>
    <span  v-if="accountsTree.clientType == '0'" style="fontSize:12px;padding:2px;">手机号：{{accountsTree.mobileTel}}</span>
    <span  style="fontSize:12px;padding:2px;" v-if="accountsTree.clientType==0">用户类型：个人户</span>
    <span  style="fontSize:12px;padding:2px;" v-if="accountsTree.clientType==1">用户类型：机构户</span>
    </div>
    <span v-if="accountsTree!=null">
    <hr  style="FILTER:alpha(opacity=100,finishopacity=0,style=2)" width="100%" color=#987cb9 size=10>
    </span>
    <el-table v-if="accountsTree!=null&&accountsTree.mobileLogin!=null&&accountsTree.mobileLogin!=undefined&&accountsTree.mobileLogin.length!=0" v-loading.body="listLoading" :data="accountsTree.mobileLogin" >
              <el-table-column label="设备Id" prop="deviceId" ></el-table-column>
              <el-table-column label="登录账号类型" prop="accountType" ></el-table-column>
              <el-table-column label="登录时间" prop="activeTime" ></el-table-column>
          </el-table>
    <el-table v-if="accountsTree!=null&&accountsTree.clientType==0" v-loading.body="listLoading" :data="accountsTree.fundAccountList" >
  <el-table-column type="expand" label="下拉显示登录信息">
      <template slot-scope="scope">
          <el-table v-if="accountsTree!=null" height='auto' v-loading.body="listLoading" :data="scope.row.LoginInfo" >
              <el-table-column label="设备Id" prop="deviceId" ></el-table-column>
              <el-table-column label="登录账号类型" prop="accountType" ></el-table-column>
              <el-table-column label="登录时间" prop="activeTime" ></el-table-column>
          </el-table>
      </template>
  </el-table-column>
  <el-table-column label="资金账号" prop="fundAccount" ></el-table-column>
  <el-table-column label="账号状态" prop="accountStatus" >
    <template slot-scope="scope">
        <span>{{accountStatusDIC(scope.row.accountStatus)}}</span>
    </template>
  </el-table-column>
  <el-table-column label="资金账号签约状态" prop="signFlag" >
      <template slot-scope="scope">
        <span v-if="scope.row.signFlag == '0'">未签约</span>
        <span v-if="scope.row.signFlag == '1'">已签约</span>
    </template>
  </el-table-column>
  <el-table-column label="客户Id" prop="clientId" ></el-table-column>
  <el-table-column label="客户类型" prop="clientType" >
        <template slot-scope="scope">
        <span v-if="scope.row.clientType == '0'">个人户</span>
        <span v-if="scope.row.clientType == '1'">机构户</span>
    </template>
  </el-table-column>
  <el-table-column label="客户状态" prop="clientStatus" >
    <template slot-scope="scope">
        <span>{{accountStatusDIC(scope.row.clientStatus)}}</span>
    </template>
  </el-table-column>
  <el-table-column label="业务系统编号" prop="bizSysId" >
      <template slot-scope="scope">
            <span>{{budinsysId(scope.row.bizSysId)}}</span>
      </template>
  </el-table-column>
  <el-table-column label="分支编号" prop="branchNo" >
  </el-table-column>
  </el-table>
  <el-table v-if="accountsTree!=null&&accountsTree.clientType==1" v-loading.body="listLoading" :data="accountsTree.deviceList" >
      <el-table-column label="设备Id" prop="deviceId" ></el-table-column>
      <el-table-column label="登录账号类型" prop="accountType" ></el-table-column>
      <el-table-column label="登录时间" prop="activeTime" ></el-table-column>
  </el-table>
    </el-card>
    </div>
</template>
<script>
import {
  Message
} from 'element-ui'
import { queryAccountList } from '@/api/DIYFunctions'
export default {
  name: 'queryUserAccountTree',
  data() {
    return {
      listLoading: false,
      FundAccount: '',
      accountsTree: []
    }
  },
  created() {
    // businsys_id	业务系统编号N3、集中交易、6两融、18期权、15理财、1008货基
    // this.qetAccountTreeData()
  },
  methods: {
    accountStatusDIC(inputId) {
      switch (inputId) {
        case '0':
          return '正常'
        case '1':
          return '冻结'
        case '2':
          return '挂失'
        case '3':
          return '销户'
        case '4':
          return '未确定'
        case '5':
          return '休假'
        case '6':
          return 'VIP客户'
        case '7':
          return '离职'
        case '8':
          return 'stop buy'
        case '9':
          return 'stop sell'
        case 'A':
          return '休眠待报送'
        case 'B':
          return '休眠待撤销'
        case 'C':
          return '中登休眠'
        case 'D':
          return '风险处置'
        case 'E':
          return '中登不合格'
        case 'F':
          return '系统锁定'
        case 'G':
          return '内部休眠'
        case 'H':
          return '纯资金休眠'
        case 'I':
          return '已置换'
        case 'J':
          return '内部不合格'
        case 'K':
          return '单边取消'
        default:
          return '未识别的状态'
      }
    },
    budinsysId(inputId) {
      switch (inputId) {
        case '3':
          return '集中交易'
        case '6':
          return '两融'
        case '18':
          return '期权'
        case '15':
          return '理财'
        case '1008':
          return '货基'
        default:
          return '未识别的id'
      }
    },
    qetAccountTreeData() {
      this.listLoading = true
      queryAccountList(this.FundAccount).then(Response => {
        this.listLoading = false
        console.log('queryAccountList', Response)
        if (Response.payload.code === 0) {
          this.accountsTree = Response.payload.data
          this.accountsTree['mobileLogin'] = []
          if (Response.payload.data.clientType === '0') {
            for (const j of Response.payload.data.fundAccountList) {
              j['LoginInfo'] = []
            }
            if (Response.payload.data.deviceList.length !== 0) {
              for (const i of Response.payload.data.deviceList) {
                if (i.logonAccount === this.accountsTree.mobileTel) {
                  this.accountsTree['mobileLogin'].push(i)
                } else {
                  for (const j of Response.payload.data.fundAccountList) {
                    if (i.logonAccount === j.fundAccount) {
                      j['LoginInfo'].push(i)
                      break
                    }
                  }
                }
              }
            }
          }

          console.log('accountsTree', this.accountsTree)
        } else {
          Message.error(Response.payload.code + ':' + Response.payload.info)
          this.accountsTree = []
        }
      })
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>