<template>
    <div class="app-container">
      <el-card>
    <transition enter-active-class="fadeInLeft"
    leave-active-class="fadeOutRight">
    <el-card class="module animated" v-show="isModuletable">
        <span class="title">模块界面</span>
        <div class="envTable">
            <span class="title">当前环境：</span>
            <el-select v-model="enviroment" @change="changeEnv">
                                                            <el-option
                                                                v-for="item in envlist"
                                                                :key="item.id"
                                                                :label="item.remark"
                                                                :value="item.env"
                                                            >
                                                                </el-option>
                                                        </el-select>
        </div>
        <el-form :inline="true" @submit.native.prevent>
                <el-form-item class="form-wrapper-item" label="模块名称" label-width="90px">
                    <el-input :disabled="disableflag" @keyup.enter.native="getList" v-model="inputModuleName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button :disabled="disableflag&&isQuery" type="primary" @click="getList" size="mini">查询</el-button>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="反向查询modules" label-width="160px">
                    <el-input :disabled="disableflag" @keyup.enter.native="handleReversequery(reverseproperties,enviroment)" v-model="reverseproperties" size="mini" placeholder=请输入要要查询的domain></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button :disabled="(reverseproperties==null)||isQuery" type="primary" @click="handleReversequery(reverseproperties,enviroment)" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox">
            <el-button v-if="hasPermission()" :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handleModuleInsert">
                <i class="el-icon-edit">添加</i>
            </el-button>
            <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handledomainWindow">
                <i class="el-icon-edit">域名界面</i>
            </el-button>
            <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handleActDialod">
                <i class="el-icon-edit">模块实际拉取配置查询</i>
            </el-button>
            <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="openPropertiesChangeList">
                <i class="el-icon-edit">配置修改记录查询</i>
            </el-button>
        </div>
        <el-table 
        ref="singleTable" 
        :data="moduleList" 
        row-key 
        size="mini"
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
            <el-table-column type="index" width="60%" header-align="center" align="left"></el-table-column>
            <el-table-column property="moduleName" label="模块名称"  header-align="center"  align="left"  width="170%">
                <template slot-scope="scope">
                    <span class="link-type animated" @click="openModuleDomain(scope.row.moduleName,true)">{{scope.row.moduleName}}</span>
                </template>
            </el-table-column>
            <el-table-column property="domains" label="包含域名"  header-align="center"  align="left" >
                <template slot-scope="scope" style="alpha: 0%">
                    <span class="domainTag" v-if="scope.row.id&&domainItem!==''" v-for="domainItem in scope.row.domains.split(',')" :key="domainItem">
                        {{domainItem}}
                    </span>
                </template>
            </el-table-column>
            <el-table-column label="所属业务域"  header-align="center"  align="left" >
                <template slot-scope="scope" style="alpha: 0%" v-if="moduleBizListMap.get(scope.row.moduleName)!=undefined">
                    <span class="bizTag" v-if="scope.row.id&&domainItem.nicName!==''" v-for="domainItem in moduleBizListMap.get(scope.row.moduleName).bizList" :key="domainItem.id">
                        {{domainItem.nicName}}
                    </span>
                </template>
            </el-table-column>
            <el-table-column v-if="hasPermission()" fixd="right" label="操作"  header-align="center"  align="center" width="200%">
                <template slot-scope="scope">
                    <el-button :disabled="disableflag" v-show="scope.row.id" type="default" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="text"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="primary"
                                                        @click="handleModuleDelete(scope.row.moduleName)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
          <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="80%">
            </el-table-column>
            <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="140%">
            </el-table-column>
        </el-table>
    </el-card>
    </transition>


    <transition enter-active-class="fadeInLeft"
    leave-active-class="fadeOutRight">
    <el-card class="domain animated" v-show="isDomtable">
        <span class="title">域名界面</span>
 	    <el-form :inline="true" @submit.native.prevent>
				<el-form-item class="form-wrapper-item" label="包含域名称" label-width="90px">
				  	<el-input :disabled="disableflag"  @keyup.enter.native="inputDomainName==''?getDomainList():getDomainListFuzzy()" v-model="inputDomainName" size="mini"></el-input>
				</el-form-item>
				<el-form-item class="form-wrapper-item" label="" label-width="0">
				  	<el-button :disabled="disableflag&&isQuery" type="primary" @click="inputDomainName==''?getDomainList():getDomainListFuzzy()" size="mini">查询</el-button>
				</el-form-item>
	 	    <div class="table-toolbox">
	            <el-button v-if="hasPermission()" :disabled="disableflag" type="default" size="mini" class="tool-item" @click="isDomdalog=true">
	                <i class="el-icon-edit">添加</i>
	            </el-button>
                <el-button :disabled="disableflag" type="success" size="lage" class="tool-item" @click="handleDomTable">
                <i class="el-icon-back   ">返回</i>
                </el-button>
	        </div>
        </el-form>
 	    <el-table
		    ref="domTable"
		    :data="domainList"
		    highlight-current-row
		    style="width: 100%"
		    :border="true"
		    :stripe="true"
		    resizable>
		    <el-table-column type="index" width="30px"  header-align="center"  align="left"></el-table-column>
		    <el-table-column property="domain" label="域名"  header-align="center"  align="left"></el-table-column>
		    <!-- <el-table-column property="env" label="所属环境"  header-align="center"  align="left"></el-table-column> -->
		    <el-table-column property="remark" label="说明"  header-align="center"  align="left">
                <template slot-scope="scope" style="alpha: 0%">
                    <span v-show="scope.row.id">
    			 	    {{scope.row.remark}}
    			    </span>
                </template>
		    </el-table-column>
        <el-table-column property="type" label="类型"  header-align="center"  align="left"></el-table-column>
		    <el-table-column fixd="right" label="操作"  header-align="center"  align="center">
                <template slot-scope="scope">
                    <el-button v-if="hasPermission()" :disabled="disableflag" v-show="scope.row.id" type="default" size="mini" class="tool-item" @click="handleDomUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                            v-if="hasPermission()"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="text"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="primary"
                                                        @click="handleDomainsDelete(scope.row.domain, scope.row.env)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                    <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="openModuleDomain(scope.row.domain,false,scope.row.env)">
                        <i class="el-icon-edit">查询属性</i>
                    </el-button>
                    <!-- <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handleReversequery(scope.$index,domlist)">
                        <i class="el-icon-edit">反向查询</i>
                    </el-button> -->
                </template>
		    </el-table-column>
        <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="300px">
            </el-table-column>
	    </el-table>
    </el-card>
    </transition>


<transition enter-active-class="fadeInLeft"
    leave-active-class="fadeOutRight">
    <el-card class="domain animated" v-show="isModDomTable">
        <span class="title">{{moduleDomTitle}}</span>
                  <div class="envTable">
            <span v-if="workingENV === 'development'&&enviroment=='dev'" class="title">当前环境：dev1</span>
            <span v-if="workingENV === 'development'&&enviroment=='sit'" class="title">当前环境：dev2</span>
            <span v-if="workingENV != 'development'" class="title">当前环境：{{enviroment}}</span>
        </div>
 	    <el-form :inline="true">
	 	    <div class="table-toolbox">
                <el-button :disabled="disableflag" type="success" size="lage" class="tool-item" @click="handleModDomTable">
                <i class="el-icon-back   ">返回</i>
                </el-button>
	        </div>
        </el-form>  
 	    <el-table
		    ref="moduleDomainList"
		    :data="moduleDomainList"
		    highlight-current-row
		    style="width: 100%"
		    :border="true"
		    :stripe="true"
		    resizable>
		    <el-table-column type="index" width="30px"  header-align="center"  align="left"></el-table-column>
            <el-table-column type="expand" >
                <template slot-scope="props">
                    <el-table
		            ref="proTable"
                    class="propertiesTable"
		            :data="props.row.properties"
                    width=100%
                    :row-class-name="tableRowClassName"
		            :row-style="changeClass"
		            :border="true"
		            resizable>
		<el-table-column type="index" width="30px"  header-align="center"  align="left" ></el-table-column>
		<el-table-column property="key" label="属性名称"  header-align="center"  align="left" width="300px" ></el-table-column>
		<el-table-column property="dynamic" label="是否动态"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.dynamic}}</span>
            </template>
		</el-table-column>
		<el-table-column property="value" label="值"  header-align="center"  align="left" width="500px">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.value}}</span>
            </template>
		</el-table-column>
		<el-table-column property="configType" label="属性参数类型"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.configType}}</span>
            </template>
		</el-table-column>
		<el-table-column property="formatter" label="格式"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.formatter}}</span>
            </template>
		</el-table-column>
		<el-table-column property="validFlag" label="是否可用"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.validFlag}}</span>
            </template>
		</el-table-column>
		<el-table-column property="remark" label="说明"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.remark}}</span>
        </template>
		</el-table-column>
    
		<el-table-column fixd="right" label="操作"  header-align="center"  align="center" v-if="hasPermission()">
            <template slot-scope="scope">
                <el-button :disabled="disableflag" v-show="scope.row.id" type="default" size="mini" class="tool-item" @click="handleProUpdate(scope.row,props.row.domain,props.row.env)">
                    <i class="el-icon-edit">修改</i> 
                </el-button>
                <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="text"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="primary"
                                                        @click="handlePropertiesDelete(props.row.domain,props.row.env,scope.row.key)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
            </template>
		</el-table-column>
    <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="300px">
            </el-table-column>
        </el-table>
	            </template>
            </el-table-column>
		    <el-table-column property="domain" label="域名"  header-align="center"  align="left"></el-table-column>
		    <!-- <el-table-column property="env" label="所属环境"  header-align="center"  align="left"></el-table-column> -->
		    <el-table-column property="remark" label="说明"  header-align="center"  align="left">
                <template slot-scope="scope" style="alpha: 0%">
                    <span v-show="scope.row.id">
    			 	    {{scope.row.remark}}
    			    </span>
                </template>
		    </el-table-column>
        <el-table-column property="type" label="类型"  header-align="center"  align="left"></el-table-column>
		    <el-table-column fixd="right" label="操作"  header-align="center"  align="center">
                <template slot-scope="scope">
                    <el-button v-if="hasPermission()" :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handlePropertiesAdd(scope.row.domain,scope.row.env)">
	                <i class="el-icon-edit">添加属性</i>
	                </el-button>
                    <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handleReversequery(scope.row.domain,scope.row.env)">
                        <i class="el-icon-edit">反向查询</i>
                    </el-button>
                </template>
		    </el-table-column>
         <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="300px">
            </el-table-column>
	    </el-table>
    </el-card>
    </transition>
</el-card>


    <el-dialog
        title="模块实际配置查询"
        :visible.sync="actDialogFlag"
        width="100%"  >
    <el-form :inline="true" @submit.native.prevent>
				<el-form-item class="form-wrapper-item"  label="查询模块名称" label-width="100px">
				   <el-input :disabled="disableflag" @keyup.enter.native="ActualModuleConfig" v-model="actNoduleName" size="mini"></el-input>
				</el-form-item>
				<el-form-item class="form-wrapper-item" label="" label-width="0">
				  	<el-button type="primary"  @click="ActualModuleConfig">查询</el-button>
				</el-form-item>      
        </el-form>
        <div class="envTable">
            <span class="title">当前环境：{{envShow}}</span>
        </div>
        <el-card style="width:100%;">
          <jsonViewer
          :json="actPropertiesList"
         >
          </jsonViewer>
          <!-- <instance-item
          :model="actPropertiesList">
          </instance-item> -->
        </el-card>
    </el-dialog>
<el-dialog
        title="配置修改记录"
        :visible.sync="properCheck.dialogFlag"
        width="100%"
        
    >
    <el-form :inline="true" @submit.native.prevent>
				<el-form-item class="form-wrapper-item"  label="查询模块名称" label-width="100px">
				   <el-input v-loading.body="listLoading" @keyup.enter.native="propertiesChangeCheck" v-model="properCheck.moduleName" size="mini"></el-input>
				</el-form-item>
        <el-form-item class="form-wrapper-item form-item-query normal-width" label="开始时间" label-width="120px" prop="startTime">
          <el-date-picker v-model="properCheck.startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
        </el-form-item>
        <el-form-item class="form-wrapper-item form-item-query normal-width" label="结束时间" label-width="100px" prop="endTime">
        <el-date-picker v-model="properCheck.endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
        </el-form-item>
				<el-form-item class="form-wrapper-item" label="" label-width="0">
				  	<el-button v-loading.body="listLoading" type="primary"  @click="propertiesChangeCheck">查询</el-button>
				</el-form-item>
                
        </el-form>
        <div class="envTable">
            <span class="title">当前环境：{{envShow}}</span>
        </div>
        <span>模块-域名修改记录</span>
        <el-table 
        ref="singleTable" 
        :data="properCheck.data.moduleChanges" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
        <el-table-column
        prop="moduleName"
        label="模块名称"></el-table-column>
         <el-table-column
        prop="domains"
        label=" 域名"></el-table-column>
         <el-table-column
        prop="operator"
        label="修改人"></el-table-column>
         <el-table-column
        prop="updated"
        label="更新时间"></el-table-column>
        </el-table>
         <span>域名-属性修改记录(下拉显示详情)</span>
        <el-table 
        ref="singleTable" 
        :data="properCheck.data.propertiesChanges" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>

        <el-table-column
        type="expand" 
        >
        <template slot-scope="scope">
          <el-table 
          ref="singleTable" 
        :data="scope.row.propertiesList" 
        row-key 
        
        :border="true" 
        :stripe="true" >
        <el-table-column property="name" label="属性名称"  header-align="center"  align="left" width="300px" ></el-table-column>
		<el-table-column property="dynamic" label="是否动态"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.dynamic}}</span>
            </template>
		</el-table-column>
		<el-table-column property="configVal" label="值"  header-align="center"  align="left" width="500px">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.configVal}}</span>
            </template>
		</el-table-column>
		<el-table-column property="configType" label="属性参数类型"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.configType}}</span>
            </template>
		</el-table-column>
		<el-table-column property="formatter" label="格式"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.formatter}}</span>
            </template>
		</el-table-column>
		<el-table-column property="validFlag" label="是否可用"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.validFlag}}</span>
            </template>
		</el-table-column>
		<el-table-column property="remark" label="说明"  header-align="center"  align="left">
            <template slot-scope="scope" style="alpha: 0%">
                <span v-show="scope.row.id">{{scope.row.remark}}</span>
        </template>
		</el-table-column>
     <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="300px">
            </el-table-column>
        </el-table>
        </template>
        </el-table-column>
                        <el-table-column
                        label="域名"
        prop="domainName"></el-table-column>
        </el-table>
        </el-dialog>
        <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
        >
        <el-form
            :inline="true"
            :model="ModuleForm"
            ref="ModuleForm"
        >
            <el-form-item
                v-if="!isUdate"
                prop="moduleName"
                label="模块名称"
                :rules="{required: true, message: '请输入模块名称'}"
                style="width:200px"
            >
                <el-input v-model="ModuleForm.moduleName"></el-input>
                </el-form-item>
                <el-form-item
                v-if="!isUdate"
                prop="grpcServicePort"
                label="grpc服务端口(没有请填null)"
                :rules="{required: true, message: '请输入grpcServicePort'}"
                style="width:200px"
            >
                <el-input v-model="ModuleForm.grpcServicePort"></el-input>
                </el-form-item>
                <el-form-item
                v-if="!isUdate"
                prop="managementAgentPort"
                label="监控端口(没有请填null)"
                :rules="{required: true, message: '请输入managementAgentPort'}"
                style="width:200px"
            >
                <el-input v-model="ModuleForm.managementAgentPort"></el-input>
                </el-form-item>
                <el-form-item label="包含域名(蓝：数据库，黑：公有，绿：中间件，红：其他)">
                    <el-checkbox-group
                      v-model="ModuleForm.domains">
                                <div 
                                style="padding:10px;">
                                <hr/>
                                <el-tag style="width:100%;">私有域</el-tag>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.name'
                                        v-for='item in domainTable'
                                        :label="item.name"
                                        v-if="item.type=='private'&&checkDomainInlist(item.name)==true"
                                        :disabled="item.type=='private'"
                                        :style="item.type=='DB'?'color:blue;':item.type=='public'?'color:black;':item.type=='middleKey'?'color:green;':item.type=='others'?'color:red;':'color:grey'"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                <div 
                                style="padding:10px;">
                                  <hr/>
                                  <el-tag style="width:100%;">数据库域</el-tag>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.name'
                                        v-for='item in domainTable'
                                        :label="item.name"
                                        v-if="item.type=='DB'"
                                        :disabled="item.type=='private'"
                                        :style="item.type=='DB'?'color:blue;':item.type=='public'?'color:black;':item.type=='middleKey'?'color:green;':item.type=='others'?'color:red;':'color:grey'"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                <div
                                
                                style="padding:10px;">
                                  <hr/>
                                  <el-tag style="width:100%;">公有域</el-tag>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.name'
                                        v-for='item in domainTable'
                                        :label="item.name"
                                        v-if="item.type=='public'"
                                        :disabled="item.type=='private'"
                                        :style="item.type=='DB'?'color:blue;':item.type=='public'?'color:black;':item.type=='middleKey'?'color:green;':item.type=='others'?'color:red;':'color:grey'"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                <div 
                                style="padding:10px;">
                                  <hr/>
                                  <el-tag style="width:100%;">中间件</el-tag>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.name'
                                        v-for='item in domainTable'
                                        :label="item.name"
                                        v-if="item.type=='middleKey'"
                                        :disabled="item.type=='private'"
                                        :style="item.type=='DB'?'color:blue;':item.type=='public'?'color:black;':item.type=='middleKey'?'color:green;':item.type=='others'?'color:red;':'color:grey'"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                <div 
                                style="padding:10px;">
                                <hr/>
                                <el-tag style="width:100%;">其他</el-tag>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.name'
                                        v-for='item in domainTable'
                                        :label="item.name"
                                        v-if="item.type=='others'"
                                        :disabled="item.type=='private'"
                                        :style="item.type=='DB'?'color:blue;':item.type=='public'?'color:black;':item.type=='middleKey'?'color:green;':item.type=='others'?'color:red;':'color:grey'"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                <div 
                                style="padding:10px;">
                                <hr/>
                                <el-tag style="width:100%;">未区分</el-tag>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.name'
                                        v-for='item in domainTable'
                                        :label="item.name"
                                        v-if="item.type==null||item.type==undefined"
                                        :disabled="item.type=='private'"
                                        :style="item.type=='DB'?'color:blue;':item.type=='public'?'color:black;':item.type=='middleKey'?'color:green;':item.type=='others'?'color:red;':'color:grey'"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                    </el-form-item>
                    <el-form-item label="所属业务域"
                    prop="bizList"
                    :rules="{required: true, message: '请选择所属业务域，若没有符合项，请去业务域关联管理页面先创建相关业务域。'}">
                <el-checkbox-group
                      v-model="currentbizList">
                                
                                <hr/>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.bizName'
                                        v-for='item in bizModuleList'
                                        :label="item.nicName"
                                        :border="true"
                                        size="mini"
                                    >{{item.nicName}}</el-checkbox>
                                </el-checkbox-group>
                    </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('ModuleForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
<el-dialog
        :title="domDialogTitle"
        :visible.sync="isDomdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="DomainForm"
            ref="DomainForm"
        >
            <el-form-item
                prop="domain"
                label="域名名称"
                :rules="{required: true, message: '请输入域名名称'}"
                style="width:200px"
            >
                <el-input v-model="DomainForm.domain"></el-input>
                </el-form-item>
                <el-form-item
                prop="remark"
                :rules="{required: true, message: '请输入域名说明'}"
                label="说明"
                style="width:200px"
            >
                <el-input v-model="DomainForm.remark"></el-input>
                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleDom('DomainForm')">确定</el-button>
      </span>
                                                                        </el-dialog>

<el-dialog
        title="冲突报告"
        :visible.sync="conflictDialog"
    >
        <el-form
            :inline="true"
            :model="DomainForm"
            ref="DomainForm"
        >
            <el-form-item
                :label="keys"
                v-for="(item,keys) in conflictData"
                :key="keys"
            >
                <el-tag v-for="items in item" :key="items">{{items}}</el-tag>
                </el-form-item>
        </el-form>
</el-dialog>

<el-dialog
        :title="proDialogTitle"
        :visible.sync="isProdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="PropertiesForm"
            ref="PropertiesForm"
        >
            <el-form-item
                prop="key"
                label="属性名称"
                :rules="{required: true, message: '请输入属性名称'}"
                style="width:200px"
            >
                <el-input v-model="PropertiesForm.key"></el-input>
                </el-form-item>
                <el-form-item
                prop="configType"
                label="属性类型"
                :rules="{required: true, message: '请输入属性类型'}"
                style="width:200px"
            >
            <el-select v-model="PropertiesForm.configType">
                                                            <el-option
                                                                v-for="item in propertiesTypeTable"
                                                                :key="item"
                                                                :label="item"
                                                                :value="item"
                                                            >
                                                                </el-option>
                                                        </el-select>
                </el-form-item>
                <el-form-item
                prop="value"
                label="属性值"
                :rules="{required: true, message: '请输入属性值'}"
                style="width:200px"
            >
                <el-input  type="textarea" autosize v-model="PropertiesForm.value"></el-input>
                </el-form-item>
                <el-form-item
                prop="formatter"
                label="格式化"
                style="width:200px"
            >
                <el-input v-model="PropertiesForm.formatter"></el-input>
                </el-form-item>
                <el-form-item
                prop="remark"
                label="说明"
            >
                <el-input v-model="PropertiesForm.remark"></el-input>
                </el-form-item>
                <el-form-item
                prop="validFlag"
                label="是否可用"
            >
                 <el-switch v-model="PropertiesForm.validFlag"></el-switch>
                </el-form-item>
                <el-form-item
                prop="dynamic"
                label="是否动态"
            >
                 <el-switch v-model="PropertiesForm.dynamic"></el-switch>
                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handlePro('PropertiesForm')">确定</el-button>
      </span>
                                                                        </el-dialog>


    </div>
</template>
<script>
let enviroment = ''
import { ModulesDialog,
  getModuleBizList,
  deleteModuleBizRelationForBizList,
  insertModuleBizRelationByBizList,
  getBizModuleList,
  ModulesInsert,
  ModulesUpdate,
  ModulesDelete,
  DomainsDialog,
  DomainsInsert,
  DomainsUpdate,
  DomainsDelete,
  envDialog,
  DomainsDialogEnv,
  DomainsDialogModule,
  PropertiesDialog,
  PropertiesInsert,
  PropertiesUpdate,
  PropertiesDelete,
  actualModuleConfig,
  PropertyChangeQuery } from '@/api/config'
import {
  Message
} from 'element-ui'
import { dateTimeFormat } from '@/store/date'
import instanceItem from './JSONInfoBox'
import { mapGetters } from 'vuex'
import jsonViewer from '@/components/JsonView'
import Axios from 'axios'
export default {
  name: 'configCenter',
  components: {
    instanceItem,
    jsonViewer
  },
  data() {
    return {
      enviroment: '',
      isDomtable: false,
      isModuletable: true,
      isModDomTable: false,
      moduleList: null,
      moduleDomainList: null,
      moduleDomTitle: '',
      isQuery: false,
      envlist: [],
      inputModuleName: '',
      inputDomainName: '',
      disableflag: false,
      domainList: null,
      isUdate: false,
      isDomUdate: false,
      isProUdate: false,
      isDomdalog: false,
      isProdalog: false,
      isdalog: false,
      conflictDialog: false,
      conflictData: {},
      TemModuleUpdateMarker: [],
      ModuleForm: {
        moduleName: '',
        grpcServicePort: '',
        managementAgentPort: '',
        domains: [],
        bizList: []
      },
      DomainForm: {
        domain: '',
        env: enviroment,
        remark: '',
        id: ''
      },
      PropertiesForm: {
        key: '',
        configType: '',
        value: '',
        formatter: '',
        remark: '',
        validFlag: true,
        dynamic: false
      },
      tmpForm: {
        domainName: '',
        env: ''
      },
      workingENV: process.env.NODE_ENV,
      domainTable: [],
      dialogTitle: '模块添加',
      domDialogTitle: '域名添加',
      proDialogTitle: '属性添加',
      listLoading: false,
      envShow: '',
      reverseproperties: null,
      propertiesTypeTable: ['Object', 'String', 'Boolean', 'Double', 'BigDecimal', 'Float', 'Long', 'Integer', 'Date', 'Timestamp', 'JsonArray', 'JsonObject'],
      actNoduleName: '',
      actPropertiesList: [],
      actDialogFlag: false,
      properCheck: {
        dialogFlag: false,
        moduleName: '',
        startTime: '',
        endTime: '',
        data: {}
      },
      currentbizList: [],
      bizModuleList: [],
      moduleBizListMap: new Map(),
      bizModuleListMap: new Map(),
      moduleBizListMark: []
    }
  },
  created() {
    this.initStartTime()
    this.initEndTime()
    this.envList()
    this.fetchBizList()
    // this.fetchModuleBizList()
  },
  activated() {
    this.fetchModuleBizList()
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  watch: {
    currentbizList(val) {
      this.ModuleForm.bizList = val
    },
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '模块修改'
      else {
        this.dialogTitle = '模块添加'
        this.ModuleForm.moduleName = ''
        this.ModuleForm.domains = []
      }
    },
    isDomUdate() {
      if (this.isDomUdate) this.domDialogTitle = '域名修改'
      else {
        this.domDialogTitle = '域名添加'
        this.DomainForm.domain = ''
        this.DomainForm.remark = ''
        this.DomainForm.id = ''
      }
    },
    isProUdate() {
      if (this.isProUdate) this.proDialogTitle = '属性修改'
      else {
        this.proDialogTitle = '属性添加'
        this.PropertiesForm.key = ''
        this.PropertiesForm.configType = ''
        this.PropertiesForm.value = ''
        this.PropertiesForm.formatter = ''
        this.PropertiesForm.remark = ''
        this.PropertiesForm.validFlag = true
        this.PropertiesForm.dynamic = false
      }
    },
    enviroment() {
      this.DomainForm.env = enviroment
      this.enviroment = enviroment
    }
    // $route() {
    //   if (this.$route.params.parserId !== undefined && this.$route.params.parserId !== ':parserId') {
    //     this.ModuleForm.parserId = this.$route.params.parserId
    //   } else {
    //     this.ModuleForm.parserId = ''
    //   }
    //   this.fetchData()
    //   // this.closeContainer()
    // }
  },
  methods: {
    fetchModuleBizList() {
      this.listLoading = true
      getModuleBizList('', '').then(response => {
        this.listLoading = false
        console.log('getModuleBizList', response)
        if (response.code === 0) {
          this.moduleBizListMap = new Map()
          for (const i of response.data.moduleBizList) {
            this.moduleBizListMap.set(i.moduleName, i)
          }
          console.log('moduleBizListMap', this.moduleBizListMap)
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch(e => {
        Message.error(e)
        this.listLoading = false
      })
    },
    fetchBizList() {
      this.listLoading = true
      getBizModuleList('', '').then(response => {
        this.listLoading = false
        console.log('getBizList', response)
        if (response.code === 0) {
          this.bizModuleList = response.data.bizModuleList
          this.bizModuleListMap = new Map()
          for (const i of response.data.bizModuleList) {
            this.bizModuleListMap.set(i.nicName, i)
          }
          console.log('bizModuleList', response.data.bizModuleList)
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch(e => {
        Message.error(e)
        this.listLoading = false
      })
    },
    handleModuleInsert() {
      this.ModuleForm = {
        moduleName: '',
        domains: [],
        bizList: []
      }
      this.currentbizList = []
      this.getDomainList()
      this.fetchBizList()
      this.isdalog = true
    },
    checkDomainInlist(val) {
      const flag = false
      for (const i of this.ModuleForm.domains) {
        if (i === val) {
          // console.log('compare:', i, val, i === val)
          return (i === val)
        }
      }
      return flag
    },
    openPropertiesChangeList() {
      this.properCheck.data = {}
      this.properCheck.dialogFlag = true
    },
    formatStartTime(val) {
      this.properCheck.startTime = dateTimeFormat(val)
    },
    formatEndTime(val) {
      this.properCheck.endTime = dateTimeFormat(val)
    },
    initStartTime() {
      var nowTime = new Date()
      nowTime.setTime(Date.now() - 7 * 24 * 60 * 60 * 1000)
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.properCheck.startTime = dateTimeFormat(nowTime)
    },
    initEndTime() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.properCheck.endTime = dateTimeFormat(nowTime)
    },
    propertiesChangeCheck() {
      this.listLoading = true
      PropertyChangeQuery(this.properCheck.moduleName, this.enviroment, this.properCheck.startTime, this.properCheck.endTime).then(response => {
        this.listLoading = false
        console.log('properCheck:', response)
        if (JSON.stringify(response.payload) !== '{}') {
          this.properCheck.data = response.payload
        } else {
          Message.error('未查询到任何数据')
        }
      })
    },
    changeClass({ row, rowIndex }) {
    //   console.log('backgroud!!!!!!!!!!!', row.errorCode !== 0)
      if (!row.validFlag) return 'background: darkgray;'
      else return 'background: floralwhite;'
    },
    handleActDialod() {
      this.actDialogFlag = true
      this.actNoduleName = ''
      this.actPropertiesList = []
    },
    ActualModuleConfig() {
      actualModuleConfig(this.actNoduleName, this.enviroment).then(response => {
        console.log('response:', response)
        if (JSON.stringify(response) !== '{}') {
          this.actPropertiesList = response
        } else {
          Message.error('未查询到任何数据')
        }
      })
    },
    hasPermission() {
      const ROLES = ['admin', 'configCenterButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    changeEnv() {
      enviroment = this.enviroment
      if (process.env.NODE_ENV === 'development') {
        if (this.enviroment === 'dev') {
          this.envShow = 'dev1'
        }
        if (this.enviroment === 'sit') {
          this.envShow = 'dev2'
        }
      } else {
        this.envShow = this.enviroment
      }
      this.getList()
    },
    envList() {
      envDialog().then(function(response) {
        if (JSON.stringify(response.payload) !== '{}') {
          if (process.env.NODE_ENV === 'development') {
            for (const i of response.payload.env) {
              if (i.env === 'dev') {
                this.envShow = 'dev1'
                i.remark = 'dev1'
              }
              if (i.env === 'sit') {
                this.envShow = 'dev2'
                i.remark = 'dev2'
              }
            }
          } else {
            for (const i of response.payload.env) {
              this.envShow = i.env
              i.remark = i.env
            }
          }
          this.envlist = response.payload.env
        }
        if (this.envlist.length > 1)enviroment = this.envlist[1].env
        else enviroment = this.envlist[0].env
        if (process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'productiongq' || process.env.NODE_ENV === 'productionxy') {
          enviroment = this.envlist[0].env
          this.envShow = this.envlist[0].env
        }
        console.log('env', enviroment)
        this.enviroment = enviroment
        this.getList()
      }.bind(this))
    },
    handleReversequery(domName, env) {
      console.log('pushto:', '/reverseQuery/reverseQuery/' + env + '/' + domName)
      this.$router.push({ path: '/reverseQuery/reverseQuery/' + env + '/' + domName })
    },
    handledomainWindow() {
      console.log('pushto:', '/configCenter/' + this.enviroment + '/domainWindow_' + this.enviroment)
      if (process.env.NODE_ENV === 'development') {
        if (this.enviroment === 'dev') this.$router.push({ path: '/configCenter/' + this.enviroment + '/domainWindow_dev1' })
        if (this.enviroment === 'sit') this.$router.push({ path: '/configCenter/' + this.enviroment + '/domainWindow_dev2' })
      } else {
        this.$router.push({ path: '/configCenter/' + this.enviroment + '/domainWindow_' + this.enviroment })
      }
    },
    handlePropertiesAdd(domainName, env) {
      this.tmpForm.domainName = domainName
      this.tmpForm.env = env
      console.log('tmpForm:', this.tmpForm)
      this.isProdalog = true
    },
    openModuleDomain(moduleName, flag, env) {
      var that = this
      if (!that.isQuery && flag) {
        that.isQuery = true
        this.moduleDomTitle = moduleName + '域名详情'
        DomainsDialogModule(moduleName, that.enviroment).then(response => {
          that.isQuery = false
          console.log('response:', response)
          if (JSON.stringify(response.payload) !== '{}') {
            that.moduleDomainList = response.payload.domain
            const requestGroup = []
            for (const i of that.moduleDomainList) {
              requestGroup.push(
                PropertiesDialog(i.domain, i.env).then(responseS => {
                  if (JSON.stringify(responseS.payload) !== '{}') {
                    i['properties'] = responseS.payload.properties.map(v => {
                      that.$set(v, 'deleteFlag', false)
                      return v
                    })
                  }
                //   that.moduleDomainList.push(i)
                })
              )
            }
            Axios.all(requestGroup).then(function() {
              this.isModuletable = false
              setTimeout(function() {
                this.isModDomTable = true
              }.bind(this), 510)
            }.bind(this))
          } else {
            Message.error('未查询到任何数据')
          }
        })
      }
      if (!that.isQuery && !flag) {
        that.isQuery = true
        this.moduleDomTitle = moduleName + '详情'
        const tmpObj = {
          domain: moduleName,
          env: env
        }
        that.moduleDomainList = [tmpObj]
        PropertiesDialog(moduleName, env).then(responseS => {
          that.isQuery = false
          console.log('response:', responseS)
          if (JSON.stringify(responseS.payload) !== '{}') {
            tmpObj['properties'] = responseS.payload.properties.map(v => {
              that.$set(v, 'deleteFlag', false)
              return v
            })
          }
          this.isDomtable = false
          setTimeout(function() {
            this.isModDomTable = true
          }.bind(this), 510)
          //   that.moduleDomainList.push(i)
        })
      }
    },
    handlePro(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.listLoading = true
              console.log('form:', this.tmpForm.env, this.PropertiesForm)
              if (this.isProUdate) {
                PropertiesUpdate(this.tmpForm.domainName.trim(), this.tmpForm.env, this.PropertiesForm, this.name).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  if (responseS.messageFlag) {
                    this.isProUdate = false
                    Message.success('修改属性成功！')
                    if (this.moduleDomTitle.split('域名详情')[0] === this.moduleDomTitle) {
                      this.openModuleDomain(this.moduleDomTitle.split('详情')[0], false, this.tmpForm.env)
                    } else {
                      this.openModuleDomain(this.moduleDomTitle.split('域名详情')[0], true)
                    }
                    this.$refs['PropertiesForm'].resetFields()
                    this.isProdalog = false
                  } else {
                    Message.error(responseS.errorCode + ':' + responseS.messageInfo)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              } else {
                PropertiesInsert(this.tmpForm.domainName.trim(), this.tmpForm.env, this.PropertiesForm, this.name).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  this.isProUdate = false
                  if (responseS.messageFlag) {
                    Message.success('添加属性成功！')
                    if (this.moduleDomTitle.split('域名详情')[0] === this.moduleDomTitle) {
                      this.openModuleDomain(this.moduleDomTitle.split('详情')[0], false, this.tmpForm.env)
                    } else {
                      this.openModuleDomain(this.moduleDomTitle.split('域名详情')[0], true)
                    }
                    this.$refs['PropertiesForm'].resetFields()
                    this.isProdalog = false
                  } else {
                    Message.error(responseS.errorCode + ':' + responseS.messageInfo)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleDom(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.listLoading = true
              if (this.isDomUdate) {
                DomainsUpdate(this.DomainForm.domain.trim(), this.DomainForm.env, this.DomainForm.remark.trim(), this.name, this.DomainForm.id).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  if (responseS.messageFlag) {
                    this.isDomUdate = false
                    Message.success('修改域名成功！')
                    this.inputDomainName = this.DomainForm.domain.trim()
                    this.getDomainListFuzzy()
                    this.getDomainList()
                    this.$refs['DomainForm'].resetFields()
                    this.isDomdalog = false
                  } else {
                    Message.error(responseS.errorCode + ':' + responseS.messageInfo)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              } else {
                DomainsInsert(this.DomainForm.domain.trim(), this.DomainForm.env, this.DomainForm.remark.trim(), this.name).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  this.isDomUdate = false
                  if (responseS.messageFlag) {
                    Message.success('添加域名成功！')
                    this.inputDomainName = this.DomainForm.domain.trim()
                    this.getDomainListFuzzy()
                    this.getDomainList()
                    this.$refs['DomainForm'].resetFields()
                    this.isDomdalog = false
                  } else {
                    Message.error(responseS.errorCode + ':' + responseS.messageInfo)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleModuleTable() {
      this.isModuletable = false
      setTimeout(function() {
        this.isDomtable = true
      }.bind(this), 510)
    },
    handleDomTable() {
      this.isDomtable = false
      this.isModDomTable = false
      setTimeout(function() {
        this.isModuletable = true
      }.bind(this), 510)
    },
    handleModDomTable() {
      this.isModDomTable = false
      if (this.moduleDomTitle.split('域名')[1] == null) {
        setTimeout(function() {
          this.isDomtable = true
        }.bind(this), 510)
      } else {
        setTimeout(function() {
          this.isModuletable = true
        }.bind(this), 510)
      }
    },
    getList: function() {
      var that = this

      if (!that.isQuery) {
        that.isQuery = true

        that.moduleList = []

        ModulesDialog(that.inputModuleName.trim()).then(function(response) {
          that.isQuery = false
          console.log('response:', response)
          if (JSON.stringify(response.payload) !== '{}') {
            that.moduleList = response.payload.module.map(v => {
              that.$set(v, 'deleteFlag', false)
              return v
            })
          }
          that.getDomainList()
          that.fetchModuleBizList()
        })
      }
    },
    getDomainList: function() {
      var that = this
      that.domainTable = []
      if (!that.isQuery) {
        that.isQuery = true

        that.domainList = []

        DomainsDialog('').then(function(response) {
          that.isQuery = false
          console.log('response:', response)
          if (JSON.stringify(response.payload) !== '{}') {
            that.domainList = response.payload[that.enviroment].map(v => {
              that.$set(v, 'deleteFlag', false)
              return v
            })
            const tableSet = new Map()
            for (const i of response.payload[that.enviroment]) {
              tableSet.set(i.domain, { name: i.domain, type: i.type })
            }
            for (const i in response.payload) {
              for (const j of response.payload[i]) {
                if (j.type === 'private' && !tableSet.has(j.domain)) {
                  // console.log('private', j)
                  tableSet.set(j.domain, { name: j.domain, type: j.type })
                }
              }
            }
            tableSet.forEach(p => {
              that.domainTable.push(p)
            })
            // console.log('domainTable',that.domainTable)
            // for (const i in tableSet) {
            //   console.log('tableSet', i)
            // }
            // that.domainTable = tableSet
          }
        })
      }
    },
    getDomainListFuzzy: function() {
      var that = this
      if (!that.isQuery) {
        that.isQuery = true

        that.domainList = []

        DomainsDialogEnv(that.inputDomainName.trim(), 'fuzzy', that.enviroment).then(function(response) {
          that.isQuery = false
          console.log('response:', response)
          if (JSON.stringify(response.payload) !== '{}') {
            that.domainList = response.payload.domain.map(v => {
              that.$set(v, 'deleteFlag', false)
              return v
            })
          }
        })
      }
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.isProUdate = false
          this.isDomUdate = false
          this.isDomdalog = false
          this.isProdalog = false
          this.$refs['ModuleForm'].resetFields()
          this.$refs['DomainForm'].resetFields()
          this.$refs['PropertiesForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.listLoading = true
              if (this.isUdate) {
                let tmpDomains = ''
                console.log('arrayss:', this.ModuleForm.domains)
                if (this.ModuleForm.domains.length > 0) {
                  tmpDomains = this.ModuleForm.domains.sort().join(',')
                } else {
                  tmpDomains = this.ModuleForm.moduleName.replace(/^\s*$/, '')
                }
                console.log('array:', tmpDomains)
                return new Promise((resolve, reject) => {
                  ModulesUpdate(this.ModuleForm.moduleName.trim(), tmpDomains, enviroment, this.name).then(response => {
                    console.log(response)
                    this.listLoading = false
                    if (response.messageFlag) {
                      const requestGroup = []
                      let step2 = false
                      let step3 = false
                      const insertModuleList = []
                      const deleteIdList = []
                      // console.log('currentbizList',this.currentbizList,this.moduleBizListMark)
                      for (const i of this.currentbizList) {
                        let checkFlag = true
                        for (const j of this.moduleBizListMark) {
                          if (i === j) {
                            checkFlag = false
                            break
                          }
                        }
                        if (checkFlag) {
                          insertModuleList.push(this.bizModuleListMap.get(i))
                        }
                      }
                      for (const i of this.moduleBizListMark) {
                        let checkFlag = true
                        for (const j of this.currentbizList) {
                          if (i === j) {
                            checkFlag = false
                            break
                          }
                        }
                        if (checkFlag) {
                          deleteIdList.push(this.bizModuleListMap.get(i).id)
                        }
                      }
                      if (insertModuleList.length !== 0) {
                        requestGroup.push(
                          insertModuleBizRelationByBizList(this.ModuleForm.id, this.ModuleForm.moduleName.trim(), insertModuleList, this.name).then(response => {
                            this.listLoading = false
                            console.log('insertModuleBizRelationByBizList', response)
                            if (response.errorCode === 'NO_ERR') {
                              step2 = true
                              //   console.log('bizModuleList', response.data.bizModuleList)
                            }
                          }).catch(e => {
                            this.listLoading = false
                          })
                        )
                      } else {
                        step2 = true
                      }
                      if (deleteIdList.length !== 0) {
                        requestGroup.push(
                          deleteModuleBizRelationForBizList(this.ModuleForm.id, deleteIdList).then(response => {
                            this.listLoading = false
                            console.log('deleteModuleBizRelation', response)
                            if (response.errorCode === 'NO_ERR') {
                              step3 = true
                              //   console.log('bizModuleList', response.data.bizModuleList)
                            }
                          }).catch(e => {
                            this.listLoading = false
                          })
                        )
                      } else {
                        step3 = true
                      }
                      Axios.all(requestGroup).then(function() {
                        this.listLoading = false
                        if (step2 & step3) {
                          Message.success('修改成功')
                          this.isUdate = false
                          this.inputModuleName = this.ModuleForm.moduleName.trim()
                          this.getList()
                          this.$refs['ModuleForm'].resetFields()
                          resolve(response)
                          this.isdalog = false
                        } else if (!step2 & !step3) {
                          Message.success('修改失败')
                        } else {
                          Message.success('修改部分成功')
                          this.isUdate = false
                          this.inputModuleName = this.ModuleForm.moduleName.trim()
                          this.getList()
                          this.$refs['ModuleForm'].resetFields()
                          resolve(response)
                          this.isdalog = false
                        }
                      }.bind(this))
                    } else {
                      if (response.errorCode === 'ERR60012') {
                        this.conflictDialog = true
                        this.conflictData = response.messageData
                      }
                      Message.error(response.errorCode + ':' + response.messageInfo)
                    }
                  }).catch((error) => {
                    reject(error)
                  })
                })
              } else {
                let tmpDomains = ''
                if (this.ModuleForm.domains.length > 0) {
                  tmpDomains = this.ModuleForm.domains.sort().join(',')
                  tmpDomains = tmpDomains + ',' + this.ModuleForm.moduleName.replace(/^\s*$/, '')
                } else {
                  tmpDomains = this.ModuleForm.moduleName.replace(/^\s*$/, '')
                }
                // let errorFlag = false
                // const remark_info = this.ModuleForm.moduleName.trim().replace(/^\s*$/, '') + '模块独有域名'
                ModulesInsert(this.ModuleForm.moduleName.trim(), tmpDomains, this.ModuleForm.grpcServicePort, this.ModuleForm.managementAgentPort, enviroment, this.name).then(responseSS => {
                  this.isQuery = false
                  this.listLoading = false
                  console.log(responseSS)
                  if (responseSS.messageFlag) {
                    Message.success('添加模块成功')
                    const tmpList = []
                    for (const i of this.currentbizList) {
                      tmpList.push(this.bizModuleListMap.get(i))
                    }
                    insertModuleBizRelationByBizList(responseSS.messageData.id, this.ModuleForm.moduleName.trim(), tmpList, this.name).then(response => {
                      this.loadingFlag = false
                      console.log('insertBizInformationTable', response)
                      if (response.errorCode === 'NO_ERR') {
                        //   console.log('bizModuleList', response.data.bizModuleList)
                        Message.success('添加业务域关联成功')
                        this.inputModuleName = this.ModuleForm.moduleName.trim()
                        this.getList()
                        this.$refs['ModuleForm'].resetFields()
                        this.isdalog = false
                      } else {
                        Message.error(response.errorCode + ':' + response.messageInfo)
                      }
                    }).catch(e => {
                      Message.error(e)
                      this.loadingFlag = false
                    })
                  } else {
                    if (responseSS.errorCode === 'ERR60012') {
                      this.conflictDialog = true
                      this.conflictData = responseSS.messageData
                    }
                    Message.error(responseSS.errorCode + ':' + responseSS.messageInfo)
                  }
                }).catch(() => {
                  this.listLoading = false
                })
                // envDialog().then(function(response) {
                //   let enviromentList = ''
                //   if (JSON.stringify(response.payload) !== '{}') {
                //     enviromentList = response.payload.env
                //   }
                //   console.log('json:', enviromentList)
                //   const requestGroup = []
                //   for (const i in enviromentList) {
                //     requestGroup.push(DomainsDialogEnv(this.ModuleForm.moduleName.trim().replace(/^\s*$/, ''), 'accurate', enviromentList[i].env).then(function(responses) {
                //       if (JSON.stringify(responses.payload) === '{}') {
                //         console.log(enviromentList[i].env)
                //         DomainsInsert(this.ModuleForm.moduleName.trim().replace(/^\s*$/, ''), enviromentList[i].env, remark_info, this.name).then(function(responseSSS) {
                //           this.isQuery = false
                //           if (responseSSS.messageFlag) {
                //             Message.success('添加模块独有域名成功！')
                //           } else {
                //             errorFlag = true
                //             Message.error(responseSSS.errorCode + ':' + responseSSS.messageInfo)
                //             // this.$message.error(responseSSS.errorCode || responseSSS.messageInfo)
                //           }
                //         }.bind(this))
                //       }
                //     }.bind(this)))
                //   }
                //   Axios.all(requestGroup).then(function() {
                //     if (!errorFlag) {
                //       ModulesInsert(this.ModuleForm.moduleName.trim(), tmpDomains, this.name).then(responseSS => {
                //         this.isQuery = false
                //         this.listLoading = false
                //         console.log(responseSS)
                //         if (responseSS.messageFlag) {
                //           Message.success('添加模块成功')
                //           this.inputModuleName = this.ModuleForm.moduleName.trim()
                //           this.getList()
                //           this.$refs['ModuleForm'].resetFields()
                //           this.isdalog = false
                //         } else {
                //           Message.error(responseSS.errorCode + ':' + responseSS.messageInfo)
                //         }
                //       }).catch(() => {
                //         this.listLoading = false
                //       })
                //     } else {
                //       this.listLoading = false
                //     }
                //   }.bind(this))
                // }.bind(this))
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.ModuleForm = JSON.parse(JSON.stringify(rows))
      this.ModuleForm.domains = []
      this.currentbizList = []
      for (const i in rows.domains.split(',')) {
        if (rows.domains.split(',')[i] !== '') {
          for (const tmpModule of this.domainTable) {
            if (tmpModule.name === rows.domains.split(',')[i]) this.ModuleForm.domains.push(rows.domains.split(',')[i])
          }
        }
      }
      if (this.moduleBizListMap.get(rows.moduleName) !== undefined) {
        for (const i of this.moduleBizListMap.get(rows.moduleName).bizList) {
          this.currentbizList.push(i.nicName)
        }
      }
      this.moduleBizListMark = JSON.parse(JSON.stringify(this.currentbizList))
      console.log('this.ModuleForm.bizList', this.ModuleForm)
      this.isdalog = true
      this.isUdate = true
      this.getDomainList()
      this.fetchBizList()
      // this.fetchModuleBizList()
    },
    handleDomUpdate(rows) {
      this.DomainForm = JSON.parse(JSON.stringify(rows))
      this.isDomUdate = true
      this.isDomdalog = true
    },
    handleProUpdate(rows, domainName, env) {
      this.PropertiesForm = JSON.parse(JSON.stringify(rows))
      if (typeof this.PropertiesForm.value !== typeof 'String') this.PropertiesForm.value = JSON.stringify(this.PropertiesForm.value)
      this.tmpForm.domainName = domainName
      this.tmpForm.env = env
      this.isProUdate = true
      this.isProdalog = true
    },
    handleModuleDelete(moduleName) {
      return new Promise((resolve, reject) => {
        ModulesDelete(moduleName).then(response => {
          console.log(response)
          this.listLoading = false
          if (response.messageFlag) {
            Message.success('删除模块成功')
            this.inputModuleName = ''
            this.getList()
            this.$refs['ModuleForm'].resetFields()
            resolve(response)
          } else {
            Message.error(response.errorCode + ':' + response.messageInfo)
          }
        })
      })
    },
    handleDomainsDelete(domainName, domEnv) {
      return new Promise((resolve, reject) => {
        DomainsDelete(domainName, domEnv).then(response => {
          console.log(response)
          this.listLoading = false
          if (response.messageFlag) {
            Message.success('删除域名成功')
            this.inputDomainName = ''
            this.getList()
            this.$refs['DomainForm'].resetFields()
            resolve(response)
          } else {
            Message.error(response.errorCode + ':' + response.messageInfo)
          }
        })
      })
    },
    handlePropertiesDelete(domainName, domEnv, proName) {
      return new Promise((resolve, reject) => {
        PropertiesDelete(domainName, domEnv, proName).then(response => {
          console.log(response)
          this.listLoading = false
          if (response.messageFlag) {
            Message.success('删除属性成功')
            if (this.moduleDomTitle.split('域名详情')[0] === this.moduleDomTitle) {
              this.openModuleDomain(this.moduleDomTitle.split('详情')[0], false, domEnv)
            } else {
              this.openModuleDomain(this.moduleDomTitle.split('域名详情')[0], true)
            }
            this.$refs['PropertiesForm'].resetFields()
            resolve(response)
          } else {
            Message.error(response.errorCode + ':' + response.messageInfo)
          }
        })
      })
    },
    tableRowClassName({ row, index }) {
      return 'successRow'
    }

  }
}
</script>
<style scoped>
@import '../../styles/animate.css';
.propertiesTable .successRow{
background:'#8ce4d2';
}
.envTable{
    float: right;
    font-size: 30px;
    background-color: rgba(255, 181, 179, 0.3);
    padding: 10px;
}
.checkboxsGroup{
  
  border-color: rgba(0, 0, 0, .05);
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.domainTag{
  /* text-shadow: blue; */
  background-color: rgba(119, 255, 248, 0.459);
  color: black;
  padding: 2px;
  border: 1px solid gray;
  margin: 1px 1px 1px 1px;
}
.bizTag{
  /* text-shadow: blue; */
   background-color: rgba(230, 124, 53, 0.459);
  color: black;
  padding: 5px;
  border: 1px solid gray;
  margin: 1px 1px 1px 1px;
}
</style>
