<template>
    <div class="app-container">
        <el-card>
            <el-form :inline="true" @submit.native.prevent>
                <el-form-item label="模块名称">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getModuleBizList" v-model="inputModuleName" size="mini"></el-input>
                </el-form-item>
                <el-form-item label="业务名称">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getModuleBizList" v-model="inputBizName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button v-loading.body="loadingFlag" type="primary" @click="getModuleBizList" size="mini">查询</el-button>
                </el-form-item>
            </el-form>
                <el-button v-if="hasPermission()" v-loading.body="loadingFlag" type="default" size="mini" class="tool-item" @click="handleInsert">
                    <i class="el-icon-edit">添加</i>
                </el-button>
            <el-table
            :data="bizModuleList"
            size="mini"
            highlight-current-row 
            style="width: 100%" 
            :border="true" 
            :stripe="true" 
            resizable>
            <el-table-column type="index" width="40%" header-align="center" align="left" ></el-table-column>
            <el-table-column property="nicName" label="业务域名"   header-align="center"  align="left" width="190%"></el-table-column>
            <el-table-column property="bizName" label="英文名称"   header-align="center"  align="left" width="190%"></el-table-column>
            <el-table-column type="expand" property="nodes" label="包含模块"  header-align="center"  align="left" width="100px">
              <template slot-scope="scope1">
                  <el-table
        ref="singleTable3" 
        size="mini"
        :data="scope1.row.moduleList" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
        <el-table-column type="index" width="40%" header-align="center" align="left" ></el-table-column>
        <el-table-column  property="moduleName" label="模块名称"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
        </el-table-column>
        <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="300px">
        </el-table-column>
        </el-table>
              </template>
            </el-table-column>
        <el-table-column v-if="hasPermission()" label="操作"  header-align="center"  align="left" width="200px" >
             <template slot-scope="scope">
            <el-button v-if="hasPermission()" v-loading.body="loadingFlag" type="warning" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                <i class="el-icon-edit">修改</i>
            </el-button>
                            <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？这将删除所有关联关系，并且无法恢复！</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="priamry"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="loadingFlag"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="doBizAllDelete(scope.row)"
                                                        v-loading.body="loadingFlag"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
             </template>
        </el-table-column>
            <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updated" label="修改时间"  header-align="center"  align="left"  width="300px">
            </el-table-column>
            </el-table>
        </el-card>
                <el-dialog
                title="添加业务域及模块关联"
                :visible.sync="insertDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-form
                  :model="bizModuleForm"
                  :inline="true"
                   ref="bizModuleForm">
                  
                  <el-form-item
                prop="bizName"
                label="业务域名称"
                :rules="{required: true, message: '请输入业务域名称'}"
                style="width:200px"
            >
                <el-input v-model="bizModuleForm.bizName"></el-input>
                </el-form-item>
                <el-form-item
                prop="nicname"
                label="中文名称"
                :rules="{required: true, message: '请输入中文名称'}"
                style="width:200px"
            >
                <el-input v-model="bizModuleForm.nicname"></el-input>
                </el-form-item>
                <el-form-item
                prop="moduleList"
                label="关联模块"
                
            >
                <el-checkbox-group
                      v-model="bizModuleForm.moduleList">
                                
                                <hr/>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.moduleName'
                                        v-for='item in moduleList'
                                        :label="item.moduleName"
                                        :border="true"
                                        size="mini"
                                    >{{item.moduleName}}</el-checkbox>
                                </el-checkbox-group>
                  </el-form-item>
                  </el-form>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doInsertBizInformationTable()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
                title="修改业务域"
                :visible.sync="updateDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-form
                  :model="bizModuleForm"
                  :inline="true"
                   ref="bizModuleForm">
                  
                  <el-form-item
                prop="bizName"
                label="业务域名称"
                :rules="{required: true, message: '请输入业务域名称'}"
                style="width:200px"
            >
                <el-input v-model="bizModuleForm.bizName"></el-input>
                </el-form-item>
                <el-form-item
                prop="nicname"
                label="中文名称"
                :rules="{required: true, message: '请输入中文名称'}"
                style="width:200px"
            >
                <el-input v-model="bizModuleForm.nicname"></el-input>
                </el-form-item>
                <el-form-item
                prop="moduleList"
                label="关联模块"
                
            >
                <el-checkbox-group
                      v-model="bizModuleForm.moduleList">
                                
                                <hr/>
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item.moduleName'
                                        v-for='item in moduleList'
                                        :label="item.moduleName"
                                        :border="true"
                                        size="mini"
                                    >{{item.moduleName}}</el-checkbox>
                                </el-checkbox-group>
                  </el-form-item>
                  </el-form>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doUpdateBizInformationTable()">确定</el-button>
        </span>
        </el-dialog>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Axios from 'axios'
import {
  insertModuleBizRelationbyModuleList,
  deleteModuleBizRelation,
  //   insertModuleBizRelationByBizList,
  insertBizInformationTable,
  updateBizInformationTable,
  deleteBizInformationTable,
  getBizModuleList,
  ModulesDialog
} from '@/api/config'
import {
  Message
} from 'element-ui'
export default {
  name: 'bizConfig',
  data() {
    return {
      loadingFlag: false,
      inputModuleName: '',
      inputBizName: '',
      insertDialogFlag: false,
      updateDialogFlag: false,
      bizModuleForm: {
        bizName: '',
        nicname: '',
        moduleList: []
      },
      bizIdMark: '',
      bizModuleList: [],
      moduleList: [],
      moduleNameMap: {},
      moduleBizListMark: []
    }
  },
  created() {
    this.getModuleList()
    this.getModuleBizList()
  },
  methods: {
    doUpdateBizInformationTable() {
      this.$refs['bizModuleForm'].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.loadingFlag = false
              const requestGroup = []
              let step1 = false
              let step2 = false
              let step3 = false
              const insertModuleList = []
              const deleteIdList = []
              for (const i of this.bizModuleForm.moduleList) {
                let checkFlag = true
                for (const j of this.moduleBizListMark) {
                  if (i === j) {
                    checkFlag = false
                    break
                  }
                }
                if (checkFlag) {
                  insertModuleList.push(this.moduleNameMap.get(i))
                }
              }
              for (const i of this.moduleBizListMark) {
                let checkFlag = true
                for (const j of this.bizModuleForm.moduleList) {
                  if (i === j) {
                    checkFlag = false
                    break
                  }
                }
                if (checkFlag) {
                  deleteIdList.push(this.moduleNameMap.get(i).id)
                }
              }
              if (insertModuleList.length !== 0) {
                requestGroup.push(
                  insertModuleBizRelationbyModuleList(this.bizIdMark, insertModuleList, this.name).then(response => {
                    this.loadingFlag = false
                    console.log('insertModuleBizRelationbyModuleList', response)
                    if (response.errorCode === 'NO_ERR') {
                      step2 = true
                      //   console.log('bizModuleList', response.data.bizModuleList)
                    }
                  }).catch(e => {
                    this.loadingFlag = false
                  })
                )
              } else {
                step2 = true
              }
              if (deleteIdList.length !== 0) {
                requestGroup.push(
                  deleteModuleBizRelation(this.bizIdMark, deleteIdList).then(response => {
                    this.loadingFlag = false
                    console.log('deleteModuleBizRelation', response)
                    if (response.errorCode === 'NO_ERR') {
                      step3 = true
                      //   console.log('bizModuleList', response.data.bizModuleList)
                    }
                  }).catch(e => {
                    this.loadingFlag = false
                  })
                )
              } else {
                step3 = true
              }
              requestGroup.push(
                updateBizInformationTable({ id: this.bizIdMark, bizName: this.bizModuleForm.bizName, nicname: this.bizModuleForm.nicname }, this.name).then(response => {
                  this.loadingFlag = false
                  console.log('updateBizInformationTable', response)
                  if (response.errorCode === 'NO_ERR') {
                    step1 = true
                    //   console.log('bizModuleList', response.data.bizModuleList)
                  }
                }).catch(e => {
                  this.loadingFlag = false
                })
              )
              Axios.all(requestGroup).then(function() {
                this.loadingFlag = false
                if (step1 & step2 & step3) {
                  Message.success('修改成功')
                  this.getModuleBizList()
                  this.updateDialogFlag = false
                } else if (!step1 & !step2 & !step3) {
                  Message.success('修改失败')
                } else {
                  Message.success('修改部分成功')
                  this.getModuleBizList()
                  this.updateDialogFlag = false
                }
              }.bind(this))
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(row) {
      this.bizModuleForm.bizName = row.bizName
      this.bizIdMark = row.id
      this.bizModuleForm.nicname = row.nicName
      this.bizModuleForm.moduleList = []
      if (row.moduleList !== undefined && row.moduleList.length !== 9) {
        for (const i of row.moduleList) {
          this.bizModuleForm.moduleList.push(i.moduleName)
        }
      }
      this.moduleBizListMark = this.bizModuleForm.moduleList
      this.updateDialogFlag = true
      this.getModuleList()
    },
    doInsertBizInformationTable() {
      this.$refs['bizModuleForm'].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.loadingFlag = true
              const tmpList = []
              for (const i of this.bizModuleForm.moduleList) {
                tmpList.push(this.moduleNameMap.get(i))
              }
              insertBizInformationTable(this.bizModuleForm.bizName, this.bizModuleForm.nicname, tmpList, this.name).then(response => {
                this.loadingFlag = false
                console.log('insertBizInformationTable', response)
                if (response.errorCode === 'NO_ERR') {
                //   console.log('bizModuleList', response.data.bizModuleList)
                  Message.success('添加成功')
                  this.getModuleBizList()
                  this.insertDialogFlag = false
                  this.bizModuleForm = {
                    bizName: '',
                    nicname: '',
                    moduleList: []
                  }
                } else {
                  Message.error(response.errorCode + ':' + response.messageInfo)
                }
              }).catch(e => {
                Message.error(e)
                this.loadingFlag = false
              })
            //   console.log(tmpList)
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    getModuleBizList() {
      this.loadingFlag = true
      getBizModuleList(this.inputModuleName, this.inputBizName).then(response => {
        this.loadingFlag = false
        console.log('moduleBizList', response)
        if (response.code === 0) {
          this.bizModuleList = response.data.bizModuleList.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
          console.log('bizModuleList', response.data.bizModuleList)
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    doBizAllDelete(row) {
      row.deleteFlag = false
      this.loadingFlag = true
      deleteBizInformationTable(row.id).then(response => {
        this.loadingFlag = false
        console.log('doBizAllDelete', response)
        if (response.errorCode === 'NO_ERR') {
          //   console.log('bizModuleList', response.data.bizModuleList)
          Message.success('删除成功')
          this.getModuleBizList()
        } else {
          Message.error(response.errorCode + ':' + response.messageInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    getModuleList() {
      var that = this
      that.moduleList = []

      ModulesDialog('').then(function(response) {
        that.isQuery = false
        console.log('response:', response)
        if (JSON.stringify(response.payload) !== '{}') {
          that.moduleList = response.payload.module
          const compare = function(obj1, obj2) {
          // // console.log('conpare', obj1, obj2)
          // const val1 = obj1.metric
          // const val2 = obj2.metric
          // if (val1 > val2) return 1
          // else if (val1 < val2) return -1
          // else return 0
            return obj1.moduleName.localeCompare(obj2.moduleName)
          }
          that.moduleNameMap = new Map()
          for (const i of response.payload.module) {
            that.moduleNameMap.set(i.moduleName, i)
          }
          //   console.log('moduleNameMap',that.moduleNameMap)
          that.moduleList = that.moduleList.sort(compare)
        }
      })
    },
    handleInsert() {
      this.insertDialogFlag = true
      this.bizModuleForm = {
        bizName: '',
        nicname: '',
        moduleList: []
      }
      this.getModuleList()
    },
    hasPermission() {
      const ROLES = ['admin', 'bizConfigButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.insertDialogFlag = false
          this.updateDialogFlag = false
          this.bizModuleForm = {
            bizName: '',
            nicname: '',
            moduleList: []
          }
          console.log('moduleList', this.bizModuleForm.moduleList)
          done()
        })
        .catch(_ => {})
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>