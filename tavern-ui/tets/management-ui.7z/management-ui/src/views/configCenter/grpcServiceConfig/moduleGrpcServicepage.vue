<template>
<div class="app-container">
     <el-card class="backGroundClass">
                     <div class="envTable">
            <span class="title">当前环境：</span>
            <el-select v-model="enviroment" @change="changeEnv">
                                                            <el-option
                                                                v-for="item in envlist"
                                                                :key="item.id"
                                                                :label="item.remark"
                                                                :value="item.env"
                                                            >
                                                                </el-option>
                                                        </el-select>
                     </div>
<el-form :inline="true" @submit.native.prevent v-loading.body="loadingFlag">
                <el-form-item class="form-wrapper-item" label="模块名称" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getModuleGrpcService" v-model="inputModuleName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="Grpc服务别名" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getModuleGrpcService" v-model="inputgrpcServiceNickName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="Grpc服务名称" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getModuleGrpcService" v-model="inputgrpcServiceName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button v-loading.body="loadingFlag" type="primary" @click="getModuleGrpcService" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox" v-loading.body="loadingFlag">
            <el-button v-if="hasPermission()" v-loading.body="loadingFlag" type="default" size="mini" class="tool-item" @click="handleInsert">
                <i class="el-icon-edit">添加</i>
            </el-button>
            <el-button  v-loading.body="loadingFlag" type="default" size="mini" class="tool-item" @click="handledictionaryWindow">
                <i class="el-icon-edit">Grpc服务配置</i>
            </el-button>
        </div>
        <el-table 
        v-loading.body="loadingFlag"
        ref="singleTable" 
        :data="moduleGrpcServiceData" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
            <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
            <el-table-column property="moduleName" label="模块名称"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column type="expand" property="dictionaryName" label="包含服务"  header-align="center"  align="left" width="150px">
                <template slot-scope="scope">
                  <el-table 
        ref="singleTable2" 
        :data="scope.row.grpcServices" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
         <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
         <el-table-column property="grpcServiceNickName" label="服务别名"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column property="grpcServiceName" label="服务名"  header-align="center"  align="left"  ></el-table-column>
          <el-table-column property="grpcClass" label="服务类"  header-align="center"  align="left"  ></el-table-column>
            <el-table-column type="expand" property="nodes" label="节点"  header-align="center"  align="left" width="100px">
              <template slot-scope="scope1">
                  <el-table 
        ref="singleTable3" 
        :data="scope1.row.nodes" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
        <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
        <el-table-column  property="nodeName" label="节点名称"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column  property="hosts" label="服务器地址"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column  property="port" label="端口"  header-align="center"  align="left"  ></el-table-column>
         <el-table-column  property="operator" label="修改用户"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="updateTime" label="修改时间"  header-align="center"  align="left" >
            </el-table-column>
            <el-table-column property="createdTime" label="修改时间"  header-align="center"  align="left"  >
              </el-table-column>
        </el-table>
              </template>
            </el-table-column>
                  <el-table-column  property="operator" label="修改用户"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="updateTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="createdTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
        </el-table>           
                </template>
            </el-table-column>
            <el-table-column v-if="hasPermission()" fixd="right" label="操作"  header-align="center"  align="center" >
                <template slot-scope="scope">
                    <el-button v-loading.body="loadingFlag" type="warning" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="loadingFlag"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleModuleGrpcServiceDelete(scope.row)"
                                                        v-loading.body="loadingFlag"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
          <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="updateTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="createdTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
        </el-table>
        <el-dialog
                title="添加模块服务对应关系"
                :visible.sync="actDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="moduleList"
                v-model="seletctModuleList"
                :titles="['可选模块','已选模块']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="grpcServiceGroupList"
                v-model="seletctGrpcServiceList"
                :titles="['可选Grpc服务','已选Grpc服务']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doModuleGrpcServiceInsert()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
                :title="updateModuleDicTitle"
                :visible.sync="updateModuleDicDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="grpcServiceGroupList"
                v-model="seletctGrpcServiceList"
                :titles="['可选Grpc服务','已选Grpc服务']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doModuleDicUpdate()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
        title="冲突报告"
        :visible.sync="conflictDialog"
    >
        <el-form
            :inline="true"
        >
            <el-form-item
                :label="keys"
                v-for="(item,keys) in conflictData"
                :key="keys"
            ><br/>
            <div
            :label="keysTwo"
                v-for="(itemTwo,keysTwo) in item"
                :key="keysTwo"
            >
            <span>{{keysTwo}}</span>
                <el-tag v-for="items in itemTwo" :key="items">{{items}}</el-tag>
            </div>
                </el-form-item>
        </el-form>
</el-dialog>
    </el-card>
    </div>
</template>
<script>
let enviroment = ''
import { mapGetters } from 'vuex'
import {
  queryModuleGrpcService,
  moduleGrpcServiceInsert,
  moduleGrpcServiceDelete,
  ModulesDialog,
  queryGrpcService,
  envDialog
} from '@/api/config'
import {
  Message
} from 'element-ui'
import Axios from 'axios'
export default {
  name: 'moduleGrpcServicepage',
  data() {
    return {
      moduleGrpcServiceData: [],
      envlist: [],
      envShow: '',
      enviroment: '',
      loadingFlag: false,
      inputModuleName: '',
      inputgrpcServiceNickName: '',
      inputgrpcServiceName: '',
      actDialogFlag: false,
      moduleList: [],
      grpcServiceGroupList: [],
      grpcServiceList: [],
      seletctModuleList: [],
      seletctGrpcServiceList: [],
      updateModuleDicTitle: '',
      updateModule: {},
      updateModuleDicDialogFlag: false,
      markModuleGrpcServiceList: [],
      conflictDialog: false,
      conflictData: {}
    }
  },
  created() {
    this.envList()
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  wathc: {
    enviroment() {
      this.DomainForm.env = enviroment
      this.enviroment = enviroment
    }
  },
  methods: {
    changeEnv() {
      enviroment = this.enviroment
      if (process.env.NODE_ENV === 'development') {
        if (this.enviroment === 'dev') {
          this.envShow = 'dev1'
        }
        if (this.enviroment === 'sit') {
          this.envShow = 'dev2'
        }
      } else {
        this.envShow = this.enviroment
      }
      this.getModuleGrpcService()
      this.getgrpcServiceGroupList()
      this.getModuleList()
    },
    envList() {
      envDialog().then(function(response) {
        if (JSON.stringify(response.payload) !== '{}') {
          if (process.env.NODE_ENV === 'development') {
            for (const i of response.payload.env) {
              if (i.env === 'dev') {
                this.envShow = 'dev1'
                i.remark = 'dev1'
              }
              if (i.env === 'sit') {
                this.envShow = 'dev2'
                i.remark = 'dev2'
              }
            }
          } else {
            for (const i of response.payload.env) {
              this.envShow = i.env
              i.remark = i.env
            }
          }
          this.envlist = response.payload.env
        }
        if (this.envlist.length > 1)enviroment = this.envlist[1].env
        else enviroment = this.envlist[0].env
        if (process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'productiongq' || process.env.NODE_ENV === 'productionxy')enviroment = this.envlist[0].env
        console.log('env', enviroment)
        this.enviroment = enviroment
        this.getModuleGrpcService()
        this.getgrpcServiceGroupList()
        this.getModuleList()
      }.bind(this))
    },
    handledictionaryWindow() {
      // console.log('push to:', '/configCenter/' + this.enviroment + '/domainWindow_' + this.enviroment)
      this.$router.push({ path: '/configCenter/GrpcServiceNodespage' })
    },
    handleModuleGrpcServiceDelete(row) {
      this.loadingFlag = true
      moduleGrpcServiceDelete(row).then(response => {
        this.loadingFlag = false
        console.log('response:', response)
        if (response.errorCode === 'NO_ERR') {
          Message.success('删除成功')
          this.getModuleGrpcService()
          this.getgrpcServiceGroupList()
          this.getModuleList()
        } else {
          Message.error(response.errorCode + ':' + response.messageInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    doModuleDicUpdate() {
      if (this.seletctGrpcServiceList.length === 0) {
        // console.log('this.seletctGrpcServiceList', this.seletctGrpcServiceList)
        Message.error('数据输入不全！')
      } else {
        this.$confirm('确认提交?')
          .then(_ => {
            this.loadingFlag = true
            // console.log('seletctModuleListA', seletctModuleListA, this.markModuleGrpcServiceList, this.seletctGrpcServiceList)
            for (const i in this.markModuleGrpcServiceList) {
              for (const j in this.seletctGrpcServiceList) {
                if (this.markModuleGrpcServiceList[i] === this.seletctGrpcServiceList[j]) {
                  this.markModuleGrpcServiceList[i] = -1
                  this.seletctGrpcServiceList[j] = -1
                  break
                }
              }
            }
            // console.log('seletctModuleListA', seletctModuleListA, this.markModuleGrpcServiceList, this.seletctGrpcServiceList)
            const seletctGrpcServiceListA = []
            for (const i of this.seletctGrpcServiceList) {
              if (i !== -1)seletctGrpcServiceListA.push(this.grpcServiceList[i])
            }
            const insertListA = []
            for (const i of this.moduleList) {
              if (i.label === this.updateModule) {
                insertListA.push({
                  moduleName: i.label,
                  id: i.ids,
                  env: this.enviroment,
                  operator: this.name,
                  grpcServices: seletctGrpcServiceListA
                })
                break
              }
            }
            // console.log('seletctGrpcServiceListA', seletctGrpcServiceListA)
            const seletctGrpcServiceListB = []
            for (const i of this.markModuleGrpcServiceList) {
              if (i !== -1)seletctGrpcServiceListB.push(this.grpcServiceList[i])
            }
            const insertListB = []
            for (const i of this.moduleList) {
              if (i.label === this.updateModule) {
                insertListB.push({
                  moduleName: i.label,
                  id: i.ids,
                  env: this.enviroment,
                  operator: this.name,
                  grpcServices: seletctGrpcServiceListB
                })
                break
              }
            }
            // console.log('seletctGrpcServiceListB', seletctGrpcServiceListB)
            const requestGroup = []
            const resultMark = []
            if (seletctGrpcServiceListA.length !== 0) {
              requestGroup.push(moduleGrpcServiceInsert(insertListA).then(response => {
                resultMark.push({ name: 'update', response: response })
              }))
            } else {
              resultMark.push({ name: 'update', response: { errorCode: 'NO_ERR' }})
            }
            if (seletctGrpcServiceListB.length !== 0) {
              requestGroup.push(moduleGrpcServiceDelete(insertListB[0]).then(response => {
                resultMark.push({ name: 'delete', response: response })
              }))
            } else {
              resultMark.push({ name: 'delete', response: { errorCode: 'NO_ERR' }})
            }
            Axios.all(requestGroup).then(function() {
              this.loadingFlag = false
              if (!(resultMark[0].response.errorCode === 'NO_ERR') && !(resultMark[1].response.errorCode === 'NO_ERR')) Message.error('修改失败')
              else if ((resultMark[0].response.errorCode === 'ERR60012')) {
                this.conflictDialog = true
                this.conflictData = resultMark[0].response.messageData
              } else if ((resultMark[1].response.errorCode === 'ERR60012')) {
                this.conflictDialog = true
                this.conflictData = resultMark[1].response.messageData
              } else if (!(resultMark[0].response.errorCode === 'NO_ERR') || !(resultMark[1].response.errorCode === 'NO_ERR')) Message.error('部分修改失败')
              else {
                Message.success('修改成功！')
                this.updateModuleDicDialogFlag = false
                this.seletctModuleList = []
                this.seletctGrpcServiceList = []
                this.getModuleGrpcService()
                this.getgrpcServiceGroupList()
                this.getModuleList()
              }
            }.bind(this)).catch(e => {
              Message.error(e)
              this.loadingFlag = false
            })
          }).catch(_ => {
          })
      }
    },
    handleUpdate(row) {
      this.getModuleList()
      this.getgrpcServiceGroupList()
      this.updateModuleDicTitle = '修改' + row.moduleName + '对应Grpc服务'
      this.updateModule = row.moduleName
      for (const i of row.grpcServices) {
        for (const j in this.grpcServiceGroupList) {
          //  console.log('i,j',i.dictionaryName,this.grpcServiceGroupList[j].label)
          if (i.grpcServiceNickName === this.grpcServiceGroupList[j].label) {
            this.seletctGrpcServiceList.push(parseInt(j))
          }
        }
      }
      //   console.log('this.seletctGrpcServiceList',this.seletctGrpcServiceList)
      this.markModuleGrpcServiceList = this.seletctGrpcServiceList
      this.updateModuleDicDialogFlag = true
    },
    doModuleGrpcServiceInsert() {
      if (this.seletctModuleList.length === 0 || this.seletctGrpcServiceList.length === 0) {
        Message.error('数据输入不全！')
      } else {
        this.$confirm('确认提交?')
          .then(_ => {
            this.loadingFlag = true
            const seletctGrpcServiceListA = []
            for (const i of this.seletctGrpcServiceList) {
              seletctGrpcServiceListA.push(this.grpcServiceList[i])
            }
            console.log('seletctGrpcServiceListA', seletctGrpcServiceListA, this.grpcServiceList, this.seletctGrpcServiceList)
            const insertList = []
            for (const i of this.seletctModuleList) {
              insertList.push({
                moduleName: this.moduleList[i].label,
                id: this.moduleList[i].ids,
                env: this.enviroment,
                operator: this.name,
                grpcServices: seletctGrpcServiceListA
              })
            }
            // console.log('asdasda', seletctModuleListA, seletctGrpcServiceListA)
            moduleGrpcServiceInsert(insertList).then(response => {
              this.loadingFlag = false
              console.log('response:', response)
              if (response.errorCode === 'NO_ERR') {
                Message.success('添加成功')
                this.getModuleGrpcService()
                this.getgrpcServiceGroupList()
                this.getModuleList()
                this.actDialogFlag = false
                this.seletctModuleList = []
                this.seletctGrpcServiceList = []
              } else {
                if (response.errorCode === 'ERR60012') {
                  this.conflictDialog = true
                  this.conflictData = response.messageData
                }
                Message.error(response.errorCode + ':' + response.messageInfo)
              }
            }).catch(e => {
              Message.error(e)
              this.loadingFlag = false
            })
          })
          .catch(_ => {
          })
      }
    },
    filtermethod(query, item) {
      return item.label.indexOf(query) > -1
    },
    getgrpcServiceGroupList() {
      this.loadingFlag = true
      queryGrpcService('', '', '', '', '', this.enviroment).then(response => {
        this.loadingFlag = false
        console.log('response:', response)
        this.grpcServiceGroupList = []
        this.grpcServiceList = []
        if (JSON.stringify(response.data) !== '{}') {
          response.data.grpcServiceList.forEach(
            (item, index) => {
              this.grpcServiceGroupList.push({
                label: item.grpcServiceNickName,
                key: index,
                ids: item.id
              })
              this.grpcServiceList.push(item)
            })
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    getModuleList() {
      this.loadingFlag = true
      queryModuleGrpcService('', '', '').then(response => {
        this.loadingFlag = false
        console.log('data', response)
        if (response.code === 0) {
          ModulesDialog('').then(responses => {
            this.loadingFlag = false
            console.log('responses:', responses)
            this.moduleList = []
            if (JSON.stringify(responses.payload) !== '{}') {
              responses.payload.module.forEach(
                (item, index) => {
                  let flag = true
                  for (const i of response.data.moduleGrpcServiceList) {
                    if (i.moduleName === item.moduleName) {
                      flag = false
                      this.moduleList.push({
                        label: item.moduleName,
                        key: index,
                        ids: item.id,
                        disabled: true
                      })
                    }
                  }
                  if (flag) {
                    this.moduleList.push({
                      label: item.moduleName,
                      key: index,
                      ids: item.id,
                      disabled: false
                    })
                  }
                }
              )
              //   this.moduleList = response.payload.module
            }
          })
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.actDialogFlag = false
          this.updateModuleDicDialogFlag = false
          this.seletctModuleList = []
          this.seletctGrpcServiceList = []
          done()
        })
        .catch(_ => {})
    },
    handleInsert() {
      this.getModuleList()
      this.getgrpcServiceGroupList()
      this.actDialogFlag = true
    },
    hasPermission() {
      const ROLES = ['admin', 'moduleGrpcServicepageButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    getModuleGrpcService() {
      this.loadingFlag = true
      queryModuleGrpcService(this.inputModuleName, this.inputgrpcServiceNickName, this.inputgrpcServiceName, this.enviroment).then(response => {
        this.loadingFlag = false
        console.log('data', response)
        if (response.code === 0) {
          this.moduleGrpcServiceData = response.data.moduleGrpcServiceList.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    }
  }
}
</script>
<style scoped>
.backGroundClass{
    background-color: rgba(219, 238, 115, 0.205)
}
.envTable{
    float: right;
    font-size: 30px;
    background-color: rgba(255, 181, 179, 0.3);
    padding: 10px;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>