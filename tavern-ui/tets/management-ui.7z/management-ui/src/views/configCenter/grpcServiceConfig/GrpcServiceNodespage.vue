<template>
<div class="app-container">
    <el-card class="backGroundClass">
              <div class="envTable">
            <span class="title">当前环境：</span>
            <el-select v-model="enviroment" @change="changeEnv">
                                                            <el-option
                                                                v-for="item in envlist"
                                                                :key="item.id"
                                                                :label="item.remark"
                                                                :value="item.env"
                                                            >
                                                                </el-option>
                                                        </el-select>
        </div>
<el-form :inline="true" @submit.native.prevent
v-loading.body="loadingFlag">

                <el-form-item class="form-wrapper-item" label="Grpc服务昵称" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getGrpcServiceList" v-model="inputgrpcServiceNickName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="Grpc服务名称" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getGrpcServiceList" v-model="inputgrpcServiceName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="节点名称" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getGrpcServiceList" v-model="inputNodeName" size="mini"></el-input>
                </el-form-item>       
                <el-form-item class="form-wrapper-item" label="节点服务器地址" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getGrpcServiceList" v-model="inputHost" size="mini"></el-input>
                </el-form-item>                
                <el-form-item class="form-wrapper-item" label="节点端口号" label-width="110px">
                    <el-input v-loading.body="loadingFlag" @keyup.enter.native="getGrpcServiceList" v-model="inputPort" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button v-loading.body="loadingFlag" type="primary" @click="getGrpcServiceList" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox"
        v-loading.body="loadingFlag">
            <el-button v-if="hasPermission()" v-loading.body="loadingFlag" type="default" size="mini" class="tool-item" @click="handleInsert">
                <i class="el-icon-edit">添加</i>
            </el-button>
            <el-button  v-loading.body="loadingFlag" type="default" size="mini" class="tool-item" @click="handledictionaryWindow">
                <i class="el-icon-edit">节点配置</i>
            </el-button>
        </div>
        <el-table 
        v-loading.body="loadingFlag"
        ref="singleTable" 
        :data="grpcServiceData" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
            <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
             <el-table-column property="grpcServiceNickName" label="服务别名"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column property="grpcServiceName" label="服务名"  header-align="center"  align="left"  ></el-table-column>
          <el-table-column property="grpcClass" label="服务类"  header-align="center"  align="left"  ></el-table-column>
            <el-table-column type="expand" property="nodes" label="节点"  header-align="center"  align="left" width="100px">
              <template slot-scope="scope1">
                  <el-table 
        ref="singleTable3" 
        :data="scope1.row.nodes" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
        <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
        <el-table-column  property="nodeName" label="节点名称"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column  property="hosts" label="服务器地址"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column  property="port" label="端口"  header-align="center"  align="left"  ></el-table-column>
         <el-table-column  property="operator" label="修改用户"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="updateTime" label="修改时间"  header-align="center"  align="left" >
            </el-table-column>
            <el-table-column property="createdTime" label="修改时间"  header-align="center"  align="left"  >
              </el-table-column>
        </el-table>
              </template>
            </el-table-column>
            <el-table-column v-if="hasPermission()" fixd="right" label="操作"  header-align="center"  align="center" >
                <template slot-scope="scope">
                    <el-button v-loading.body="loadingFlag" type="warning" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="loadingFlag"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleModuleGrpcServiceDelete(scope.row)"
                                                        v-loading.body="loadingFlag"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
          <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="updateTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="createdTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
        </el-table>
        <el-dialog
                title="添加服务节点对应关系"
                :visible.sync="actDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                  <el-form
                  :model="grpcServiceForm"
                  :inline="true"
                   ref="grpcServiceForm">
                  
                  <el-form-item
                prop="grpcServiceNickName"
                label="服务昵称"
                :rules="{required: true, message: '请输入服务昵称'}"
                style="width:200px"
            >
                <el-input v-model="grpcServiceForm.grpcServiceNickName"></el-input>
                </el-form-item>
                <el-form-item
                prop="grpcServiceName"
                :rules="{required: true, message: '请输入服务名称'}"
                label="服务名称"
                style="width:200px"
            >
                <el-input v-model="grpcServiceForm.grpcServiceName"></el-input>
                </el-form-item>
                  <el-form-item
                prop="grpcClass"
                label="class名称"
                :rules="{required: true, message: '请输入class名称'}"
                style="width:200px"
            >
                <el-input v-model="grpcServiceForm.grpcClass"></el-input>
                </el-form-item>
                  <el-form-item>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="nodesGroupList"
                v-model="seletctnodesList"
                :titles="['可选节点','已选节点']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                  </el-form-item>
                  </el-form>
                
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doGrpcServiceInsert()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
                :title="updateGrpcServiceDicTitle"
                :visible.sync="updateGrpcServiceDicDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-form
                  :model="grpcServiceForm"
                  :inline="true"
                   ref="grpcServiceForm">
                  
                  <el-form-item
                prop="grpcServiceNickName"
                label="服务昵称"
                :rules="{required: true, message: '请输入服务昵称'}"
                style="width:200px"
            >
                <el-input v-model="grpcServiceForm.grpcServiceNickName"></el-input>
                </el-form-item>
                <el-form-item
                prop="grpcServiceName"
                :rules="{required: true, message: '请输入服务名称'}"
                label="服务名称"
                style="width:200px"
            >
                <el-input v-model="grpcServiceForm.grpcServiceName"></el-input>
                </el-form-item>
                  <el-form-item
                prop="grpcClass"
                label="class名称"
                :rules="{required: true, message: '请输入class名称'}"
                style="width:200px"
            >
                <el-input v-model="grpcServiceForm.grpcClass"></el-input>
                </el-form-item>
                  <el-form-item>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="nodesGroupList"
                v-model="seletctnodesList"
                :titles="['可选节点','已选节点']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                  </el-form-item>
                  </el-form>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doModuleGrpcServiceUpdate()">确定</el-button>
        </span>
        </el-dialog>
    </el-card>
    </div>
</template>
<script>
let enviroment = ''
import { mapGetters } from 'vuex'
import {
  queryGrpcServiceDelete,
  queryGrpcServiceInsert,
  queryGrpcServiceUpdate,
  GrpcServiceDelete,
  queryGrpcNodes,
  queryGrpcService,
  envDialog
} from '@/api/config'
import {
  Message
} from 'element-ui'
import Axios from 'axios'
export default {
  name: 'GrpcServiceNodespage',
  data() {
    return {
      grpcServiceData: [],
      loadingFlag: false,
      inputPort: '',
      inputHost: '',
      envlist: [],
      inputNodeName: '',
      inputgrpcServiceNickName: '',
      inputgrpcServiceName: '',
      actDialogFlag: false,
      nodesGroupList: [],
      grpcServiceGroupList: [],
      nodeList: [],
      seletctnodesList: [],
      seletctGrpcServiceList: [],
      updateGrpcServiceDicTitle: '',
      updateGrpcService: {},
      updateGrpcServiceDicDialogFlag: false,
      markSelectNodeList: [],
      grpcServiceForm: {
        grpcClass: '',
        grpcServiceName: '',
        grpcServiceNickName: '',
        id: '',
        env: '',
        nodes: []
      },
      envShow: '',
      enviroment: ''
    }
  },
  created() {
    this.envList()
  },
  watch: {
    enviroment() {
      this.DomainForm.env = enviroment
      this.enviroment = enviroment
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  methods: {
    changeEnv() {
      enviroment = this.enviroment
      if (process.env.NODE_ENV === 'development') {
        if (this.enviroment === 'dev') {
          this.envShow = 'dev1'
        }
        if (this.enviroment === 'sit') {
          this.envShow = 'dev2'
        }
      } else {
        this.envShow = this.enviroment
      }
      this.getGrpcServiceList()
      this.getgrpcServiceGroupList()
      this.getnodesList()
    },
    envList() {
      envDialog().then(function(response) {
        if (JSON.stringify(response.payload) !== '{}') {
          if (process.env.NODE_ENV === 'development') {
            for (const i of response.payload.env) {
              if (i.env === 'dev') {
                this.envShow = 'dev1'
                i.remark = 'dev1'
              }
              if (i.env === 'sit') {
                this.envShow = 'dev2'
                i.remark = 'dev2'
              }
            }
          } else {
            for (const i of response.payload.env) {
              this.envShow = i.env
              i.remark = i.env
            }
          }
          this.envlist = response.payload.env
        }
        if (this.envlist.length > 1)enviroment = this.envlist[1].env
        else enviroment = this.envlist[0].env
        if (process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'productiongq' || process.env.NODE_ENV === 'productionxy')enviroment = this.envlist[0].env
        console.log('env', enviroment)
        this.enviroment = enviroment
        this.getGrpcServiceList()
        this.getgrpcServiceGroupList()
        this.getnodesList()
      }.bind(this))
    },
    handledictionaryWindow() {
      // console.log('push to:', '/configCenter/' + this.enviroment + '/domainWindow_' + this.enviroment)
      this.$router.push({ path: '/configCenter/nodeConfigPage' })
    },
    handleModuleGrpcServiceDelete(row) {
      this.loadingFlag = true
      GrpcServiceDelete(row.id).then(response => {
        this.loadingFlag = false
        console.log('response:', response)
        if (response.errorCode === 'NO_ERR') {
          Message.success('删除成功')
          this.getGrpcServiceList()
          this.getgrpcServiceGroupList()
          this.getnodesList()
        } else {
          Message.error(response.errorCode + ':' + response.messageInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    doModuleGrpcServiceUpdate() {
      if (this.seletctnodesList.length === 0) {
        // console.log('this.seletctGrpcServiceList', this.seletctGrpcServiceList)
        Message.error('数据输入不全！')
      } else {
        this.$confirm('确认提交?')
          .then(_ => {
            this.loadingFlag = true
            // console.log('seletctnodesListA', seletctnodesListA, this.markSelectNodeList, this.seletctGrpcServiceList)
            for (const i in this.markSelectNodeList) {
              for (const j in this.seletctnodesList) {
                if (this.markSelectNodeList[i] === this.seletctnodesList[j]) {
                  this.markSelectNodeList[i] = -1
                  this.seletctnodesList[j] = -1
                  break
                }
              }
            }
            // console.log('seletctnodesListA', seletctnodesListA, this.markSelectNodeList, this.seletctGrpcServiceList)
            const selectNodeListA = []
            for (const i of this.seletctnodesList) {
              if (i !== -1)selectNodeListA.push(this.nodeList[i])
            }
            const insertListA = JSON.parse(JSON.stringify(this.grpcServiceForm))
            insertListA.nodes = selectNodeListA
            // console.log('selectNodeList', selectNodeList)
            const seletctnodesListB = []
            for (const i of this.markSelectNodeList) {
              if (i !== -1)seletctnodesListB.push(this.nodeList[i])
            }
            const insertListB = JSON.parse(JSON.stringify(this.grpcServiceForm))
            insertListB.nodes = seletctnodesListB
            // console.log('seletctGrpcServiceListB', seletctGrpcServiceListB)
            const requestGroup = []
            const resultMark = []
            requestGroup.push(queryGrpcServiceUpdate(insertListA).then(response => {
              resultMark.push({ name: 'update', response: response })
            }))
            if (selectNodeListA.length !== 0) {
              requestGroup.push(queryGrpcServiceInsert(insertListA).then(response => {
                resultMark.push({ name: 'update', response: response })
              }))
            } else {
              resultMark.push({ name: 'update', response: { errorCode: 'NO_ERR' }})
            }
            if (seletctnodesListB.length !== 0) {
              requestGroup.push(queryGrpcServiceDelete(insertListB).then(response => {
                resultMark.push({ name: 'delete', response: response })
              }))
            } else {
              resultMark.push({ name: 'delete', response: { errorCode: 'NO_ERR' }})
            }
            Axios.all(requestGroup).then(function() {
              this.loadingFlag = false
              console.log('resultMark', resultMark)
              if (!(resultMark[0].response.errorCode === 'NO_ERR') && !(resultMark[1].response.errorCode === 'NO_ERR')) Message.error('修改失败')
              else if (!(resultMark[0].response.errorCode === 'NO_ERR') || !(resultMark[1].response.errorCode === 'NO_ERR')) Message.error('部分修改失败')
              else {
                Message.success('修改成功！')
                this.updateGrpcServiceDicDialogFlag = false
                this.seletctnodesList = []
                this.seletctGrpcServiceList = []
                this.grpcServiceForm = {
                  grpcClass: '',
                  grpcServiceName: '',
                  grpcServiceNickName: '',
                  id: '',
                  nodes: []
                }
                this.getGrpcServiceList()
                this.getgrpcServiceGroupList()
                this.getnodesList()
              }
            }.bind(this)).catch(e => {
              Message.error(e)
              this.loadingFlag = false
            })
          }).catch(_ => {
          })
      }
    },
    handleUpdate(row) {
      this.getnodesList()
      this.getgrpcServiceGroupList()
      this.updateGrpcServiceDicTitle = '修改' + row.grpcServiceNickName
      this.updateGrpcService = row.grpcServiceNickName
      this.grpcServiceForm = {
        grpcClass: row.grpcClass,
        grpcServiceName: row.grpcServiceName,
        grpcServiceNickName: row.grpcServiceNickName,
        operator: this.name,
        env: this.enviroment,
        id: row.id,
        nodes: []
      }
      for (const i of row.nodes) {
        for (const j in this.nodesGroupList) {
          //  console.log('i,j',i.dictionaryName,this.grpcServiceGroupList[j].label)
          if ((i.nodeName) === this.nodesGroupList[j].label) {
            this.seletctnodesList.push(parseInt(j))
          }
        }
      }
      console.log('seletctnodesList', this.seletctnodesList)
      //   console.log('this.seletctGrpcServiceList',this.seletctGrpcServiceList)
      this.markSelectNodeList = this.seletctnodesList
      this.updateGrpcServiceDicDialogFlag = true
    },
    doGrpcServiceInsert() {
      this.$refs['grpcServiceForm'].validate((valid) => {
        if (valid) {
          if (this.seletctnodesList.length === 0) {
            Message.error('数据输入不全！')
          } else {
            this.$confirm('确认提交?')
              .then(_ => {
                this.loadingFlag = true
                const selectNodeList = []
                for (const i of this.seletctnodesList) {
                  selectNodeList.push(this.nodeList[i])
                }
                console.log('selectNodeList', selectNodeList, this.grpcServiceList, this.seletctGrpcServiceList)
                const insertdata =
              {
                grpcClass: this.grpcServiceForm.grpcClass,
                operator: this.name,
                env: this.enviroment,
                grpcServiceName: this.grpcServiceForm.grpcServiceName,
                grpcServiceNickName: this.grpcServiceForm.grpcServiceNickName,
                nodes: selectNodeList
              }
              // console.log('asdasda', seletctnodesListA, selectNodeList)
                queryGrpcServiceInsert(insertdata).then(response => {
                  this.loadingFlag = false
                  console.log('response:', response)
                  if (response.errorCode === 'NO_ERR') {
                    Message.success('添加成功')
                    this.getGrpcServiceList()
                    this.getgrpcServiceGroupList()
                    this.getnodesList()
                    this.actDialogFlag = false
                    this.seletctnodesList = []
                    this.seletctGrpcServiceList = []
                    this.grpcServiceForm = {
                      grpcClass: '',
                      grpcServiceName: '',
                      grpcServiceNickName: '',
                      id: '',
                      nodes: []
                    }
                  } else {
                    Message.error(response.errorCode + ':' + response.messageInfo)
                  }
                }).catch(e => {
                  Message.error(e)
                  this.loadingFlag = false
                })
              })
              .catch(_ => {
              })
          }
        }
      })
    },
    filtermethod(query, item) {
      return item.label.indexOf(query) > -1
    },
    getgrpcServiceGroupList() {
      this.loadingFlag = true
      queryGrpcService('', '', '', '', '', this.enviroment).then(response => {
        this.loadingFlag = false
        console.log('response:', response)
        this.grpcServiceGroupList = []
        this.grpcServiceList = []
        if (JSON.stringify(response.data) !== '{}') {
          response.data.grpcServiceList.forEach(
            (item, index) => {
              this.grpcServiceGroupList.push({
                label: item.grpcServiceNickName,
                key: index,
                ids: item.id
              })
              this.grpcServiceList.push(item)
            })
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    getnodesList() {
      this.loadingFlag = true
      queryGrpcNodes('', '', '', this.enviroment).then(response => {
        this.loadingFlag = false
        console.log('nodesdata', response)
        if (response.code === 0) {
          this.nodesGroupList = []
          this.nodeList = []
          response.data.grpcNodesList.forEach(
            (item, index) => {
              this.nodeList.push(item)
              this.nodesGroupList.push({
                label: item.nodeName,
                key: index,
                ids: item.id,
                disabled: false
              })
            })
          // for (const i in response.data.grpcNodesList) {
          //   this.nodeList.push(response.data.grpcNodesList[i])
          //   this.nodesGroupList.push({
          //     label: response.data.grpcNodesList[i].hosts + ':' + response.data.grpcNodesList[i].port,
          //     key: i,
          //     ids: response.data.grpcNodesList[i].id,
          //     disabled: false
          //   })
          // }
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.actDialogFlag = false
          this.updateGrpcServiceDicDialogFlag = false
          this.seletctnodesList = []
          this.seletctGrpcServiceList = []
          done()
        })
        .catch(_ => {})
    },
    handleInsert() {
      this.getnodesList()
      this.getgrpcServiceGroupList()
      this.actDialogFlag = true
    },
    hasPermission() {
      const ROLES = ['admin', 'GrpcServiceNodespageButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    getGrpcServiceList() {
      this.loadingFlag = true
      queryGrpcService(this.inputPort, this.inputHost, this.inputgrpcServiceNickName, this.inputgrpcServiceName, this.inputNodeName, this.enviroment).then(response => {
        this.loadingFlag = false
        console.log('data', response)
        if (response.code === 0) {
          this.grpcServiceData = response.data.grpcServiceList.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    }
  }
}
</script>
<style scoped>
.backGroundClass{
    background-color: rgba(115, 238, 121, 0.205)
}
.envTable{
    float: right;
    font-size: 30px;
    background-color: rgba(255, 181, 179, 0.3);
    padding: 10px;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>