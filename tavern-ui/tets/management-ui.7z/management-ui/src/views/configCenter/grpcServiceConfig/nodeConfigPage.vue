<template>
<div class="app-container">
    <el-card class="backGroundClass">
                           <div class="envTable">
            <span class="title">当前环境：</span>
            <el-select v-model="enviroment" @change="changeEnv">
                                                            <el-option
                                                                v-for="item in envlist"
                                                                :key="item.id"
                                                                :label="item.remark"
                                                                :value="item.env"
                                                            >
                                                                </el-option>
                                                        </el-select>
                     </div>
<el-form :inline="true" @submit.native.prevent>
                <el-form-item class="form-wrapper-item" label="节点名称" label-width="110px">
                    <el-input v-loading.body="loadFlag" @keyup.enter.native="getGrpcServiceList" v-model="inputNodeName" size="mini"></el-input>
                </el-form-item>       
                <el-form-item class="form-wrapper-item" label="节点服务器地址" label-width="110px">
                    <el-input v-loading.body="loadFlag" @keyup.enter.native="getNodeData" v-model="inputHost" size="mini"></el-input>
                </el-form-item>                
                <el-form-item class="form-wrapper-item" label="节点端口号" label-width="110px">
                    <el-input v-loading.body="loadFlag" @keyup.enter.native="getNodeData" v-model="inputPort" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button v-loading.body="loadFlag" type="primary" @click="getNodeData" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox">
            <el-button v-if="hasPermission()" v-loading.body="loadFlag" type="default" size="mini" class="tool-item" @click="handleInsert">
                <i class="el-icon-edit">添加</i>
            </el-button>
        </div>
        <el-table 
        ref="singleTable" 
        :data="nodeListData" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
            <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
            <el-table-column  property="nodeName" label="节点名称"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column  property="hosts" label="服务器地址"  header-align="center"  align="left"  ></el-table-column>
        <el-table-column  property="port" label="端口"  header-align="center"  align="left"  ></el-table-column>
            <el-table-column v-if="hasPermission()" fixd="right" label="操作"  header-align="center"  align="center" >
                <template slot-scope="scope">
                    <el-button v-loading.body="loadFlag" type="warning" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="loadFlag"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleNodeDelete(scope.row)"
                                                        v-loading.body="loadFlag"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
          <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="updateTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
            <el-table-column property="createdTime" label="修改时间"  header-align="center"  align="left"  >
            </el-table-column>
        </el-table>
        <el-dialog
                title="添加节点"
                :visible.sync="actDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                  <el-form
                  :model="NodeForm"
                  :inline="true"
                   ref="NodeForm">
                                     <el-form-item
                prop="nodeName"
                label="节点名称"
                :rules="{required: true, message: '请输入节点名称'}"
                style="width:200px"
            >
                <el-input v-model="NodeForm.nodeName"></el-input>
                </el-form-item>
                  <el-form-item
                prop="hosts"
                label="服务器地址"
                :rules="{required: true, message: '请输入服务器地址'}"
                style="width:200px"
            >
                <el-input v-model="NodeForm.hosts"></el-input>
                </el-form-item>
                  <el-form-item
                prop="port"
                label="节点端口"
                :rules="{required: true, message: '请输入节点端口'}"
                style="width:200px"
            >
                <el-input v-model="NodeForm.port"></el-input>
                </el-form-item>
                  </el-form>
                
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doNodeInsert()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
                title="更新节点"
                :visible.sync="updateNodeDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-form
                  :model="NodeForm"
                  :inline="true"
                   ref="NodeForm">
                    <el-form-item
                prop="nodeName"
                label="节点名称"
                :rules="{required: true, message: '请输入节点名称'}"
                style="width:200px"
            >
                <el-input v-model="NodeForm.nodeName"></el-input>
                </el-form-item>
                  <el-form-item
                prop="hosts"
                label="服务器地址"
                :rules="{required: true, message: '请输入服务器地址'}"
                style="width:200px"
            >
                <el-input v-model="NodeForm.hosts"></el-input>
                </el-form-item>
                  <el-form-item
                prop="port"
                label="节点端口"
                :rules="{required: true, message: '请输入节点端口'}"
                style="width:200px"
            >
                <el-input v-model="NodeForm.port"></el-input>
                </el-form-item>
                  </el-form>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doNodeUpdate()">确定</el-button>
        </span>
        </el-dialog>
    </el-card>
    </div>
</template>
<script>
let enviroment = ''
import { mapGetters } from 'vuex'
import {
  queryGrpcNodes,
  queryGrpcNodesDelete,
  queryGrpcNodesInsert,
  queryGrpcNodesUpdate,
  envDialog
} from '@/api/config'
import {
  Message
} from 'element-ui'
export default {
  name: 'nodeConfigPage',
  data() {
    return {
      inputHost: '',
      envlist: [],
      envShow: '',
      enviroment: '',
      inputPort: '',
      inputNodeName: '',
      loadFlag: false,
      NodeForm: {
        id: '',
        hosts: '',
        port: '',
        nodeName: '',
        env: this.enviroment,
        operator: this.name
      },
      nodeListData: [],
      actDialogFlag: false,
      updateNodeDialogFlag: false
    }
  },
  created() {
    this.envList()
  },
  wathc: {
    enviroment() {
      this.DomainForm.env = enviroment
      this.enviroment = enviroment
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  methods: {
    changeEnv() {
      enviroment = this.enviroment
      if (process.env.NODE_ENV === 'development') {
        if (this.enviroment === 'dev') {
          this.envShow = 'dev1'
        }
        if (this.enviroment === 'sit') {
          this.envShow = 'dev2'
        }
      } else {
        this.envShow = this.enviroment
      }
      this.getNodeData()
    },
    envList() {
      envDialog().then(function(response) {
        if (JSON.stringify(response.payload) !== '{}') {
          if (process.env.NODE_ENV === 'development') {
            for (const i of response.payload.env) {
              if (i.env === 'dev') {
                this.envShow = 'dev1'
                i.remark = 'dev1'
              }
              if (i.env === 'sit') {
                this.envShow = 'dev2'
                i.remark = 'dev2'
              }
            }
          } else {
            for (const i of response.payload.env) {
              this.envShow = i.env
              i.remark = i.env
            }
          }
          this.envlist = response.payload.env
        }
        if (this.envlist.length > 1)enviroment = this.envlist[1].env
        else enviroment = this.envlist[0].env
        if (process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'productiongq' || process.env.NODE_ENV === 'productionxy')enviroment = this.envlist[0].env
        console.log('env', enviroment)
        this.enviroment = enviroment
        this.getNodeData()
      }.bind(this))
    },
    hasPermission() {
      const ROLES = ['admin', 'nodeConfigPageButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    getNodeData() {
      this.loadFlag = true
      queryGrpcNodes(this.inputPort, this.inputHost, this.inputNodeName, this.enviroment).then(Response => {
        this.loadFlag = false
        console.log('nodeList:', Response)
        if (Response.code === 0) {
          this.nodeListData = Response.data.grpcNodesList
        } else {
          Message.error(Response.errorCode + ':' + Response.messageInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadFlag = false
      })
    },
    handleInsert() {
      this.NodeForm = {
        id: '',
        hosts: '',
        port: '',
        nodeName: '',
        env: this.enviroment,
        operator: this.name
      }
      this.actDialogFlag = true
    },
    handleUpdate(row) {
      this.NodeForm = {
        id: row.id,
        hosts: row.hosts,
        port: row.port,
        nodeName: row.name,
        env: row.enviroment,
        operator: this.name
      }
      this.updateNodeDialogFlag = true
    },
    handleNodeDelete(row) {
      const nodeId = row.id
      this.loadFlag = true
      queryGrpcNodesDelete(nodeId).then(Response => {
        this.loadFlag = false
        console.log('delete:', Response)
        if (Response.errorCode === 'NO_ERR') {
          Message.success('删除成功')
          this.getNodeData()
          this.actDialogFlag = false
        } else {
          Message.error(Response.errorCode + ':' + Response.messageInfo)
        }
      }).catch(e => {
        Message.error(e)
        this.loadFlag = false
      })
    },
    doNodeInsert() {
      this.$refs['NodeForm'].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.loadFlag = true
              queryGrpcNodesInsert(this.NodeForm).then(Response => {
                this.loadFlag = false
                console.log('indert:', Response)
                if (Response.errorCode === 'NO_ERR') {
                  Message.success('添加成功')
                  this.getNodeData()
                  this.actDialogFlag = false
                } else {
                  Message.error(Response.errorCode + ':' + Response.messageInfo)
                }
              }).catch(e => {
                Message.error(e)
                this.loadFlag = false
              })
            }).catch(_ => {
            })
        }
      })
    },
    doNodeUpdate() {
      this.$refs['NodeForm'].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.loadFlag = true
              queryGrpcNodesUpdate(this.NodeForm).then(Response => {
                this.loadFlag = false
                console.log('indert:', Response)
                if (Response.errorCode === 'NO_ERR') {
                  Message.success('修改成功')
                  this.getNodeData()
                  this.updateNodeDialogFlag = false
                } else {
                  Message.error(Response.errorCode + ':' + Response.messageInfo)
                }
              }).catch(e => {
                Message.error(e)
                this.loadFlag = false
              })
            }).catch(_ => {
            })
        }
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.actDialogFlag = false
          this.updateNodeDialogFlag = false
          done()
        })
        .catch(_ => {})
    }
  }
}
</script>
<style scoped>
.backGroundClass{
    background-color: rgba(115, 219, 238, 0.205)
}
.envTable{
    float: right;
    font-size: 30px;
    background-color: rgba(255, 181, 179, 0.3);
    padding: 10px;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
