<template>
    <div class="app-container">
        <el-card>
            <el-table
            ref="systemList"
		    :data="list"
		    style="width: 100%"
		    :border="true"
		    :stripe="true"
		    resizable>
            <el-table-column label="名称"
            prop="name"
            width=120>
            <template slot-scope="scope">
                <span>
                    {{systemTable[scope.row.name]}}
                </span>
            </template>
            </el-table-column>
            <el-table-column label="信息"
            prop="info"></el-table-column>
            <el-table-column label="开始时间"
            width="160"
            prop="startAt"></el-table-column>
            <el-table-column label="结束时间"
            width="160"
            prop="endAt"></el-table-column>
            <el-table-column label="修改人"
            width="100"
            prop="operator"></el-table-column>
            <el-table-column label="修改时间"
            width="160"
            prop="updateTime"></el-table-column>
		    <el-table-column fixd="right" label="操作"  header-align="center"  align="center" width="120">
                <template slot-scope="scope">
                    <el-button v-if="hasPermission()"  type="default" size="mini" class="tool-item" @click="handleChange(scope.row)">
	                <i class="el-icon-edit">修改</i>
	                </el-button>
                </template>
		    </el-table-column>
            </el-table>
        <el-dialog
        title="修改系统开关"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="systemInfoForm"
            ref="systemInfoForm"
        >
        <div>
<el-form-item  label="开始时间" label-width="120px" prop="startAt">
    <el-date-picker v-model="systemInfoForm.startAt" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
</el-form-item>
<el-form-item  label="结束时间" label-width="100px" prop="endAt">
    <el-date-picker v-model="systemInfoForm.endAt" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
</el-form-item>
        </div>         
            <el-form-item
                prop="info"
                label-width="100px"
                label="信息"
                class="textarea"
                :rules="{required: true, message: '请输入信息'}"
            >
                <el-input :rows = "3" class="textarea" type="textarea" v-model="systemInfoForm.info"></el-input>
                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doChanger('systemInfoForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
        </el-card>
    </div>
</template>
<script>
import {
  getSystemOfflineInfo,
  setSystemOfflineInfo } from '@/api/config'
import { mapGetters } from 'vuex'
import Axios from 'axios'
import { dateTimeFormat } from '@/store/date'
import {
  Message
} from 'element-ui'
export default {
  name: 'SystemOfflineControl',
  data() {
    return {
      systemTable: {
        credit: '融资融券柜台',
        trade: '集中交易柜台',
        ifs: '财富账户系统',
        xy: '新意',
        counter: 'T2多金柜台',
        option: '期权'
      },
      systemInfoForm: {
        startAt: '',
        endAt: '',
        info: '',
        operator: this.name,
        updateTime: ''
      },
      listloadingFlag: false,
      list: [],
      systemName: '',
      isdalog: false
    }
  },
  created() {
    this.getSysteminfo()
  },
  methods: {
    doChanger(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.listLoading = true
              this.systemInfoForm.operator = this.name
              this.initStartTime()
              setSystemOfflineInfo(this.systemName, this.systemInfoForm).then(response => {
                this.listloadingFlag = false
                console.log('setSystemOfflineInfo', response)
                if (response.code === 0) {
                  Message.success('修改成功！')
                  this.getSysteminfo()
                  this.isdalog = false
                } else {
                  Message.error(response.code + ':' + response.info)
                }
              }).catch(e => {
                Message.error(e)
                this.listloadingFlag = false
              })
            })
            .catch(_ => {

            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleChange(row) {
      this.systemName = row.name
      this.systemInfoForm.startAt = row.startAt
      this.systemInfoForm.endAt = row.endAt
      this.systemInfoForm.info = row.info
      //   this.systemInfoForm.startAt = row.startAt
      //   this.systemInfoForm.startAt = row.startAt
      //   this.systemInfoForm.startAt = row.startAt
      this.isdalog = true
    },
    formatStartTime: function(val) {
      this.systemInfoForm.startAt = dateTimeFormat(val)
    },
    formatEndTime: function(val) {
      this.systemInfoForm.endAt = dateTimeFormat(val)
    },
    initStartTime: function() {
      var nowTime = new Date()
      this.systemInfoForm.updateTime = dateTimeFormat(nowTime)
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          done()
        })
        .catch(_ => {})
    },
    getSysteminfo() {
      this.listloadingFlag = true
      const requestGroup = []
      this.list = []
      //   console.log(this.systemTable)
      for (const i in this.systemTable) {
        requestGroup.push(
          getSystemOfflineInfo(i).then(response => {
            this.listloadingFlag = false
            console.log('getSystemOfflineInfo', response)
            if (response.code === 0) {
              response.data[0]['name'] = i
              this.list.push(response.data[0])
            } else {
              Message.error(response.code + ':' + response.info)
            }
          }).catch(e => {
            Message.error(e)
            this.listloadingFlag = false
          })
        )
        Axios.all(requestGroup).then(response => {
          console.log('list', this.list)
        })
      }
    },
    hasPermission() {
      const ROLES = ['admin', 'SystemOfflineControlButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  }
}
</script>

<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.textarea{
    width: 300%;
}
</style>