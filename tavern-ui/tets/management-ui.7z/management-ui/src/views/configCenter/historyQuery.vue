<template>
    <div class="app-container">
        <el-card>
            <el-form :inline="true" @submit.native.prevent>
                <el-form-item label="名称">
<el-input  @keyup.enter.native="getHistory" v-model="formData.objectName" size="mini"></el-input>
                </el-form-item>
                <el-form-item label="上级名称">
<el-input  @keyup.enter.native="getHistory" v-model="formData.dependenceName" size="mini"></el-input>
                </el-form-item>
                <el-form-item label="类型">
                             <el-select v-model="formData.objectType">
                                                            <el-option
                                                                v-for="item in objectTypeTable"
                                                                :key="item.value"
                                                                :label="item.name"
                                                                :value="item.value"
                                                            >
                                                                </el-option>
                                                        </el-select>
                </el-form-item>
                <el-form-item label="环境">
            <el-select v-loading.body="listloadingFlag" v-model="formData.env">
                                                            <el-option
                                                                v-for="item in envlist"
                                                                :key="item.id"
                                                                :label="item.remark"
                                                                :value="item.env"
                                                            >
                                                                </el-option>
                                                        </el-select>
                </el-form-item>
                <el-form-item label="操作类型">
                             <el-select v-model="formData.operation">
                                                            <el-option
                                                                v-for="item in operationTable"
                                                                :key="item.value"
                                                                :label="item.name"
                                                                :value="item.value"
                                                            >
                                                                </el-option>
                                                        </el-select>
                </el-form-item>
                <el-form-item label="操作员">
<el-input  @keyup.enter.native="getHistory" v-loading.body="listloadingFlag" v-model="formData.operator" size="mini"></el-input>
                </el-form-item>
                <div>
<el-form-item  label="开始时间"  prop="startAt">
    <el-date-picker v-loading.body="listloadingFlag" v-model="beginTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
</el-form-item>
<el-form-item  label="结束时间"  prop="endAt">
    <el-date-picker v-loading.body="listloadingFlag" v-model="endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
</el-form-item>
<el-form-item  label="结束时间"  prop="endAt">
    <el-button type="primary" @click="getHistory()" size="mini" v-loading.body="listloadingFlag">查询</el-button>
</el-form-item>
                </div>
            </el-form>
            <el-table
            ref="systemList"
		    :data="list"
		    style="width: 100%"
		    :border="true"
		    :stripe="true"
		    resizable>
            <el-table-column label="名称"
            prop="objectName"
            width=120>
            </el-table-column>
            <el-table-column label="类型"
            prop="objectType"></el-table-column>
            <el-table-column label="上级名称"
            prop="dependenceName"></el-table-column>
            <el-table-column label="环境"
            width="160"
            prop="env"></el-table-column>
            <el-table-column label="操作之前值"
            width="160"
            prop="preData"></el-table-column>
            <el-table-column label="操作之后值"
            width="160"
            prop="nowData"></el-table-column>
            <el-table-column label="操作类型"
            width="160"
            prop="operation"></el-table-column>
            <el-table-column label="修改人"
            width="100"
            prop="operator"></el-table-column>
            <el-table-column label="修改时间"
            width="160"
            prop="operationTime"></el-table-column>
            </el-table>
        </el-card>
    </div>
</template>
<script>
import {
  queryHistory,
  envDialog } from '@/api/config'
import { mapGetters } from 'vuex'
import { dateTimeFormat } from '@/store/date'
import {
  Message
} from 'element-ui'
let enviroment = ''
export default {
  name: 'historyQuery',
  data() {
    return {
      objectTypeTable: [{ name: '属性', value: 'property' }, { name: '域名', value: 'domain' }, { name: '模块', value: 'module' },
        { name: '字典项', value: 'dictionary' }, { name: 'grpc服务', value: 'grpcService' }, { name: 'grpc节点', value: 'grpcNode' }, { name: '业务域', value: 'biz' }],
      operationTable: [{ name: '修改', value: 'update' }, { name: '添加', value: 'insert' }, { name: '删除', value: 'delete' }],
      formData: {
        objectName: '',
        objectType: 'property',
        dependenceName: '',
        env: '',
        operation: 'update',
        operator: ''
      },
      beginTime: '',
      endTime: '',
      listloadingFlag: false,
      list: [],
      systemName: '',
      isdalog: false,
      envShow: '',
      envlist: []
    }
  },
  created() {
    // this.getSysteminfo()
    this.getenvList()
    this.initStartTime()
    this.initendTime()
  },
  methods: {
    getenvList() {
      envDialog().then(function(response) {
        if (JSON.stringify(response.payload) !== '{}') {
          if (process.env.NODE_ENV === 'development') {
            for (const i of response.payload.env) {
              if (i.env === 'dev') {
                this.envShow = 'dev1'
                i.remark = 'dev1'
              }
              if (i.env === 'sit') {
                this.envShow = 'dev2'
                i.remark = 'dev2'
              }
            }
          } else {
            for (const i of response.payload.env) {
              this.envShow = i.env
              i.remark = i.env
            }
          }
          this.envlist = response.payload.env
          this.envlist.push({
            id: '1111x',
            show: 'all',
            env: 'all'
          })
        }
        if (this.envlist.length > 1)enviroment = this.envlist[1].env
        else enviroment = this.envlist[0].env
        if (process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'productiongq' || process.env.NODE_ENV === 'productionxy') {
          enviroment = this.envlist[0].env
          this.envShow = this.envlist[0].env
        }
        console.log('env', enviroment)
        this.formData.env = enviroment
      }.bind(this))
    },
    // doChanger(formName) {
    //   this.$refs[formName].validate((valid) => {
    //     if (valid) {
    //       this.$confirm('确认提交?')
    //         .then(_ => {
    //           this.listloadingFlag = true
    //           this.systemInfoForm.operator = this.name
    //           this.initStartTime()
    //           setSystemOfflineInfo(this.systemName, this.systemInfoForm).then(response => {
    //             this.listloadingFlag = false
    //             console.log('setSystemOfflineInfo', response)
    //             if (response.code === 0) {
    //               Message.success('修改成功！')
    //               this.getSysteminfo()
    //               this.isdalog = false
    //             } else {
    //               Message.error(response.code + ':' + response.info)
    //             }
    //           }).catch(e => {
    //             Message.error(e)
    //             this.listloadingFlag = false
    //           })
    //         })
    //         .catch(_ => {

    //         })
    //     } else {
    //       console.log('error submit!')
    //     }
    //   })
    // },
    handleChange(row) {
    //   this.systemName = row.name
    //   this.systemInfoForm.startAt = row.startAt
    //   this.systemInfoForm.endAt = row.endAt
    //   this.systemInfoForm.info = row.info
    //   //   this.systemInfoForm.startAt = row.startAt
    //   //   this.systemInfoForm.startAt = row.startAt
    //   //   this.systemInfoForm.startAt = row.startAt
    //   this.isdalog = true
    },
    formatStartTime: function(val) {
      this.beginTime = dateTimeFormat(val)
    },
    formatEndTime: function(val) {
      this.endTime = dateTimeFormat(val)
    },
    initStartTime: function() {
      var nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.beginTime = dateTimeFormat(nowTime)
    },
    initendTime: function() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.endTime = dateTimeFormat(nowTime)
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          done()
        })
        .catch(_ => {})
    },
    getHistory() {
      this.listloadingFlag = true
      queryHistory(this.formData, this.beginTime, this.endTime).then(response => {
        this.listloadingFlag = false
        console.log('queryHistory', response)
        if (response.code === 0) {
          this.list = response.data
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch(e => {
        Message.error(e)
        this.listloadingFlag = false
      })
    },
    hasPermission() {
      const ROLES = ['admin', 'SystemOfflineControlButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  }
}
</script>

<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.textarea{
    width: 300%;
}
</style>