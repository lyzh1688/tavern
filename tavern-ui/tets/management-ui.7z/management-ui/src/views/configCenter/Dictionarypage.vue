<template>
<div class="app-container">
    <el-card>
<el-form :inline="true" @submit.native.prevent>
                <el-form-item class="form-wrapper-item" label="字典名称">
                    <el-input v-loading.body="LoadingFlag" @keyup.enter.native="getDictionaryList" v-model="inputGroupName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="源名称">
                    <el-input v-loading.body="LoadingFlag" @keyup.enter.native="getDictionaryList" v-model="inputSource" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="字典方向">
                    <el-input v-loading.body="LoadingFlag" @keyup.enter.native="getDictionaryList" v-model="inputDirection" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="描述">
                    <el-input v-loading.body="LoadingFlag" @keyup.enter.native="getDictionaryList" v-model="inputRemark" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button v-loading.body="LoadingFlag" type="primary" @click="getDictionaryList" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox">
            <el-button v-if="hasPermission()" v-loading.body="LoadingFlag" type="default" size="mini" class="tool-item" @click="handleInsert">
                <i class="el-icon-edit">添加</i>
            </el-button>
        </div>
        <el-table
        size="mini"
		    ref="moduleDomainList"
		    :data="dictionaryData"
		    highlight-current-row
		    style="width: 100%"
		    :border="true"
		    :stripe="true"
		    resizable>
		    <el-table-column type="index" width="50%"  header-align="center"  align="left"></el-table-column>
            <el-table-column type="expand" >
                <template slot-scope="props">
                    <el-table
                    :stripe="true"
                    size="mini"
		            ref="proTable"
                    class="propertiesTable"
		            :data="props.row.value"
                    width=100%
		            :border="true"
		            resizable>
		<el-table-column type="index" width="50%"  header-align="center"  align="left" ></el-table-column>
		<el-table-column property="source" label="源"  header-align="center"  align="left"  ></el-table-column>
		<el-table-column property="target" label="目标"  header-align="center"  align="left">
		</el-table-column>
		<el-table-column property="direction" label="转换方向"  header-align="center"  align="left">
		</el-table-column>
		<el-table-column property="remark" label="描述"  header-align="center"  align="left">
		</el-table-column> 
		<el-table-column v-if="hasPermission()" fixd="right" label="操作"  header-align="center"  align="center" width="200px">
            <template slot-scope="scope">
                <el-button v-loading.body="LoadingFlag" type="warning" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                    <i class="el-icon-edit">修改</i> 
                </el-button>
                <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="LoadingFlag"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleModuleDicDelete(scope.row)"
                                                        v-loading.body="LoadingFlag"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
            </template>
		</el-table-column>
    <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updatedTime" label="修改时间"  header-align="center"  align="left"  width="300px">
            </el-table-column>
        </el-table>
	            </template>
            </el-table-column>
		    <el-table-column property="name" label="字典名称"  header-align="center"  align="left"></el-table-column>
	    </el-table>
        <el-dialog
                title="添加模块字典对应关系"
                :visible.sync="actDialogFlag"
                :before-close="handleColse"
                >
             <el-form
            :inline="true"
            :model="dictionaryForm"
            ref="dictionaryForm"
        >
            <el-form-item
                prop="groupName"
                label="字典名称"
                :rules="{required: true, message: '请输入字典名称'}"
                style="min-width:200px;"
            >
            <span>点击选择已有字典，自行输入则新建字典</span>
            <el-autocomplete
            v-model="dictionaryForm.groupName"
            :fetch-suggestions="querySearch"
            @select="handleinsertSelect"></el-autocomplete>
                <!-- <el-input v-model="dictionaryForm.key"></el-input> -->
                </el-form-item>
                <el-form-item
                prop="source"
                label="源值"
                :rules="{required: true, message: '请输入源值'}"
                style="min-width:200px;"
            >
                <el-input type="textarea" autosize v-model="dictionaryForm.source"></el-input>
                </el-form-item>
                <el-form-item
                prop="target"
                label="目标值"
                :rules="{required: true, message: '请输入目标值'}"
                style="min-width:200px;"
            >
                <el-input type="textarea" autosize v-model="dictionaryForm.target"></el-input>
                </el-form-item>
                                <el-form-item
                prop="direction"
                label="字典方向"
                :rules="{required: true, message: '请输入字典方向'}"
                style="min-width:200px;"
            >
            <el-select v-model="dictionaryForm.direction">
                                                            <el-option
                                                                v-for="item in directionTable"
                                                                :key="item"
                                                                :label="item"
                                                                :value="item"
                                                            >
                                                                </el-option>
                                                        </el-select>
                </el-form-item>
                <el-form-item
                prop="remark"
                label="字典项名称"
                :rules="{required: true, message: '请输入描述'}"
                style="min-width:200px;"
            >
                <el-input type="textarea" autosize v-model="dictionaryForm.remark"></el-input>
                </el-form-item>
                                                                        </el-form>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doDictionaryInsert()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
                :title="updateModuleDicTitle"
                :visible.sync="updateModuleDicDialogFlag"
                :before-close="handleColse"
                >
                <el-form
            :inline="true"
            :model="dictionaryForm"
            ref="dictionaryForm"
        >
                <el-form-item
                prop="target"
                label="目标值"
                :rules="{required: true, message: '请输入目标值'}"
                style="min-width:200px;"
            >
                <el-input type="textarea" autosize v-model="dictionaryForm.target"></el-input>
                </el-form-item>
                <el-form-item
                prop="remark"
                label="字典项名称"
                :rules="{required: true, message: '请输入描述'}"
                style="min-width:200px;"
            >
                <el-input type="textarea" autosize v-model="dictionaryForm.remark"></el-input>
                </el-form-item>
                                                                        </el-form>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doModuleDicUpdate()">确定</el-button>
        </span>
        </el-dialog>
    </el-card>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import {
  queryDictionary,
  insertDictionary,
  updateDictionary,
  deletDictionary,
  queryDictionaryGroup
} from '@/api/config'
import {
  Message
} from 'element-ui'
export default {
  name: 'Dictionarypage',
  data() {
    return {
      dictionaryData: [],
      LoadingFlag: false,
      inputGroupName: '',
      inputSource: '',
      inputDirection: '',
      inputRemark: '',
      actDialogFlag: false,
      moduleList: [],
      dictionaryGroupList: [],
      dictionaryForm: {
        groupName: '',
        target: '',
        operator: '',
        groupId: '',
        source: '',
        direction: '',
        remark: ''
      },
      seletctModuleList: [],
      seletctDictionarList: [],
      updateModuleDicTitle: '',
      updateModule: {},
      updateModuleDicDialogFlag: false,
      markModuleDicList: [],
      directionTable: ['ZT_XY', 'ZT_CF', 'XY_ZT', 'CF_ZT']
    }
  },
  created() {
    // this.LoadingFlag = false
    this.getDictionaryList()
    this.getdictionaryGroupLis
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  methods: {
    querySearch(queryString, cb) {
      const tmpDictionaryGroupList = this.loadGrouplist()
      console.log('tmpDictionaryGroupList', tmpDictionaryGroupList)
      const results = queryString ? tmpDictionaryGroupList.filter(this.createFilter(queryString)) : tmpDictionaryGroupList
      cb(results)
    },
    createFilter(queryString) {
      return (tmpDictionaryGroupList) => {
        return (tmpDictionaryGroupList.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    loadGrouplist() {
      const tmp = []
      for (const i of this.dictionaryGroupList) {
        tmp.push({ value: i.name, ids: i.key })
      }
      return [...tmp]
    },
    handleinsertSelect(item) {
      this.dictionaryForm.groupId = item.ids
      console.log('item', item)
    },
    handleModuleDicDelete(row) {
      this.LoadingFlag = true
      this.dictionaryForm = JSON.parse(JSON.stringify(row))
      this.dictionaryForm.operator = this.name
      deletDictionary(this.dictionaryForm).then(response => {
        this.LoadingFlag = false
        console.log('response:', response)
        if (response.code === 0) {
          Message.success('删除成功')
          this.getDictionaryList()
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      })
    },
    doModuleDicUpdate() {
      this.$refs['dictionaryForm'].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log('form:', this.dictionaryForm)
              this.dictionaryForm.operator = this.name
              this.LoadingFlag = true
              updateDictionary(this.dictionaryForm).then(response => {
                this.LoadingFlag = false
                console.log('response:', response, this.LoadingFlag)
                if (response.code === 0) {
                  Message.success('更新成功')
                  this.getDictionaryList()
                  this.dictionaryForm = {
                    groupName: '',
                    target: '',
                    operator: '',
                    groupId: '',
                    source: '',
                    direction: '',
                    remark: ''
                  }
                  this.updateModuleDicDialogFlag = false
                } else {
                  Message.error(response.errorCode + ':' + response.errorInfo)
                }
              })
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(row) {
      this.updateModuleDicTitle = '修改' + row.remark
      this.dictionaryForm = JSON.parse(JSON.stringify(row))
      this.updateModuleDicDialogFlag = true
    },
    doDictionaryInsert() {
      // let that = this
      this.$refs['dictionaryForm'].validate((valid) => {
        if (valid) {
          if (this.dictionaryForm.groupName.indexOf('__') === -1) {
            Message.error('字典名称出错!请包含“__”')
          } else {
            if (this.dictionaryForm.groupName.split('__')[0] !== '') {
              Message.error('请以“__”开头，并加上其他字母')
            } else {
              if (this.dictionaryForm.groupName.split('__')[1] === '') {
                Message.error('“__”之后要加上其他字母')
              } else {
                this.$confirm('确认提交?')
                  .then(_ => {
                    console.log('form:', this.dictionaryForm)
                    this.dictionaryForm.operator = this.name
                    this.LoadingFlag = true
                    insertDictionary(this.dictionaryForm).then(response => {
                      this.LoadingFlag = false
                      console.log('response:', response, this.LoadingFlag)
                      if (response.code === 0) {
                        Message.success('添加成功')
                        this.dictionaryForm = {
                          groupName: this.dictionaryForm.groupName,
                          target: '',
                          operator: '',
                          groupId: this.dictionaryForm.groupId,
                          source: '',
                          direction: '',
                          remark: ''
                        }
                        this.getDictionaryList()
                        this.actDialogFlag = false
                      } else {
                        Message.error(response.errorCode + ':' + response.errorInfo)
                      }
                    })
                  })
              }
            }
          }
        } else {
          console.log('error submit!')
        }
      })
    },
    filtermethod(query, item) {
      return item.label.indexOf(query) > -1
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.actDialogFlag = false
          this.updateModuleDicDialogFlag = false
          this.seletctModuleList = []
          this.seletctDictionarList = []
          done()
        })
        .catch(_ => {})
    },
    handleInsert() {
      this.actDialogFlag = true
    },
    hasPermission() {
      const ROLES = ['admin', 'DictionarypageButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    getDictionaryList() {
      this.LoadingFlag = true
      this.dictionaryData = []
      queryDictionaryGroup().then(response => {
        this.LoadingFlag = false
        console.log('response:', response)
        this.dictionaryGroupList = []
        if (JSON.stringify(response.data) !== '{}') {
          this.dictionaryGroupList = response.data
          queryDictionary(this.inputGroupName, this.inputSource, this.inputDirection, this.inputRemark).then(response => {
            this.LoadingFlag = false
            console.log('data', response)
            let tmpList = []
            if (JSON.stringify(response.data) !== '{}' && response.data.length !== 0) {
              tmpList = response.data.map(v => {
                this.$set(v, 'deleteFlag', false)
                return v
              })
              if (this.inputGroupName === '') {
                for (const i of this.dictionaryGroupList) {
                  this.dictionaryData.push({ name: i.name, value: [] })
                }
                for (const i of tmpList) {
                  for (const j in this.dictionaryData) {
                    if (this.dictionaryData[j].name === i.groupName) {
                      this.dictionaryData[j].value.push(i)
                    }
                  }
                }
              } else {
                this.dictionaryData.push({ name: this.inputGroupName, value: [] })
                for (const i of tmpList) {
                  this.dictionaryData[0].value.push(i)
                }
              }
              console.log('dictionaryData', this.dictionaryData)
            } else {
              Message.error('未查询到数据')
            }
          })
        }
      })
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
