<template>
    <div class="app-container">
        <el-card class="module animated" >
        <span class="title">域名模块插入界面</span>
        <div class="envTable">
            <span class="title">当前环境：</span>
            <el-select v-model="enviroment" @change="changeEnv">
                                                            <el-option
                                                                v-for="item in envlist"
                                                                :key="item.id"
                                                                :label="item.remark"
                                                                :value="item.env"
                                                            >
                                                                </el-option>
                                                        </el-select>
                                                                </div>
 <el-form ref="templateNameInput" :rules="rule" :inline="true" @submit.native.prevent :model="tmplateForm">
                <el-form-item  class="form-wrapper-item" label="域名" label-width="90px" prop="templateName">
                    <el-input  v-loading.body="loadingFlag" v-model="tmplateForm.templateName" size="mini"></el-input>
                </el-form-item>
                <el-form-item  class="form-wrapper-item" label="说明" label-width="90px" prop="remark">
                    <el-input  v-loading.body="loadingFlag" v-model="tmplateForm.remark" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="模板类型" label-width="90px">
                    <el-select v-model="tmplateForm.domainType" @change="Tes">
                                                            <el-option
                                                                v-for="item in templateList"
                                                                :key="item.type"
                                                                :label="item.type"
                                                                :value="item.type"
                                                            >
                                                                </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="insertFlag"
                                            v-loading.body="loadingFlag"
                                            v-if="hasPermission()"
                                        >
                                            <p>确定添加吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="insertFlag=false"
                                                    v-loading.body="loadingFlag"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleTemplateInsert"
                                                        v-loading.body="loadingFlag"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">添加</i></el-button>
                                                </el-popover>
                </el-form-item>
        </el-form>
        <el-card>
            <header>出现红框请检查属性值输入是否完整，完整后再次点击提交则会变成绿色（formatter是选择性输入值）</header>
            <el-form :rules="rule" :model="tmplateForm" ref="templateDataInput">
                <el-form-item v-for="items in tmplateForm.templateData" :key="items.key" prop="templateData">
                    <header>{{items.key=nameformatter(items.prefix,tmplateForm.templateName,items.afterfix)}}</header>
                    <el-card style="float:left;padding:10px;">
                    <header>属性类型</header>
                    <span>{{items.configType}}</span>
                    </el-card>
                    <el-card style="float:left;padding:10px;">
                    <header>属性值</header>
                    <el-input v-loading.body="loadingFlag" v-model="items.value" size="mini"></el-input>
                    </el-card>
                    <el-card style="float:left;padding:10px;">
                    <header>formatter</header>
                    <el-input v-loading.body="loadingFlag" v-model="items.formatter" size="mini"></el-input>
                    </el-card>
                    <el-card style="float:left;padding:10px;">
                    <header>是否可用</header>
                    <el-switch v-model="items.validFlag"></el-switch>
                    </el-card>
                    <el-card style="float:left;padding:10px;">
                    <header>是否动态</header>
                    <el-switch v-model="items.dynamic"></el-switch>
                    </el-card>
                </el-form-item>
            </el-form>
        </el-card>
        </el-card>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
let enviroment = ''
import {
  envDialog,
  templateInsert
} from '@/api/config'
import {
  Message
} from 'element-ui'
export default {
  name: 'templatesDomain',
  data() {
    var that = this
    // 校验规则
    var _ruletTmplateName = (rule, value, callback) => {
      if (that.tmplateForm.templateName === '') {
        callback(new Error('请输入域名!'))
      } else {
        callback()
      }
    }
    var _ruletTmplateRemark = (rule, value, callback) => {
      if (that.tmplateForm.remark === '') {
        callback(new Error('请输入说明!'))
      } else {
        callback()
      }
    }
    var _ruleTemplateData = (rule, value, callback) => {
      console.log('value', rule)
      for (const i of that.tmplateForm.templateData) {
        if (i.value === '')callback(new Error('请输入' + i.key + '的属性值!'))
      }
      callback()
    }
    return {
      enviroment: '',
      envlist: [],
      workingENV: process.env.NODE_ENV,
      envShow: '',
      tmplateForm: {
        templateName: '',
        templateData: [],
        domainType: '',
        remark: ''
      },
      rule: {
        templateName: [{ validator: _ruletTmplateName, trigger: 'blur' }],
        templateData: [{ validator: _ruleTemplateData, trigger: 'blur' }],
        remark: [{ validator: _ruletTmplateRemark, trigger: 'blur' }]
      },
      insertFlag: false,
      loadingFlag: false,
      templateList:
      [
        { type: 'DB',
          properties: [
            { key: '', prefix: 'custom.jdbc.', afterfix: '.driverClassName', configType: 'String', value: '', formatter: '', remark: 'driverClassName', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.initialSize', configType: 'Integer', value: '', formatter: '', remark: 'initialSize', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.maxActive', configType: 'Integer', value: '', formatter: '', remark: 'maxActive', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.maxWait', configType: 'Integer', value: '', formatter: '', remark: 'maxWait', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.minIdle', configType: 'Integer', value: '', formatter: '', remark: 'minIdle', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.password', configType: 'String', value: '', formatter: '', remark: 'password', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.url', configType: 'String', value: '', formatter: '', remark: 'url', validFlag: true, dynamic: false },
            { key: '', prefix: 'custom.jdbc.', afterfix: '.username', configType: 'String', value: '', formatter: '', remark: 'username', validFlag: true, dynamic: false }
          ],
          domainType: 'DB'
        }
      ]
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    enviroment() {
      this.enviroment = enviroment
    }
  },
  created() {
    this.envList()
  },
  methods: {
    Tes(val) {
      for (const i of this.templateList) {
        if (i.type === val) {
          this.tmplateForm.templateData = i.properties
          this.tmplateForm.domainType = i.domainType
        }
      }
      console.log('test', val)
    },
    handleTemplateInsert() {
      this.insertFlag = false
      this.$refs['templateNameInput'].validate((valid) => {
        if (valid) {
          this.$refs['templateDataInput'].validate((valid1) => {
            if (valid1) {
              this.loadingFlag = true
              templateInsert(this.tmplateForm.templateData, this.tmplateForm.templateName, this.tmplateForm.domainType, this.tmplateForm.remark, this.enviroment, this.name).then(response => {
                this.loadingFlag = false
                if (response.messageFlag) {
                  this.isProUdate = false
                  Message.success('添加域名成功！')
                  this.tmplateForm.templateName = ''
                  this.tmplateForm.templateData = []
                  this.tmplateForm.domainType = ''
                  this.tmplateForm.remark = ''
                } else {
                  Message.error(response.errorCode + ':' + response.messageInfo)
                  // this.$message.error(responseS.errorCode || responseS.messageInfo)
                }
              })
            //   console.log('templateData', this.tmplateForm)
            }
          })
        }
      })
    },
    nameformatter(prefix, param, afterfix) {
      return prefix + '' + param + '' + afterfix
    },
    changeEnv() {
      enviroment = this.enviroment
      if (process.env.NODE_ENV === 'development') {
        if (this.enviroment === 'dev') {
          this.envShow = 'dev1'
        }
        if (this.enviroment === 'sit') {
          this.envShow = 'dev2'
        }
      } else {
        this.envShow = this.enviroment
      }
    },
    envList() {
      this.loadingFlag = true
      envDialog().then(function(response) {
        this.loadingFlag = false
        if (JSON.stringify(response.payload) !== '{}') {
          if (process.env.NODE_ENV === 'development') {
            for (const i of response.payload.env) {
              if (i.env === 'dev') {
                this.envShow = 'dev1'
                i.remark = 'dev1'
              }
              if (i.env === 'sit') {
                this.envShow = 'dev2'
                i.remark = 'dev2'
              }
            }
          } else {
            for (const i of response.payload.env) {
              this.envShow = i.env
              i.remark = i.env
            }
          }
          this.envlist = response.payload.env
        }
        if (this.envlist.length > 1)enviroment = this.envlist[1].env
        else enviroment = this.envlist[0].env
        if (process.env.NODE_ENV === 'sit' || process.env.NODE_ENV === 'productiongq' || process.env.NODE_ENV === 'productionxy')enviroment = this.envlist[0].env
        console.log('env', enviroment)
        this.enviroment = enviroment
      }.bind(this))
    },
    hasPermission() {
      const ROLES = ['admin', 'templatesDomainButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    }
  }
}
</script>
<style scoped>
.envTable{
    float: right;
    font-size: 30px;
    background-color: rgba(255, 181, 179, 0.3);
    padding: 10px;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
