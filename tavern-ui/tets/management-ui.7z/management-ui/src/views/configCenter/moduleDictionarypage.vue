<template>
<div class="app-container">
    <el-card>
<el-form :inline="true" @submit.native.prevent>
                <el-form-item class="form-wrapper-item" label="模块名称" label-width="90px">
                    <el-input v-loading.body="listLoading" @keyup.enter.native="getModuleDictionary" v-model="inputModuleName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="字典名称" label-width="90px">
                    <el-input v-loading.body="listLoading" @keyup.enter.native="getModuleDictionary" v-model="inputDictionaryName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button v-loading.body="listLoading" type="primary" @click="getModuleDictionary" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox">
            <el-button v-if="hasPermission()" v-loading.body="listLoading" type="default" size="mini" class="tool-item" @click="handleInsert">
                <i class="el-icon-edit">添加</i>
            </el-button>
            <el-button  v-loading.body="listLoading" type="default" size="mini" class="tool-item" @click="handledictionaryWindow">
                <i class="el-icon-edit">字典配置</i>
            </el-button>
        </div>
        <el-table 
        size="mini"
        ref="singleTable" 
        :data="ModuleDataList" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable>
            <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
            <el-table-column property="moduleName" label="模块名称"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="dictionaryName" label="包含字典"  header-align="center"  align="left" >
                <template slot-scope="scope">
                    <el-tag v-for="item in scope.row.dictionaries" :key="item.dictionaryId">{{item.dictionaryName}}</el-tag>
                </template>
            </el-table-column>
            <el-table-column v-if="hasPermission()" fixd="right" label="操作"  header-align="center"  align="center" width="200px">
                <template slot-scope="scope">
                    <el-button v-loading.body="listLoading" type="warning" size="mini" class="tool-item" @click="handleUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleModuleDicDelete(scope.row)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
          <el-table-column property="operator" label="修改用户"  header-align="center"  align="left"  width="150px">
            </el-table-column>
            <el-table-column property="updatedTime" label="修改时间"  header-align="center"  align="left"  width="200px">
            </el-table-column>
        </el-table>
        <el-dialog
                title="添加模块字典对应关系"
                :visible.sync="actDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="moduleList"
                v-model="seletctModuleList"
                :titles="['可选模块','已选模块']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="dictionaryGroupList"
                v-model="seletctDictionarList"
                :titles="['可选字典','已选字典']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doModuleDicInsert()">确定</el-button>
        </span>
        </el-dialog>
        <el-dialog
                :title="updateModuleDicTitle"
                :visible.sync="updateModuleDicDialogFlag"
                :before-close="handleColse"
                >
                <el-card>
                <el-transfer
                filterable
                :filter-method="filtermethod"
                filter-placeholder="请输入搜索名称"
                :data="dictionaryGroupList"
                v-model="seletctDictionarList"
                :titles="['可选字典','已选字典']"
                style="float:left;padding:5px;"
                >
                </el-transfer>
                </el-card>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="doModuleDicUpdate()">确定</el-button>
        </span>
        </el-dialog>
    </el-card>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import {
  queryModuleDictionary,
  insertModuleDictionary,
  deleteModuleDictionary,
  ModulesDialog,
  queryDictionaryGroup
} from '@/api/config'
import {
  Message
} from 'element-ui'
import Axios from 'axios'
export default {
  name: 'moduleDictionarypage',
  data() {
    return {
      ModuleDataList: [],
      listloading: false,
      inputModuleName: '',
      inputDictionaryName: '',
      actDialogFlag: false,
      moduleList: [],
      dictionaryGroupList: [],
      seletctModuleList: [],
      seletctDictionarList: [],
      updateModuleDicTitle: '',
      updateModule: {},
      updateModuleDicDialogFlag: false,
      markModuleDicList: []
    }
  },
  created() {
    this.listLoading = false
    this.getModuleDictionary()
    this.getdictionaryGroupList()
    this.getModuleList()
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  methods: {
    handledictionaryWindow() {
      console.log('push to:', '/configCenter/' + this.enviroment + '/domainWindow_' + this.enviroment)
      this.$router.push({ path: '/configCenter/Dictionarypage' })
    },
    handleModuleDicDelete(row) {
      this.listloading = true
      const seletctModuleListA = []
      for (const i of this.moduleList) {
        //   console.log('i', i, this.updateModule)
        if (i.label === row.moduleName) {
          seletctModuleListA.push(i)
          break
        }
      }
      const seletctDictionarListA = []
      for (const i of row.dictionaries) {
        seletctDictionarListA.push({ label: i.dictionaryName, ids: i.dictionaryId })
      }
      deleteModuleDictionary(seletctModuleListA, seletctDictionarListA, this.name).then(response => {
        this.listloading = false
        console.log('response:', response)
        if (response.code === 0) {
          Message.success('删除成功')
          this.getModuleDictionary()
          this.getdictionaryGroupList()
          this.getModuleList()
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      })
    },
    doModuleDicUpdate() {
      if (this.seletctDictionarList.length === 0) {
        // console.log('this.seletctDictionarList', this.seletctDictionarList)
        Message.error('数据输入不全！')
      } else {
        this.listloading = true
        const seletctModuleListA = []
        for (const i of this.moduleList) {
        //   console.log('i', i, this.updateModule)
          if (i.label === this.updateModule) {
            seletctModuleListA.push(i)
            break
          }
        }
        // console.log('seletctModuleListA', seletctModuleListA, this.markModuleDicList, this.seletctDictionarList)
        for (const i in this.markModuleDicList) {
          for (const j in this.seletctDictionarList) {
            if (this.markModuleDicList[i] === this.seletctDictionarList[j]) {
              this.markModuleDicList[i] = -1
              this.seletctDictionarList[j] = -1
              break
            }
          }
        }
        // console.log('seletctModuleListA', seletctModuleListA, this.markModuleDicList, this.seletctDictionarList)
        const seletctDictionarListA = []
        for (const i of this.seletctDictionarList) {
          if (i !== -1)seletctDictionarListA.push(this.dictionaryGroupList[i])
        }
        // console.log('seletctDictionarListA', seletctDictionarListA)
        const seletctDictionarListB = []
        for (const i of this.markModuleDicList) {
          if (i !== -1)seletctDictionarListB.push(this.dictionaryGroupList[i])
        }
        // console.log('seletctDictionarListB', seletctDictionarListB)
        const requestGroup = []
        const resultMark = []
        if (seletctDictionarListA.length !== 0) {
          requestGroup.push(insertModuleDictionary(seletctModuleListA, seletctDictionarListA, this.name).then(response => {
            resultMark.push({ name: 'update', response: response })
          }))
        } else {
          resultMark.push({ name: 'update', response: { code: 0 }})
        }
        if (seletctDictionarListB.length !== 0) {
          requestGroup.push(deleteModuleDictionary(seletctModuleListA, seletctDictionarListB, this.name).then(response => {
            resultMark.push({ name: 'delete', response: response })
          }))
        } else {
          resultMark.push({ name: 'delete', response: { code: 0 }})
        }
        Axios.all(requestGroup).then(function() {
          this.listloading = true
          if (!(resultMark[0].response.code === 0) && !(resultMark[1].response.code === 0)) Message.error('修改失败')
          else if (!(resultMark[0].response.code === 0) || !(resultMark[1].response.code === 0)) Message.error('部分修改失败')
          else {
            Message.success('修改成功！')
            this.getModuleDictionary()
            this.getdictionaryGroupList()
            this.getModuleList()
            this.updateModuleDicDialogFlag = false
            this.seletctModuleList = []
            this.seletctDictionarList = []
          }
        }.bind(this))
      }
    },
    handleUpdate(row) {
      this.updateModuleDicTitle = '修改' + row.moduleName + '对应字典'
      this.updateModule = row.moduleName
      for (const i of row.dictionaries) {
        for (const j in this.dictionaryGroupList) {
          //  console.log('i,j',i.dictionaryName,this.dictionaryGroupList[j].label)
          if (i.dictionaryName === this.dictionaryGroupList[j].label) {
            this.seletctDictionarList.push(parseInt(j))
          }
        }
      }
      //   console.log('this.seletctDictionarList',this.seletctDictionarList)
      this.markModuleDicList = this.seletctDictionarList
      this.updateModuleDicDialogFlag = true
    },
    doModuleDicInsert() {
      if (this.seletctModuleList.length === 0 || this.seletctDictionarList.length === 0) {
        Message.error('数据输入不全！')
      } else {
        this.listloading = true
        const seletctModuleListA = []
        for (const i of this.seletctModuleList) {
          seletctModuleListA.push(this.moduleList[i])
        }
        const seletctDictionarListA = []
        for (const i of this.seletctDictionarList) {
          seletctDictionarListA.push(this.dictionaryGroupList[i])
        }
        // console.log('asdasda', seletctModuleListA, seletctDictionarListA)
        insertModuleDictionary(seletctModuleListA, seletctDictionarListA, this.name).then(response => {
          this.listloading = false
          console.log('response:', response)
          if (response.code === 0) {
            Message.success('添加成功')
            this.getModuleDictionary()
            this.getdictionaryGroupList()
            this.getModuleList()
            this.actDialogFlag = false
            this.seletctModuleList = []
            this.seletctDictionarList = []
          } else {
            Message.error(response.errorCode + ':' + response.errorInfo)
          }
        })
      }
    },
    filtermethod(query, item) {
      return item.label.indexOf(query) > -1
    },
    getdictionaryGroupList() {
      this.listloading = true
      queryDictionaryGroup().then(response => {
        this.listloading = true
        console.log('response:', response)
        this.dictionaryGroupList = []
        if (JSON.stringify(response.data) !== '{}') {
          response.data.forEach(
            (item, index) => {
              this.dictionaryGroupList.push({
                label: item.name,
                key: index,
                ids: item.key
              })
            })
        }
      })
    },
    getModuleList() {
      this.listloading = true
      queryModuleDictionary('', '').then(response => {
        this.listloading = false
        console.log('data', response)
        if (response.code === 0) {
          ModulesDialog('').then(responses => {
            this.listloading = true
            console.log('responses:', responses)
            this.moduleList = []
            if (JSON.stringify(responses.payload) !== '{}') {
              responses.payload.module.forEach(
                (item, index) => {
                  let flag = true
                  for (const i of response.data) {
                    if (i.moduleName === item.moduleName) {
                      flag = false
                      this.moduleList.push({
                        label: item.moduleName,
                        key: index,
                        ids: item.id,
                        disabled: true
                      })
                    }
                  }
                  if (flag) {
                    this.moduleList.push({
                      label: item.moduleName,
                      key: index,
                      ids: item.id,
                      disabled: false
                    })
                  }
                }
              )
              //   this.moduleList = response.payload.module
            }
          })
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.actDialogFlag = false
          this.updateModuleDicDialogFlag = false
          this.seletctModuleList = []
          this.seletctDictionarList = []
          done()
        })
        .catch(_ => {})
    },
    handleInsert() {
      this.actDialogFlag = true
    },
    hasPermission() {
      const ROLES = ['admin', 'moduleDictionarypageButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    getModuleDictionary() {
      this.listloading = true
      queryModuleDictionary(this.inputModuleName, this.inputDictionaryName).then(response => {
        this.listloading = false
        console.log('data', response)
        if (response.code === 0) {
          this.ModuleDataList = response.data.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
        } else {
          Message.error(response.errorCode + ':' + response.errorInfo)
        }
      })
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
