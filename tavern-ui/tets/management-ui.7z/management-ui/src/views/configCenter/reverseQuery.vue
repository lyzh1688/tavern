<template>
    <div class="app-container">
      <el-card>
  <div class="wrapper-box" ref="wrapperBox">
  	<p style="font-size:30px">{{title}}</p>
  </div>
  <section class="table-container">
    <el-table
            ref="singleTable"
            :data="list"
            row-key
            style="width: 100%"
            :border="true"
            :stripe="true"
            resizable>
      <el-table-column type="index" width="30px"  header-align="center"  align="left"></el-table-column>
	  <!-- <el-table-column property="domain" label="域名"  header-align="center"  align="left"  width="300px"></el-table-column>
	  <el-table-column  property="env" label="所属环境"  header-align="center"  align="left"></el-table-column>
	  <el-table-column  property="remark" label="说明"  header-align="center"  align="left"></el-table-column> -->
      <el-table-column  property="moduleName" label="模块名称"  header-align="center"  align="left"  width="300px"></el-table-column>
      <el-table-column  property="domains" label="包含域名"  header-align="center"  align="left"></el-table-column>
    </el-table>
  </section>
  </el-card>
  	 </div>    
</template>
<script>
import { reverse } from '@/api/config'
export default {
  name: 'reverseQuery',
  data() {
    return {
      list: [],
      env: '',
      title: 'test',
      Domname: '',
      isQuery: false
    }
  },
  created() {
    if (this.$route.params.Domname !== undefined) {
      this.Domname = this.$route.params.Domname
    }
    if (this.$route.params.env !== undefined) {
      this.env = this.$route.params.env
    }
    this.title = this.env + '环境下包含' + this.Domname + '的modules'
    this.getList()
  },
  mounted() {
    this.$el.className = 'show'
  },
  methods: {
    getList: function() {
      var that = this
      if (!this.isQuery) {
        this.isQuery = true
        reverse(that.Domname).then(function(response) {
          that.isQuery = false
          that.list = response.payload.module
        })
      }
    }
  }

}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>