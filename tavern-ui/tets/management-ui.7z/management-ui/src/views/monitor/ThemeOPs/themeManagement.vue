<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true" @submit.native.prevent>
                <el-form-item>
                    <el-popover
                        placement="right"
                        width="708"
                        trigger="click"
                    >
                        <el-card>
                            <div class="header">
                                <div style="display:flex;justify-content:center">
                                    <p>列表显示内容</p>
                                </div>
                            </div>
                            <el-checkbox-group
                                v-model="checkboxVal"
                                style="float: left;"
                            >
                                <div style="display:flex;flex-wrap:wrap;justify-content:flex-end">
                                    <el-checkbox
                                        :key='item'
                                        v-for='item in formTheadOptions'
                                        :label="item"
                                        :border="true"
                                        size="small"
                                        style="width:150px"
                                    >{{$t('themePageList.'+item)}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                        </el-card>

                        <el-button
                            slot="reference"
                            style="float: left"
                            type="primary"
                            size="mini"
                        >列表内容</el-button>
                            </el-popover>
                </el-form-item>
                <el-form-item label="服务名称:">
                    <el-input
                        v-model="inputThemeName"
                        @keyup.enter.native="fetchData"
                        size="mini"
                        placeholder="请输入服务名称"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="fetchData"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="isdalog=true"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('themePageList.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item == 'artifactType'">{{scope.row[item]=='0'?'其他':(scope.row[item] =='1'?'vertx':'spring')}}</p>
                          <p v-else>{{scope.row[item]}}</p> 
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item class="buttonFOrm">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(scope.row.id)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="themeForm"
            ref="themeForm"
        >
        <el-form-item
                                prop="themeName"
                                label="主题名称"
                                :rules="[
          {required: true, message: '请输入主题名称'}
          ]"
                                style="width:200px"
                            >
                                <el-input v-model="themeForm.themeName"></el-input>
                                </el-form-item>
            <el-form-item
                prop="themeType"
                label="主题类型"
                :rules="{required: true, message: '请输入主题类型'}"
                style="width:200px"
            >
            <el-select v-model="themeForm.themeType">
                        <el-option
                            v-for="item in ThemeNameTable"
                            :key="item"
                            :label="item"
                            :value="item"
                        >
                            </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item
                                prop="level"
                                label="级别（越大优先级越高）"
                                :rules="[
          {required: true, message: '请输入级别'}
          ]"
                                style="width:200px"
                            >
                                <el-input v-model="themeForm.level"></el-input>
                                </el-form-item>
                <el-form-item
                    prop="showInPages"
                    label="主题显示页面"
                    >
                 <el-checkbox-group
                                v-model="themeForm.showInPages"
                            >
                                <div >
                                    <el-checkbox
                                    class="checkBox"
                                        :key="item"
                                        v-for="item in pageNameTable"
                                        :label="item"
                                        :border="true"
                                        size="small"
                                    >{{item}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                    </el-form-item>
                    <el-form-item
                    prop="itemsId"
                    label="主题包含模块(显示顺序和选择顺序一致)"
                    >
                 <el-checkbox-group
                                v-model="themeForm.itemsId"
                            >
                                <div >
                                    <el-checkbox
                                    class="checkBox"
                                        :key="item.name"
                                        v-for="item in moduleList"
                                        :label="item.value"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                    </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('themeForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
</div>
</template>




<script>
const defaultFormThead = ['themeName', 'themeType', 'itemsId', 'showInPages', 'level']
import {
  queryThemeByName,
  insertTheme,
  updateTheme,
  deleteTheme,
  getModuleList
} from '@/api/monitor'
export default {
  name: 'themeManagement',
  data() {
    return {
      list: null,
      moduleList: null,
      templatesList: null,
      themeForm: {
        id: '',
        itemsId: [],
        showInPages: [],
        themeName: '',
        themeType: '',
        level: '',
        user: this.$store.state.user.name
      },
      isUdate: false,
      dialogTitle: '主题添加',
      listLoading: true,
      isdalog: false,
      inputThemeName: '',
      inputModuleType: '',
      inputArtifactType: '',
      inputArtifactName: '',
      inputMonitorEnabled: true,
      inputTemplateId: '',
      ThemeNameTable: this.$store.state.dashboardTheme.themeNameList,
      pageNameTable: this.$store.state.dashboardTheme.pageNameList,
      formTheadOptions: ['id', 'itemsId', 'showInPages', 'themeName', 'themeType', 'level', 'created'],
      checkboxVal: defaultFormThead,
      formThead: ['themeName', 'themeType', 'itemsId', 'showInPages', 'level']
    }
  },
  created() {
    this.fetchData()
    this.fetchModuleData()
    console.log('created moduleList!')
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '主题修改'
      else this.dialogTitle = '主题添加'
    }
  },
  methods: {
    fetchModuleData() {
      this.listLoading = true
      if (!this.inputMonitorEnabled) this.inputMonitorEnabled = ''
      getModuleList('', '', '', true, '', '').then(response => {
        console.log(response)
        // this.moduleList = response.data.ModuleList
        this.moduleList = []
        for (const i of response.data.ModuleList) {
          this.moduleList.push({ name: i.moduleName, value: i.moduleName + ':' + i.id })
        }
        console.log(this.moduleList)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchData() {
      this.listLoading = true
      //   this.themeForm = {
      //     id: '',
      //     itemsId: [],
      //     showInPages: [],
      //     themeName: '',
      //     user: this.$store.state.user.name
      //   }
      if (!this.inputMonitorEnabled) this.inputMonitorEnabled = ''
      queryThemeByName(this.inputThemeName, this.themeForm.user).then(response => {
        console.log(response)
        this.list = response.data.ThemeList.map(v => {
          this.$set(v, 'deleteFlag', false)
          return v
        })
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.themeForm)
              if (this.themeForm.showInPages.length > 1) this.themeForm.showInPages = this.themeForm.showInPages.join(',')
              else this.themeForm.showInPages = this.themeForm.showInPages.pop()
              if (this.themeForm.itemsId.length > 1) this.themeForm.itemsId = this.themeForm.itemsId.join(',')
              else this.themeForm.itemsId = this.themeForm.itemsId.pop()
              if (this.themeForm.itemsId === undefined) this.themeForm.itemsId = ''
              if (this.themeForm.showInPages === undefined) this.themeForm.showInPages = ''
              this.listLoading = true
              if (this.isUdate) {
                return new Promise((resolve, reject) => {
                  updateTheme(this.themeForm).then(response => {
                    console.log(response)
                    this.fetchData()
                    this.listLoading = false
                    this.isUdate = false
                    this.themeForm = {
                      id: '',
                      itemsId: [],
                      showInPages: [],
                      themeName: '',
                      themeType: '',
                      user: this.$store.state.user.name
                    }
                    resolve(response)
                    this.isdalog = false
                  }).catch((error) => {
                    this.themeForm = {
                      id: '',
                      itemsId: [],
                      showInPages: [],
                      themeName: '',
                      themeType: '',
                      user: this.$store.state.user.name
                    }
                    this.listLoading = false
                    this.isUdate = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              } else {
                return new Promise((resolve, reject) => {
                  insertTheme(this.themeForm).then(response => {
                    console.log(response)
                    this.fetchData()
                    this.listLoading = false
                    this.themeForm = {
                      id: '',
                      itemsId: [],
                      showInPages: [],
                      themeName: '',
                      themeType: '',
                      user: this.$store.state.user.name
                    }
                    resolve(response)
                    this.isdalog = false
                  }).catch((error) => {
                    this.themeForm = {
                      id: '',
                      itemsId: [],
                      showInPages: [],
                      themeName: '',
                      themeType: '',
                      user: this.$store.state.user.name
                    }
                    this.listLoading = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.themeForm = Object.assign({}, rows)
      this.themeForm.user = this.$store.state.user.name
      this.themeForm.showInPages = this.themeForm.showInPages.split(',')
      this.themeForm.itemsId = this.themeForm.itemsId.split(',')
      //   for (const j of rows.itemsId.split(',')) {
      //     for (const i of this.moduleList) {
      //       console.log('j:', j === i.value)
      //       if (j === i.value) {
      //         this.themeForm.itemsId.push(i.value)
      //         break
      //       }
      //     }
      //   }
      //   console.log('itemId:', this.themeForm.itemsId)
      this.isdalog = true
      this.isUdate = true
    },
    handleDelete(id) {
      return new Promise((resolve, reject) => {
        deleteTheme(id).then(response => {
          console.log(response)
          this.fetchData()
          this.listLoading = false
          resolve(response)
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    }
  }
}
</script>



<style>
.checkBox{
    clear:right;
    float: left;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
