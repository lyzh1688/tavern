<template>
    <div class="app-container">
        <el-card>
            <el-form :inline="true">
        <el-form-item label="关心的业务域">
            <el-checkbox-group
            @change="checkVal"
            v-model="bizform.selectBizList">
            <el-checkbox-button
                        :key='item.bizName'
                        v-for='item in bizList'
                        :label="item.nicName"
                        :border="true"
                        size="small"
                        
                    >{{item.nicName}}</el-checkbox-button>
            </el-checkbox-group>
        </el-form-item>
        <el-form-item v-if="changeFlag">
            <el-button
            
                        type="primary"
                        @click="handleChange"
                        v-loading.body="listLoadingFlag"
                        size="mini"
                    >提交修改</el-button>
        </el-form-item>
            </el-form>
        </el-card>
    </div>
</template>
<script>
import store from '../../../store'
import {
  queryBizPreferByName,
  insertBizPrefer,
  updateBizPrefer,
  deleteBizPrefer
} from '@/api/monitor'
import {
  Message
} from 'element-ui'
import {
  getBizList
} from '@/api/config'
export default {
  name: 'bizPrefer',
  data() {
    return {
      listLoadingFlag: false,
      bizList: [],
      bizform: {
        selectBizList: []
      },
      selectBizListMark: ['全部'],
      selectBizListInit: [],
      bizListMap: new Map(),
      bizListIdMap: new Map(),
      changeFlag: false,
      bizIdMark: ''
    }
  },
  watch: {
  },
  created() {
    this.fetchBizList()
  },
  methods: {
    listCheck(list1, list2) {
      const tmp1 = [...list1].sort().toString()
      const tmp2 = [...list2].sort().toString()
      return tmp1 === tmp2
    },
    handleChange() {
      this.$confirm('确认提交?')
        .then(_ => {
          if (this.selectBizListInit[0] === '全部') {
            this.listLoadingFlag = true
            const tmplist = []
            for (const i of this.bizform.selectBizList) {
              tmplist.push(this.bizListMap.get(i).id)
            }
            insertBizPrefer({ bizPrefer: tmplist.join(','), user: this.$store.state.user.name }).then(response => {
              this.listLoadingFlag = false
              console.log('insertBizPrefer', response)
              if (response.code === 0) {
                Message.success('提交成功')
                store.dispatch('fetchModuleNameList')
                this.fetchBizList()
              } else {
                Message.error(response.code + ':' + response.info)
              }
            }).catch(e => {
              Message.error(e)
              this.listLoadingFlag = false
            })
          }

          if (this.selectBizListInit.length >= 1) {
            if (this.bizform.selectBizList[0] === '全部') {
              this.listLoadingFlag = true
              console.log('delete', this.selectBizListInit.length, this.bizform.selectBizList[0], this.bizIdMark)
              deleteBizPrefer(this.bizIdMark).then(response => {
                this.listLoadingFlag = false
                console.log('deleteBizPrefer', response)
                if (response.code === 0) {
                  Message.success('提交成功')
                  store.dispatch('fetchModuleNameList')
                  this.fetchBizList()
                } else {
                  Message.error(response.code + ':' + response.info)
                }
              }).catch(e => {
                Message.error(e)
                this.listLoadingFlag = false
              })
            } else {
              this.listLoadingFlag = true
              const tmplist = []
              for (const i of this.bizform.selectBizList) {
                tmplist.push(this.bizListMap.get(i).id)
              }
              updateBizPrefer({ id: this.bizIdMark, bizPrefer: tmplist.join(','), user: this.$store.state.user.name }).then(response => {
                this.listLoadingFlag = false
                console.log('updateBizPrefer', response)
                if (response.code === 0) {
                  Message.success('提交成功')
                  store.dispatch('fetchModuleNameList')
                  this.fetchBizList()
                } else {
                  Message.error(response.code + ':' + response.info)
                }
              }).catch(e => {
                Message.error(e)
                this.listLoadingFlag = false
              })
            }
          }
        })
        .catch(_ => {})
    },
    checkVal() {
      let checkFlag1 = false
      let checkFlag2 = false
      for (const i of this.selectBizListMark) {
        if (i === '全部')checkFlag1 = true
      }
      for (const i of this.bizform.selectBizList) {
        if (i === '全部')checkFlag2 = true
      }
      //   console.log('checkVal',this.selectBizListMark,!checkFlag1 && checkFlag2)
      if (!checkFlag1 && checkFlag2) {
        this.bizform.selectBizList = ['全部']
      } else {
        const tmpList = []
        for (const i of this.bizform.selectBizList) {
          if (i !== '全部') tmpList.push(i)
        }
        this.bizform.selectBizList = tmpList
      }
      if (this.bizform.selectBizList.length === 0) this.bizform.selectBizList = ['全部']
      this.selectBizListMark = this.bizform.selectBizList
      this.changeFlag = !this.listCheck(this.selectBizListInit, this.bizform.selectBizList)
    },
    fetchBizList() {
      this.listLoadingFlag = true
      getBizList('').then(response => {
        this.listLoadingFlag = false
        console.log('getBizList', response)
        if (response.code === 0) {
          this.bizList = response.data.bizModuleList
          this.bizListMap = new Map()
          this.bizListIdMap = new Map()
          for (const i of response.data.bizModuleList) {
            this.bizListMap.set(i.nicName, i)
            this.bizListIdMap.set(i.id, i.nicName)
          }
          this.bizList.push({
            nicName: '全部', bizName: 'All'
          })
          console.log('bizList', this.bizList)
          this.fetchUserBizList()
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    },
    fetchUserBizList() {
      this.listLoadingFlag = true
      queryBizPreferByName(this.$store.state.user.name).then(response => {
        this.listLoadingFlag = false
        console.log('queryBizPreferByName', response)
        if (response.code === 0) {
          if (response.data.bizPreferList.length === 0) {
            this.bizform.selectBizList = ['全部']
          } else {
            this.bizform.selectBizList = []
            for (const i of response.data.bizPreferList[0].bizPrefer.split(',')) {
              this.bizform.selectBizList.push(this.bizListIdMap.get(i))
            }
            // this.bizform.selectBizList = tmpMark
            this.bizIdMark = response.data.bizPreferList[0].id
          }
          this.selectBizListMark = JSON.parse(JSON.stringify(this.bizform.selectBizList))
          this.selectBizListInit = JSON.parse(JSON.stringify(this.bizform.selectBizList))
          // this.selectBizListInit = ['行情计算','监控管理']
          this.changeFlag = !this.listCheck(this.selectBizListInit, this.bizform.selectBizList)
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch(e => {
        Message.error(e)
        this.loadingFlag = false
      })
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
