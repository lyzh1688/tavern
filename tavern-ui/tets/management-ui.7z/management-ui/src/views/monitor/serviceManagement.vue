<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true" @submit.native.prevent>
                <el-form-item>
                    <el-popover
                        placement="right"
                        width="708"
                        trigger="click"
                    >
                        <el-card>
                            <div class="header">
                                <div style="display:flex;justify-content:center">
                                    <p>列表显示内容</p>
                                </div>
                            </div>
                            <el-checkbox-group
                                v-model="checkboxVal"
                                style="float: left;"
                            >
                                <div style="display:flex;flex-wrap:wrap;justify-content:flex-end">
                                    <el-checkbox
                                        :key='item'
                                        v-for='item in formTheadOptions'
                                        :label="item"
                                        :border="true"
                                        size="small"
                                        style="width:150px"
                                    >{{$t('serviceList.'+item)}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                        </el-card>

                        <el-button
                            slot="reference"
                            style="float: left"
                            type="primary"
                            size="mini"
                        >列表内容</el-button>
                            </el-popover>
                </el-form-item>
                <el-form-item label="服务名称:">
                    <el-input
                        v-model="inputServiceName"
                        size="mini"
                        @keyup.enter.native="fetchData"
                        placeholder="请输入服务名称"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="fetchData"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
                <!-- <el-form-item>
                    <el-button
                        type="primary"
                        @click="isdalog=true"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item> -->
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('serviceList.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item == 'artifactType'">{{scope.row[item]=='0'?'其他':(scope.row[item] =='1'?'vertx':'spring')}}</p>
                          <p v-else>{{scope.row[item]}}</p> 
                        </template>
                        </el-table-column>
                         <el-table-column
                         prop="instanceList"
                         label="提供服务的实例"
                         width="400px"
                         :filters="[{text:'上线',value:'上线'},{text:'未监控',value:'未监控'},{text:'未启用监控',value:'未启用监控'},{text:'下线',value:'下线'}]"
                         :filter-method="TabbleFillter"
                         filter-placement="bottom-end"
                    >
                        <template slot-scope="scope">
                            <div v-for="item in scope.row.instanceList"
                                                :key="item.objectId">
                         <el-button
                                                :type="item.id === '上线' ? 'success': (item.id === '未监控' ? 'warning':(item.id === '未启用监控' ? 'info':'danger'))"
                                                v-if="item.id != '未监控'&&item.serviceId !== null&&item.id != '未启用监控'"
                                                size="mini"
                                                class="selectButton"
                                                v-loading.body="listLoading"
                                                @click="handleDetailInfo(item.serviceId,item.serverIp,item.version,item.instanceName)">
                                                {{item.instanceName}}
                                                </el-button>
                                                <el-tag
                                                :type="item.id === '上线' ? 'success': (item.id === '未监控' ? 'warning':(item.id === '未启用监控' ? 'info':'danger'))"
                                                v-else
                                                size="mini"
                                                class="selectButton"
                                                v-loading.body="listLoading"
                                                >
                                                {{item.instanceName}}
                                                </el-tag>
                                                 <el-tag>
                                                {{item.serverIp}}
                                                </el-tag>
                                                <el-tag>
                                                 {{item.port}}
                                                </el-tag>
                                                </div>
                        </template>
                        
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                            width="100px"
                            v-if="hasPermission()"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item class="buttonFOrm">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm">
                                        <!-- <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="text"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="primary"
                                                        @click="handleDelete(scope.row.id)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="primary"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover> -->
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="serviceForm"
            ref="serviceForm"
        >
            <!-- <el-form-item
                prop="serviceName"
                label="服务名称"
                :rules="{required: true, message: '请输入服务名称'}"
                style="width:200px"
            >
                <el-input v-model="serviceForm.serviceName"></el-input>
                </el-form-item>
                <el-form-item
                    prop="protocolType"
                    label="服务协议类型"
                    :rules="[
          {required: true, message: '请输入服务协议类型'}
          ]"
                    style="width:200px"
                >
                    <el-select v-model="serviceForm.protocolType">
                        <el-option
                            v-for="item in protocolTypeTable"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                    </el-form-item>
                        <el-form-item
                            prop="grpcClass"
                            label="grpc类名"
                            :rules="[
          {required: true, message: '请输入grpc类名'}
          ]"
                            style="width:200px"
                        >
                            <el-input v-model="serviceForm.grpcClass"></el-input>
                            </el-form-item>-->
                                <el-form-item
                                    prop="remark"
                                    label="说明"
                                    style="width:200px"
                                >
                                    <el-input v-model="serviceForm.remark"></el-input>
                                    </el-form-item> 
                                    <el-form-item
                                        prop="monitorEnabled"
                                        label="是否监控"
                                        style="width:200px"
                                    >
                                        <el-switch v-model="serviceForm.monitorEnabled"></el-switch>
                                        </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('serviceForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
</div>
</template>




<script>
const defaultFormThead = ['serviceName', 'protocolType', 'grpcClass', 'monitorEnabled', 'remark']
import {
  queryServiceByName,
  insertService,
  updateService,
  deleteService
} from '@/api/monitor'
import { mapGetters } from 'vuex'
export default {
  name: 'serviceLists',
  data() {
    return {
      list: null,
      templatesList: null,
      serviceForm: {
        id: '',
        serviceName: '',
        protocolType: '',
        grpcClass: '',
        remark: '',
        monitorEnabled: false
      },
      isUdate: false,
      dialogTitle: '服务添加',
      listLoading: true,
      isdalog: false,
      inputServiceName: '',
      inputModuleType: '',
      inputArtifactType: '',
      inputArtifactName: '',
      inputMonitorEnabled: true,
      inputTemplateId: '',
      moduleTypeTable: [{
        value: 'GW'
      }, {
        value: 'SP'
      }, {
        value: 'ZK'
      }],
      artifactTypeTable: [{
        name: '其他',
        value: 0
      }, {
        name: 'vertx',
        value: 1
      }, {
        name: 'spring',
        value: 2
      }],
      protocolTypeTable: [{
        name: 'grpc',
        value: 'grpc'
      }, {
        name: 'HTTP',
        value: 'HTTP'
      }],
      formTheadOptions: ['id', 'serviceName', 'protocolType', 'grpcClass', 'monitorEnabled', 'remark', 'created'],
      checkboxVal: defaultFormThead,
      formThead: ['serviceName', 'protocolType', 'grpcClass', 'monitorEnabled', 'remark']
    }
  },
  created() {
    this.fetchData()
    console.log('created moduleList!')
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '服务修改'
      else this.dialogTitle = '服务添加'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'serviceListsButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    TabbleFillter(value, row) {
      console.log('filter:')
      for (const i of row.instanceList) {
        console.log('filter:', i, value)
        if (i.id === value) { return true }
      }
      return false
    },
    handleDetailInfo: function(instanceID, serverIP, moduleId, moduleName) {
      // let queryStatus = ''
      // if (Status === '正常') {
      //   queryStatus = '0'
      // } else if (Status === '告警') {
      //   queryStatus = '1'
      // } else if (Status === '未采集数据') {
      //   queryStatus = '-1'
      // } else if (Status === '未启用监控') {
      //   queryStatus = '-1'
      // }
      // console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
      // this.$router.push('/monitor/instanceStatus/' + -1 + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      console.log('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      this.$router.push('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + moduleName + ':' + serverIP.replace(new RegExp(/\./g), '_'))
      // window.parent.addTab(title, seqUrl)
    },
    fetchData() {
      this.listLoading = true
      if (!this.inputMonitorEnabled) this.inputMonitorEnabled = ''
      queryServiceByName(this.inputServiceName).then(response => {
        console.log(response)
        this.list = response.data.serviceList.map(v => {
          this.$set(v, 'deleteFlag', false)
          return v
        })
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.$refs['serviceForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.serviceForm)
              this.listLoading = true
              if (this.isUdate) {
                return new Promise((resolve, reject) => {
                  updateService(this.serviceForm).then(response => {
                    console.log(response)
                    this.fetchData()
                    this.listLoading = false
                    this.isUdate = false
                    this.$refs['serviceForm'].resetFields()
                    resolve(response)
                    this.isdalog = false
                  }).catch((error) => {
                    this.listLoading = false
                    this.isUdate = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              } else {
                return new Promise((resolve, reject) => {
                  insertService(this.serviceForm).then(response => {
                    console.log(response)
                    this.fetchData()
                    this.listLoading = false
                    this.$refs['serviceForm'].resetFields()
                    resolve(response)
                    this.isdalog = false
                  }).catch((error) => {
                    this.listLoading = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.serviceForm = Object.assign({}, rows)
      this.isdalog = true
      this.isUdate = true
    },
    handleDelete(id) {
      return new Promise((resolve, reject) => {
        deleteService(id).then(response => {
          console.log(response)
          this.fetchData()
          this.listLoading = false
          this.$refs['serviceForm'].resetFields()
          resolve(response)
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    }
  }
}
</script>



<style>
.selectButton {
    margin-top: 5px;
    margin-left: 10px;
    width: 150px;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
