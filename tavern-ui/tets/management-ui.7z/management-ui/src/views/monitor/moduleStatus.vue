<template>
<div class="app-container">
    <el-card>

        <el-popover
            placement="left"
            trigger="click">
            <el-form ref="ruleForm">
                <div class="form-wrapper">
                    <el-form-item
                        class="form-wrapper-item"
                        label="轮询时间"
                        label-width="160px">
                        <el-select
                            v-model="countertime"
                            placeholder="轮询间隔时间">
                            <el-option
                                v-for="item in timeTable"
                                :key="item.value"
                                :label="item.value"
                                :value="item.time">
                                </el-option>
                                </el-select>
                                <el-button
                                    :type="timerStatus === '开始轮询' ? 'primary' : 'danger' "
                                    @click="stopQuery"
                                    v-loading.body="listLoading"
                                    size="mini">{{timerStatus}}</el-button>
                    </el-form-item>
                    <el-form-item
                        class="form-wrapper-item"
                        label="集群"
                        label-width="160px">
                        <el-select
                            v-model="clusterName"
                            placeholder="集群名称"
                            @change="fetchData">
                            <el-option
                                v-for="item in clusterTable"
                                :key="item.value"
                                :label="item.name"
                                :value="item.value">
                                </el-option>
                                </el-select>
                    </el-form-item>
                </div>
            </el-form>

            <el-button
                slot="reference"
                style="float: left;margin-right: 10px;"
                type="text"
            >操作按钮</el-button>
                </el-popover>
                <div style="float: left;clear:right;margin-top: 10px;">
                  <el-tag type="warning">是否启用业务域筛选<el-switch v-model="doFilter"></el-switch></el-tag>
            </div>
                <el-table
                size="mini"
                    :data="showList"
                    v-loading.body="listLoading"
                    element-loading-text="Loading"
                    border
                    fit
                    highlight-current-row
                    :stripe="true"
                    class="outTable">

                    <!-- <el-table-column align="center" label='NO.' width="95">
        <template slot-scope="scope">
          {{scope.$index}}
        </template>
      </el-table-column> -->
                    <el-table-column
                        label="模块名"
                        width=160>
                        <template slot-scope="scope">
                            <!-- <router-link class="pan-btn light-blue-btn" :to="'/monitor/moduleDetail/'+scope.row.moduleId+'/'+scope.row.moduleName">{{scope.row.moduleName}}</router-link> -->
                            <div size="mini" style="text-align: center;font-size:20px;" type="info"><span>{{scope.row.moduleName}}</span></div>
                        </template>
                        </el-table-column>
                        <el-table-column>
                            <template slot-scope="scope">
                                <el-table
                                size="mini"
                                    :data="scope.row.clusters"
                                    v-loading.body="listLoading"
                                    element-loading-text="Loading"
                                    border
                                    fit
                                    highlight-current-row
                                    :show-header="false"
                                    :stripe="true"
                                    class="innerTable">
                                    <el-table-column width=150>
                                        <template slot-scope="scope1">
                                            {{scope1.row.clusterName}}
                                        </template>
                                    </el-table-column>
                                    <el-table-column>
                                        <template slot-scope="scope1">
                                          <el-button
                                                :type="item.status === '正常' ? 'success': (item.status === '未采集数据' ? 'warning':(item.status === '未启用监控' ? 'info':'danger'))"
                                                v-for="item in scope1.row.instances"
                                                :key="item.instanceId"
                                                size="mini"
                                                class="selectButton"
                                                @click="handleDetailInfo(item.instanceId,item.serverIp,scope.row.moduleId,scope.row.moduleName)"
                                                v-loading.body="listLoading">
                                                {{item.serverIp}}:{{item.status}}
                                                </el-button>
                                        </template>
                                    </el-table-column>
                                    </el-table>
                            </template>
                        </el-table-column>
                        </el-table>
    </el-card>
</div>
</template>


<script>
import {
  getModuleStatus,
  getModuleStatusUpdate,
  queryClusters
} from '@/api/monitor'
import PanThumb from '@/components/PanThumb'
export default {
  name: 'moduleStatus',
  data() {
    return {
      list: null,
      updateList: null,
      listLoading: true,
      countertime: 20,
      timeOut: '30',
      timerStatus: '开始轮询',
      timeTable: [{
        value: '十秒',
        time: 10
      }, {
        value: '二十秒',
        time: 20
      }, {
        value: '三十秒',
        time: 30
      }, {
        value: '一分钟',
        time: 60
      }],
      ref: null,
      clusterTable: [],
      clusterName: '',
      doFilter: true,
      showList: []
    }
  },
  components: {
    PanThumb
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  watch: {
    doFilter(val) {
      // console.log(val)
      if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
        // new Array().includes
        this.showList = []
        for (const i of this.list) {
          if (this.$store.state.user.preferModules.includes(i.moduleName)) {
            this.showList.push(i)
          }
          // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
        }
      } else {
        this.showList = JSON.parse(JSON.stringify(this.list))
      }
    },
    list(val) {
      if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
        // new Array().includes
        this.showList = []
        for (const i of this.list) {
          if (this.$store.state.user.preferModules.includes(i.moduleName)) {
            this.showList.push(i)
          }
          // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
        }
      } else {
        this.showList = JSON.parse(JSON.stringify(this.list))
      }
    }
  },
  created() {
    this.fetchClusterTablr()
    this.fetchData()
    this.stopQuery()
    console.log('moduleNameList', this.$store.state.user.preferModules)
    if (this.$route.query.doFilter !== undefined) {
      this.doFilter = this.$route.query.doFilter
    }
  },
  methods: {
    fetchClusterTablr() {
      queryClusters().then(response => {
        for (const i of response.data.clusterList) {
          this.clusterTable.push({
            name: i.clusterName,
            value: i.clusterName
          })
        }
        this.clusterTable.push({
          name: '不过滤',
          value: ''
        })
        this.listLoading = false
      })
    },
    fetchData() {
      getModuleStatus('', this.clusterName).then(response => {
        console.log(response)
        this.list = []

        for (const i of response.data.moduleInstance) {
          if (i.clusters.length === 0) continue
          this.list.push(i)
        }
        this.list = JSON.parse(JSON.stringify(this.list))
        // this.showList = JSON.parse(JSON.stringify(this.list))
        console.log(this.list)
        this.updateStatus()
        this.listLoading = false
      })
      console.log('modulestatus:', this.list)
    },
    updateStatus() {
      getModuleStatusUpdate(this.timeOut).then(response => {
        console.log(response)
        this.updateList = response.data.monitorStatus
        console.log(this.updateList)
        for (const tmp of this.updateList) {
          let markFlag = 0
          for (let value = 0; value < this.list.length; value++) {
            if (markFlag === 1) break
            for (let value1 = 0; value1 < this.list[value].clusters.length; value1++) {
              if (markFlag === 1) break
              for (let value2 = 0; value2 < this.list[value].clusters[value1].instances.length; value2++) {
                if (markFlag === 1) break
                if (this.list[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
                  this.list[value].clusters[value1].instances[value2].status = tmp.status
                  this.list[value].clusters[value1].instances[value2].remark = tmp.message
                  markFlag = 1
                  // console.log(this.list[value].clusters[value1].instances[value2].status)
                }
              }
            }
          }
        }
        this.list = JSON.parse(JSON.stringify(this.list))
        // this.showList = JSON.parse(JSON.stringify(this.list))
        this.listLoading = false
      })
    },
    handleDetailInfo: function(instanceID, serverIP, moduleId, moduleName) {
      // let queryStatus = ''
      // if (Status === '正常') {
      //   queryStatus = '0'
      // } else if (Status === '告警') {
      //   queryStatus = '1'
      // } else if (Status === '未采集数据') {
      //   queryStatus = '-1'
      // } else if (Status === '未启用监控') {
      //   queryStatus = '-1'
      // }
      // console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
      // this.$router.push('/monitor/instanceStatus/' + -1 + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      console.log('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      this.$router.push('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + moduleName + ':' + serverIP.replace(new RegExp(/\./g), '_'))
      // window.parent.addTab(title, seqUrl)
    },
    stopQuery: function() {
      if (this.timerStatus === '停止轮询') {
        this.timerStatus = '开始轮询'
        clearInterval(this.ref)
      } else {
        console.log(this.countertime)
        clearInterval(this.ref)
        const that = this
        this.ref = setInterval(function() {
          that.updateStatus()
        }, this.countertime * 1000)
        this.$store.dispatch('addTimer', { name: this.$route.path, timer: this.ref })
        this.timerStatus = '停止轮询'
      }
    }
  },
  destroyed: function() {
    console.log('Destroy moduleStatus!')
    clearInterval(this.ref)
  }
}
</script>

<style lang="scss" scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.outTable {
    width: 100%;
}

.innerTable {
    width: 100%;
}

.selectButton {
    margin-top: 5px;
    margin-left: 10px;
    width: 180px;
}
.pan-btn{
  width: 220px;
  
  text-align: center;
}
</style>
