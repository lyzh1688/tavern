<template>
<div class="app-container">
  <el-row class="panel-group">
    
            <el-col :xs="48" :sm="48" :lg="24" class="card-panel-col">
    
                <div class="card-panel" @click="moduleInfoFlag=!moduleInfoFlag">
    
                    <div class="card-panel-header">
    
                        <div v-if="list[0].moduleType == 'SP' " class="card-panel-icon-wrapper icon-trade">
                            <svg-icon  icon-class="trade" class-name="card-panel-icon" />
                        </div>
                        <div v-if="list[0].moduleType == 'GW' " class="card-panel-icon-wrapper icon-gateway">
                            <svg-icon  icon-class="gateway" class-name="card-panel-icon" />
                        </div>
                        <div v-if="list[0].moduleType == 'ZK' " class="card-panel-icon-wrapper icon-cluster">
                            <svg-icon  icon-class="cluster" class-name="card-panel-icon" />
                        </div>
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">{{moduleName}}</div>
    
    
    
                        </div>
    
                    </div>
                    <!-- <div class='chart-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData.spxexchangertradeRequest"></innerBarChart>
    
                    </div> -->
    
                </div>
    
            </el-col>
  </el-row>
  <el-row class="panel-group" :v-show="moduleInfoFlag">
    
            <el-col :xs="48" :sm="48" :lg="24" class="card-panel-col" :v-show="moduleInfoFlag" >
    
                <div class="card-panel" v-show="moduleInfoFlag">
                   <div class="card-panel-header" > 
                    <el-form :inline="true">
                    <el-form-item
                    v-for="(moduleItem,moduleIndex) in moduleList[0]"
                    :key="moduleIndex"
                    :label="$t('moduleListTable.'+moduleIndex)"
                    class="moduleInfoTitle"
                    >
                    <!-- <el-input class="moduleInfo" :placeholder="moduleItem" :disabled="true"></el-input> -->
                    <span class="moduleInfo" >{{moduleItem}}</span>
                    </el-form-item>
                    </el-form>
                     
                    </div>
    
                </div>
    
            </el-col>
  </el-row>
  <el-card>
      <div class="header" style="display: inline;">
        <div>包含实例</div>
        <el-popover
            placement="left"
            trigger="click">
            <el-form ref="ruleForm">
                <div class="form-wrapper">
                    <el-form-item
                        class="form-wrapper-item"
                        label="轮询时间"
                        label-width="160px">
                        <el-select
                            v-model="countertime"
                            placeholder="轮询间隔时间">
                            <el-option
                                v-for="item in timeTable"
                                :key="item.value"
                                :label="item.value"
                                :value="item.time">
                                </el-option>
                                </el-select>
                                <el-button
                                    :type="timerStatus === '开始轮询' ? 'primary' : 'danger' "
                                    @click="stopQuery"
                                    v-loading.body="listLoading"
                                    size="mini">{{timerStatus}}</el-button>
                    </el-form-item>
                </div>
            </el-form>
            <el-button
                slot="reference"
                style="float: left"
                type="text"
            >操作按钮</el-button>
                </el-popover>
                </div>
                <div class="container">
                  
                                <el-table
                                    :data="list[0].clusters"
                                    v-loading.body="listLoading"
                                    element-loading-text="Loading"
                                    border
                                    fit
                                    highlight-current-row
                                    :stripe="true"
                                    class="innerTable">
                                    <el-table-column type="expand" >
                                        <template slot-scope="scope">
                                          <el-form size="big" label-position="left" v-for="itemAAA in scope.row.instances"
                                          :key="itemAAA.instanceId"
                                          >
                                          <el-card>
                                          <el-form-item :label="itemAAA.serverIp+'上实例详情：'" >
                                          <instanceItem
                                          class="instanceItem"
                                          :model="itemAAA.remark">
                                          </instanceItem>
                                          </el-form-item>
                                          <div class="chartBox">
                                          <div class="chart-container" v-if="itemAAA.remark!=null&&itemAAA.remark.instance!=null">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:itemAAA.remark.instance.systemLoad*100,valueName:'系统负载'}"></gaugePanel>
                                          </div>
                                          <div class="chart-container" v-if="itemAAA.remark!=null&&itemAAA.remark.diskSpace!=null">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:((itemAAA.remark.diskSpace.total-itemAAA.remark.diskSpace.free)/itemAAA.remark.diskSpace.total)*100,valueName:'磁盘利用率'}"></gaugePanel>
                                          </div>
                                          <div class="chart-container" v-if="itemAAA.monitor!=null&&MemeryUse.monitorName=='内存堆使用率'" v-for="MemeryUse in itemAAA.monitor" :key="MemeryUse.monitorId">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:MemeryUse.monitorVal,valueName:'内存堆使用率'}"></gaugePanel>
                                          </div>
                                          <div class="chart-container" v-if="itemAAA.monitor!=null&&MemeryUse.monitorName=='文件句柄使用率'" v-for="MemeryUse in itemAAA.monitor" :key="MemeryUse.monitorId">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:MemeryUse.monitorVal,valueName:'文件句柄使用率'}"></gaugePanel>
                                          </div>
                                          </div>
                                          </el-card>
                                          </el-form>
                                          <el-row class="panel-group" :gutter="20">
    
            <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
    
                <div class="card-panel" @click="isShow==false&&selectName==scope.row.clusterName.split('集群').pop()?isShow=true:isShow==false&&selectName!=scope.row.clusterName.split('集群').pop()?(selectName=scope.row.clusterName.split('集群').pop(),isShow= !isShow):selectName==scope.row.clusterName.split('集群').pop()?isShow= !isShow:selectName=scope.row.clusterName.split('集群').pop()">
    
                    <div class="card-panel-header">
    
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">请求速率</div>
                        </div>
    
                    </div>
    
                    <div class='innerchartData-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData[scope.row.clusterName.split('集群').pop()]"></innerBarChart>
    
                    </div>
    
                </div>
    
            </el-col>
                                          </el-row>
                                        </template>
                                    </el-table-column>
                                    <el-table-column width=150 label="集群名称">
                                        <template slot-scope="scope1">
                                            {{scope1.row.clusterName}}
                                        </template>
                                    </el-table-column>
                                    
                                    <el-table-column label="实例所在服务器">
                                        <template slot-scope="scope1">
                                          <div class="instanceInfoBox" v-for="item in scope1.row.instances"
                                                :key="item.instanceId">
                                           <el-button
                                                :type="item.status === '正常' ? 'success': (item.status === '未采集数据' ? 'warning':(item.status === '未启用监控' ? 'info':'danger'))"
                                                size="mini"
                                                class="selectButton"
                                                @click="handleDetailInfo(item.instanceId,item.serverIp,item.status)"
                                                v-loading.body="listLoading">
                                                {{item.serverIp}}:{{item.status}}
                                                </el-button>
                                                <el-tag
                                                v-for="monitorTag in item.monitor"
                                                :key="monitorTag.monitorId"
                                                :type="monitorTag.status === '正常' ? 'success': (monitorTag.status === '未采集数据' ? 'warning':(monitorTag.status === '未启用监控' ? 'info':'danger'))"
                                                >
                                                {{monitorTag.monitorName}}:{{monitorTag.status}},状态值：{{monitorTag.monitorVal}}
                                                </el-tag>
                                                </div>
                                        </template>
                                    </el-table-column>
                                    </el-table>
                                    <el-row
            
            style="background:#fff;padding:16px 16px 0;margin-bottom:32px;margin-top:-12px;"
        >
            <div class='chartData-container' v-if="selectName!= null" >
                <chart v-show="isShow == true"
                    height='45vh'
                    width='100%'
                    :chart-data="lineChartData[selectName]"
                    :className="classname[selectName]"
                    
                ></chart>
            </div>
            </el-row>
                            </div>
    </el-card>
</div>
</template>
<script>
import {
  getModuleStatus,
  getModuleStatusUpdate,
  getModuleList,
  getAlarmStatus,
  getMetricsTimer
} from '@/api/monitor'
// import PanThumb from '@/components/PanThumb'
import instanceItem from '@/components/JSONInfoBox'
import gaugePanel from '@/components/Charts/gaugePanel'
import innerBarchart from '@/components/Charts/innerBarchart'
import axios from 'axios'
import Chart from '@/components/Charts/mixChart'
import {
  formatDate
} from '@/store/date'
import {
  Message
} from 'element-ui'

const lineChartData = {
  gwuserRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }]
  }
}
export default {
  name: 'moduleDetail',
  data() {
    return {
      lineChartData: '',
      functionData: {
      },
      selectName: '',
      classname: {},
      isShow: true,
      list: [1],
      updateList: null,
      moduleList: [1],
      listLoading: true,
      moduleId: null,
      moduleName: null,
      moduleInfoFlag: false,
      countertime: 20,
      timeOut: '30',
      initFlag: true,
      timerStatus: '开始轮询',
      timeTable: [{
        value: '十秒',
        time: 10
      }, {
        value: '二十秒',
        time: 20
      }, {
        value: '三十秒',
        time: 30
      }, {
        value: '一分钟',
        time: 60
      }],
      ref: null
    }
  },
  components: {
    instanceItem,
    gaugePanel,
    Chart,
    innerBarchart
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  created() {
    if (this.$route.params.moduleId !== undefined) {
      this.moduleId = this.$route.params.moduleId
    }
    if (this.$route.params.moduleName) {
      this.moduleName = (this.$route.params.moduleName).split('详情').shift()
    }
    this.fetchData(this.moduleName)
    this.fetchModuleList()
    this.stopQuery()
  },
  methods: {
    setView() {
      console.log('scroll')
      window.scrollTo(0, 1000000000)
    },
    fetchModuleList() {
      this.listLoading = true
      getModuleList(this.moduleName, '', '', '', '', '').then(response => {
        console.log(response)
        this.moduleList = response.data.ModuleList
        console.log(this.moduleList)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchData(ModuleName) {
      getModuleStatus(ModuleName).then(response => {
        console.log(response)
        this.list = response.data.moduleInstance
        console.log(this.list)
        this.updateStatus()
        if (this.initFlag) {
          const requestGRoup = []
          for (const CLUSTERS of this.list[0].clusters) {
            for (const INSTANCE in CLUSTERS.instances) {
              requestGRoup.push(
                getAlarmStatus('-1', '', CLUSTERS.instances[INSTANCE]['instanceId']).then(response => {
                  console.log('monitorData:', response)
                  CLUSTERS.instances[INSTANCE]['monitor'] = response.data.alarmList
                }))
            }
          }
          axios.all(requestGRoup).then(function() {
            console.log('listData:', this.list)
            this.listLoading = false
            this.formGrapData(this.list[0].clusters, 'request')
          }.bind(this))
        }
      })
      console.log('modulestatus:', this.list)
    },
    updateStatus() {
      getModuleStatusUpdate(this.timeOut).then(response => {
        console.log(response)
        this.updateList = response.data.monitorStatus
        console.log(this.updateList)
        for (const tmp of this.updateList) {
          let markFlag = 0
          for (let value = 0; value < this.list.length; value++) {
            if (markFlag === 1) break
            for (let value1 = 0; value1 < this.list[value].clusters.length; value1++) {
              if (markFlag === 1) break
              for (let value2 = 0; value2 < this.list[value].clusters[value1].instances.length; value2++) {
                if (markFlag === 1) break
                if (this.list[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
                  this.list[value].clusters[value1].instances[value2].status = tmp.status
                  this.list[value].clusters[value1].instances[value2].remark = tmp.message
                  if (tmp.message !== null && tmp.message.instance !== null && tmp.message.instance !== undefined) {
                    const data = new Date(tmp.message.instance.startTime)
                    // console.log(data.getMonth())
                    tmp.message.instance.startTime = data.getFullYear() + '-' + (data.getMonth() + 1) + '-' + data.getDate() + ' ' + data.getHours() + ':' + data.getMinutes() + ':' + data.getSeconds()
                    // console.log('startTime:', data.getFullYear() + '-' + data.getMonth() + '-' + data.getDate() + ' ' + data.getHours() + ':' + data.getMinutes() + ':' + data.getSeconds())
                  }
                  markFlag = 1
                  console.log(this.list[value].clusters[value1].instances[value2].status)
                }
              }
            }
          }
        }
        if (!this.initFlag) {
          const requestGRoup = []
          for (const CLUSTERS of this.list[0].clusters) {
            for (const INSTANCE in CLUSTERS.instances) {
              requestGRoup.push(
                getAlarmStatus('-1', '', CLUSTERS.instances[INSTANCE]['instanceId']).then(response => {
                  console.log('monitorData:', response)
                  CLUSTERS.instances[INSTANCE]['monitor'] = response.data.alarmList
                }))
            }
          }
          axios.all(requestGRoup).then(function() {
            console.log('listData:', this.list)
            this.listLoading = false
          }.bind(this))
        }
        this.initFlag = false
      })
    },
    handleDetailInfo: function(instanceID, serverIP, Status) {
      let queryStatus = ''
      if (Status === '正常') {
        queryStatus = '0'
      } else if (Status === '告警') {
        queryStatus = '1'
      } else if (Status === '未采集数据') {
        queryStatus = '-1'
      } else if (Status === '未启用监控') {
        queryStatus = '-1'
      }
      console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
      this.$router.push('/monitor/instanceStatus/' + queryStatus + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      // window.parent.addTab(title, seqUrl)
    },
    stopQuery: function() {
      if (this.timerStatus === '停止轮询') {
        this.timerStatus = '开始轮询'
        clearInterval(this.ref)
      } else {
        console.log(this.countertime)
        clearInterval(this.ref)
        const that = this
        this.ref = setInterval(function() {
          that.updateStatus()
        }, this.countertime * 1000)
        this.$store.dispatch('addTimer', { name: this.$route.path, timer: this.ref })
        this.timerStatus = '停止轮询'
      }
    },
    formGrapData(clusters, keyword) {
      var nowTime = new Date()
      // nowTime.setDate(21)
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      const startTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
      nowTime = new Date()
      // nowTime.setDate(21)
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      const endTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
      const requestGroup = []
      for (const clusterItem of clusters) {
        lineChartData[clusterItem.clusterName.split('集群').pop()] = {}
        lineChartData[clusterItem.clusterName.split('集群').pop()]['xdata'] = []
        lineChartData[clusterItem.clusterName.split('集群').pop()]['ydata'] = []
        lineChartData[clusterItem.clusterName.split('集群').pop()]['namedata'] = []
        lineChartData[clusterItem.clusterName.split('集群').pop()]['functionData'] = []
        console.log('instancelist:', clusterItem.instances)
        for (const i of clusterItem.instances) {
          requestGroup.push(
            getMetricsTimer(i.instanceId, keyword, startTime, endTime).then(response => {
              if (response.data.metricsTimer.length !== 0) {
                const tempx = []
                const tempy = []
                let mark = true
                for (const s of response.data.metricsTimer) {
                  if (mark) {
                    lineChartData[clusterItem.clusterName.split('集群').pop()]['functionData'].push({
                      name: i.serverIp,
                      m1Rate: s.m1Rate,
                      m5Rate: s.m5Rate,
                      m15Rate: s.m15Rate
                    })
                    // for (let test = 1; test < 10; test++) {
                    //   lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData.push({
                    //     name: (i.serverIp + test),
                    //     m1Rate: s.m1Rate + test,
                    //     m5Rate: s.m5Rate + test,
                    //     m15Rate: s.m15Rate + test
                    //   })
                    // }

                    mark = false
                  }
                  tempx.push(s.ts.substr(0, 4) + '' + s.ts.substr(4, 2) + '-' + s.ts.substr(6, 2) + ' ' + s.ts.substr(8, 2) + ':' + s.ts.substr(10, 2) + ':' + s.ts.substr(12, 2))
                  tempy.push(s.m1Rate)
                }
                lineChartData[clusterItem.clusterName.split('集群').pop()]['xdata'].push(tempx.reverse())
                lineChartData[clusterItem.clusterName.split('集群').pop()]['ydata'].push(tempy.reverse())
                lineChartData[clusterItem.clusterName.split('集群').pop()]['namedata'].push(i.instanceName + ':' + i.serverIp)
              } else {
                Message.error(i.instanceName + ':' + i.serverIp + '无数据')
              }
            }))
        }
      }

      axios.all(requestGroup).then(function() {
        for (const clusterItem of clusters) {
          this.functionData[clusterItem.clusterName.split('集群').pop()] = lineChartData[clusterItem.clusterName.split('集群').pop()].functionData
          this.classname[clusterItem.clusterName.split('集群').pop()] = clusterItem.clusterName + '请求速率'
        }
        console.log('chartQueryData:', this.functionData, lineChartData)
        this.lineChartData = lineChartData
      }.bind(this))
    }
  },
  destroyed() {
    console.log('DestroyDetail')
    clearInterval(this.ref)
  },
  watch: {
    isShow() {
      if (this.isShow === true)window.scrollTo(0, 1000000000)
    },
    selectName() {
      if (this.selectName !== '')window.scrollTo(0, 1000000000)
    }
  },
  // watch: {
  //   $route(to, from, next) {
  //     if (from.path !== this.$route.path) {
  //       console.log('enter!', from.path, '   ', this.$route.path,"  ",to.p)
  //       if (this.$route.params.moduleId !== undefined) {
  //         this.moduleId = this.$route.params.moduleId
  //       }
  //       if (this.$route.params.moduleName) {
  //         this.moduleName = (this.$route.params.moduleName).split('详情').shift()
  //       }
  //       this.fetchData(this.moduleName)
  //       this.fetchModuleList()
  //     // this.closeContainer()
  //     }
  //   }
  // },
  activated() {
    // this.fetchData(this.moduleName)
    if (!this.initFlag) {
      console.log('resize!')
      this.formGrapData(this.list[0].clusters, 'request')
      this.updateStatus()
    }
  }
}
</script>

<style lang="scss" scoped>
.formItemInfo{
  float: left;
  clear: right;
  width: 400px;
}
.instanceInfoBox{
  float: left;
  clear: right;
}
.panel-group{
  margin-bottom: 5px;
}
.moduleInfo{
  border-style: solid;
  border-color: snow;
  border-width: 5px;
  outline-style: solid;
  outline-width: 2px;
  outline-color: steelblue;
  
}
.moduleInfoTitle{
  margin-left: 30px;
  margin-top: 10px;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.outTable {
    width: 100%;
}

.innerTable {
    width: 100%;
}

.selectButton {
    margin-top: 5px;
    margin-left: 10px;
    width: 180px;
}
.pan-btn{
  width: 220px;
  height: auto;
  text-align: center;
}
.chartBox{
  display: inline;
}
.chartData-container {
    // margin-top: -40px;
    padding: 20px;
    width: auto;
    height: 45vh;
}
.innerchartData-container {
    
                height: 200px;
    
                position: relative;
    
                display: flex;
    
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
            }
.chart-container {
    
                height: auto;
    
                position: relative;
                float: left;
                clear: right;
                display: flex;
            }
.card-panel {
    
            height: auto;
            cursor: pointer;
    
            font-size: 12px;
    
            position: relative;
    
            overflow: hidden;
    
            color: #666;
    
            background: #fff;
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
            border-color: rgba(0, 0, 0, .05);
    
            &:hover {
    
                .card-panel-icon-wrapper {
    
                    color: #fff;
    
                }
    
                .icon-warning {
    
                    background: #f80606;
    
                }
    
                .icon-module {
    
                    background: #f0be1d;
    
                }
    
                .icon-gateway {
    
                    background: #2109f7;
    
                }
    
                .icon-trade {
    
                    background: #34bfa3;
    
                }
    
                .icon-credit {
    
                    background: #f518e2;
    
                }
    
                .icon-router {
    
                    background: #3f0186;
    
                }
                .icon-cluster{
                  
                    background: #015313;
    
                }
    
            }
    
            .icon-warning {
    
                color: #f80606;
    
            }
    
            .icon-module {
    
                color: #f0be1d;
    
            }
    
            .icon-gateway {
    
                color: #2109f7;
    
            }
    
            .icon-trade {
    
                color: #34bfa3;
    
            }
    
            .icon-credit {
    
                color: #f518e2;
    
            }
    
            .icon-router {
    
                color: #3f0186;
    
            }
            .icon-cluster{
    
                    color: #015313;
    
            }
    
            .card-panel-icon-wrapper {
    
                float: left;
    
                margin: 14px 0 10px 14px;
    
                padding: 16px;
    
                transition: all 0.38s ease-out;
    
                border-radius: 6px;
                
    
            }
    
            .card-panel-icon {
    
                float: left;
    
                font-size: 48px;

                
    
            }
    
            .card-panel-description {
    
                float: right;
    
                font-weight: bold;
    
                margin: 26px;
    
                margin-left: 0px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
            .card-panel-descriptions {
    
                float: left;
    
                font-weight: bold;
    
                margin: 26px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
        }

</style>
