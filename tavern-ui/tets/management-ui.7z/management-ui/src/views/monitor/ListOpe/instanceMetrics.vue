<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true">
                <el-form-item>
                    <el-popover
                        placement="right"
                        width="708"
                        trigger="click"
                    >
                        <el-card>
                            <div class="header" >
                                <div style="display:flex;justify-content:center">
                                    <p>列表显示内容</p>
                                </div>
                            </div>
                            <el-checkbox-group
                                v-model="checkboxVal"
                                style="float: left;"
                            >
                                <div style="display:flex;flex-wrap:wrap;justify-content:flex-end">
                                    <el-checkbox
                                        :key='item'
                                        v-for='item in formTheadOptions'
                                        :label="item"
                                        :border="true"
                                        size="small"
                                        style="width:150px"
                                    >{{$t('metricsList.'+item)}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                        </el-card>

                        <el-button
                            v-if="diableFlag==false"
                            slot="reference"
                            style="float: left"
                            type="primary"
                            size="mini"
                        >列表内容</el-button>
                            </el-popover>
                </el-form-item>
                <el-form-item v-if="hasPermission()">
                    <el-button
                        v-if="diableFlag==false"
                        type="primary"
                        @click="handleAdd"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('metricsList.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item == 'nickname'"><span v-if="scope.row.updateFlag==false">{{scope.row[item]}}</span></p>
                          <p v-else>{{scope.row[item]}}</p> 
                          <el-input v-model="nickname" v-if="item == 'nickname'&&scope.row.updateFlag==true"></el-input>
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                            v-if="hasPermission()"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item class="buttonFOrm" v-if="diableFlag==false">
                                        <el-button
                                            
                                            type="warning"
                                            @click="scope.row.updateFlag=true,diableFlag=true,nickname=scope.row.nickname"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                     <el-form-item class="buttonFOrm" v-if="scope.row.updateFlag==true">
                                        <el-popover
                                            
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.updateconfirmFlag"
                                        >
                                            <p>确定提交吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                 @click="scope.row.updateconfirmFlag=false"
                                                    type="primary"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleupdate(scope.row),scope.row.updateconfirmFlag=false,diableFlag=false"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >提交</el-button>
                                                </el-popover>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm"  v-if="scope.row.updateFlag==true">
                                        <el-button
                                            type="primary"
                                            @click="scope.row.updateFlag=false,diableFlag=false"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >取消</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="diableFlag==false">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(scope.row.id),scope.row.deleteFlag=false"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-checkbox-group
                                v-model="selectMetrics"
                            >
                                <div >
                                    <el-checkbox
                                    class="checkBox"
                                        :key='item.value'
                                        v-for='item in metricCheckBoxVal'
                                        :label="item.value"
                                        :border="true"
                                        size="small"
                                    >{{item.name}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('proxyForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
</div>
</template>




<script>
const defaultFormThead = ['metric', 'metricPattern', 'metricType', 'nickname', 'created']
import {
  queryinstanceMetrics,
  insertinstanceMetrics,
  deleteinstanceMetrics,
  updateinstanceMetrics,
  queryMetricsByInstanceId
} from '@/api/monitor'
import { mapGetters } from 'vuex'
import Axios from 'axios'
export default {
  name: 'instanceMetrics',
  data() {
    return {
      list: null,
      metricList: null,
      nickname: null,
      metricCheckBoxVal: null,
      diableFlag: false,
      selectMetrics: [],
      originMetrics: null,
      messageExpExample: '[#{location}][#{cluster}][#{serverIp}][#{moduleInstance}] 最近五分钟连接失败次数(#{monitorVal}/秒)',
      monitorIdGenExample: '模块：#{objectId} 模块指标：#{objectId}-#{ruleId}',
      dialogTitle: '指标添加,请选择要添加的指标',
      listLoading: true,
      isdalog: false,
      formTheadOptions: ['id', 'metric', 'metricPattern', 'metricType', 'metricId', 'instanceId', 'nickname', 'created'],
      checkboxVal: defaultFormThead,
      formThead: ['metric', 'metricPattern', 'metricType', 'nickname', 'created']
    }
  },
  created() {
    if (this.$route.params.instanceId !== undefined && this.$route.params.instanceId !== ':instanceId') {
      this.instanceId = this.$route.params.instanceId
    }
    this.fetchData()
    this.fetchMetricsData()
    console.log('created moduleList!')
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    }
    // $route() {
    //   if (this.$route.params.parserId !== undefined && this.$route.params.parserId !== ':parserId') {
    //     this.proxyForm.parserId = this.$route.params.parserId
    //   } else {
    //     this.proxyForm.parserId = ''
    //   }
    //   this.fetchData()
    //   // this.closeContainer()
    // }
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'instanceMetricsButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    fetchMetricsData() {
      this.listLoading = true
      queryMetricsByInstanceId(this.instanceId).then(response => {
        console.log(response)
        this.metricList = response.data.metrics
        this.metricCheckBoxVal = []
        for (const i of response.data.metrics) {
          this.metricCheckBoxVal.push({ name: 'NAME:' + i.metric + ' TYPE:' + i.type + ' PATTERN:' + i.pattern, value: i.id })
        }
        console.log('metricsList:', this.metricCheckBoxVal)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchData() {
      this.listLoading = true
      queryinstanceMetrics(this.instanceId).then(response => {
        console.log(response)
        this.list = response.data.instanceMetrics.map(v => {
          this.$set(v, 'deleteFlag', false)
          this.$set(v, 'updateFlag', false)
          this.$set(v, 'updateconfirmFlag', false)
          return v
        })
        this.originMetrics = []
        for (const i of response.data.instanceMetrics) {
          this.originMetrics.push({ name: 'NAME:' + i.metric + ' TYPE:' + i.type + ' PATTERN:' + i.pattern, value: i.metricId, instanceMetricsId: i.id })
        }
        console.log(this.originMetrics)
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.$refs['proxyForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$confirm('确认提交?')
        .then(_ => {
        //   console.log('contain?', this.originMetrics.contain(this.selectMetrics[0]))
        //   console.log('contain?', this.selectMetrics)
        //   if (this.proxyForm.metric === '') this.proxyForm.metric = null
          const groupRequest = []
          for (const i of this.selectMetrics) {
            let addFlag = true
            for (const item of this.originMetrics) {
              if (i === item.value)addFlag = false
            }
            if (addFlag) {
              groupRequest.push(insertinstanceMetrics(this.instanceId, i).then(response => {
                console.log(response)
              }))
            }
          }
          for (const i of this.originMetrics) {
            let deleteFlag = true
            for (const item of this.selectMetrics) {
              if (i.value === item)deleteFlag = false
            }
            if (deleteFlag) {
              groupRequest.push(deleteinstanceMetrics(i.instanceMetricsId).then(response => {
                console.log(response)
              }))
            }
          }
          this.listLoading = true
          return new Promise((resolve, reject) => {
            Axios.all(groupRequest).then(function() {
              console.log('')
              this.fetchData()
              this.listLoading = false
              this.isdalog = false
              resolve()
            }.bind(this)).catch((error) => {
              this.listLoading = false
              reject(error)
              this.isdalog = false
            })
          })
        })
        .catch(_ => {
        })
    },
    handleupdate(rows) {
      return new Promise((resolve, reject) => {
        updateinstanceMetrics(rows.id, rows.instanceId, rows.metricId, this.nickname).then(response => {
          console.log(response)
          if (response.code === 0) {
            this.fetchData()
            this.listLoading = false
            resolve(response)
          }
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    },
    handleDelete(id) {
      return new Promise((resolve, reject) => {
        deleteinstanceMetrics(id).then(response => {
          console.log(response)
          if (response.code === 0) {
            this.fetchData()
            this.listLoading = false
            resolve(response)
          }
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    },
    handleInstance: function(moduleId, moduleName) {
      console.log('/monitor/' + moduleId + '/' + moduleName)
      this.$router.push('/monitor/' + moduleId + '/' + moduleName)
      // window.parent.addTab(title, seqUrl)
    },
    handleAdd() {
      this.selectMetrics = []
      for (const i of this.originMetrics) {
        this.selectMetrics.push(i.value)
      }
      console.log('this.selectMetrics', this.selectMetrics)
      this.isdalog = true
    }
  }
}
</script>



<style scoped>
.checkBox{
    /* float: left; */
    margin-left: 10px;
    /* clear: both; */
    width: 80%;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
