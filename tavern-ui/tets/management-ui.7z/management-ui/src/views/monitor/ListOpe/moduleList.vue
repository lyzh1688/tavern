<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true"  @submit.native.prevent>
                <el-form-item>
                    <el-popover
                        placement="right"
                        width="708"
                        trigger="click"
                    >
                        <el-card>
                            <div class="header">
                                <div style="display:flex;justify-content:center">
                                    <p>列表显示内容</p>
                                </div>
                            </div>
                            <el-checkbox-group
                                v-model="checkboxVal"
                                style="float: left;"
                            >
                                <div style="display:flex;flex-wrap:wrap;justify-content:flex-end">
                                    <el-checkbox
                                        :key='item'
                                        v-for='item in formTheadOptions'
                                        :label="item"
                                        :border="true"
                                        size="small"
                                        style="width:150px"
                                    >{{$t('moduleListTable.'+item)}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                        </el-card>

                        <el-button
                            slot="reference"
                            style="float: left"
                            type="primary"
                            size="mini"
                        >列表内容</el-button>
                            </el-popover>
                </el-form-item>
                <el-form-item label="模块名称:">
                    <el-input
                        v-model="inputModuleName"
                        size="mini"
                         @keyup.enter.native="fetchData"
                        placeholder="请输入模块名称"
                    ></el-input>
                </el-form-item>
                <el-form-item label="模块类型:">
                    <el-input
                        v-model="inputModuleType"
                        size="mini"
                         @keyup.enter.native="fetchData"
                        placeholder="请输入模块类型"
                    ></el-input>
                </el-form-item>
                <el-form-item label="构件名称:">
                    <el-input
                        v-model="inputArtifactName"
                        size="mini"
                         @keyup.enter.native="fetchData"
                        placeholder="请输入构件名称"
                    ></el-input>
                </el-form-item>
                <el-form-item label="构件类型:">
                    <el-input
                        v-model="inputArtifactType"
                        size="mini"
                         @keyup.enter.native="fetchData"
                        placeholder="请输入构件类型"
                    ></el-input>
                </el-form-item>
                <el-form-item label="模板Id:">
                    <el-input
                        v-model="inputTemplateId"
                        size="mini"
                         @keyup.enter.native="fetchData"
                        placeholder="请输入模板Id"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="fetchData"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="OneKeyUpdateManagementAgentPort"
                        v-loading.body="listLoading"
                        size="mini"
                    >一键同步监控端口</el-button>
                </el-form-item>
                <el-form-item v-if="hasPermission()">
                    <el-button
                        type="primary"
                        @click="handleModuleInsert"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="checkLog"
                        v-loading.body="listLoading"
                        size="mini"
                    > 查询模块日志</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="isTabledalog=true"
                        v-loading.body="listLoading"
                        size="mini"
                    > 实例分布列表</el-button>
                </el-form-item>
                <el-form-item>
                    <el-checkbox
                        label="是否监控:"
                        v-model="inputMonitorEnabled"
                        size="mini"
                        @change="fetchData"
                        :border="true"
                    ></el-checkbox>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                :row-style="changeClass"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('moduleListTable.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item == 'artifactType'">{{scope.row[item]=='0'?'其他':(scope.row[item] =='1'?'vertx':'spring')}}</p>
                          <p v-else>{{scope.row[item]}}</p> 
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item class="buttonFOrm" v-if="hasPermission()">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm">
                                        <el-button
                                            type="primary"
                                            @click="handleInstance(scope.row.id,scope.row.moduleName)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >实例详情</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="hasPermission()">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(scope.row.id)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="moduleForm"
            ref="moduleForm"
        >
            <el-form-item
                prop="moduleName"
                label="模块名称"
                :rules="{required: true, message: '请输入模块名称'}"
                style="width:200px"
            >
                <el-input v-model="moduleForm.moduleName"></el-input>
                </el-form-item>
                <el-form-item
                    prop="moduleType"
                    label="模块类型"
                    :rules="[
          {required: true, message: '请输入模块类型'}
          ]"
                    style="width:200px"
                >
                    <el-select v-model="moduleForm.moduleType">
                        <el-option
                            v-for="item in moduleTypeTable"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                    </el-form-item>
                    <el-form-item
                        prop="artifactType"
                        label="构件类型"
                        :rules="[
          {required: true, message: '请输入构件类型'},
          {type: 'number', message: '必须为数字'}
          ]"
                        style="width:200px"
                    >
                        <el-select v-model="moduleForm.artifactType">
                            <el-option
                                v-for="item in artifactTypeTable"
                                :key="item.value"
                                :label="item.name"
                                :value="item.value"
                            >
                                </el-option>
                        </el-select>
                        </el-form-item>
                        <el-form-item
                            prop="artifactName"
                            label="构件名称"
                            :rules="[
          {required: true, message: '请输入构件名称'}
          ]"
                            style="width:200px"
                        >
                            <el-input v-model="moduleForm.artifactName"></el-input>
                            </el-form-item>
                            <el-form-item
                            prop="firstdev"
                            label="第一负责人"
                            :rules="[
          {required: true, message: '请输入第一负责人'}
          ]"
                            style="width:200px"
                        >
                            <el-input v-model="moduleForm.firstdev"></el-input>
                            </el-form-item>
                            <el-form-item
                            prop="seconddev"
                            label="第二负责人"
                            :rules="[
          {required: true, message: '请输入第二负责人'}
          ]"
                            style="width:200px"
                        >
                            <el-input v-model="moduleForm.seconddev"></el-input>
                            </el-form-item>
                            <el-form-item
                                prop="version"
                                label="版本号"
                                :rules="[
          {required: true, message: '请输入版本号'}
          ]"
                                style="width:200px"
                            >
                                <el-input v-model="moduleForm.version"></el-input>
                                </el-form-item>
                                <el-form-item
                                    prop="remark"
                                    label="说明"
                                    style="width:200px"
                                >
                                    <el-input v-model="moduleForm.remark"></el-input>
                                    </el-form-item>
                                    <el-form-item
                                        prop="monitorEnabled"
                                        label="是否监控"
                                        style="width:200px"
                                    >
                                        <el-switch v-model="moduleForm.monitorEnabled" @change="autoSetWarningMessage"></el-switch>
                                        </el-form-item>
                                        <el-form-item
                                            prop="monitorType"
                                            label="监控类型"
                                            :rules="[
          {required: true, message: '请输入监控类型'}
          ]"
                                            v-if="moduleForm.monitorEnabled"
                                            style="width:200px"
                                        >
                                        <el-select v-model="moduleForm.monitorType" @change="autoSetAlarmSchema">
                            <el-option
                                v-for="item in monitorTypeTable"
                                :key="item.value"
                                :label="item.name"
                                :value="item.value"
                            >
                                </el-option>
                        </el-select>
                                            </el-form-item>
                                            <el-form-item
                                                prop="monitorPort"
                                                label="监控端口号"
                                                :rules="[
          {required: true, message: '请输入监控端口号'},
          {type: 'number', message: '必须为数字'}
          ]"
                                                v-if="moduleForm.monitorEnabled"
                                                style="width:200px"
                                            >
                                                <el-input v-model.number="moduleForm.monitorPort"></el-input>
                                                </el-form-item>
                                                <el-form-item
                                                    prop="alarmFailed"
                                                    label="告警失效"
                                                    :rules="[
          {required: true, message: '请输入告警失效'}
          ]"
                                                    v-if="moduleForm.monitorEnabled"
                                                    style="width:200px"
                                                >
                                                    <el-switch v-model="moduleForm.alarmFailed"></el-switch>
                                                    </el-form-item>
                                                    <el-form-item
                                                        prop="templateId"
                                                        label="模板名称"
                                                        :rules="[
          {required: true, message: '请输入模板名称'}
          ]"
                                                        v-if="moduleForm.monitorEnabled"
                                                        style="width:200px"
                                                    >
                                                        <el-select v-model="moduleForm.templateId">
                                                            <el-option
                                                                v-for="item in templatesList"
                                                                :key="item.id"
                                                                :label="item.templateName"
                                                                :value="item.id"
                                                            >
                                                                </el-option>
                                                        </el-select>
                                                        </el-form-item>
                                                        <el-form-item
                                                            prop="monitorSchema"
                                                            label="监控模式"
                                                            :rules="[
          {required: true, message: '请输入监控集合'}
          ]"
                                                            v-if="moduleForm.monitorEnabled"
                                                            style="width:100%"
                                                        >
                                                            <el-input
                                                                v-model="moduleForm.monitorSchema"
                                                                type="textarea"
                                                                :autosize="true"
                                                                style="width:600px"
                                                            ></el-input>
                                                                </el-form-item>
                                                                <el-form-item
                                                                    prop="alarmMessage"
                                                                    label="告警信息"
                                                                    :rules="[
          {required: true, message: '请输入告警信息'}
          ]"
                                                                    v-if="moduleForm.monitorEnabled"
                                                                    style="width:100%"
                                                                >
                                                                    <el-input
                                                                        v-model="moduleForm.alarmMessage"
                                                                        type="textarea"
                                                                        :autosize="true"
                                                                        style="width:600px"
                                                                    ></el-input>
                                                                        </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('moduleForm')">确定</el-button>
      </span>
                                                                        </el-dialog>



<el-dialog
        title="实例分布表"
        :visible.sync="isTabledalog"
    >
    <el-form :inline="true"  @submit.native.prevent>
    <el-form-item label="实例名称:">
                    <el-input
                        v-model="inputInstacneName"
                        size="mini"
                          @keyup.enter.native="fetchInstanceTable"
                        placeholder="请输入实例名称"
                    ></el-input>
                </el-form-item>
                <el-form-item label="服务器地址:">
                    <el-input
                        v-model="inputServerIp"
                        size="mini"
                          @keyup.enter.native="fetchInstanceTable"
                        placeholder="请输入服务器地址"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="fetchInstanceTable"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
    </el-form>
    <el-table
                :data="instanceTable"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
                :span-method="objectspanMethod"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                    prop="serverIp"
                    label='服务器地址'
                >
                    </el-table-column>
                    <el-table-column
                    prop="instanceName"
                    label='实例名称'
                >
                    </el-table-column>
                    <el-table-column
                    prop="clusterId"
                    label='所属集群'
                    :filters="clusterFilter"
                    :filter-method="TabbleFillter"
                >
                <template slot-scope="scope">
                    <span v-for="item in clusterTable" :key="item.id" v-if="item.id==scope.row.clusterId">{{item.clusterName}}</span>
                </template>
                    </el-table-column>
    </el-table>
    </el-dialog>
</div>
</template>




<script>
const defaultFormThead = ['moduleName', 'moduleType', 'artifactName', 'artifactType', 'version', 'remark', 'monitorType', 'monitorPort', 'firstdev', 'seconddev', 'monitorEnabled']
import {
  getModuleList,
  insertModule,
  updateModule,
  deleteModule,
  findTemplate,
  instanceTable,
  queryClusters,
  modulesUpdatePort
} from '@/api/monitor'
import { managementAgentPortQuery } from '@/api/config'
import { mapGetters } from 'vuex'
import {
  Message
} from 'element-ui'
export default {
  name: 'moduleList',
  data() {
    return {
      list: null,
      templatesList: null,
      moduleForm: {
        moduleId: '',
        moduleName: '',
        moduleType: '',
        artifactType: null,
        artifactName: '',
        version: '',
        remark: '',
        monitorType: '',
        monitorPort: null,
        monitorSchema: '',
        monitorEnabled: false,
        alarmFailed: true,
        alarmMessage: '',
        templateId: null,
        firstdev: '',
        seconddev: ''
      },
      isUdate: false,
      dialogTitle: '模块添加',
      listLoading: true,
      isdalog: false,
      inputModuleName: '',
      inputModuleType: '',
      inputArtifactType: '',
      inputArtifactName: '',
      isTabledalog: false,
      instanceTable: [],
      inputInstacneName: '',
      inputServerIp: '',
      tableMerge: {
        rowNUm: [],
        rowSpace: []
      },
      clusterTable: null,
      clusterFilter: [],
      inputMonitorEnabled: false,
      inputTemplateId: '',
      moduleTypeTable: [{
        value: 'GW'
      }, {
        value: 'SP'
      }, {
        value: 'ZK'
      }],
      artifactTypeTable: [{
        name: '其他',
        value: 0
      }, {
        name: 'vertx',
        value: 1
      }, {
        name: 'spring',
        value: 2
      }],
      monitorTypeTable: [{
        name: 'JMX',
        value: 'JMX'
      }, {
        name: 'HTTP',
        value: 'HTTP'
      }],
      formTheadOptions: ['id', 'moduleName', 'moduleType', 'artifactName', 'artifactType', 'version', 'remark', 'monitorType', 'monitorPort', 'monitorSchema', 'monitorEnabled', 'alarmFailed', 'alarmMessage', 'templateId', 'created', 'firstdev', 'seconddev', 'updated'],
      checkboxVal: defaultFormThead,
      formThead: ['moduleName', 'moduleType', 'artifactName', 'artifactType', 'version', 'remark', 'monitorType', 'monitorPort', 'firstdev', 'seconddev', 'monitorEnabled']
    }
  },
  created() {
    this.fetchData()
    this.fetchInstanceTable()
    this.fetchClusterTablr()
    this.fetchTemplates()
    console.log('created moduleList!')
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '模块修改'
      else this.dialogTitle = '模块添加'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  methods: {
    OneKeyUpdateManagementAgentPort() {
      this.listLoading = true
      managementAgentPortQuery().then(response => {
        if (JSON.stringify(response) !== '{}') {
          console.log('port:', response)
          modulesUpdatePort(response).then(responses => {
            this.listLoading = false
            console.log('update:', responses)
            if (responses.code === 0) {
              Message.success('同步成功!')
              this.fetchData()
            } else {
              Message.error('同步失败!')
            }
          })
        }
      })
    },
    changeClass({ row, rowIndex }) {
    //   console.log('backgroud!!!!!!!!!!!', row.errorCode !== 0)
      if (!row.monitorEnabled) return 'background: darkgray;'
      else return 'background: floralwhite;'
    },
    handleModuleInsert() {
    //   this.moduleForm = {}
      this.moduleForm['moduleId'] = ''
      this.moduleForm['moduleName'] = ''
      this.moduleForm['moduleType'] = ''
      this.moduleForm['artifactType'] = null
      this.moduleForm['artifactName'] = ''
      this.moduleForm['version'] = ''
      this.moduleForm['remark'] = ''
      this.moduleForm['monitorType'] = ''
      this.moduleForm['monitorPort'] = null
      this.moduleForm['monitorSchema'] = ''
      this.moduleForm['monitorEnabled'] = false
      this.moduleForm['alarmFailed'] = true
      this.moduleForm['alarmMessage'] = ''
      this.moduleForm['templateId'] = null
      this.moduleForm['firstdev'] = ''
      this.moduleForm['seconddev'] = ''
      this.isdalog = true
    },
    TabbleFillter(value, row) {
    //   console.log('filter:')
      if (row.clusterId === value) { return true }
      return false
    },
    fetchClusterTablr() {
      queryClusters().then(response => {
        this.clusterTable = response.data.clusterList
        this.clusterFilter = []
        for (const i of response.data.clusterList) {
          this.clusterFilter.push({
            text: i.clusterName,
            value: i.id
          })
        }
        console.log('clusterTable', this.clusterTable)
        this.listLoading = false
      })
    },
    objectspanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 1 || columnIndex === 0) {
        // if (rowIndex === 0) {
        //   return {
        //     rowspan: 1,
        //     colspan: 1
        //   }
        // }
        for (const i in this.tableMerge.rowNUm) {
          if (this.tableMerge.rowNUm[i] === rowIndex) {
            return {
              rowspan: this.tableMerge.rowSpace[i],
              colspan: 1
            }
          }
        }
        return {
          rowspan: 0,
          colspan: 0
        }
      }
    },
    fetchInstanceTable() {
      this.listLoading = true
      instanceTable(this.inputInstacneName, this.inputServerIp).then(response => {
        console.log(response)
        this.instanceTable = response.data.instanceTable
        /** 获取合并table的结构，rowNum为内容不同的的行的开始行号，rowSpace是由此行接下来几行是相同名称的需要合并 */
        this.tableMerge.rowNUm = []
        this.tableMerge.rowSpace = []
        var tempNmae = this.instanceTable[0].serverIp
        var count = 0
        var countspace = 1
        for (const i in this.instanceTable) {
          if (i > 0) {
            if (this.instanceTable[i].serverIp !== tempNmae) {
              tempNmae = this.instanceTable[i].serverIp
              this.tableMerge.rowSpace.push(countspace)
              if (this.tableMerge.rowSpace.length === 1) {
                this.tableMerge.rowNUm.push(count)
                count += countspace
                this.tableMerge.rowNUm.push(count)
              } else {
                count += countspace
                this.tableMerge.rowNUm.push(count)
              }
              countspace = 1
            } else {
              countspace++
            }
          }
        }
        if (this.tableMerge.rowNUm.length === 0) {
          this.tableMerge.rowSpace.push(countspace)
          if (this.tableMerge.rowSpace.length === 1) {
            this.tableMerge.rowNUm.push(count)
            count += countspace
            this.tableMerge.rowNUm.push(count)
          } else {
            count += countspace
            this.tableMerge.rowNUm.push(count)
          }
          countspace = 1
        }
        this.tableMerge.rowSpace.push(countspace)
        this.objectspanMethod({ row: 1, colum: 1, rowIndex: 0, columIndex: 1 })
        // console.log('instanceTable', this.instanceTable)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    hasPermission() {
      const ROLES = ['admin', 'moduleListButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    autoSetAlarmSchema() {
      if (this.moduleForm.monitorType === 'HTTP') this.moduleForm.monitorSchema = 'http://#{host}:#{port}'
      else if (this.moduleForm.monitorType === 'JMX') this.moduleForm.monitorSchema = 'service:jmx:rmi:///jndi/rmi://#{host}:#{port}/jmxrmi'
      else this.moduleForm.monitorSchema = ''
    },
    autoSetWarningMessage() {
      console.log('enter auto')
      if (this.moduleForm.monitorEnabled) this.moduleForm.alarmMessage = '[#{location}][#{cluster}][#{serverIp}][#{moduleInstance}] 状态未知(监控连接异常)'
      else this.moduleForm.alarmMessage = ''
    },
    fetchTemplates() {
      findTemplate('').then(response => {
        console.log(response)
        this.templatesList = response.data.templates
      })
    },
    fetchData() {
      this.listLoading = true
      if (!this.inputMonitorEnabled) this.inputMonitorEnabled = ''
      getModuleList(this.inputModuleName, this.inputModuleType, this.inputArtifactType, this.inputMonitorEnabled, this.inputTemplateId, this.inputArtifactName).then(response => {
        console.log(response)
        this.list = response.data.ModuleList.map(v => {
          this.$set(v, 'deleteFlag', false)
          return v
        })
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.$refs['moduleForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.moduleForm)
              this.listLoading = true
              if (!this.moduleForm.monitorEnabled) {
                this.moduleForm.monitorType = ''
                this.moduleForm.monitorPort = null
                this.moduleForm.monitorSchema = ''
                this.moduleForm.alarmFailed = true
                this.moduleForm.alarmMessage = ''
                this.moduleForm.templateId = null
                console.log('列表清空' + this.moduleForm.templateId)
              }
              this.fetchTemplates()
              if (this.moduleForm.templateId != null) {
                findTemplate(this.moduleForm.templateId).then(response => {
                  console.log(response)
                  if (response.data.templates.length === 0) {
                    this.listLoading = false
                    Message.error('templateId不存在,请重新输入')
                  } else {
                    if (this.isUdate) {
                      return new Promise((resolve, reject) => {
                        updateModule(this.moduleForm).then(response => {
                          console.log(response)
                          this.fetchData()
                          this.listLoading = false
                          this.isUdate = false
                          this.$refs['moduleForm'].resetFields()
                          resolve(response)
                          this.isdalog = false
                        }).catch((error) => {
                          this.listLoading = false
                          this.isUdate = false
                          reject(error)
                          this.isdalog = false
                        })
                      })
                    } else {
                      return new Promise((resolve, reject) => {
                        insertModule(this.moduleForm).then(response => {
                          console.log(response)
                          this.fetchData()
                          this.listLoading = false
                          this.$refs['moduleForm'].resetFields()
                          resolve(response)
                          this.isdalog = false
                        }).catch((error) => {
                          this.listLoading = false
                          reject(error)
                          this.isdalog = false
                        })
                      })
                    }
                  }
                })
              } else {
                if (this.isUdate) {
                  return new Promise((resolve, reject) => {
                    updateModule(this.moduleForm).then(response => {
                      console.log(response)
                      this.fetchData()
                      this.listLoading = false
                      this.isUdate = false
                      this.$refs['moduleForm'].resetFields()
                      resolve(response)
                      this.isdalog = false
                    }).catch((error) => {
                      this.listLoading = false
                      this.isUdate = false
                      reject(error)
                      this.isdalog = false
                    })
                  })
                } else {
                  return new Promise((resolve, reject) => {
                    insertModule(this.moduleForm).then(response => {
                      console.log(response)
                      this.fetchData()
                      this.listLoading = false
                      this.$refs['moduleForm'].resetFields()
                      resolve(response)
                      this.isdalog = false
                    }).catch((error) => {
                      this.listLoading = false
                      reject(error)
                      this.isdalog = false
                    })
                  })
                }
              }
              this.fetchData()
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.moduleForm = Object.assign({}, rows)
      this.isdalog = true
      this.isUdate = true
    },
    handleDelete(id) {
      return new Promise((resolve, reject) => {
        deleteModule(id).then(response => {
          console.log(response)
          this.fetchData()
          this.listLoading = false
          this.$refs['moduleForm'].resetFields()
          resolve(response)
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    },
    handleInstance: function(moduleId, moduleName) {
      console.log('/monitor/instanceList/' + moduleId + '/' + moduleName)
      this.$router.push('/monitor/instanceList/' + moduleId + '/' + moduleName)
      // window.parent.addTab(title, seqUrl)
    },
    checkLog() {
      console.log('/monitor/moduleManagement')
      this.$router.push('/monitor/moduleManagement')
    }
  }
}
</script>



<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
