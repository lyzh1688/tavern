<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true">
                <el-form-item>
                    <el-popover
                        placement="right"
                        width="708"
                        trigger="click"
                    >
                        <el-card>
                            <div class="header">
                                <div style="display:flex;justify-content:center">
                                    <p>列表显示内容</p>
                                </div>
                            </div>
                            <el-checkbox-group
                                v-model="checkboxVal"
                                style="float: left;"
                            >
                                <div style="display:flex;flex-wrap:wrap;justify-content:flex-end">
                                    <el-checkbox
                                        :key='item'
                                        v-for='item in formTheadOptions'
                                        :label="item"
                                        :border="true"
                                        size="small"
                                        style="width:150px"
                                    >{{$t('instanceTable.'+item)}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                        </el-card>
                        <el-button
                            slot="reference"
                            style="float: left"
                            type="primary"
                            size="mini"
                        >列表内容</el-button>
                            </el-popover>
                </el-form-item>
                <el-form-item>
                    <el-checkbox
                        label="是否可用:"
                        v-model="inputValid"
                        size="mini"
                        @change="fetchData"
                        :border="true"
                    ></el-checkbox>
                </el-form-item>
                <el-form-item v-if="hasPermission()">
                    <el-button
                        type="primary"
                        @click="isdalog=true"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                :row-style="changeClass"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('instanceTable.'+item)"
                        width="auto"
                    >
                        <template slot-scope="scope">
                            <p
                                v-if="item=='locationId'&scope.row[item]==itemA.id"
                                v-for="itemA in LocationList"
                                :key="itemA.id"
                            >{{itemA.location}}</p>
                                <p
                                    v-if="item=='clusterId'&scope.row[item]==itemB.id"
                                    v-for="itemB in ClusterList"
                                    :key="itemB.id"
                                >{{itemB.clusterName}}</p>
                                    <p
                                        v-if="item=='proxyId'&scope.row[item]==itemA.id"
                                        v-for="itemA in ProxyList"
                                        :key="itemA.id"
                                    >{{itemA.proxyName}}</p>
                                        <p v-if="item=='moduleId'">{{instanceForm.instanceName}}</p>
                                        <p v-if="item=='id'">{{scope.row[item]}}</p>
                                        <p v-if="item=='created'">{{scope.row[item]}}</p>
                                        <p v-if="item=='instanceName'">{{scope.row[item]}}</p>
                                        <p v-if="item=='serverIp'">{{scope.row[item]}}</p>
                                        <p v-if="item=='valid'">{{scope.row[item]}}</p>
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                            width="500px"
                        >
                            <template slot-scope="scope">
                                <el-form :inline="true">
                                    <el-form-item class="buttonFOrm" v-if="hasPermission()">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm">
                                        <el-button
                                    type="primary"
                                    @click="handleInstanceMetrics(scope.row.id,scope.row.instanceName)"
                                    v-loading.body="listLoading"
                                    size="mini"
                                    > 实例指标</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm">
                                        <el-button
                                    type="primary"
                                    @click="handleDetailInfo(scope.row.id,scope.row.serverIp,scope.row.moduleId,scope.row.instanceName)"
                                    v-loading.body="listLoading"
                                    size="mini"
                                    >实例状态及管理</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="hasPermission()">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(scope.row)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="instanceForm"
            ref="instanceForm"
        >
            <el-form-item
                prop="instanceName"
                label="实例名称"
                :rules="{required: true, message: '请输入实例名称'}"
                style="width:200px"
            >
                <el-input v-model="instanceForm.instanceName"></el-input>
                </el-form-item>
                <el-form-item
                    prop="serverIp"
                    label="服务器地址"
                    :rules="[
          {required: true, message: '请输入服务器地址'}
          ]"
                    style="width:200px"
                >
                    <el-input v-model="instanceForm.serverIp"></el-input>
                    </el-form-item>
                    <el-form-item
                        prop="locationId"
                        label="位置名称"
                        :rules="[
          {required: true, message: '请输入位置名称'}
          ]"
                        style="width:200px"
                    >
                        <el-select v-model="instanceForm.locationId">
                            <el-option
                                v-for="item in LocationList"
                                :key="item.id"
                                :label="item.location"
                                :value="item.id"
                            >
                                </el-option>
                        </el-select>
                        </el-form-item>
                        <el-form-item
                            prop="clusterId"
                            label="集群名称"
                            :rules="[
          {required: true, message: '请输入集群名称'}
          ]"
                            style="width:200px"
                        >
                            <el-select v-model="instanceForm.clusterId">
                                <el-option
                                    v-for="item in ClusterList"
                                    :key="item.id"
                                    :label="item.clusterName"
                                    :value="item.id"
                                >
                                    </el-option>
                            </el-select>
                            </el-form-item>
                            <el-form-item
                                prop="proxyId"
                                label="代理名称"
                                :rules="[
          {required: true, message: '请输入代理名称'}
          ]"
                                style="width:200px"
                            >
                                <el-select v-model="instanceForm.proxyId">
                                    <el-option
                                        v-for="item in ProxyList"
                                        :key="item.id"
                                        :label="item.proxyName"
                                        :value="item.id"
                                    >
                                        </el-option>
                                </el-select>
                                </el-form-item>
                                <el-form-item
                                prop="valid"
                                label="是否可用"
                                :rules="[
          {required: true, message: '请输入是否可用'}
          ]"
                                style="width:200px"
                            >
                                <el-switch v-model="instanceForm.valid"></el-switch>
                                </el-form-item>
                                </el-form>
                                <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('instanceForm')">确定</el-button>
      </span>
                                </el-dialog>
</div>
</template>


<script>
const defaultFormThead = ['instanceName', 'serverIp', 'locationId', 'clusterId', 'proxyId', 'valid', 'created']
import {
  queryProxy,
  queryClusters,
  queryLocations,
  updateInstance,
  insertInstance,
  queryInstance
} from '@/api/monitor'
import { mapGetters } from 'vuex'
export default {
  name: 'instanceList',
  data() {
    return {
      list: null,
      LocationList: null,
      ClusterList: null,
      ProxyList: null,
      instanceForm: {
        moduleId: '',
        instanceName: '',
        ClusterId: '',
        LocationId: '',
        proxyId: '',
        id: '',
        valid: true,
        serverIp: ''
      },
      isUdate: false,
      dialogTitle: '添加实例',
      listLoading: true,
      isdalog: false,
      inputValid: false,
      formTheadOptions: ['id', 'instanceName', 'serverIp', 'locationId', 'clusterId', 'moduleId', 'proxyId', 'valid', 'created'],
      checkboxVal: defaultFormThead,
      formThead: ['instanceName', 'serverIp', 'locationId', 'clusterId', 'proxyId', 'valid', 'created']
    }
  },
  created() {
    if (this.$route.params.moduleId !== undefined) {
      this.instanceForm.moduleId = this.$route.params.moduleId
    }
    if (this.$route.params.moduleName !== undefined) {
      this.instanceForm.instanceName = this.$route.params.moduleName
    }
    this.fetchData()
    this.fetchLocations()
    this.fetchProxy()
    this.fetchClusters()
    console.log('created moduleList!')
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  watch: {
    // $route() {
    //   if (this.$route.params.moduleId !== undefined) {
    //     this.instanceForm.moduleId = this.$route.params.moduleId
    //   }
    //   if (this.$route.params.moduleName !== undefined) {
    //     this.instanceForm.instanceName = this.$route.params.moduleName
    //   }
    //   this.fetchData()
    //   this.fetchLocations()
    //   this.fetchProxy()
    //   this.fetchClusters()
    // },
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '修改实例'
      else this.dialogTitle = '添加实例'
    }
  },
  methods: {
    changeClass({ row, rowIndex }) {
    //   console.log('backgroud!!!!!!!!!!!', row.errorCode !== 0)
      if (!row.valid) return 'background: darkgray;'
      else return 'background: floralwhite;'
    },
    handleDetailInfo: function(instanceID, serverIP, moduleId, moduleName) {
      // let queryStatus = ''
      // if (Status === '正常') {
      //   queryStatus = '0'
      // } else if (Status === '告警') {
      //   queryStatus = '1'
      // } else if (Status === '未采集数据') {
      //   queryStatus = '-1'
      // } else if (Status === '未启用监控') {
      //   queryStatus = '-1'
      // }
      // console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
      // this.$router.push('/monitor/instanceStatus/' + -1 + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      console.log('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      this.$router.push('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + moduleName + ':' + serverIP.replace(new RegExp(/\./g), '_'))
      // window.parent.addTab(title, seqUrl)
    },
    hasPermission() {
      const ROLES = ['admin', 'instanceListButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    fetchLocations() {
      queryLocations().then(response => {
        console.log(response)
        this.LocationList = response.data.locationList
      })
    },
    fetchClusters() {
      queryClusters().then(response => {
        console.log(response)
        this.ClusterList = response.data.clusterList
      })
    },
    fetchProxy() {
      queryProxy().then(response => {
        console.log(response)
        this.ProxyList = response.data.proxyList
      })
    },
    fetchData() {
      this.listLoading = true
      queryInstance(this.instanceForm.moduleId, this.inputValid).then(response => {
        console.log(response)
        this.list = response.data.instanceList.map(v => {
          this.$set(v, 'deleteFlag', false)
          return v
        })
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.$refs['instanceForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.instanceForm)
              this.listLoading = true
              this.fetchLocations()
              this.fetchProxy()
              this.fetchClusters()
              if (this.isUdate) {
                return new Promise((resolve, reject) => {
                  updateInstance(this.instanceForm).then(response => {
                    console.log(response)
                    this.fetchData()
                    this.listLoading = false
                    this.isUdate = false
                    this.$refs['instanceForm'].resetFields()
                    resolve(response)
                    this.isdalog = false
                  }).catch((error) => {
                    this.listLoading = false
                    this.isUdate = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              } else {
                return new Promise((resolve, reject) => {
                  insertInstance(this.instanceForm).then(response => {
                    console.log(response)
                    this.fetchData()
                    this.listLoading = false
                    this.$refs['instanceForm'].resetFields()
                    resolve(response)
                    this.isdalog = false
                  }).catch((error) => {
                    this.listLoading = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              }
            })
            .catch(_ => {
              this.$refs['instanceForm'].resetFields()
            })
        } else {
          this.$refs['instanceForm'].resetFields()
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.instanceForm = Object.assign({}, rows)
      this.isdalog = true
      this.isUdate = true
    },
    handleDelete(rows) {
      this.instanceForm = Object.assign({}, rows)
      this.instanceForm.valid = false
      return new Promise((resolve, reject) => {
        updateInstance(this.instanceForm).then(response => {
          console.log(response)
          this.fetchData()
          this.listLoading = false
          this.isUdate = false
          this.$refs['instanceForm'].resetFields()
          resolve(response)
          this.isdalog = false
        }).catch((error) => {
          this.listLoading = false
          this.isUdate = false
          reject(error)
          this.isdalog = false
        })
      })
    },
    handleInstanceMetrics: function(id, name) {
      console.log('/monitor/instanceMetrics/' + id + '/' + name + ':M')
      this.$router.push('/monitor/instanceMetrics/' + id + '/' + name + ':M')
      // window.parent.addTab(title, seqUrl)
    }
  }
}
</script>

<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}


</style>
