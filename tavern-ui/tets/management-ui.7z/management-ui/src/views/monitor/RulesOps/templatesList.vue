<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true" @submit.native.prevent>
                <el-form-item>
                </el-form-item>
                <el-form-item label="模板Id:">
                    <el-input
                        v-model="inputTemplateId"
                        size="mini"
                        @keyup.enter.native="fetchData"
                        placeholder="请输入模块名称"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="fetchData"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
                <el-form-item v-if="hasPermission()">
                    <el-button
                        type="primary"
                        @click="isdalog=true"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('moduleListTable.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item=='id'">{{scope.row[item]}}</p> 
                          <p v-if="item=='created'">{{scope.row[item]}}</p> 
                          <p v-if="item=='templateName'&&scope.row.updateFlag==false">{{scope.row[item]}}</p> 
                          <p v-if="item=='remark'&&scope.row.updateFlag==false">{{scope.row[item]}}</p> 
                          <el-input v-if="item=='templateName'&&scope.row.updateFlag==true" v-model="templateForm.templateName"></el-input>
                          <el-input v-if="item=='remark'&&scope.row.updateFlag==true" v-model="templateForm.remark"></el-input>
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item  class="buttonFOrm" v-if="scope.row.updateFlag==false&&isUpdate==false&&hasPermission()">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row,false)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="scope.row.updateFlag==true&&hasPermission()">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.updatePopFlag"
                                        >
                                            <p>确定提交吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.updatePopFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleUpdate(scope.row,true)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="danger"
                                                class="operationButton"
                                                type="primary"
                                                size="mini"
                                            >提交</el-button>
                                                </el-popover>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="scope.row.updateFlag==true&&hasPermission()">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.updateCancelFlag"
                                        >
                                            <p>确定取消吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.updateCancelFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="scope.row.updateFlag=false,isUpdate=false,scope.row.updateCancelFlag=false"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="primary"
                                                size="mini"
                                            >取消</el-button>
                                                </el-popover>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="scope.row.updateFlag==false&&isUpdate==false">
                                        <el-button
                                            type="primary"
                                            @click="handleParser(scope.row.id,scope.row.templateName)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >解析器</el-button>
                                    </el-form-item>
                                    <!-- <el-form-item class="buttonFOrm" v-if="scope.row.updateFlag==false&&isUpdate==false">
                                        <el-button
                                            type="primary"
                                            @click="handleAlarmRule(scope.row.id,scope.row.templateName)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >告警规则</el-button>
                                    </el-form-item> -->
                                    <el-form-item class="buttonFOrm" v-if="scope.row.updateFlag==false&&isUpdate==false&&hasPermission()">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(scope.row.id,scope.row.templateName)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="templateForm"
            ref="templateForm"
        >
            <el-form-item
                prop="templateName"
                label="模板名称"
                :rules="{required: true, message: '请输入模板名称'}"
                style="width:200px"
            >
                <el-input v-model="templateForm.templateName"></el-input>
                </el-form-item>
            <el-form-item
                prop="remark"
                label="说明"
                style="width:200px"
            >
                <el-input v-model="templateForm.remark"></el-input>
                </el-form-item>
        </el-form>
        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('templateForm')">确定</el-button>
      </span>
</el-dialog>
</div>
</template>




<script>
import {
  insertTemplate,
  updateTemplate,
  deleteTemplate,
  findTemplate
} from '@/api/monitor'
import { mapGetters } from 'vuex'
export default {
  name: 'templatesList',
  data() {
    return {
      list: null,
      templateForm: {
        remark: '',
        templateName: ''
      },
      isUpdate: false,
      dialogTitle: '模板添加',
      listLoading: true,
      isdalog: false,
      inputTemplateId: '',
      formThead: ['id', 'templateName', 'remark', 'created']
    }
  },
  created() {
    this.fetchData()
    console.log('created moduleList!')
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUpdate() {
      if (this.isUpdate) this.dialogTitle = '模板修改'
      else this.dialogTitle = '模板添加'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'templatesListButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    fetchData() {
      this.listLoading = true
      findTemplate(this.inputTemplateId).then(response => {
        console.log(response)
        this.list = response.data.templates.map(v => {
          this.$set(v, 'deleteFlag', false)
          this.$set(v, 'updateFlag', false)
          this.$set(v, 'updateCancelFlag', false)
          this.$set(v, 'updatePopFlag', false)
          return v
        })
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUpdate = false
          this.$refs['templateForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.templateForm)
              this.listLoading = true
              insertTemplate(this.templateForm.templateName, this.templateForm.remark).then(response => {
                console.log(response)
                this.listLoading = false
                if (response.code === 0) {
                  this.$refs['templateForm'].resetFields()
                  this.isdalog = false
                  this.fetchData()
                }
              })
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows, confirm) {
      this.isUpdate = true
      rows.updateFlag = true
      if (confirm) {
        updateTemplate(rows.id, this.templateForm.templateName, this.templateForm.remark).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            console.log(response)
            rows.updateFlag = false
            this.isUpdate = false
            this.fetchData()
          }
        })
      } else this.templateForm = Object.assign({}, rows)
    },
    handleDelete(id, templateName) {
      return new Promise((resolve, reject) => {
        deleteTemplate(id, templateName).then(response => {
          console.log(response)
          if (response.code === 0) {
            this.fetchData()
            this.listLoading = false
          }
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    },
    handleParser(moduleId, templateName) {
    //   console.log('/monitor/' + moduleId + '/' + moduleName)
      this.$router.push({ path: '/monitor/AlarmRulesManagement/parserList', query: { templateName: templateName }})
      // window.parent.addTab(title, seqUrl)
    },
    handleAlarmRule(moduleId, moduleName) {
    //   console.log('/monitor/' + moduleId + '/' + moduleName)
      this.$router.push('/monitor/AlarmRulesManagement/alarmRulesList')
      // window.parent.addTab(title, seqUrl)
    }
  }
}
</script>



<style>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
