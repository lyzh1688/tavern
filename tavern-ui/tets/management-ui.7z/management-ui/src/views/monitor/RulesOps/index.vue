<template>
<transition
    name="fade"
    mode="out-in"
>
    <keep-alive :include='cachedViews'>
        <router-view :key="$route.path" ></router-view>
    </keep-alive>
    </transition>
</template>


<script>
export default {
  name: 'RuleTableMain',
  computed: {
    cachedViews() {
      return this.$store.state.tagsView.cachedViews
    }
  }
}
</script>
