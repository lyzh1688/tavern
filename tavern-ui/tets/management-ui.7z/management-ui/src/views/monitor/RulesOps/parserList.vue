<template>
<div class="app-container">
    <el-tabs tab-position="left" v-model="activePane">
        <el-tab-pane v-for="itemABC in templatesList" :key="itemABC.templateName" :label="itemABC.templateName" :name="itemABC.templateName"><el-card >
        <div class="header">
            <el-form :inline="true" v-if="hasPermission()">
                <el-form-item >
                    <el-button
                        type="primary"
                        @click="isdalog=true,insertTemplateId=itemABC.id"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="listA._c.get(itemABC.templateName)"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('parser.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item == 'artifactType'">{{scope.row[item]=='0'?'其他':(scope.row[item] =='1'?'vertx':'spring')}}</p>
                          <p v-else>{{scope.row[item]}}</p> 
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item class="buttonFOrm" v-if="hasPermission()">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" >
                                        <el-button
                                            type="primary"
                                            @click="handleAlarmRule(scope.row.id,(itemABC.templateName+':'+scope.row.parserName.replace(' ','')))"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >告警规则</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" >
                                        <el-button
                                            type="primary"
                                            @click="handleMetrics(scope.row.id,(itemABC.templateName+':'+scope.row.parserName.replace(' ','')))"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >指标管理</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm" v-if="hasPermission()">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(itemABC.templateName,itemABC.id,scope.row.id)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card></el-tab-pane>
    </el-tabs>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="parserForm"
            ref="parserForm"
        >
            <el-form-item
                prop="parserName"
                label="解析器名称"
                :rules="{required: true, message: '请输入解析器名称'}"
                style="width:200px"
            >
                <el-input v-model="parserForm.parserName"></el-input>
                </el-form-item>
                <el-form-item
                prop="attributeName"
                label="属性名称"
                style="width:200px"
            >
                <el-input v-model="parserForm.attributeName"></el-input>
                </el-form-item>
                <el-form-item
                prop="parser"
                label="解析器"
                :rules="{required: true, message: '请输入解析器'}"
                style="width:200px"
            >
                <el-input v-model="parserForm.parser"></el-input>
                </el-form-item>
                <el-form-item
                prop="remark"
                label="说明"
                style="width:200px"
                >
                <el-input v-model="parserForm.remark"></el-input>
                </el-form-item>
                <el-form-item
                                                            prop="objectName"
                                                            label="JMX对象名称"
                                                            :rules="[
          {required: true, message: '请输入JMX对象名称'}
          ]"
                                                            style="width:100%"
                                                        >
                                                            <el-input
                                                                v-model="parserForm.objectName"
                                                                type="textarea"
                                                                :autosize="true"
                                                                style="width:600px"
                                                            ></el-input>
                                                                </el-form-item>
                                                                <el-form-item
                                                            prop="messageExp"
                                                            label="消息格式"
                                                            style="width:100%"
                                                        >
                                                            <el-input
                                                                v-model="parserForm.messageExp"
                                                                type="textarea"
                                                                :autosize="true"
                                                                style="width:600px"
                                                            ></el-input>
                                                                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('parserForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
</div>
</template>




<script>
import {
  queryParser,
  insertParser,
  updateParser,
  deleteParser,
  findTemplateParser,
  insertTemplateParser,
  deleteTemplateParser,
  findTemplate
} from '@/api/monitor'
import { mapGetters } from 'vuex'
import axios from 'axios'
export default {
  name: 'parserList',
  data() {
    return {
      list: new Map(),
      listA: new Map(),
      templatesList: null,
      templatesParsersList: new Map(),
      parserForm: {
        id: '',
        parserName: '',
        parser: '',
        objectName: '',
        remark: '',
        attributeName: '',
        messageExp: ''
      },
      isUdate: false,
      dialogTitle: '解析器添加',
      activePane: '',
      listLoading: true,
      isdalog: false,
      insertTemplateId: '',
      moduleTypeTable: [{
        value: 'GW'
      }, {
        value: 'SP'
      }, {
        value: 'ZK'
      }],
      artifactTypeTable: [{
        name: '其他',
        value: 0
      }, {
        name: 'vertx',
        value: 1
      }, {
        name: 'spring',
        value: 2
      }],
      monitorTypeTable: [{
        name: 'JMX',
        value: 'JMX'
      }, {
        name: 'HTTP',
        value: 'HTTP'
      }],
      formThead: ['id', 'parserName', 'parser', 'objectName', 'attributeName', 'messageExp', 'remark', 'created']
    }
  },
  created() {
    console.log('created moduleList!')
  },
  activated() {
    if (this.$route.query.templateName !== undefined && this.$route.query.templateName !== '' && this.$route.query.templateName !== '0') {
      this.activePane = this.$route.query.templateName
      console.log('activePane', this.activePane)
    }
    console.log('activePane', this.activePane)
    this.fetchTemplates()
    // console.log('name:', this.activePane)
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '解析器修改'
      else this.dialogTitle = '解析器添加'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'parserListButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    fetchTemplates() {
      findTemplate('').then(response => {
        console.log(response)
        this.templatesList = response.data.templates
        if (this.activePane === '' || this.activePane === '0') this.activePane = this.templatesList[0].templateName
        this.fetchTemplatesParsers()
      })
    },
    fetchTemplatesParsers() {
      this.listLoading = true
      const requestGroup = []
      for (const i of this.templatesList) {
        requestGroup.push(
          findTemplateParser(i.id).then(response => {
            console.log(response)
            this.templatesParsersList.set(i.templateName, response.data.templateParsers)
          })
        )
      }
      axios.all(requestGroup).then(function() {
        this.listLoading = false
        // this.functionData[secction.replace(new RegExp(/-/g), '') + 'Request'] = lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData
        console.log('templatesParsersList:', this.templatesParsersList)
        this.fetchData()
      }.bind(this))
    },
    fetchData() {
      const requestGroup = []
      for (const i of this.templatesList) {
        this.list.set(i.templateName, [])
        for (const j of this.templatesParsersList.get(i.templateName)) {
          requestGroup.push(
            queryParser(j.parserId, '').then(response => {
              console.log(response)
              const compare = function(obj1, obj2) {
                const val1 = obj1.parserName
                const val2 = obj2.parserName
                if (val1 > val2) return -1
                else if (val1 < val2) return 1
                else return 0
              }
              this.list.set(i.templateName, this.list.get(i.templateName).concat(response.data.parsers.map(v => {
                this.$set(v, 'deleteFlag', false)
                return v
              })).sort(compare))
            })
          )
        }
      }
      axios.all(requestGroup).then(function() {
        this.listLoading = false
        // this.$set(this.listA, 'this.listA', this.list)
        this.listA = Object.assign({}, this.list)
        // this.listA = [... this.list]// table检测不到内部赋值，例如set。push等，所以直接用list作为table的数据来源会导致table不会刷新，数据出不来。所以需要新建一个变量直接赋值来刷新表格。
        // this.functionData[secction.replace(new RegExp(/-/g), '') + 'Request'] = lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData
        console.log('list:', this.listA._c, this.list)
      }.bind(this))
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.$refs['parserForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.parserForm)
              this.listLoading = true
              if (this.parserForm.messageExp === '') this.parserForm.messageExp = null
              if (!this.isUdate) {
                return new Promise((resolve, reject) => {
                  insertParser(this.parserForm).then(response => {
                    console.log(response)
                    if (response.code === 0) {
                      const OBJ = {
                        templateId: this.insertTemplateId,
                        parserId: response.message
                      }
                      insertTemplateParser(OBJ).then(response => {
                        if (response.code === 0) {
                          this.listLoading = false
                          this.isUdate = false
                          this.$refs['parserForm'].resetFields()
                          resolve(response)
                          this.isdalog = false
                          this.fetchTemplates()
                        }
                      })
                    }
                  }).catch((error) => {
                    this.listLoading = false
                    this.isUdate = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              } else {
                return new Promise((resolve, reject) => {
                  updateParser(this.parserForm).then(response => {
                    if (response.code === 0) {
                      this.listLoading = false
                      this.isUdate = false
                      this.$refs['parserForm'].resetFields()
                      resolve(response)
                      this.isdalog = false
                      this.fetchTemplates()
                    }
                  }).catch((error) => {
                    this.listLoading = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.parserForm = Object.assign({}, rows)
      this.isdalog = true
      this.isUdate = true
    },
    handleDelete(templateName, templateId, parserId) {
      let deleteParserId = ''
      for (const i of this.templatesParsersList.get(templateName)) {
        console.log('templateId:', i.templateId, 'parserId', i.parserId)
        if (i.templateId === templateId && i.parserId === parserId) deleteParserId = i['id']
      }
      return new Promise((resolve, reject) => {
        deleteTemplateParser(deleteParserId).then(response => {
          console.log(response)
          if (response.code === 0) {
            deleteParser(parserId).then(response => {
              if (response.code === 0) {
                this.listLoading = false
                this.fetchTemplates()
              }
            })
          }
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    },
    handleAlarmRule(moduleId, moduleName) {
    //   console.log('/monitor/' + moduleId + '/' + moduleName)
      this.$router.push('/monitor/AlarmRulesManagement/alarmRulesList/' + moduleId + '/' + moduleName)
      // window.parent.addTab(title, seqUrl)
    },
    handleMetrics(moduleId, moduleName) {
    //   console.log('/monitor/' + moduleId + '/' + moduleName)
      this.$router.push('/monitor/AlarmRulesManagement/metricsList/' + moduleId + '/' + moduleName)
      // window.parent.addTab(title, seqUrl)
    }
  }
}
</script>



<style>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
