<template>
<div class="app-container">
    <el-card>
        <div class="header">
            <el-form :inline="true" @submit.native.prevent>
                <el-form-item>
                    <el-popover
                        placement="right"
                        width="708"
                        trigger="click"
                    >
                        <el-card>
                            <div class="header">
                                <div style="display:flex;justify-content:center">
                                    <p>列表显示内容</p>
                                </div>
                            </div>
                            <el-checkbox-group
                                v-model="checkboxVal"
                                style="float: left;"
                            >
                                <div style="display:flex;flex-wrap:wrap;justify-content:flex-end">
                                    <el-checkbox
                                        :key='item'
                                        v-for='item in formTheadOptions'
                                        :label="item"
                                        :border="true"
                                        size="small"
                                        style="width:150px"
                                    >{{$t('alarmRules.'+item)}}</el-checkbox>
                                </div>
                                </el-checkbox-group>
                        </el-card>

                        <el-button
                            slot="reference"
                            style="float: left"
                            type="primary"
                            size="mini"
                        >列表内容</el-button>
                            </el-popover>
                </el-form-item>
                <el-form-item label="规则名称:">
                    <el-input
                        v-model="inputRuleName"
                        size="mini"
                        @keyup.enter.native="fetchData"
                        placeholder="请输入规则名称"
                    ></el-input>
                </el-form-item>
                <el-form-item label="规则Id:">
                    <el-input
                        v-model="inputRuleId"
                        size="mini"
                        @keyup.enter.native="fetchData"
                        placeholder="请输入规则Id"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button
                        type="primary"
                        @click="fetchData"
                        v-loading.body="listLoading"
                        size="mini"
                    >查询</el-button>
                </el-form-item>
                <el-form-item v-if="hasPermission()">
                    <el-button
                        type="primary"
                        @click="isdalog=true"
                        v-loading.body="listLoading"
                        size="mini"
                    > 添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table
                :data="list"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item'
                        v-for='item in formThead'
                        :label="$t('alarmRules.'+item)"
                    >
                        <template slot-scope="scope">
                          <p v-if="item == 'monitorType'">{{scope.row[item]=='0'?'其他':(scope.row[item] =='1'?'模块':'模块指标')}}</p>
                          <p v-else>{{scope.row[item]}}</p> 
                        </template>
                        </el-table-column>
                        <el-table-column
                            align="center"
                            label="操作"
                            v-if="hasPermission()"
                        >
                            <template slot-scope="scope">
                                <el-form>
                                    <el-form-item class="buttonFOrm">
                                        <el-button
                                            type="warning"
                                            @click="handleUpdate(scope.row)"
                                            v-loading.body="listLoading"
                                            size="mini"
                                            class="operationButton"
                                        >修改</el-button>
                                    </el-form-item>
                                    <el-form-item class="buttonFOrm">
                                        <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleDelete(scope.row.id)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                                slot="reference"
                                                class="operationButton"
                                                type="danger"
                                                size="mini"
                                            >删除</el-button>
                                                </el-popover>
                                    </el-form-item>
                                </el-form>
                            </template>
                            </el-table-column>
                            </el-table>
        </div>
    </el-card>
    <el-dialog
        :title="dialogTitle"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="alarmRuleForm"
            ref="alarmRuleForm"
        >
            <el-form-item
                prop="ruleName"
                label="规则名称"
                :rules="{required: true, message: '请输入规则名称'}"
                style="width:200px"
            >
                <el-input v-model="alarmRuleForm.ruleName"></el-input>
                </el-form-item>
                <el-form-item
                    prop="monitorType"
                    label="规则类型"
                    :rules="[
          {required: true, message: '请输入规则类型'}
          ]"
                    style="width:200px"
                >
                    <el-select v-model="alarmRuleForm.monitorType">
                        <el-option
                            v-for="item in ruleTypeTable"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                    </el-form-item>
                            <el-form-item
                                prop="metric"
                                label="性能指标"
                                style="width:200px"
                            >
                                <el-input v-model="alarmRuleForm.metric"></el-input>
                                </el-form-item>
                                    <el-form-item
                                                prop="referValExp"
                                                label="参考值"
                                                :rules="[
          {required: true, message: '请输入监控端口号'}
          ]"
                                                
                                                style="width:200px"
                                            >
                                                <el-input v-model.number="alarmRuleForm.referValExp"></el-input>
                                                </el-form-item>
                                        <el-form-item
                                            prop="comparator"
                                            label="比较器"
                                            :rules="[
          {required: true, message: '请选择比较器'}
          ]"
                                            
                                            style="width:200px"
                                        >
                                        <el-select v-model="alarmRuleForm.comparator">
                            <el-option
                                v-for="item in compareTable"
                                :key="item.value"
                                :label="item.name"
                                :value="item.value"
                            >
                                </el-option>
                        </el-select>
                                            </el-form-item>
                                            <el-form-item
                                        prop="valid"
                                        label="是否启用"
                                        style="width:200px"
                                    >
                                        <el-switch v-model="alarmRuleForm.valid"></el-switch>
                                        </el-form-item>
                                                <el-form-item
                            prop="monitorIdGen"
                            label="监控Id生成规则"
                            :rules="[
          {required: true, message: '请输入监控Id生成规则'}
          ]"
                            style="width:400px"
                        >
                            <p style=" color: rgba(0, 0, 0, 0.45);">{{monitorIdGenExample}}</p>
                            <el-input v-model="alarmRuleForm.monitorIdGen"></el-input>
                            </el-form-item>
                                                        <el-form-item
                                                            prop="messageExp"
                                                            label="消息表达式"
                                                            :rules="[
          {required: true, message: '请输入消息表达式'}
          ]"
                                                            
                                                            style="width:100%"
                                                        >
                                                        <p style=" color: rgba(0, 0, 0, 0.45);">例子：{{messageExpExample}}</p>
                                                            <el-input
                                                                v-model="alarmRuleForm.messageExp"
                                                                type="textarea"
                                                                :autosize="true"
                                                                style="width:600px"
                                                            ></el-input>
                                                                </el-form-item>
                                                                <el-form-item
                                                            prop="monitorValExp"
                                                            label="指标表达式"
                                                            :rules="[
          {required: true, message: '请输入指标表达式'}
          ]"
                                                            
                                                            style="width:100%"
                                                        >
                                                            <el-input
                                                                v-model="alarmRuleForm.monitorValExp"
                                                                type="textarea"
                                                                :autosize="true"
                                                                style="width:600px"
                                                            ></el-input>
                                                                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleinsert('alarmRuleForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
</div>
</template>




<script>
const defaultFormThead = ['ruleName', 'monitorType', 'monitorIdGen', 'monitorValExp', 'referValExp', 'comparator']
import {
  findAlarmRules,
  insertAlarmRules,
  deleteAlarmRules,
  updateAlarmRules
} from '@/api/monitor'
import { mapGetters } from 'vuex'
export default {
  name: 'alarmRulesList',
  data() {
    return {
      list: null,
      templatesList: null,
      alarmRuleForm: {
        ruleName: '',
        monitorType: '',
        monitorIdGen: '',
        parserId: '',
        metric: '',
        monitorValExp: '',
        referValExp: '',
        messageExp: '',
        comparator: '',
        valid: ''
      },
      messageExpExample: '[#{location}][#{cluster}][#{serverIp}][#{moduleInstance}] 最近五分钟连接失败次数(#{monitorVal}/秒)',
      monitorIdGenExample: '模块：#{objectId} 模块指标：#{objectId}-#{ruleId}',
      isUdate: false,
      dialogTitle: '告警规则添加',
      listLoading: true,
      isdalog: false,
      inputRuleId: '',
      inputRuleName: '',
      inputMonitorEnabled: true,
      compareTable: [{
        value: 'comparator.gt'
      }, {
        value: 'comparator.lt'
      }, {
        value: 'comparator.notEqualsTo'
      }, {
        value: 'comparator.notIn'
      }],
      ruleTypeTable: [{
        name: '其他',
        value: 0
      }, {
        name: '模块',
        value: 1
      }, {
        name: '模块指标',
        value: 2
      }],
      monitorTypeTable: [{
        name: 'JMX',
        value: 'JMX'
      }, {
        name: 'HTTP',
        value: 'HTTP'
      }],
      formTheadOptions: ['id', 'ruleName', 'monitorType', 'monitorIdGen', 'parserId', 'metric', 'monitorValExp', 'referValExp', 'messageExp', 'comparator', 'valid', 'created'],
      checkboxVal: defaultFormThead,
      formThead: ['ruleName', 'monitorType', 'monitorIdGen', 'monitorValExp', 'referValExp', 'comparator']
    }
  },
  created() {
    if (this.$route.params.parserId !== undefined && this.$route.params.parserId !== ':parserId') {
      this.alarmRuleForm.parserId = this.$route.params.parserId
    }
    this.fetchData()
    console.log('created moduleList!')
  },
  watch: {
    checkboxVal(valArr) {
      this.formThead = this.formTheadOptions.filter(i => valArr.indexOf(i) >= 0)
      this.key = this.key + 1 // 为了保证table 每次都会重渲 In order to ensure the table will be re-rendered each time
    },
    isUdate() {
      if (this.isUdate) this.dialogTitle = '告警规则修改'
      else this.dialogTitle = '告警规则添加'
    }
    // $route() {
    //   if (this.$route.params.parserId !== undefined && this.$route.params.parserId !== ':parserId') {
    //     this.alarmRuleForm.parserId = this.$route.params.parserId
    //   } else {
    //     this.alarmRuleForm.parserId = ''
    //   }
    //   this.fetchData()
    //   // this.closeContainer()
    // }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'alarmRulesListButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    fetchData() {
      this.listLoading = true
      findAlarmRules(this.inputRuleId, this.inputRuleName, this.alarmRuleForm.parserId).then(response => {
        console.log(response)
        this.list = response.data.alarmRules.map(v => {
          this.$set(v, 'deleteFlag', false)
          return v
        })
        console.log(this.list)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isdalog = false
          this.isUdate = false
          this.$refs['alarmRuleForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              console.log(this.alarmRuleForm)
              if (this.alarmRuleForm.metric === '') this.alarmRuleForm.metric = null
              this.listLoading = true
              if (this.isUdate) {
                return new Promise((resolve, reject) => {
                  updateAlarmRules(this.alarmRuleForm).then(response => {
                    console.log(response)
                    if (response.code === 0) {
                      this.fetchData()
                      this.listLoading = false
                      this.isUdate = false
                      this.$refs['alarmRuleForm'].resetFields()
                      resolve(response)
                      this.isdalog = false
                    }
                  }).catch((error) => {
                    this.listLoading = false
                    this.isUdate = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              } else {
                return new Promise((resolve, reject) => {
                  insertAlarmRules(this.alarmRuleForm).then(response => {
                    console.log(response)
                    if (response.code === 0) {
                      this.fetchData()
                      this.listLoading = false
                      this.$refs['alarmRuleForm'].resetFields()
                      resolve(response)
                      this.isdalog = false
                    }
                  }).catch((error) => {
                    this.listLoading = false
                    reject(error)
                    this.isdalog = false
                  })
                })
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    handleUpdate(rows) {
      this.alarmRuleForm = Object.assign({}, rows)
      this.isdalog = true
      this.isUdate = true
    },
    handleDelete(id) {
      return new Promise((resolve, reject) => {
        deleteAlarmRules(id).then(response => {
          console.log(response)
          if (response.code === 0) {
            this.fetchData()
            this.listLoading = false
            this.$refs['alarmRuleForm'].resetFields()
            resolve(response)
          }
        }).catch((error) => {
          this.listLoading = false
          reject(error)
        })
      })
    },
    handleInstance: function(moduleId, moduleName) {
      console.log('/monitor/' + moduleId + '/' + moduleName)
      this.$router.push('/monitor/' + moduleId + '/' + moduleName)
      // window.parent.addTab(title, seqUrl)
    }
  }
}
</script>



<style>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.operationButton {
    width: 80px;
}

.buttonFOrm {
    margin: 0px;
    display: inline;
}
</style>
