<template>
<div class="app-container">
  <el-row class="panel-group">
    
            <el-col :xs="48" :sm="48" :lg="24" class="card-panel-col">
    
                <div class="card-panel" >
    
                    <div class="card-panel-header" >
    
                        <div v-if="instanceTypeFlag == 'SP' " class="card-panel-icon-wrapper icon-trade" @click="moduleInfoFlag=!moduleInfoFlag">
                            <svg-icon  icon-class="trade" class-name="card-panel-icon" />
                            <div class="card-panel-text">{{moduleName}}</div>
                        </div>
                        <div v-if="instanceTypeFlag == 'GW' " class="card-panel-icon-wrapper icon-gateway" @click="moduleInfoFlag=!moduleInfoFlag">
                            <svg-icon  icon-class="gateway" class-name="card-panel-icon" />
                            <div class="card-panel-text">{{moduleName}}</div>
                        </div>
                        <div v-if="instanceTypeFlag == 'ZK' " class="card-panel-icon-wrapper icon-cluster" @click="moduleInfoFlag=!moduleInfoFlag">
                            <svg-icon  icon-class="cluster" class-name="card-panel-icon" />
                            <div class="card-panel-text">{{moduleName}}</div>
                        </div>
                        <el-form :inline="true">
                          <el-form-item
                    label="状态"
                    class="statusModuleInfoTitle">
                    <div :class="instanceStatusFlag === '正常' ? 'breathe-success-btn': (instanceStatusFlag === '未采集数据' ? 'breathe-unknown-btn':(instanceStatusFlag === '未启用监控' ? 'breathe-disable-btn':'breathe-warning-btn'))"></div>                                               
                    </el-form-item>
                    
                    <el-form-item
                    label="操作"
                    class="statusModuleInfoTitle"
                    >
                    <el-button type="primary" @click="operateInstance">实例操作</el-button>
                    <el-button type="primary" v-if="hasPermission()" @click="handleScheduleDialog">定时重启设置</el-button>
                    </el-form-item>
                    <el-form-item
                    label="轮询设置"
                    class="statusModuleInfoTitle">
                    <el-popover
            placement="right"
            trigger="click">
            <el-form ref="ruleForm">
                <div class="form-wrapper">
                    <el-form-item
                        class="form-wrapper-item"
                        label="状态轮询时间"
                        label-width="160px">
                        <el-select
                            v-model="countertime"
                            placeholder="状态轮询间隔时间">
                            <el-option
                                v-for="item in timeTable"
                                :key="item.value"
                                :label="item.value"
                                :value="item.time">
                                </el-option>
                                </el-select>
                    </el-form-item>
                    <el-form-item
                        class="form-wrapper-item"
                        label="图表轮询时间"
                        label-width="160px">
                                <el-select
                            v-model="countertimeT"
                            placeholder="图表轮询间隔时间">
                            <el-option
                                v-for="items in timeTableT"
                                :key="items.value"
                                :label="items.value"
                                :value="items.time">
                                </el-option>
                                </el-select>
                                <el-button
                                    :type="timerStatus === '开始轮询' ? 'primary' : 'danger' "
                                    @click="stopQuery"
                                    v-loading.body="listLoading"
                                    size="mini">{{timerStatus}}</el-button>
                    </el-form-item>
                </div>
            </el-form>
            <el-button
                slot="reference"
                style="float: left"
                type="text"
            >操作按钮</el-button>
                </el-popover>
                    </el-form-item>
                    </el-form>
                    <el-form class="moduleInfoForm" :inline="true">
                     
                    
                    </el-form>
                    
                    </div>
                    <!-- <div class='chart-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData.spxexchangertradeRequest"></innerBarChart>
    
                    </div> -->
    
                </div>
    <el-collapse v-model="activeLine" accordion >
                      <el-collapse-item  name="1" class="pan-btn light-blue-btn" style="width:100%;padding:10px;">
                        <template slot="title" >
                        <span style="font-size:18px;">服务器信息</span>
                        <I class="el-icon-zoom-in" ></I>
                        </template>
                        <el-form >
                                                   <div class="lineDIV">
                    <el-form-item
                    :label="$t('instanceSummary.startTime')"
                    class="moduleInfoTitle"
                    v-if="summaryList!=undefined"
                    >
                    <span class="moduleInfo" >{{summaryList.startTime}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('instanceSummary.pid')"
                    class="moduleInfoTitle"
                    v-if="summaryList!=undefined"
                    >
                    <span class="moduleInfo" >{{summaryList.pid}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('moduleListTable.monitorPort')"
                    class="moduleInfoTitle"
                    v-if="moduleList[0]!=undefined"
                    >
                    <span class="moduleInfo" >{{moduleList[0].monitorPort}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('moduleListTable.monitorType')"
                    class="moduleInfoTitle"
                     v-if="moduleList[0]!=undefined"
                    >
                    <span class="moduleInfo" >{{moduleList[0].monitorType}}</span>
                    </el-form-item>
                    </div>
                    <div class="lineDIV">
                    <el-form-item
                    :label="$t('instanceTable.serverIp')"
                    class="moduleInfoTitle"
                    v-if="instanceDetail!=undefined"
                    >
                    <span class="moduleInfo" >{{instanceDetail.serverIp}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('instanceTable.locationId')"
                    class="moduleInfoTitle"
                     v-if="instanceDetail!=undefined"
                    >
                    <span class="moduleInfo" >{{instanceDetail.locationId}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('instanceTable.clusterId')"
                    class="moduleInfoTitle"
                    v-if="instanceDetail!=undefined"
                    >
                    <span class="moduleInfo" >{{instanceDetail.clusterId}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('instanceTable.proxyId')"
                    class="moduleInfoTitle"
                    v-if="instanceDetail!=undefined"
                    >
                    <span class="moduleInfo" >{{instanceDetail.proxyId}}</span>
                    </el-form-item>
                    <el-form-item

                    :label="$t('instanceSummary.osVersion')"
                    class="moduleInfoTitle"
                    v-if="summaryList!=undefined"
                    >
                    <span class="moduleInfo" >{{summaryList.osVersion}}</span>
                    </el-form-item>
                    <el-form-item

                    :label="$t('instanceSummary.physicalMem')"
                    class="moduleInfoTitle"
                    v-if="summaryList!=undefined"
                    >
                    <span class="moduleInfo" >{{summaryList.physicalMem}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('instanceSummary.processors')"
                    class="moduleInfoTitle"
                    v-if="summaryList!=undefined"
                    >
                    <span class="moduleInfo" >{{summaryList.processors}}</span>
                    </el-form-item>
                    <el-form-item
                    :label="$t('instanceSummary.threadCount')"
                    class="moduleInfoTitle"
                    v-if="summaryList!=undefined"
                    >
                    <span class="moduleInfo" >{{summaryList.threadCount}}</span>
                    </el-form-item>
                    </div>
                    </el-form>

                      </el-collapse-item>
                      <el-collapse-item name="2" class="pan-btn light-blue-btn" style="width:100%;padding:10px;margin-top: 10px;"> 
                        <template slot="title" >
                        <span style="font-size:18px;">健康状态信息</span>
                        <I class="el-icon-zoom-in" ></I>
                        </template>
                    <div class="card-panel" >
                   <div class="card-panel-header" > 
                     
                    <el-form :inline="true" v-if="instanceStatusremark!=null" style="text-align: left;">
                      <div class="lineDIV" v-if="instanceStatusremark.zkrole!=undefined">
                         <el-form-item
                      class="instanceItemFormTitle"
                      label="zk角色">                                          
                      </el-form-item>
                      <el-form-item
                      label="数据"
                      class="instanceItemForm">
                      <span class="moduleInfo" >{{instanceStatusremark.zkrole}}</span>
                      </el-form-item>
                      </div>
                      <div class="lineDIV">
                         <el-form-item
                      v-if="instanceStatusremark.status!=null&&instanceStatusremark.status!=undefined&&instanceStatusremark.zkrole!=undefined"
                      class="instanceItemFormTitle"
                      label="总体健康状态">
                      <div :class="instanceStatusremark.status === 'UP' ? 'breathe-success-btn':'breathe-warning-btn'"></div>                                               
                      </el-form-item>
                      <el-form-item
                      v-if="instanceStatusremark.instance!=null&&instanceStatusremark.instance!=undefined&&instanceStatusremark.zkrole!=undefined"
                      label="数据"
                      class="instanceItemForm">
                      <span class="moduleInfo" >{{instanceStatusremark.instance}}</span>
                      </el-form-item>
                      </div>
                      <div class="lineDIV" v-for="(itemITEM,index) in instanceStatusremark" :key="index" v-if="index!='status'&&index!='instance'&&index!='zkrole'">
                      <el-form-item
                      v-if="itemITEM.status!=null&&itemITEM.status!=undefined"
                      :label="itemITEM.desc!=undefined?itemITEM.desc:index+' 状态'"
                      class="instanceItemFormTitle">
                      <div :class="itemITEM.status === 'UP' ? 'breathe-success-btn':'breathe-warning-btn'"></div>
                      <div v-if="itemITEM.status !== 'UP'&&itemITEM.remark!=undefined">
                        <br>
                      <span>
                        {{itemITEM.remark}}
                      </span>
                      </div>
                      <!-- <span class="moduleInfo" >{{itemITEM.status}}</span> -->
                      </el-form-item>
                      <el-form-item
                      :label="index"
                      class="instanceItemForm">
                      <jsonViewer
                      style="height:auto;width:100%;float:left;"
                      :json="itemITEM">
                      </jsonViewer>
                      <!-- <instanceItem
                      class="instanceItem"
                      :model="itemITEM">
                      </instanceItem> -->
                      </el-form-item>
                      </div>
                    </el-form>
                     
                    </div>
    
                </div>
                      </el-collapse-item>
                    </el-collapse>
            </el-col>
  </el-row>
  <!-- <el-row class="panel-group" :v-show="moduleInfoFlag">
    
            <el-col :xs="48" :sm="48" :lg="24" class="card-panel-col" :v-show="moduleInfoFlag" >
    
                <div class="card-panel" v-show="moduleInfoFlag">
                   <div class="card-panel-header" > 
                    <el-form :inline="true">
                    <el-form-item
                    v-for="(moduleItem,moduleIndex) in moduleList[0]"
                    :key="moduleIndex"
                    :label="$t('moduleListTable.'+moduleIndex)"
                    class="moduleInfoTitle"
                    >
                    <span class="moduleInfo" >{{moduleItem}}</span>
                    </el-form-item>
                    </el-form>
                     
                    </div>
    
                </div>
    
            </el-col>
  </el-row>
  <el-row class="panel-group" :v-show="moduleInfoFlag">
    
            <el-col :xs="48" :sm="48" :lg="24" class="card-panel-col" :v-show="moduleInfoFlag" >
    
                <div class="card-panel" v-show="moduleInfoFlag">
                   <div class="card-panel-header" > 
                    <el-form :inline="true">
                    <el-form-item
                    v-for="(moduleItem,moduleIndex) in instanceDetail"
                    :key="moduleIndex"
                    :label="$t('instanceTable.'+moduleIndex)"
                    class="moduleInfoTitle"
                    v-if="moduleIndex!='moduleId'&&moduleIndex!='valid'"
                    >
                    <span class="moduleInfo" >{{moduleItem}}</span>
                    </el-form-item>
                    </el-form>
                     
                    </div>
    
                </div>
    
            </el-col>
  </el-row> -->
                
  <el-card class="runtimeContainer" >
      <div>运行情况</div>
      <div class="card-panel" @click="isShow=!isShow,resizeFlag=!resizeFlag">
        <div  class="chart-container" v-if="summaryList!=null&&summaryList.systemLoad!=null&&summaryList.processors!=null">
        <gaugePanel :key="instanceId" class="gaugeChart" height="300px" width="270px" :chartData="{name:moduleName,value:(summaryList.systemLoad)*100,valueName:'系统负载'}"></gaugePanel>
        </div>
        <div  class="chart-container" v-if="summaryList!=null&&summaryList.processLoad!=null">
        <gaugePanel :key="instanceId" class="gaugeChart" height="300px" width="270px" :chartData="{name:moduleName,value:(summaryList.processLoad)*100,valueName:'进程负载'}"></gaugePanel>
        </div>
        <div  class="chart-container" v-if="summaryList!=null&&summaryList.physicalMemUsage!=null">
        <gaugePanel :key="instanceId" class="gaugeChart" height="300px" width="270px" :chartData="{name:moduleName,value:(summaryList.physicalMemUsage)*100,valueName:'物理内存使用率'}"></gaugePanel>
        </div>
        <div  class="chart-container" v-if="summaryList!=null&&summaryList.fdUsage!=null">
        <gaugePanel :key="instanceId" class="gaugeChart"  height="300px" width="270px" :chartData="{name:moduleName,value:(summaryList.fdUsage)*100,valueName:'文件句柄使用率'}"></gaugePanel>
        </div>
        <div  class="chart-container" v-if="summaryList!=null&&summaryList.heapUsed!=null&&summaryList.heapMax!=null">
        <gaugePanel :key="instanceId" class="gaugeChart" height="300px" width="270px" :chartData="{name:moduleName,value:(summaryList.heapUsed / summaryList.heapMax)*100,valueName:'堆栈内存使用率'}"></gaugePanel>
        </div>
        <!-- <div  class="chart-container" v-if="summaryList!=null&&summaryList.nonheapUsed!=null&&summaryList.physicalMem!=null">
        <gaugePanel class="gaugeChart" height="300px" width="270px" :chartData="{name:moduleName,value:(summaryList.nonheapUsed / summaryList.physicalMem)*100,valueName:'非堆栈内存使用率'}"></gaugePanel>
        </div> -->
      </div>
  </el-card>
        <div
            v-show="isShow == true"
            style="background:#fff;padding:16px 16px 0;"
        >
            <div class='chartData-container' v-show="isShow == true">
                <chart
                :key="instanceId"
                v-show="isShow == true"
                    height='100%'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData.systemData"
                    :className="'系统运行图'"
                ></chart>
            </div>
            </div>
            <el-card class="runtimeContainer" >
      <div>实例性能指标</div>
                <el-col   class="card-panel-cols" 
                v-for="itmeMetric in instanceMetricsList"
                :key="itmeMetric.id">
                
                <div class='card-panel' @click="resizeFlag=!resizeFlag,handleSetLineChartData(itmeMetric.metric)" v-if="itmeMetric.metricType=='counter'||itmeMetric.metricType=='gauge'">
                  <div class="card-panel-icon-wrapper icon-gateway">
    
                           <div class="MetricsContainer">
    
                        <div v-if="itmeMetric.nickname == null||itmeMetric.nickname == ''" class="card-panel-text"><span>{{itmeMetric.metric}}</span></div>
                        <div v-else class="card-panel-text"><span>{{itmeMetric.nickname}}</span></div>
                        <div v-if="lineChartData[itmeMetric.metric]!=undefined&&lineChartData[itmeMetric.metric].functionData!=null&&lineChartData[itmeMetric.metric].functionData[0]!=undefined" class="card-panel-num">{{lineChartData[itmeMetric.metric].functionData[0].data}}</div>
    
                    </div>
    
                </div>
                    
    
                </div>
                <div class='card-panel' @click="resizeFlag=!resizeFlag,handleSetLineChartData(itmeMetric.metric)" v-if="itmeMetric.metricType=='timer'||itmeMetric.metricType=='meter'">
                  <div class="card-panel-icon-wrapper icon-gateway">
    
                           <div class="MetricsContainer">
    
                        <div v-if="itmeMetric.nickname == null||itmeMetric.nickname == ''" class="card-panel-text"><span>{{itmeMetric.metric}}</span></div>
                        <div v-else class="card-panel-text"><span>{{itmeMetric.nickname}}</span></div>
                        <count-to v-if="lineChartData[itmeMetric.metric]!=undefined&&lineChartData[itmeMetric.metric].functionData!=null&&lineChartData[itmeMetric.metric].functionData[0]!=undefined" class="card-panel-num" :startVal="0" :endVal="lineChartData[itmeMetric.metric].functionData[0].m1Rate" :duration="3000"></count-to>
    
                    </div>
    
                </div>
                    
    
                </div>
    
            </el-col>
  </el-card>
  <div
            v-show="isShowMetric == true"
            style="background:#fff;padding:16px 16px 0;"
        >
            <div class='chartData-container' v-show="isShowMetric == true">
                <chart
                :key="instanceId"
                v-show="isShowMetric == true"
                    height='100%'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="currentChartData"
                    :className="currentChartName"
                ></chart>
            </div>
            </div>
  <el-card>
      <div class="header" style="display: inline;">
        <div>服务</div>
        <el-table
                :data="instanceServiceList"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                highlight-current-row
                :stripe="true"
                class="outTable"
            >
                <el-table-column
                    align="center"
                    label='NO.'
                    width="95"
                >
                    <template slot-scope="scope">
                        {{scope.$index}}
                    </template>
                    </el-table-column>
                    <el-table-column
                        :key='item.name'
                        v-for='item in formThead'
                        :label="$t('instanceServiceList.'+item['name'])"
                        :width="item.width"
                    >
                        <template slot-scope="scope">
                                        <p v-if="item.name != 'status'">{{scope.row[item.name]}}</p>
                                        <div v-if="item.name == 'status'" :class="scope.row[item.name] === '正常' ? 'breathe-success-btn':'breathe-warning-btn'"></div>  
                        </template>
                        </el-table-column>
                            </el-table>
      </div>
  </el-card>
        <instanceStatus :queryflag="timerStatus" class="instanceStatusWindow"></instanceStatus>
  <!-- <el-card>
      <div class="header" style="display: inline;">
        <div>包含实例</div>
        <el-popover
            placement="left"
            trigger="click">
            <el-form ref="ruleForm">
                <div class="form-wrapper">
                    <el-form-item
                        class="form-wrapper-item"
                        label="轮询时间"
                        label-width="160px">
                        <el-select
                            v-model="countertime"
                            placeholder="轮询间隔时间">
                            <el-option
                                v-for="item in timeTable"
                                :key="item.value"
                                :label="item.value"
                                :value="item.time">
                                </el-option>
                                </el-select>
                                <el-button
                                    :type="timerStatus === '开始轮询' ? 'primary' : 'danger' "
                                    @click="stopQuery"
                                    v-loading.body="listLoading"
                                    size="mini">{{timerStatus}}</el-button>
                    </el-form-item>
                </div>
            </el-form>
            <el-button
                slot="reference"
                style="float: left"
                type="text"
            >操作按钮</el-button>
                </el-popover>
                </div>
                <div class="container">
                  
                                <el-table
                                    :data="list[0].clusters"
                                    v-loading.body="listLoading"
                                    element-loading-text="Loading"
                                    border
                                    fit
                                    highlight-current-row
                                    :stripe="true"
                                    class="innerTable">
                                    <el-table-column type="expand" >
                                        <template slot-scope="scope">
                                          <el-form size="big" label-position="left" v-for="itemAAA in scope.row.instances"
                                          :key="itemAAA.instanceId"
                                          >
                                          <el-card>
                                          <el-form-item :label="itemAAA.serverIp+'上实例详情：'" >
                                          <instanceItem
                                          class="instanceItem"
                                          :model="itemAAA.remark">
                                          </instanceItem>
                                          </el-form-item>
                                          <div class="chartBox">
                                          <div class="chart-container" v-if="itemAAA.remark!=null&&itemAAA.remark.instance!=null">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:itemAAA.remark.instance.systemLoad*100,valueName:'系统负载'}"></gaugePanel>
                                          </div>
                                          <div class="chart-container" v-if="itemAAA.remark!=null&&itemAAA.remark.diskSpace!=null">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:((itemAAA.remark.diskSpace.total-itemAAA.remark.diskSpace.free)/itemAAA.remark.diskSpace.total)*100,valueName:'磁盘利用率'}"></gaugePanel>
                                          </div>
                                          <div class="chart-container" v-if="itemAAA.monitor!=null&&MemeryUse.monitorName=='内存堆使用率'" v-for="MemeryUse in itemAAA.monitor" :key="MemeryUse.monitorId">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:MemeryUse.monitorVal,valueName:'内存堆使用率'}"></gaugePanel>
                                          </div>
                                          <div class="chart-container" v-if="itemAAA.monitor!=null&&MemeryUse.monitorName=='文件句柄使用率'" v-for="MemeryUse in itemAAA.monitor" :key="MemeryUse.monitorId">
                                          <gaugePanel height="300px" width="300px" :chartData="{name:itemAAA.serverIp,value:MemeryUse.monitorVal,valueName:'文件句柄使用率'}"></gaugePanel>
                                          </div>
                                          </div>
                                          </el-card>
                                          </el-form>
                                          <el-row class="panel-group" :gutter="20">
    
            <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
    
                <div class="card-panel" @click="isShow==false&&selectName==scope.row.clusterName.split('集群').pop()?isShow=true:isShow==false&&selectName!=scope.row.clusterName.split('集群').pop()?(selectName=scope.row.clusterName.split('集群').pop(),isShow= !isShow):selectName==scope.row.clusterName.split('集群').pop()?isShow= !isShow:selectName=scope.row.clusterName.split('集群').pop()">
    
                    <div class="card-panel-header">
    
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">请求速率</div>
                        </div>
    
                    </div>
    
                    <div class='innerchartData-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData[scope.row.clusterName.split('集群').pop()]"></innerBarChart>
    
                    </div>
    
                </div>
    
            </el-col>
                                          </el-row>
                                        </template>
                                    </el-table-column>
                                    <el-table-column width=150 label="集群名称">
                                        <template slot-scope="scope1">
                                            {{scope1.row.clusterName}}
                                        </template>
                                    </el-table-column>
                                    
                                    <el-table-column label="实例所在服务器">
                                        <template slot-scope="scope1">
                                          <div class="instanceInfoBox" v-for="item in scope1.row.instances"
                                                :key="item.instanceId">
                                           <el-button
                                                :type="item.status === '正常' ? 'success': (item.status === '未采集数据' ? 'warning':(item.status === '未启用监控' ? 'info':'danger'))"
                                                size="mini"
                                                class="selectButton"
                                                @click="handleDetailInfo(item.instanceId,item.serverIp,item.status)"
                                                v-loading.body="listLoading">
                                                {{item.serverIp}}:{{item.status}}
                                                </el-button>
                                                <el-tag
                                                v-for="monitorTag in item.monitor"
                                                :key="monitorTag.monitorId"
                                                :type="monitorTag.status === '正常' ? 'success': (monitorTag.status === '未采集数据' ? 'warning':(monitorTag.status === '未启用监控' ? 'info':'danger'))"
                                                >
                                                {{monitorTag.monitorName}}:{{monitorTag.status}},状态值：{{monitorTag.monitorVal}}
                                                </el-tag>
                                                </div>
                                        </template>
                                    </el-table-column>
                                    </el-table>
                                    <el-row
            
            style="background:#fff;padding:16px 16px 0;margin-bottom:32px;margin-top:-12px;"
        >
            <div class='chartData-container' v-if="selectName!= null" >
                <chart v-show="isShow == true"
                    height='45vh'
                    width='100%'
                    :chart-data="lineChartData[selectName]"
                    :className="classname[selectName]"
                    
                ></chart>
            </div>
            </el-row>
                            </div>
    </el-card> -->

    <el-dialog
        title="实例定时起停设置"
        :visible.sync="scheduleFlag"
    >
    <el-table
            ref="singleTable"
            :data="ScheduleList"
            highlight-current-row
            style="width: 100%"
            :border="true"
            :stripe="true"
            resizable>
      <el-table-column type="expand">
        <template slot-scope="scope">
          <el-form class="table-inner" :inline="true">
            <div class="form-wrapper">
              <el-form-item label="任务Id" label-width="110px" class="form-wrapper-item form-item-three">
                <span>{{scope.row.taskId}}</span>
              </el-form-item>
              <el-form-item label="任务请求地址" label-width="110px" class="form-wrapper-item form-item-three">
                <span v-show="!scope.row.isEdit">{{scope.row.target}}</span>
              </el-form-item>
              <el-form-item label="时间表达式" label-width="110px" class="form-wrapper-item form-item-three">
                <span v-show="!scope.row.isEdit">{{scope.row.cronExpression}}</span>
              </el-form-item>
            </div>
            <div class="form-wrapper">
              <el-form-item label="任务请求参数" label-width="110px" class="form-wrapper-item form-item-one ">
                <span v-show="!scope.row.isEdit">{{scope.row.invokeBody}}</span>
              </el-form-item>
            </div>
            <div class="form-wrapper">
              <el-form-item label="任务开始时间" label-width="110px" class="form-wrapper-item form-item-three">
                <span>{{scope.row.startTime}}</span>
              </el-form-item>
              <el-form-item label="任务结束时间" label-width="110px" class="form-wrapper-item form-item-three">
                <span v-show="!scope.row.isEdit">{{scope.row.endTime}}</span>
              </el-form-item>
            </div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column property="prevFireTime" label="上次执行时间"  align="center"  class="form-wrapper-item form-item-10-percent" width="160%"></el-table-column>
      <el-table-column property="nextFireTime" label="下次执行时间"  align="center"  class="form-wrapper-item form-item-10-percent" width="160%"></el-table-column>
      <el-table-column property="triggerState" label="任务状态"  align="center"  class="form-wrapper-item form-item-10-percent" width="100%"></el-table-column>
      <el-table-column fixd="right" label="操作" align="center" class="form-wrapper-item form-item-20-percent">
        <template slot-scope="scope">
          <el-button  v-show="!scope.row.isEdit" type="default" size="mini" class="tool-item" @click="handlePause(scope.$index,list)">
            <i class="el-icon-edit">暂停</i>
          </el-button>
          <el-button  v-show="!scope.row.isEdit" type="default" size="mini" class="tool-item" @click="handleResume(scope.$index,list)">
            <i class="el-icon-edit">恢复</i>
          </el-button>
          <el-button  v-show="!scope.row.isEdit" type="default" size="mini" class="tool-item" @click="handleDel(scope.$index,list)">
            <i class="el-icon-edit">删除</i>
          </el-button>

        </template>
      </el-table-column>
    </el-table>
        <el-form
            :inline="true"
            :model="formData"
            ref="formData"
        >
            <el-form-item
                prop="cron"
                label="时间表达式"
                :rules="{required: true, message: '请输入时间表达式'}"
            >
            <span>时间表达式格式："* * * * * ?"其中五个*分别代表秒 分 时 天 月，最后？不可省略，例如：0 0 1 * * ？表示每天的1：00：00执行，0 0 0/1 * * ？表示以0：00：00开始，每过一个小时执行一次，以此类推，具体请自行百度</span>
                <el-input v-model="formData.cron"></el-input>
                <el-button v-if="ScheduleList==null||ScheduleList.length==0" type="primary" @click="handleinsert('formData')">添加</el-button>
                <el-button v-else type="primary" @click="handleinsert('formData')">修改</el-button>
                </el-form-item>
                                                                        </el-form>
                                                                        </el-dialog>

</div>
</template>
<script>
import {
  getModuleStatus,
  statusGroupQuery,
  getModuleList,
  // getAlarmStatus,
  getMetricsTimer,
  queryInstanceByInstanceId,
  querySnapshot,
  querySummary,
  queryinstanceMetrics,
  getMetricsGauges,
  queryInstanceServices
} from '@/api/monitor'
import { dateTimeFormat } from '@/store/date'
import { getSchedulerList,
  deleteTask,
  pauseTask,
  resumeTask,
  updateTask,
  createTask } from '@/api/schedule'
import CountTo from 'vue-count-to'
// import PanThumb from '@/components/PanThumb'
import instanceItem from './components/JSONInfoBox'
import instanceStatus from './instanceStatus'
import gaugePanel from '@/components/Charts/gaugePanel'
import innerBarchart from '@/components/Charts/innerBarchart'
import axios from 'axios'
import Chart from '@/components/Charts/mixChart'
import {
  formatDate
} from '@/store/date'
import {
  Message
} from 'element-ui'
import jsonViewer from '@/components/JsonView'
import { mapGetters } from 'vuex'
// const lineChartData = {
//   gwuserRequest: {
//     xdata: [0],
//     ydata: [0],
//     namedata: [0],
//     functionData: [{
//       name: 0,
//       m1Rate: 0,
//       m5Rate: 0,
//       m15Rate: 0
//     }]
//   }
// }
export default {
  name: 'instanceDetail',
  data() {
    return {
      lineChartData: {},
      instanceMetricsList: null,
      functionData: {},
      currentChartData: null,
      currentChartName: null,
      instanceServiceList: null,
      history: null,
      selectName: '',
      classname: {},
      isShow: false,
      isShowMetric: false,
      list: [1],
      instanceDetail: null,
      instanceStatusFlag: null,
      instanceStatusremark: [],
      resizeFlag: true,
      instanceTypeFlag: null,
      instanceId: null,
      updateList: null,
      moduleList: [1],
      listLoading: true,
      moduleId: null,
      moduleName: null,
      moduleInfoFlag: false,
      summaryList: null,
      snapshotList: null,
      countertime: 20,
      countertimeT: 300,
      timeOut: '30',
      initFlag: true,
      timerStatus: '开始轮询',
      timeTable: [{
        value: '十秒',
        time: 10
      }, {
        value: '二十秒',
        time: 20
      }, {
        value: '三十秒',
        time: 30
      }, {
        value: '一分钟',
        time: 60
      }],
      timeTableT: [{
        value: '一分钟',
        time: 60
      }, {
        value: '五分钟',
        time: 300
      }, {
        value: '十分钟',
        time: 600
      }, {
        value: '半小时',
        time: 1800
      }],
      ref: null,
      ref2: null,
      ref3: null,
      formThead: [{ name: 'status', width: '100px' }, { name: 'serviceName', width: '250px' }, { name: 'port', width: '100px' }, { name: 'registerTime', width: '200px' }, { name: 'protocolType', width: '100px' }, { name: 'grpcClass', width: '600px' }],
      formData: {
        jobName: '',
        jobGroup: 'InstanceSchedule',
        invokeBody: '',
        cron: '',
        remark: '',
        target: '',
        startAt: '',
        endAt: '',
        taskId: ''
      },
      scheduleFlag: false,
      isScheduleUdate: false,
      ScheduleList: null,
      activeLine: ''
    }
  },
  components: {
    jsonViewer,
    instanceItem,
    gaugePanel,
    Chart,
    innerBarchart,
    instanceStatus,
    CountTo
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  created() {
    if (this.$route.params.moduleId !== undefined) {
      this.moduleId = this.$route.params.moduleId
    }
    if (this.$route.params.instanceId !== undefined) {
      this.instanceId = this.$route.params.instanceId
    }
    if (this.$route.params.moduleName) {
      this.moduleName = (this.$route.params.moduleName).split(':').shift()
    }
    this.fetchData(this.moduleName)
    this.fetchInstanceMetrics()
    this.fetchInstanceData()
    this.fetchModuleList()
    this.fetchSnapshotData()
    this.fetchSummaryData()
    this.stopQuery()
    this.getScheduleList()
  },
  //   mounted() {
  //     const that = this
  //     setTimeout(function() {
  //       that.isShow = false
  //     }, 500)
  //   },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'moduleManagementButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    handlePause: function(index, row) {
      var that = this
      this.$confirm('确认暂停该任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        pauseTask({
          jobName: that.formData.jobName.replace(/^\s*$/, ''),
          jobGroup: that.formData.jobGroup.replace(/^\s*$/, ''),
          invokeBody: that.formData.invokeBody.replace(/^\s*$/, ''),
          cron: that.formData.cron.replace(/^\s*$/, ''),
          target: that.formData.target.replace(/^\s*$/, ''),
          remark: that.formData.remark.replace(/^\s*$/, ''),
          startAt: that.formData.startAt,
          endAt: that.formData.endAt
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            Message.success('执行成功！')
            that.getScheduleList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handleResume: function(index, row) {
      var that = this
      this.$confirm('确认恢复任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        resumeTask({
          jobName: that.formData.jobName.replace(/^\s*$/, ''),
          jobGroup: that.formData.jobGroup.replace(/^\s*$/, ''),
          invokeBody: that.formData.invokeBody.replace(/^\s*$/, ''),
          cron: that.formData.cron.replace(/^\s*$/, ''),
          target: that.formData.target.replace(/^\s*$/, ''),
          remark: that.formData.remark.replace(/^\s*$/, ''),
          startAt: that.formData.startAt,
          endAt: that.formData.endAt
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            Message.success('执行成功！')
            that.getScheduleList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handleDel: function(index, row) {
      var that = this
      this.$confirm('确认删除该任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        deleteTask({
          jobName: that.formData.jobName.replace(/^\s*$/, ''),
          jobGroup: that.formData.jobGroup.replace(/^\s*$/, ''),
          invokeBody: that.formData.invokeBody.replace(/^\s*$/, ''),
          cron: that.formData.cron.replace(/^\s*$/, ''),
          target: that.formData.target.replace(/^\s*$/, ''),
          remark: that.formData.remark.replace(/^\s*$/, ''),
          startAt: that.formData.startAt,
          endAt: that.formData.endAt
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            Message.success('删除成功！')
            that.getScheduleList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handleScheduleDialog() {
      this.getScheduleList()
      this.formData.jobName = this.moduleName + '_' + this.instanceDetail.serverIp + 'Schedule'
      this.formData.invokeBody = '{"funcNo":"default","targetModule":"' + this.moduleName + '","artifactName":"' + this.moduleList[0].artifactName + '","targetIp":"' + this.instanceDetail.serverIp + '","version":"' + this.moduleList[0].version + '"}'
      this.formData.remark = this.moduleName + '_' + this.instanceDetail.serverIp + '定时起停任务'
      this.formData.target = process.env.zt_api_alarm_gw_url + '/ssh/setSchedule'
      this.formData.startAt = dateTimeFormat(new Date())
      this.scheduleFlag = true
    },
    getScheduleList: function() {
      var that = this
      getSchedulerList(this.moduleName + '_' + this.instanceDetail.serverIp + 'Schedule')
        .then(function(response) {
          console.log('response:', response)
          if (response.code === 0) {
            const d = response.data[0].schedulerTaskBOs
            d.forEach(item => {
              item['isEdit'] = false
            })
            that.ScheduleList = d
            console.log('ScheduleList:', that.ScheduleList)
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
          if (that.ScheduleList != null && that.ScheduleList.length !== 0) {
            that.formData.cron = that.ScheduleList[0].cronExpression
            that.isScheduleUdate = true
          } else {
            that.isScheduleUdate = false
          }
        })
    },
    handleinsert(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.listLoading = true
          this.formData.jobName = this.moduleName + '_' + this.instanceDetail.serverIp + 'Schedule'
          this.formData.invokeBody = '{"funcNo":"default","targetModule":"' + this.moduleName + '","artifactName":"' + this.moduleList[0].artifactName + '","targetIp":"' + this.instanceDetail.serverIp + '","version":"' + this.moduleList[0].version + '"}'
          this.formData.remark = this.moduleName + '_' + this.instanceDetail.serverIp + '定时起停任务'
          this.formData.target = process.env.zt_api_alarm_gw_url + '/ssh/setSchedule'
          this.formData.startAt = dateTimeFormat(new Date())
          console.log('formData:', this.formData)
          if (this.isScheduleUdate) {
            return new Promise((resolve, reject) => {
              updateTask({
                jobName: this.formData.jobName.replace(/^\s*$/, ''),
                jobGroup: this.formData.jobGroup.replace(/^\s*$/, ''),
                invokeBody: this.formData.invokeBody.replace(/^\s*$/, ''),
                cron: this.formData.cron.replace(/^\s*$/, ''),
                target: this.formData.target.replace(/^\s*$/, ''),
                remark: this.formData.remark.replace(/^\s*$/, ''),
                startAt: this.formData.startAt,
                endAt: this.formData.endAt
              }).then(function(response) {
                this.listLoading = false
                console.log('updateResposne:', response)
                if (response.payload.code === 0) {
                  this.getScheduleList()
                  Message.success('修改成功！')
                } else {
                  Message.error(response.payload.code + response.payload.info)
                }
              }.bind(this))
            })
          } else {
            return new Promise((resolve, reject) => {
              createTask({
                jobName: this.formData.jobName.replace(/^\s*$/, ''),
                jobGroup: this.formData.jobGroup.replace(/^\s*$/, ''),
                invokeBody: this.formData.invokeBody.replace(/^\s*$/, ''),
                cron: this.formData.cron.replace(/^\s*$/, ''),
                target: this.formData.target.replace(/^\s*$/, ''),
                remark: this.formData.remark.replace(/^\s*$/, ''),
                startAt: this.formData.startAt,
                endAt: this.formData.endAt
              }).then(function(response) {
                console.log(response)
                this.listLoading = false
                if (response.payload.code === 0) {
                  Message.success('添加成功！')
                  this.getScheduleList()
                } else {
                  Message.error(response.payload.code + response.payload.info)
                }
              }.bind(this))
            })
          }
        } else {
          this.$refs['instanceForm'].resetFields()
          console.log('error submit!')
        }
      })
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.scheduleFlag = false
          this.isScheduleUdate = false
          this.$refs['formData'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    operateInstance() {
      console.log('/monitor/moduleManagement')
      this.$router.push({ path: '/monitor/moduleManagement', query: { moduleName: this.moduleName, serverIp: this.instanceDetail.serverIp }})
    },
    fetchInstanceServices() {
      this.listLoading = true
      queryInstanceServices(this.instanceId, this.instanceDetail.instanceName, this.instanceDetail.serverIp).then(response => {
        console.log('instanceService:', response)
        this.instanceServiceList = response.data.instanceService
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleSetLineChartData(type) {
      if (this.history === type) this.isShowMetric = !this.isShowMetric
      else {
        this.isShowMetric = true
        this.history = type
      }
      this.currentChartData = JSON.parse(JSON.stringify(this.lineChartData[type]))
      this.currentChartName = type + '历史详情'
      this.resizeFlag = !this.resizeFlag
      console.log('type:', this.lineChartData[type])
    },
    fetchInstanceMetrics() {
      this.listLoading = true
      queryinstanceMetrics(this.instanceId).then(response => {
        console.log(response)
        const compare = function(obj1, obj2) {
          // // console.log('conpare', obj1, obj2)
          // const val1 = obj1.metric
          // const val2 = obj2.metric
          // if (val1 > val2) return 1
          // else if (val1 < val2) return -1
          // else return 0
          return obj1.metric.localeCompare(obj2.metric)
        }
        this.instanceMetricsList = response.data.instanceMetrics.sort(compare)
        console.log('instanceMetricsList:', this.instanceMetricsList)
        this.formGrapData()
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchSummaryData() {
      this.listLoading = true
      querySummary(this.instanceId).then(response => {
        console.log(response)
        this.summaryList = response.data.summary[0]
        console.log('summaryList:', this.summaryList)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchSnapshotData() {
      this.listLoading = true
      const nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      const endDayTime = new Date()
      endDayTime.setHours(23)
      endDayTime.setMinutes(59)
      endDayTime.setSeconds(0)
      querySnapshot(this.instanceId, formatDate(nowTime, 'yyyyMMddhhmmss'), formatDate(endDayTime, 'yyyyMMddhhmmss')).then(response => {
        console.log(response)
        this.snapshotList = response.data.snapshot
        console.log('snapshotList:', this.instanceId, '-', this.snapshotList)
        this.formSystemGrapData()
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchInstanceData() {
      this.listLoading = true
      queryInstanceByInstanceId(this.instanceId, true).then(response => {
        console.log(response)
        if (response.data !== undefined && response.data != null) {
          for (const items of response.data.instanceList) {
            if (items.id === this.instanceId) this.instanceDetail = items
          }
        }
        this.fetchInstanceServices()
        console.log('instanceDetail:', this.instanceDetail)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    setView() {
      console.log('scroll')
      window.scrollTo(0, 1000000000)
    },
    fetchModuleList() {
      this.listLoading = true
      getModuleList(this.moduleName, '', '', '', '', '').then(response => {
        console.log(response)
        this.moduleList = response.data.ModuleList
        console.log(this.moduleList)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    fetchData(ModuleName) {
      getModuleStatus(ModuleName).then(response => {
        console.log(response)
        this.list = response.data.moduleInstance
        console.log(this.list)
        this.updateStatus()
        // if (this.initFlag) {
        //   this.instanceTypeFlag = this.list[0].moduleType
        //   // console.log('sha?', this.instanceTypeFlag)
        //   const requestGRoup = []
        //   for (const CLUSTERS of this.list[0].clusters) {
        //     for (const INSTANCE in CLUSTERS.instances) {
        //       requestGRoup.push(
        //         getAlarmStatus('-1', '', CLUSTERS.instances[INSTANCE]['instanceId']).then(response => {
        //           console.log('monitorData:', response)
        //           CLUSTERS.instances[INSTANCE]['monitor'] = response.data.alarmList
        //         }))
        //     }
        //   }
        //   axios.all(requestGRoup).then(function() {
        //     console.log('listData:', this.list)
        //     this.listLoading = false
        //     // this.formGrapData(this.list[0].clusters, 'request')
        //   }.bind(this))
        // }
      })
      console.log('modulestatus:', this.list)
    },
    updateStatus() {
      statusGroupQuery(this.timeOut, [this.instanceId]).then(response => {
        console.log(response)
        this.updateList = response.data.monitorStatus
        // console.log(this.updateList)
        for (const tmp of this.updateList) {
          if (tmp.instanceId === this.instanceId) {
            this.instanceStatusFlag = tmp.status
            const compare = function(obj1, obj2) {
              // console.log('conpare', obj1, obj2)
              const val1 = obj1.key
              const val2 = obj2.key
              if (val1 > val2) return 1
              else if (val1 < val2) return -1
              else return 0
            }
            let a = []
            // a = tmp.message
            for (const jsonKey in tmp.message) {
              const tmps = { key: jsonKey, value: tmp.message[jsonKey] }
              a.push(tmps)
            }
            a = a.sort(compare)
            this.instanceStatusremark = {}
            for (const i of a) {
              this.instanceStatusremark[i.key] = JSON.parse(JSON.stringify(i.value))
            }
            // this.instanceStatusremark = JSON.parse(JSON.stringify(tmp.message))
            // this.instanceStatusremark = a.sort(compare)
            console.log('status:', this.instanceStatusFlag)
            console.log('remark:', this.instanceStatusremark)
          }
          let markFlag = 0
          for (let value = 0; value < this.list.length; value++) {
            if (markFlag === 1) break
            for (let value1 = 0; value1 < this.list[value].clusters.length; value1++) {
              if (markFlag === 1) break
              for (let value2 = 0; value2 < this.list[value].clusters[value1].instances.length; value2++) {
                if (markFlag === 1) break
                if (this.list[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
                  this.list[value].clusters[value1].instances[value2].status = tmp.status
                  this.list[value].clusters[value1].instances[value2].remark = tmp.message
                  if (tmp.message !== null && tmp.message.instance !== null && tmp.message.instance !== undefined) {
                    const data = new Date(tmp.message.instance.startTime)
                    // console.log(data.getMonth())
                    tmp.message.instance.startTime = data.getFullYear() + '-' + (data.getMonth() + 1) + '-' + data.getDate() + ' ' + data.getHours() + ':' + data.getMinutes() + ':' + data.getSeconds()
                    // console.log('startTime:', data.getFullYear() + '-' + data.getMonth() + '-' + data.getDate() + ' ' + data.getHours() + ':' + data.getMinutes() + ':' + data.getSeconds())
                  }
                  markFlag = 1
                  // console.log(this.list[value].clusters[value1].instances[value2].status)
                }
              }
            }
          }
        }
        // if (!this.initFlag) {
        //   const requestGRoup = []
        //   for (const CLUSTERS of this.list[0].clusters) {
        //     for (const INSTANCE in CLUSTERS.instances) {
        //       requestGRoup.push(
        //         getAlarmStatus('-1', '', CLUSTERS.instances[INSTANCE]['instanceId']).then(response => {
        //           console.log('monitorData:', response)
        //           CLUSTERS.instances[INSTANCE]['monitor'] = response.data.alarmList
        //         }))
        //     }
        //   }
        //   axios.all(requestGRoup).then(function() {
        //     console.log('listData:', this.list)
        //     this.listLoading = false
        //   }.bind(this))
        // }
        this.initFlag = false
      })
    },
    handleDetailInfo: function(instanceID, serverIP, Status) {
      let queryStatus = ''
      if (Status === '正常') {
        queryStatus = '0'
      } else if (Status === '告警') {
        queryStatus = '1'
      } else if (Status === '未采集数据') {
        queryStatus = '-1'
      } else if (Status === '未启用监控') {
        queryStatus = '-1'
      }
      console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
      this.$router.push('/monitor/instanceStatus/' + queryStatus + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
      // window.parent.addTab(title, seqUrl)
    },
    stopQuery: function() {
      if (this.timerStatus === '停止轮询') {
        this.timerStatus = '开始轮询'
        clearInterval(this.ref)
        clearInterval(this.ref2)
        clearInterval(this.ref3)
      } else {
        console.log(this.countertime)
        clearInterval(this.ref)
        clearInterval(this.ref2)
        clearInterval(this.ref3)
        const that = this
        this.ref = setInterval(function() {
          that.fetchData(this.moduleName)
          that.fetchInstanceData()
          that.fetchModuleList()
          that.fetchSummaryData()
        }, this.countertime * 1000)
        this.ref2 = setInterval(function() {
          that.fetchSnapshotData()
        }, this.countertimeT * 1000)
        this.ref3 = setInterval(function() {
          that.fetchInstanceMetrics()
        }, 60 * 1000)
        this.$store.dispatch('addTimer', { name: this.$route.path, timer: this.ref })
        this.$store.dispatch('addTimer', { name: this.$route.path, timer: this.ref2 })
        this.$store.dispatch('addTimer', { name: this.$route.path, timer: this.ref3 })
        this.timerStatus = '停止轮询'
      }
    },
    formSystemGrapData() {
    //   console.log('chartQueryData:', this.lineChartData, lineChartData)
      if (this.snapshotList.length !== 0) {
        const tempx = []
        const physicalMemUsage = []
        const processLoad = []
        const systemLoad = []
        const threadCount = []
        // const nonheapUsed = []
        const heapUsed = []
        const fdUsage = []
        this.lineChartData['systemData'] = {}
        this.lineChartData['systemData']['xdata'] = []
        this.lineChartData['systemData']['ydata'] = []
        this.lineChartData['systemData']['namedata'] = []
        this.lineChartData['systemData']['functionData'] = []
        for (const items of this.snapshotList) {
          tempx.push(items.ts.substr(0, 4) + '' + items.ts.substr(4, 2) + '-' + items.ts.substr(6, 2) + ' ' + items.ts.substr(8, 2) + ':' + items.ts.substr(10, 2) + ':' + items.ts.substr(12, 2))
          physicalMemUsage.push(items.physicalMemUsage * 100)
          processLoad.push(items.processLoad * 100)
          systemLoad.push((items.systemLoad) * 100)
          threadCount.push(items.threadCount)
          //   nonheapUsed.push((items.nonheapUsed / this.summaryList.physicalMem) * 100)
          heapUsed.push((items.heapUsed / items.heapMax) * 100)
          fdUsage.push(items.fdUsage * 100)
        }
        this.lineChartData['systemData']['xdata'].push(tempx.reverse())
        this.lineChartData['systemData']['ydata'].push(physicalMemUsage.reverse())
        this.lineChartData['systemData']['namedata'].push('物理内存使用率')
        this.lineChartData['systemData']['ydata'].push(processLoad.reverse())
        this.lineChartData['systemData']['namedata'].push('进程负载')
        this.lineChartData['systemData']['ydata'].push(systemLoad.reverse())
        this.lineChartData['systemData']['namedata'].push('系统负载')
        this.lineChartData['systemData']['ydata'].push(threadCount.reverse())
        this.lineChartData['systemData']['namedata'].push('线程数')
        // lineChartData['systemData']['ydata'].push(nonheapUsed.reverse())
        // lineChartData['systemData']['namedata'].push('非堆栈内存使用率')
        this.lineChartData['systemData']['ydata'].push(heapUsed.reverse())
        this.lineChartData['systemData']['namedata'].push('堆栈内存使用率')
        this.lineChartData['systemData']['ydata'].push(fdUsage.reverse())
        this.lineChartData['systemData']['namedata'].push('文件句柄使用率')
      } else {
        console.log('snapshotList is empty!')
        this.lineChartData['systemData'] = {}
        this.lineChartData['systemData']['xdata'] = []
        this.lineChartData['systemData']['ydata'] = []
        this.lineChartData['systemData']['namedata'] = []
        this.lineChartData['systemData']['functionData'] = []
      }
      console.log('chartQueryData:', this.instanceId, '-', this.lineChartData)
      this.lineChartData = JSON.parse(JSON.stringify(this.lineChartData))
    },
    formGrapData() {
      var nowTime = new Date()
      // nowTime.setDate(21)
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      const startTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
      nowTime = new Date()
      // nowTime.setDate(21)
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      const endTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
      const requestGroup = []
      const formGrapData_lineChartData = {}
      for (const clusterItem of this.instanceMetricsList) {
        formGrapData_lineChartData[clusterItem.metric] = {}
        formGrapData_lineChartData[clusterItem.metric]['xdata'] = []
        formGrapData_lineChartData[clusterItem.metric]['ydata'] = []
        formGrapData_lineChartData[clusterItem.metric]['namedata'] = []
        formGrapData_lineChartData[clusterItem.metric]['functionData'] = []
        if (clusterItem.metricType === 'counter' || clusterItem.metricType === 'gauge') {
          requestGroup.push(
            getMetricsGauges(this.instanceId, clusterItem.metric, startTime, endTime).then(response => {
              if (response.data.metricsGauges.length !== 0) {
                const tempx = []
                const tempy = []
                let mark = true
                for (const s of response.data.metricsGauges) {
                  if (mark) {
                    formGrapData_lineChartData[clusterItem.metric]['functionData'].push({
                      data: s.data
                    })
                    // for (let test = 1; test < 10; test++) {
                    //   lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData.push({
                    //     name: (i.serverIp + test),
                    //     m1Rate: s.m1Rate + test,
                    //     m5Rate: s.m5Rate + test,
                    //     m15Rate: s.m15Rate + test
                    //   })
                    // }

                    mark = false
                  }
                  tempx.push(s.ts.substr(0, 4) + '' + s.ts.substr(4, 2) + '-' + s.ts.substr(6, 2) + ' ' + s.ts.substr(8, 2) + ':' + s.ts.substr(10, 2) + ':' + s.ts.substr(12, 2))
                  tempy.push(s.data)
                }
                formGrapData_lineChartData[clusterItem.metric]['xdata'].push(tempx.reverse())
                formGrapData_lineChartData[clusterItem.metric]['ydata'].push(tempy.reverse())
                formGrapData_lineChartData[clusterItem.metric]['namedata'].push(clusterItem.metric)
              } else {
                formGrapData_lineChartData[clusterItem.metric]['xdata'] = []
                formGrapData_lineChartData[clusterItem.metric]['ydata'] = []
                formGrapData_lineChartData[clusterItem.metric]['namedata'] = []
                Message.error(clusterItem.metric + '无数据')
              }
            }))
        }
        if (clusterItem.metricType === 'timer' || clusterItem.metricType === 'meter') {
          requestGroup.push(
            getMetricsTimer(this.instanceId, clusterItem.metric, startTime, endTime).then(response => {
              if (response.data.metricsTimer.length !== 0) {
                const tempx = []
                const tempym1Rate = []
                const tempym5Rate = []
                const tempym15Rate = []
                let mark = true
                for (const s of response.data.metricsTimer) {
                  if (mark) {
                    formGrapData_lineChartData[clusterItem.metric]['functionData'].push({
                      m1Rate: s.m1Rate,
                      m5Rate: s.m5Rate,
                      m15Rate: s.m15Rate
                    })
                    // for (let test = 1; test < 10; test++) {
                    //   lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData.push({
                    //     name: (i.serverIp + test),
                    //     m1Rate: s.m1Rate + test,
                    //     m5Rate: s.m5Rate + test,
                    //     m15Rate: s.m15Rate + test
                    //   })
                    // }

                    mark = false
                  }
                  tempx.push(s.ts.substr(0, 4) + '' + s.ts.substr(4, 2) + '-' + s.ts.substr(6, 2) + ' ' + s.ts.substr(8, 2) + ':' + s.ts.substr(10, 2) + ':' + s.ts.substr(12, 2))
                  tempym1Rate.push(s.m1Rate)
                  tempym5Rate.push(s.m5Rate)
                  tempym15Rate.push(s.m15Rate)
                }
                formGrapData_lineChartData[clusterItem.metric]['xdata'].push(tempx.reverse())
                formGrapData_lineChartData[clusterItem.metric]['ydata'].push(tempym1Rate.reverse())
                formGrapData_lineChartData[clusterItem.metric]['ydata'].push(tempym5Rate.reverse())
                formGrapData_lineChartData[clusterItem.metric]['ydata'].push(tempym15Rate.reverse())
                formGrapData_lineChartData[clusterItem.metric]['namedata'].push('一分钟速率')
                formGrapData_lineChartData[clusterItem.metric]['namedata'].push('五分钟速率')
                formGrapData_lineChartData[clusterItem.metric]['namedata'].push('十五分钟速率')
              } else {
                formGrapData_lineChartData[clusterItem.metric]['xdata'] = []
                formGrapData_lineChartData[clusterItem.metric]['ydata'] = []
                formGrapData_lineChartData[clusterItem.metric]['namedata'] = []
                Message.error(clusterItem.metric + '无数据')
              }
            }))
        }
        if (clusterItem.metricType === 'histogram')Message.error('暂不支持histogram数据')
      }

      axios.all(requestGroup).then(function() {
        for (const clusterItem of this.instanceMetricsList) {
          this.functionData[clusterItem.metric] = JSON.parse(JSON.stringify(formGrapData_lineChartData[clusterItem.metric].functionData))
          this.classname[clusterItem.metric] = clusterItem.metric + '历史记录'
        }
        console.log('chartQueryDataMetrics:', this.functionData)
        this.lineChartData = JSON.parse(JSON.stringify(formGrapData_lineChartData))
        if (this.currentChartName !== null) {
          const a = this.currentChartName.split('历史详情')[0]
          this.currentChartData = JSON.parse(JSON.stringify(this.lineChartData[a]))
        }
        this.resizeFlag = !this.resizeFlag
      }.bind(this))
    }
  },
  destroyed() {
    console.log('DestroyDetail')
    clearInterval(this.ref)
  },
  watch: {
    // isShow() {
    //   if (this.isShow === true)window.scrollTo(0, 1000000000)
    // },
    selectName() {
      if (this.selectName !== '')window.scrollTo(0, 1000000000)
    }
  },
  // watch: {
  //   $route(to, from, next) {
  //     if (from.path !== this.$route.path) {
  //       console.log('enter!', from.path, '   ', this.$route.path,"  ",to.p)
  //       if (this.$route.params.moduleId !== undefined) {
  //         this.moduleId = this.$route.params.moduleId
  //       }
  //       if (this.$route.params.moduleName) {
  //         this.moduleName = (this.$route.params.moduleName).split('详情').shift()
  //       }
  //       this.fetchData(this.moduleName)
  //       this.fetchModuleList()
  //     // this.closeContainer()
  //     }
  //   }
  // },
  activated() {
    // this.fetchData(this.moduleName)
    // console.log('type:', this.instanceTypeFlag)
    if (!this.initFlag) {
      console.log('actived!')
      //   this.formGrapData(this.list[0].clusters, 'request')
      //   this.formSystemGrapData()
      //   const that = this
      //   setTimeout(function() {
      //     that.isShow = false
      //   }, 500)
      this.formSystemGrapData()
      this.fetchInstanceMetrics()
      this.resizeFlag = !this.resizeFlag
      this.updateStatus()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/breathe-btn.scss';
.serviceTable{
  flex: auto;
}
.card-panel-col{
  width: 100%;
}
.card-panel-cols{
  width: auto;
}
.MetricsContainer{
    
                float: right;
    
                font-weight: bold;
    
                margin: 26px;
    
                margin-left: 0px;
    
                .card-panel-text {
                    line-height: 18px;
    
                    // color: rgba(0, 0, 0, 0.45);
    
                    font-size: 30px;
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
}
.instanceItemFormTitle{
  margin-left: 10px;
  margin-top: 10px;
  margin-bottom: 10px;
  position: relative;
//   width:305px;
  border-style: solid;
  border-color: snow;
  border-width: 5px;
  outline-style: outset;
  outline-width: 1px;
  outline-color: rgb(150, 135, 135);
  width: 15%;
}
.instanceItemForm{
  margin-left: 10px;
  margin-top: 10px;
  margin-bottom: 10px;
  // position: relative;
//   width:305px;
  border-style: solid;
  border-color: snow;
  border-width: 5px;
  outline-style: outset;
  outline-width: 1px;
  outline-color: rgb(150, 135, 135);
  width: 80%;
}
.instanceItem{
  clear: right;
  float: right;
  // width: 100%;
}
.lineDIV{
  float: left;
  width: 100%;
}
.moduleInfoForm{
  float:left;
  width: 80%;
    // margin-left: 30px;
}
.runtimeContainer{
    height: auto;
}
.isntanceStatusContainer{
    height: 400px; 
    overflow-y: auto;
}
.instanceStatusWindow{
    // height: 200px;
    // margin-top: -20px;
    // margin-left: -20px;
}
.gaugeChart{
    margin-top: -50px;
    margin-bottom: -80px;
}
.formItemInfo{
  float: left;
  clear: right;
  width: 400px;
}
.instanceInfoBox{
  float: left;
  clear: right;
}
.panel-group{
  margin-bottom: 5px;
}
.moduleInfo{
//   border-style: solid;
//   border-color: snow;
//   border-width: 5px;
//   outline-style: solid;
//   outline-width: 1px;
//   outline-color: steelblue;
  
}
.moduleInfoTitle{
  margin-left: 10px;
  margin-top: 10px;
  margin-bottom: 10px;
  clear: right;
  float: left;
  width:23%;
  border-style: solid;
  border-color: snow;
  border-width: 2px;
  outline-style: outset;
  outline-width: 1px;
  outline-color: rgb(150, 135, 135);
}
.statusModuleInfoTitle{
    margin-left: 10px;
  margin-top: 10px;
  margin-bottom: 10px;
  clear: right;
  float: left;
  // width:23%;
  border-style: solid;
  border-color: snow;
  border-width: 5px;
  outline-style: outset;
  outline-width: 1px;
  outline-color: rgb(150, 135, 135);
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.outTable {
    width: 100%;
}

.innerTable {
    width: 100%;
}

.selectButton {
    margin-top: 5px;
    margin-left: 10px;
    width: 180px;
}
.pan-btn{
  width: 220px;
  height: auto;
  text-align: center;
}
.chartBox{
  display: inline;
}
.chartData-container {
    // margin-top: -40px;
    padding: 20px;
    width: 100%;
    height: 500px;
}
.innerchartData-container {
    
                height: 200px;
    
                position: relative;
    
                display: flex;
    
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
            }
.chart-container {
    
                height: auto;
    
                position: relative;
                float: left;
                clear: right;
                display: flex;
            }
.card-panel {
    
            height: auto;
            cursor: pointer;
            font-size: 12px;
    
            position: relative;
    
            overflow: hidden;
    
            color: #666;
    
            background: #fff;
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
            border-color: rgba(0, 0, 0, .05);
    
            &:hover {
    
                .card-panel-icon-wrapper {
    
                    color: #fff;
    
                }
    
                .icon-warning {
    
                    background: #f80606;
    
                }
    
                .icon-module {
    
                    background: #f0be1d;
    
                }
    
                .icon-gateway {
    
                    background: #2109f7;
    
                }
    
                .icon-trade {
    
                    background: #34bfa3;
    
                }
    
                .icon-credit {
    
                    background: #f518e2;
    
                }
    
                .icon-router {
    
                    background: #3f0186;
    
                }
                .icon-cluster{
                  
                    background: #015313;
    
                }
    
            }
    
            .icon-warning {
    
                color: #f80606;
    
            }
    
            .icon-module {
    
                color: #f0be1d;
                
            }
    
            .icon-gateway {
    
                color: #2109f7;
    
            }
    
            .icon-trade {
    
                color: #34bfa3;
    
            }
    
            .icon-credit {
    
                color: #f518e2;
    
            }
    
            .icon-router {
    
                color: #3f0186;
    
            }
            .icon-cluster{
    
                    color: #015313;
    
            }
    
            .card-panel-icon-wrapper {
    
                // float: left;
                display: flex;
                float: left;
                clear: right;
                align-items:center;
                margin: 14px 10px 10px 14px;
    
                padding: 16px;
    
                transition: all 0.38s ease-out;
    
                border-radius: 6px;
                
    
            }
    
            .card-panel-icon {
    
                // float: right;

                font-size: 48px;

                
    
            }
    
            .card-panel-description {
    
                float: right;
    
                font-weight: bold;
    
                margin: 26px;
    
                margin-left: 0px;
    
                .card-panel-text {
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 30px;
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
            .card-panel-descriptions {
    
                float: right;
                font-weight: bold;
    
                margin: 26px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
        }

</style>
