<template>
<div class="app-container">
    <section class="table-container">
        <h3 v-html="logTitle"> </h3>
        <div  style="height: 450px; background: #333; color: #aaa; padding: 10px;">
        <div  id="logWindow" style="height: 400px; overflow-y: auto; background: #333; color: #aaa; padding: 10px;">
            <div style="margin-bottom:50px;" v-html="logHtml">
            </div>
        </div>
        </div>
        <div
            class="wrapper-box"
            ref="wrapperBox"
        >
            <el-form
                ref="ruleForm"
                :inline="true"
                @submit.native.prevent
            >
                <div class="form-wrapper">
                    <el-form-item
                        class="form-wrapper-item form-item-query normal-width"
                        label="模块名称"
                        label-width="100px"
                        prop="includeCode"
                    >
                        <el-input
                            v-model="moduleName"
                            size="mini"
                            placeholder="请输入模块名称"
                             @keyup.enter.native="handleQuery('ruleForm')"
                        ></el-input>
                            </el-form-item>
                            <el-form-item
                        class="form-wrapper-item form-item-query normal-width"
                        label="服务器地址"
                        label-width="100px"
                        prop="includeCode"
                    >
                        <el-input
                            v-model="serverIp"
                            size="mini"
                             @keyup.enter.native="handleQuery('ruleForm')"
                            placeholder="请输入服务器地址"
                        ></el-input>
                            </el-form-item>
                            <el-form-item
                                class="form-wrapper-item form-item-query normal-width"
                                label=""
                                label-width="0"
                            >
                                <el-button
                                    type="primary"
                                    @click="handleQuery('ruleForm')"
                                    :disabled="isQuery"
                                    size="mini"
                                    :loading="listLoading"
                                >查询</el-button>
                                 <el-button
                                    type="primary"
                                    @click="wsOver"
                                    :disabled="isQuery"
                                    size="mini"
                                    :loading="listLoading"
                                >停止日志</el-button>
                                </el-form-item>
                                   

                </div>
                </el-form>
</div>
<el-table
    ref="singleTable"
    :data="list"
    highlight-current-row
    style="width: 100%"
    :border="true"
    :stripe="true"
    resizable
    :span-method="objectspanMethod"
>
    <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
            property="moduleName"
            label="模块名"
            header-align="center"
            align="left"
            
        >
            <template slot-scope="scope">
                <p >{{scope.row.moduleName}}</p>
            </template>
            </el-table-column>
            <el-table-column
                property="serverIp"
                label="部署IP"
                header-align="center"
                align="left"
            >
                <template slot-scope="scope">
                    <p>{{scope.row.serverIp}}</p>
                </template>
                </el-table-column>
                <el-table-column
                    property="artifactName"
                    label="构件名称"
                    header-align="center"
                    align="left"
                >
                    <template slot-scope="scope">
                        <p>{{scope.row.artifactName}}</p>
                    </template>
                    </el-table-column>
                    <el-table-column
                        property="artifactType"
                        label="构件类型"
                        header-align="center"
                        align="left"
                    >
                        <template
                            slot-scope="scope"
                            style="alpha: 0%"
                        >
                            <el-tag type="success">{{scope.row.artifactTypeInfo}}</el-tag>
                            </template>
                            </el-table-column>
                            <el-table-column
                                property="clusterName"
                                label="集群名称"
                                header-align="center"
                                align="left"
                            >
                                <template slot-scope="scope">
                                    <p>{{scope.row.clusterName}}</p>
                                </template>
                                </el-table-column>
                                <!-- <el-table-column
                                property="startTime"
                                label="模块启动时间"
                                header-align="center"
                                align="left"
                            >
                                <template slot-scope="scope">
                                    <p>{{scope.row.startTime}}</p>
                                </template>
                                </el-table-column> -->
                                
                                <el-table-column
                                    fixd="right"
                                    label="操作"
                                    align="center"
                                    width="300px"
                                >
                                    <template slot-scope="scope">
                                        <el-button
                                            type="default"
                                            size="mini"
                                            class="tool-item"
                                            @click="sshLoginForLog(scope.row)"
                                        >
                                        <div class="opContainer" :loading="listLoading">
                                              <i class="el-icon-search"></i>
                                             <p class="el-icon-search-text">查看日志</p>
                                        </div>
                                        
                                                   
                                            </el-button>
                                            <el-button
                                            v-if="hasPermission()"
                                            type="default"
                                            size="mini"
                                            class="tool-item"
                                            @click="sshLoginForStop(scope.row,scope.$index)"
                                        >
                                        <div class="opContainer" :loading="listLoading">
                                              <i class="el-icon-search"></i>
                                             <p class="el-icon-search-text">停止</p>
                                        </div>
                                        
                                                   
                                            </el-button>
                                            <el-button
                                            type="default"
                                            size="mini"
                                            v-if="hasPermission()"
                                            class="tool-item"
                                            @click="sshLoginForStart(scope.row,scope.$index)"
                                        >
                                        <div class="opContainer" :loading="listLoading">
                                              <i class="el-icon-search"></i>
                                             <p class="el-icon-search-text">启动</p>
                                        </div>
                                        
                                                   
                                            </el-button>
                                    </template>
                                    </el-table-column>
                                    </el-table>

                                    <el-dialog
                                        title="停止模块远程登录"
                                        :visible.sync="stopDialog"
                                        :loading="listLoading"
                                    >
                                        <el-form :model="sshObj" :loading="listLoading">
                                            <el-form-item
                                                label="登录名"
                                                class="form-wrapper-item"
                                                label-width="90px"
                                            >
                                                <el-input
                                                    v-model="sshObj.username"
                                                    size="mini"
                                                ></el-input>
                                                    </el-form-item>
                                                    <el-form-item
                                                        label="登录密码"
                                                        class="form-wrapper-item"
                                                        label-width="90px"
                                                        
                                                    >
                                                        <el-input
                                                            v-model="sshObj.password"
                                                            size="mini"
                                                            type="password"
                                                        ></el-input>
                                                            </el-form-item>
                                        </el-form>
                                        <div
                                            slot="footer"
                                            class="dialog-footer"
                                        >
                                            <el-button @click="stopDialog = false" :loading="listLoading">取 消</el-button>
                                            <el-button
                                                type="primary"
                                                @click="sshStop"
                                                :loading="listLoading"
                                            >确 定</el-button>
                                                </div>
                                                </el-dialog>
                                                <el-dialog
                                                    title="启动模块远程登录"
                                                    :visible.sync="startDialog"
                                                    :loading="listLoading"
                                                >
                                                    <el-form :model="sshObj" :loading="listLoading">
                                                        <el-form-item>
                                                            <span class="warningText" >该功能只能用作模块停止后的启动，不是重启。若模块已经运行则需先停止后在执行启动！</span>
                                                        </el-form-item>
                                                        <el-form-item
                                                            label="登录名"
                                                            class="form-wrapper-item"
                                                            label-width="90px"
                                                        >
                                                            <el-input
                                                                v-model="sshObj.username"
                                                                size="mini"
                                                            ></el-input>
                                                                </el-form-item>
                                                                <el-form-item
                                                                    label="登录密码"
                                                                    class="form-wrapper-item"
                                                                    label-width="90px"
                                                                >
                                                                    <el-input
                                                                        v-model="sshObj.password"
                                                                        type="password"
                                                                        size="mini"
                                                                    ></el-input>
                                                                        </el-form-item>
                                                    </el-form>
                                                    <div
                                                        slot="footer"
                                                        class="dialog-footer"
                                                    >
                                                        <el-button @click="startDialog = false" :loading="listLoading">取 消</el-button>
                                                        <el-button
                                                            type="primary"
                                                            @click="sshStart"
                                                            :loading="listLoading"
                                                        >确 定</el-button>
                                                            </div>
                                                            </el-dialog>

                                                            <el-dialog
                                                                title="查看日志远程登录"
                                                                :visible.sync="logDialog"
                                                                :loading="listLoading"
                                                            >
                                                                <el-form :model="sshObj" :loading="listLoading">
                                                                    <el-form-item
                                                                        label="登录名"
                                                                        class="form-wrapper-item"
                                                                        label-width="90px"
                                        
                                                                    >
                                                                        <el-input
                                                                            v-model="sshObj.username"
                                                                            size="mini"
                                                                        ></el-input>
                                                                            </el-form-item>
                                                                            <el-form-item
                                                                                label="登录密码"
                                                                                class="form-wrapper-item"
                                                                                label-width="90px"
                                                                               
                                                                            >
                                                                                <el-input
                                                                                    v-model="sshObj.password"
                                                                                    size="mini"
                                                                                     type="password"
                                                                                ></el-input>
                                                                                    </el-form-item>
                                                                </el-form>
                                                                <div
                                                                    slot="footer"
                                                                    class="dialog-footer"
                                                                >
                                                                    <el-button @click="logDialog = false" :loading="listLoading">取 消</el-button>
                                                                    <el-button
                                                                        type="primary"
                                                                        @click="logPrint"
                                                                        :loading="listLoading"
                                                                    >确 定</el-button>
                                                                        </div>
                                                                        </el-dialog>
                                                                        </section>

                                                                        </div>
</template>



<script>
import {
  queryModuleInstanceList2,
  moduleinstanceopStart,
  moduleinstanceopStop,
  getModuleStatusUpdate
} from '@/api/monitor'
import {
  Message
} from 'element-ui'
import { mapGetters } from 'vuex'
export default {
  name: 'moduleManagement',
  data() {
    return {
      timeOut: '30',
      isEdit: false,
      isQuery: false,
      isModify: false,
      isDialog: false,
      list: [],
      moduleName: '',
      serverIp: '',
      isAddDialog: false,
      logHtml: '',
      logTitle: '',
      wsBaseUrl: '',
      logDialog: false,
      startDialog: false,
      stopDialog: false,
      listLoading: false,
      lastModule: '',
      firstFlage: true,
      isdalog: true,
      initTImer: 500,
      tableMerge: {
        rowNUm: [],
        rowSpace: []
      },
      sshObj: {
        username: 'obgear',
        password: 'y2iaciej'
      },
      moduleInstance: {
        serverIp: '',
        moduleName: '',
        artifactType: '',
        artifactName: ''
      },
      isScrollTop: false
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  created() {
    this.wsBaseUrl = process.env.zt_monitor_ws_url_ws
    console.log('wsBaseUrl:', process.env.zt_monitor_ws_url_ws)
    // this.getList()
  },
  activated() {
    if (this.$route.query.moduleName !== undefined && this.$route.query.moduleName !== '' && this.$route.query.moduleName !== '0') {
      this.moduleName = this.$route.query.moduleName
    }
    if (this.$route.query.serverIp !== undefined && this.$route.query.serverIp !== '' && this.$route.query.serverIp !== '0') {
      this.serverIp = this.$route.query.serverIp
      if (this._ws) this.wsOver()
    }
    console.log('actived!')
    this.getList()
    // console.log('name:', this.activePane)
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'moduleManagementButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    sshLoginForStop(row, index) {
      this.stopDialog = true
      this.moduleInstance = row
    },
    sshLoginForStart(row, index) {
      this.startDialog = true
      this.moduleInstance = row
    },
    sshLoginForLog(row) {
      this.logDialog = true
      this.moduleInstance = row
    },
    handleQuery() {
      this.getList()
    },
    getList() {
      this.isdalog = true
      queryModuleInstanceList2(this.moduleName, this.serverIp).then(response => {
        this.isdalog = false
        console.log('response:', response)
        if (response.code === 0) {
          const d = response.data[0]
          d.forEach(item => {
            switch (item['artifactType']) {
              case 0:
                item['artifactTypeInfo'] = 'UNKNOWN'
                break
              case 1:
                item['artifactTypeInfo'] = 'VERTX'
                break
              case 2:
                item['artifactTypeInfo'] = 'SPRING'
                break
              default:
                break
            }
          })
          this.list = d
          this.updateStatus()
          console.log('list:', this.list)
          /** 获取合并table的结构，rowNum为内容不同的的行的开始行号，rowSpace是由此行接下来几行是相同名称的需要合并 */
          this.tableMerge.rowNUm = []
          this.tableMerge.rowSpace = []
          var tempNmae = this.list[0].moduleName
          var count = 0
          var countspace = 1
          for (const i in this.list) {
            if (i > 0) {
              if (this.list[i].moduleName !== tempNmae) {
                tempNmae = this.list[i].moduleName
                this.tableMerge.rowSpace.push(countspace)
                if (this.tableMerge.rowSpace.length === 1) {
                  this.tableMerge.rowNUm.push(count)
                  count += countspace
                  this.tableMerge.rowNUm.push(count)
                } else {
                  count += countspace
                  this.tableMerge.rowNUm.push(count)
                }
                countspace = 1
              } else {
                countspace++
              }
            }
          }
          if (this.tableMerge.rowNUm.length === 0) {
            this.tableMerge.rowSpace.push(countspace)
            if (this.tableMerge.rowSpace.length === 1) {
              this.tableMerge.rowNUm.push(count)
              count += countspace
              this.tableMerge.rowNUm.push(count)
            } else {
              count += countspace
              this.tableMerge.rowNUm.push(count)
            }
            countspace = 1
          }
          this.tableMerge.rowSpace.push(countspace)
        } else {
          Message.error(response.errorCode + ':' + response.messageInfo)
        }
        this.objectspanMethod({ row: 1, colum: 1, rowIndex: 0, columIndex: 1 })
      })
    },
    /** 合并table的函数 */
    objectspanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 1 || columnIndex === 0) {
        // if (rowIndex === 0) {
        //   return {
        //     rowspan: 1,
        //     colspan: 1
        //   }
        // }
        for (const i in this.tableMerge.rowNUm) {
          if (this.tableMerge.rowNUm[i] === rowIndex) {
            return {
              rowspan: this.tableMerge.rowSpace[i],
              colspan: 1
            }
          }
        }
        return {
          rowspan: 0,
          colspan: 0
        }
      }
    },
    updateStatus() {
      getModuleStatusUpdate(this.timeOut).then(response => {
        console.log(response)
        this.updateList = response.data.monitorStatus
        console.log(this.updateList)
        for (const tmp of this.updateList) {
          let markFlag = 0
          for (const value of this.list) {
            if (markFlag === 1) break
            if (value.id === tmp.instanceId) {
              markFlag = 1
              if (tmp.message !== null && tmp.message.instance !== null && tmp.message.instance !== undefined) {
                const data = new Date(tmp.message.instance.startTime)
                value.startTime = data.getFullYear() + '-' + (data.getMonth() + 1) + '-' + data.getDate() + ' ' + data.getHours() + ':' + data.getMinutes() + ':' + data.getSeconds()
                console.log('startTime:', data.getFullYear() + '-' + data.getMonth() + '-' + data.getDate() + ' ' + data.getHours() + ':' + data.getMinutes() + ':' + data.getSeconds())
              } else {
                value.startTime = ''
              }
            //   console.log(this.list[value].clusters[value1].instances[value2].status)
            }
          }
        }
        this.listLoading = false
      })
    },
    sshStop() {
      this.listLoading = true
      this.isScrollTop = false
      moduleinstanceopStop(this.moduleInstance.moduleName, this.moduleInstance.serverIp, this.sshObj.username, this.sshObj.password, this.moduleInstance.artifactName, this.moduleInstance.artifactType, this.moduleInstance.version).then(response => {
        console.log('response', response)
        this.listLoading = false
        if (response.code === 0) {
          this.stopDialog = false
          Message.success('停止成功！')
        //   this.logPrint()
        } else {
          Message.error(response.errorCode + ':' + response.messageInfo)
        }
        setTimeout(function() {
          this.$nextTick(() => {
            document.getElementById('logWindow').scrollTop = document.getElementById('logWindow').scrollHeight
          })
          this.isScrollTop = true
        }.bind(this), 6000)
      })
    },
    logPrint() {
      this.listLoading = true
      this.isScrollTop = false
      if (this.firstFlage) {
        this.lastModule = this.moduleInstance.moduleName
        this.firstFlage = false
      }
      this.logHtml = ''
      this.logTitle = ''
      var serverIp = this.moduleInstance.serverIp
      var moduleName = this.moduleInstance.moduleName
      const targetWSURL = this.wsBaseUrl
      var url = this._ws ? this._ws.url : ''
      var sendDataJson = {}
      sendDataJson['serverIp'] = serverIp
      sendDataJson['moduleName'] = moduleName
      sendDataJson['username'] = this.sshObj.username
      sendDataJson['password'] = this.sshObj.password

      var sendData = JSON.stringify(sendDataJson)
      console.log((targetWSURL + moduleName), ',', (url + this.lastModule))
      if (this._ws && (targetWSURL + moduleName) === (url + this.lastModule) && this._ws.readyState === 1) { // 1 websocket.OPEN
        this._ws.send(sendData)
      } else if (this._ws && (targetWSURL + moduleName) === (url + this.lastModule) && this._ws.readyState === 0) { // 0 websocket.OPEN
        setTimeout(function() {
          this._ws.send(sendData)
        }, 300)
      } else {
        const that = this // 保存当前对象this
        if ((that._ws && (targetWSURL + moduleName) !== (url + that.lastModule))) {
          that.lastModule = moduleName
          console.log(url + 'close ')
          that.wsOver()
        }
        this.initWS(targetWSURL, sendData)
        this.logTitle = 'moduleName：' + moduleName + ' ,serverIp:' + serverIp
      }
      this.logDialog = false
      this.listLoading = false
      setTimeout(function() {
        this.$nextTick(() => {
          document.getElementById('logWindow').scrollTop = document.getElementById('logWindow').scrollHeight
        })
        this.isScrollTop = true
      }.bind(this), 2000)
    },
    wsOver() { // 关闭
      console.log(this._ws.url + 'close ')
      this.logHtml = ''
      this.logTitle = ''
      this._ws.close()
    //   onclose
    },
    initWS(targetWSURL, sendData) { // 初始化weosocket
      // ws地址
      var ws = new WebSocket(targetWSURL)
      ws.onmessage = this.wsOnMessage
      ws.onclose = this.wsClose
      ws.over = this.wsOver

      ws.addEventListener('open', function(evt) {
        this.logHtml = ''
        this.logTitle = ''
        console.log('open evt  triggered...')
        ws.send(sendData)
      })
      this._ws = ws
    },
    sshStart: function() {
      this.listLoading = true
      this.isScrollTop = false
      moduleinstanceopStart(this.moduleInstance.moduleName, this.moduleInstance.serverIp, this.sshObj.username, this.sshObj.password, this.moduleInstance.artifactName, this.moduleInstance.artifactType, this.moduleInstance.version).then(response => {
        console.log('response', response)
        this.listLoading = false
        if (response.code === 0) {
          this.startDialog = false
          Message.success('启动成功！')
        //   this.logPrint()
        } else {
          Message.error(response.errorCode + ':' + response.messageInfo)
        }
        setTimeout(function() {
          this.$nextTick(() => {
            document.getElementById('logWindow').scrollTop = document.getElementById('logWindow').scrollHeight
          })
          this.isScrollTop = true
        }.bind(this), 6000)
      })
    },
    wsOnMessage(evt) { // 数据接收
      console.log('data received...')
      this.logHtml = this.logHtml + evt.data
      if (this.isScrollTop) {
        this.$nextTick(() => {
          document.getElementById('logWindow').scrollTop = document.getElementById('logWindow').scrollHeight
        })
      }
    },
    wsClose(e) { // 关闭
      console.log('connection closed (' + e.code + ')')
    }
  }
}
</script>
<style>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.el-icon-search{
    display: inline-block;
  }
.opContainer{
    display: inline-block; 
  }
.opContainer{
  display: inline-block;
}
.warningText{
    font-size: 30px;
    color: rgb(241, 10, 10);
}
</style>
