<template>
  <div class="app-container">
    <el-container ref="mainform" >
    <el-card class="leftContainer">
          <el-popover
          placement="left"
          trigger="click">
           <el-form ref="ruleForm" @submit.native.prevent>
        <div class="form-wrapper">
          <el-form-item class="form-wrapper-item form-item-query normal-width" label="模块实例id" label-width="100px" prop="includeCode">
            <el-input v-model="instanceId" size="mini" @keyup.enter.native="listLoading"  placeholder="请输入模块实例id"></el-input>
             <el-button type="primary" @click="fetchData" v-loading.body="listLoading" size="mini">查询</el-button>
          </el-form-item>
          <el-form-item class="form-wrapper-item form-item-query normal-width" label="监控点id" label-width="100px" prop="includeCode">
            <el-input v-model="monitorId" size="mini" @keyup.enter.native="listLoading" placeholder="请输入监控点id"></el-input>
            <el-button type="primary" @click="fetchData" v-loading.body="listLoading" size="mini">查询</el-button>
          </el-form-item>
          <el-form-item class="form-wrapper-item" label="轮询时间" label-width="160px">
            <el-select v-model="countertime" placeholder="轮询间隔时间" >
              <el-option
                      v-for="item in timeTable"
                      :key="item.value"
                      :label="item.value"
                      :value="item.time">
              </el-option>
            </el-select>
            <el-button :type = "timerStatus === '开始轮询' ? 'primary' : 'danger' " @click="stopQuery" v-loading.body="listLoading" size="mini">{{timerStatus}}</el-button>
          </el-form-item>
        </div>
      </el-form>
                <el-button slot="reference" style="float: left;margin-right: 10px;" type="text">操作按钮</el-button>
          </el-popover>
                <div style="float: left;clear:right;margin-top: 10px;">
                  <el-tag type="warning">是否启用业务域筛选<el-switch v-model="doFilter"></el-switch></el-tag>
            </div>
    <el-table
            v-loading.body="listLoading" element-loading-text="Loading" border fit highlight-current-row
            size="mini"
            ref="singleTable"
            :data="showList"
            style="width: 100%"
            height="750"
            :stripe="true"
            resizable>
      <!-- <el-table-column type="index" width="30px" align="center"></el-table-column> -->
      <el-table-column type="expand" >
        <template slot-scope="scope">
          <el-form label-position="left">
        <el-form-item label="模块实例ID" >
                <span >{{scope.row.objectId}}</span>
            </el-form-item>
          <el-form-item label="监控点iD" >
                <span >{{scope.row.monitorId}}</span>
            </el-form-item>
            <el-form-item label="监控值" >
              <span >{{scope.row.monitorVal}}</span>
            </el-form-item>
            <el-form-item label="参考值" >
              <span >{{scope.row.referVal}}</span>
            </el-form-item>
            <el-form-item label="remark信息" >
              <span >{{scope.row.remark}}</span>
            </el-form-item>
            </el-form>
        </template>
      </el-table-column>
      <el-table-column property="objectName" label="模块实例名称"  header-align="center"  align="center" width= 150>
        <template slot-scope="scope">
          <p >{{scope.row.objectName}}</p>
        </template>
      </el-table-column>
      <el-table-column property="monitorName" label="监控点名称"  header-align="center"  align="center" width= 150>
          <template slot-scope="scope1">
            <p >{{scope1.row.monitorName}}</p>
          </template>
      </el-table-column>
      <el-table-column property="serverIp" label="服务器地址"  header-align="center"  align="center" width= 150>
        <template slot-scope="scope">
          <p >{{scope.row.serverIp}}</p>
        </template>
        </el-table-column>
        <el-table-column property="message" label="告警信息"  header-align="center"  align="left">
          <template slot-scope="scope">
            <p >{{scope.row.message}}</p>
          </template>
      </el-table-column>
      <el-table-column property="status" label="状态"  header-align="center"  align="center" width= 150>
        <template slot-scope="scope">
          <el-tag :type = "scope.row.status === '正常' ? 'success': (scope.row.status === '未采集数据' ? 'warning':(scope.row.status === '未启用监控' ? 'info':'danger'))"
                   style="margin-right: 10px">{{scope.row.status}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column property="updated" label="更新时间"  header-align="center"  align="center" width= 170>
        <template slot-scope="scope">
          <p >{{scope.row.updated}}</p>
        </template>
      </el-table-column>
      <el-table-column
                        label="操作"
                        header-align="center"
                        align="center"
                        width=150
                    >
                        <template slot-scope="scope1">
                            <el-button
                                slot="primary"
                                @click="fetchEventData(scope1.row.monitorId,scope1.row.objectId,'1',scope1.row.monitorName)"
                            >
                                <span>告警详情</span>
                                </el-button>
                        </template>
                        </el-table-column>
    </el-table>
    </el-card>
       <transition name="el-zoom-in-top">
        <el-card  class="rightContainer" v-if = "isEventShow === 'true'">
          <span class="SideWindowtitle">{{sideWindowName}}</span>
          <span class='el-icon-close' @click.prevent.stop='closeContainer()' style="float: right"></span>
          <el-popover
          placement="left"
          trigger="click">
          <el-form :inline="true" v-if = "isEventShow === 'true'">
                <el-form-item class="form-wrapper-item form-item-query normal-width" label="起止时间" label-width="100px" prop="startTime">
                  <el-date-picker v-model="startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
                  <el-date-picker v-model="endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
                </el-form-item>
                <el-form-item class="form-wrapper-item form-item-query normal-width" label="" label-width="0" size="small">
                  <el-button type="primary" v-loading.body="listLoading"  @click="fetchEventData(1,1,'0')">查询</el-button>
                </el-form-item>
                </el-form>
               
                <el-button slot="reference" style="float: right" type="text">操作按钮</el-button>
               
          </el-popover>
            
              <el-table
              size="mini"
            ref="singleTables"
            :data="eventList"
            style="width: 100%"
            :border="true"
            :stripe="true"
            height="750"
            resizable
            v-if = "isEventShow === 'true'">
            <!-- <el-table-column type="index" width="30px" align="center"></el-table-column> -->
            <el-table-column type="expand" >
            <template slot-scope="scope">
            <el-form label-position="left">
            <el-form-item label="模块实例ID" >
            <span >{{scope.row.objectId}}</span>
            </el-form-item>
            <el-form-item label="监控点iD" >
            <span >{{scope.row.monitorId}}</span>
            </el-form-item>
            <el-form-item label="监控值" >
            <span >{{scope.row.monitorVal}}</span>
            </el-form-item>
            <el-form-item label="参考值" >
            <span >{{scope.row.referVal}}</span>
            </el-form-item>
            <el-form-item label="remark信息" >
            <span >{{scope.row.remark|json}}</span>
            </el-form-item>
            </el-form>
            </template>
            </el-table-column>
            <el-table-column property="message" label="告警信息"  header-align="center"  align="left">
            <template slot-scope="scope">
            <p >{{scope.row.message}}</p>
            </template>
            </el-table-column>
            <el-table-column property="status" label="事件类型"  header-align="center"  align="center" width= 150>
              <template slot-scope="scope">
                <el-tag :type = "scope.row.status === '正常' ? 'success': (scope.row.status === '未采集数据' ? 'warning':(scope.row.status === '未启用监控' ? 'info':'danger'))"
                        style="margin-right: 10px">{{scope.row.status}}</el-tag>
              </template>
            </el-table-column>
            <el-table-column property="updated" label="事件时间"  header-align="center"  align="center" width= 170>
            <template slot-scope="scope">
            <p >{{scope.row.updated}}</p>
            </template>
            </el-table-column>

            </el-table>
            </el-card>
    </transition>
    </el-container> 
  </div>
</template>

<script>
import { getAlarmStatus, getAlarmEvents } from '@/api/monitor'
import { formatDate } from '@/store/date'
export default {
  name: 'alarmStatus',
  data() {
    return {
      list: null,
      eventList: null,
      listLoading: true,
      countertime: 20,
      startTime: '',
      endTime: '',
      monitorId: '',
      instanceId: '',
      eventMonitorId: '',
      eventInstanceId: '',
      sideWindowName: '',
      isEventShow: 'false',
      queryStatus: '1',
      timerStatus: '开始轮询',
      timeTable: [{ value: '十秒', time: 10 }, { value: '二十秒', time: 20 }, { value: '三十秒', time: 30 }, { value: '一分钟', time: 60 }],
      ref: null,
      doFilter: true,
      showList: []
    }
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  watch: {
    doFilter(val) {
      // console.log(val)
      if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
        // new Array().includes
        this.showList = []
        for (const i of this.list) {
          if (this.$store.state.user.preferModules.includes(i.objectName)) {
            this.showList.push(i)
          }
          // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
        }
      } else {
        this.showList = JSON.parse(JSON.stringify(this.list))
      }
    },
    list(val) {
      if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
        // new Array().includes
        this.showList = []
        for (const i of this.list) {
          if (this.$store.state.user.preferModules.includes(i.objectName)) {
            this.showList.push(i)
          }
          // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
        }
      } else {
        this.showList = JSON.parse(JSON.stringify(this.list))
      }
    }
  },
  created() {
    if (this.$route.params.monitorId !== undefined) {
      this.monitorId = this.$route.params.monitorId
    }
    if (this.$route.params.instanceId) {
      this.instanceId = this.$route.params.instanceId
    }
    if (this.$route.params.queryStatus !== undefined) {
      this.queryStatus = this.$route.params.queryStatus
    }
    if (this.$route.query.doFilter !== undefined) {
      this.doFilter = this.$route.query.doFilter
      console.log('query!')
    }
    this.initStartTime()
    this.initEndTime()
    this.fetchData()
    this.stopQuery()
  },
  methods: {
    fetchData() {
      getAlarmStatus(this.queryStatus, this.monitorId, this.instanceId).then(response => {
        console.log(response)
        this.list = response.data.alarmList
        console.log(this.list)
        this.listLoading = false
      })
    },
    fetchEventData(MONITORID, INSTANCEID, FLAG, SIDEWINDOW) {
      if (FLAG === '1') {
        this.initStartTime()
        this.initEndTime()
        this.eventMonitorId = MONITORID
        this.eventInstanceId = INSTANCEID
        this.isEventShow = 'true'
        this.sideWindowName = SIDEWINDOW + '的事件'
      }
      getAlarmEvents(this.eventMonitorId, this.eventInstanceId, this.startTime, this.endTime).then(response => {
        console.log(response)
        this.eventList = response.data.alarmEventList
        console.log(this.eventList)
        this.listLoading = false
      })
    },
    stopQuery: function() {
      if (this.timerStatus === '停止轮询') {
        this.timerStatus = '开始轮询'
        clearInterval(this.ref)
      } else {
        console.log(this.countertime)
        clearInterval(this.ref)
        const that = this
        this.ref = setInterval(function() {
          that.fetchData()
        }, this.countertime * 1000)
        this.$store.dispatch('addTimer', { name: this.$route.path, timer: this.ref })
        this.timerStatus = '停止轮询'
      }
    },
    formatStartTime: function(val) {
      if (val !== undefined) this.startTime = formatDate(val, 'yyyy-MM-dd hh:mm:ss')
    },
    formatEndTime: function(val) {
      if (val !== undefined) this.endTime = formatDate(val, 'yyyy-MM-dd hh:mm:ss')
    },
    initStartTime: function() {
      var nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.startTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
    },
    initEndTime: function() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.endTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
    },
    closeContainer: function() {
      this.isEventShow = 'false'
    }
  },
  destroyed: function() {
    clearInterval(this.ref)
  },
  activated() {
    this.initStartTime()
    this.initEndTime()
    this.fetchData()
    this.closeContainer()
  }
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.outTable {
  width: 100%;
}
.innerTable{
  width: 100%;
}
.selectButton{
  width: 180px;
}
.leftContainer{
  width: 100%
}
.rightContainer{
  width: 100%;
}
.SideWindowtitle{


align-items: center;
justify-content: center;

}
</style>
