<template>
    <div class="app-container">
      <el-card>
        <el-form :inline="true" @submit.native.prevent>
                <el-form-item class="form-wrapper-item" label="模板名称" label-width="90px">
                    <el-input @keyup.enter.native="getTemplateList"  :disabled="disableflag" v-model="inputTemplateName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button :disabled="disableflag&&isQuery" type="primary" @click="getTemplateList" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox">
            <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="isTemplateDialog=true">
                <i class="el-icon-edit">添加</i>
            </el-button>
        </div>
        <el-table
        :data="templateList"
        ref="singleTable" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :stripe="true" 
        resizable
        >
         <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
        <el-table-column property="templateName" label="模板名称"  header-align="center"  align="left"  width="300px">
          </el-table-column>
          <el-table-column property="roleList" label="角色列表"  header-align="center"  align="left"  width="300px">
            </el-table-column>
            <el-table-column property="updated" label="更新时间"  header-align="center"  align="left"  width="300px">
              </el-table-column>
              <el-table-column property="created" label="创建时间"  header-align="center"  align="left"  width="300px">
        </el-table-column>
        <el-table-column fixd="right" label="操作"  header-align="center"  align="center" width="300px">
                <template slot-scope="scope">
                    <el-button type="warning" size="mini" class="tool-item" @click="handleTemplateUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleTemplateDelete(scope.row.id)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
        </el-table>
      </el-card>
      <el-dialog
        :title="temDialogTitle"
        :visible.sync="isTemplateDialog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="templateForm"
            ref="templateForm"
        >
            <el-form-item
                prop="templateName"
                label="模板名称"
                :rules="{required: true, message: '请输入模板名称'}"
                style="width:200px"
            >
                <el-input v-model="templateForm.templateName"></el-input>
                </el-form-item>
                <el-form-item
                prop="roleList"
                label="包含权限"
                style="width:200px"
            >
                    <el-tree
        :data="accessedRouter"
        :show-checkbox="true"
        :default-expand-all="true"
        node-key="name"
        ref="tree"
        :highlight-current="true"
        :props="defaultProps"></el-tree>
                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleTemplate('templateForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { userTemplateQuery,
  userTemplateInsert,
  userTemplateUpdate,
  userTemplateDelete } from '@/api/login'
import {
  Message
} from 'element-ui'
export default {
  name: 'roleTemplateManagement',
  data() {
    return ({
      templateList: null,
      inputTemplateName: '',
      accessedRouter: null,
      choseList: null,
      defaultProps: {
        children: 'children',
        label: 'titleName'
      },
      templateForm: {
        templateName: '',
        roleList: '',
        id: '',
        leafNodeList: ''
      },
      isTemplateDialog: false,
      isTemplateUpdate: false,
      temDialogTitle: '模板添加',
      isQuery: false,
      listLoading: false,
      disableflag: false

    })
  },
  computed: {
    ...mapGetters([
      'permission_routers'
    ])
  },
  created() {
    this.getList()
    this.getTemplateList()
  },
  activated() {
    this.getList()
    this.getTemplateList()
  },
  watch: {
    isTemplateUpdate() {
      if (this.isTemplateUpdate) this.temDialogTitle = '模块修改'
      else this.temDialogTitle = '模块添加'
    }
  },
  methods: {
    handleTemplateDelete(templateId) {
      return new Promise((resolve, reject) => {
        userTemplateDelete(templateId).then(response => {
          console.log(response)
          this.listLoading = false
          if (response.code === 0) {
            Message.success('删除模板成功')
            this.inputTemplateName = ''
            this.getTemplateList()
            this.$refs['templateForm'].resetFields()
            resolve(response)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        })
      })
    },
    handleTemplateUpdate(rows) {
      this.templateForm = Object.assign({}, rows)
      this.isTemplateDialog = true
      this.isTemplateUpdate = true
      if (rows.leafNodeList.indexOf(',') !== -1) setTimeout(function() { this.$refs.tree.setCheckedKeys(rows.leafNodeList.split(',')) }.bind(this), 100)
      if (rows.leafNodeList.indexOf(',') === -1) setTimeout(function() { this.$refs.tree.setCheckedKeys([rows.leafNodeList]) }.bind(this), 100)
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isTemplateDialog = false
          this.isTemplateUpdate = false
          this.$refs['templateForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleTemplate(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.listLoading = true
              this.templateForm.roleList = (this.$refs.tree.getCheckedKeys()).concat(this.$refs.tree.getHalfCheckedKeys())
              this.templateForm.leafNodeList = (this.$refs.tree.getCheckedKeys())
              console.log('form:', this.templateForm.templateName, this.templateForm.roleList.join(','), this.templateForm.leafNodeList.join(','))
              if (this.isTemplateUpdate) {
                userTemplateUpdate(this.templateForm.templateName.trim(), this.templateForm.roleList.join(','), this.templateForm.id, this.templateForm.leafNodeList.join(',')).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  this.isTemplateUpdate = false
                  if (responseS.code === 0) {
                    Message.success('修改模板成功！')
                    this.inputTemplateName = this.templateForm.templateName
                    this.getTemplateList()
                    this.$refs['templateForm'].resetFields()
                    this.isTemplateDialog = false
                  } else {
                    Message.error(responseS.code + ':' + responseS.info)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              } else {
                userTemplateInsert(this.templateForm.templateName.trim(), this.templateForm.roleList.join(','), this.templateForm.leafNodeList.join(',')).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  this.isTemplateUpdate = false
                  if (responseS.code === 0) {
                    Message.success('添加模板成功！')
                    this.inputTemplateName = this.templateForm.templateName
                    this.getTemplateList()
                    this.$refs['templateForm'].resetFields()
                    this.isTemplateDialog = false
                  } else {
                    Message.error(responseS.code + ':' + responseS.info)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    getTemplateList() {
      userTemplateQuery(this.inputTemplateName).then(response => {
        console.log('response:', response)
        if (response.code === 0) {
          this.templateList = response.data.templateList.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
          console.log('templateList:', this.templateList)
        } else {
          console.log('templateList is empty')
        }
      })
    },
    filterAsyncRouter(asyncRouterMap) {
      const accessedRouters = asyncRouterMap.filter(route => {
        if (route.meta && route.meta.roles) {
        //   console.log('roles', this.$t('route.' + this.$t(String(route.name))), route.name)
          route['titleName'] = this.$t('route.' + String(this.$t(String(route.meta.roles[0]))))
          if (route.children && route.children.length) {
            route.children = this.filterAsyncRouter(route.children)
          }
          return true
        }
        return false
      })
      return accessedRouters
    },
    getList() {
      this.accessedRouter = this.filterAsyncRouter(JSON.parse(JSON.stringify(this.permission_routers)))
    },
    submitChoice() {
      this.templateForm.roleList = (this.$refs.tree.getCheckedKeys()).concat(this.$refs.tree.getHalfCheckedKeys())
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>