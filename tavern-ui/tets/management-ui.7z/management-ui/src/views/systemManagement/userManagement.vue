<template>
    <div class="app-container">
      <el-card>
        <el-form :inline="true" @submit.native.prevent>
                <el-form-item class="form-wrapper-item" label="用户名称" label-width="90px">
                    <el-input  @keyup.enter.native="getUserList" :disabled="disableflag" v-model="inputUserName" size="mini"></el-input>
                </el-form-item>
                <el-form-item class="form-wrapper-item" label="" label-width="0">
                    <el-button :disabled="disableflag&&isQuery" type="primary" @click="getUserList" size="mini">查询</el-button>
                </el-form-item>
        </el-form>
        <div class="table-toolbox">
            <el-button :disabled="disableflag" type="default" size="mini" class="tool-item" @click="isUserDialog=true">
                <i class="el-icon-edit">添加</i>
            </el-button>
        </div>
        <el-table
        :data="userList"
        ref="singleTable" 
        row-key 
        style="width: 100%" 
        :border="true" 
        :row-style="changeClass"
        resizable
        >
         <el-table-column type="index" width="30px" header-align="center" align="left"></el-table-column>
        <el-table-column property="username" label="用户名称"  header-align="center"  align="left"  width="300px">
          </el-table-column>
          <!-- <el-table-column property="password" label="密码"  header-align="center"  align="left"  width="300px">
            </el-table-column> -->
            <el-table-column property="enabled" label="是否启用"  header-align="center"  align="left"  width="300px">
                <template slot-scope="scope">
                      <span>{{scope.row.enabled}}</span>
                  </template>
              </el-table-column>
              <el-table-column property="templateId" label="权限模板"  header-align="center"  align="left"  width="300px">
                  <template slot-scope="scope">
                      <span  v-for="item in templateList" :key="item.id" v-if="scope.row.templateId === item.id">{{item.templateName}}</span>
                  </template>      
        </el-table-column>
        <el-table-column fixd="right" label="操作"  header-align="center"  align="center" width="300px">
                <template slot-scope="scope">
                    <el-button type="warning" size="mini" class="tool-item" @click="handleUserUpdate(scope.row)">
                        <i class="el-icon-edit">修改</i>
                    </el-button>
                    <el-popover
                                            placement="top"
                                            width="100"
                                            v-model="scope.row.deleteFlag"
                                        >
                                            <p>确定删除吗？</p>
                                            <div style="text-align: center;marrgin: 0">
                                                <el-button
                                                    type="primary"
                                                    @click="scope.row.deleteFlag=false"
                                                    v-loading.body="listLoading"
                                                    size="mini"
                                                >取消</el-button>
                                                    <el-button
                                                        type="text"
                                                        @click="handleUserDelete(scope.row)"
                                                        v-loading.body="listLoading"
                                                        size="mini"
                                                    >确定</el-button>
                                            </div>
                                            <el-button
                                            type="danger"
                                                slot="reference"
                                                class="tool-item"
                                                size="mini"
                                            ><i class="el-icon-edit">删除</i></el-button>
                                                </el-popover>
                </template>
	        </el-table-column>
        </el-table>
      </el-card>
      <el-dialog
        :title="userDialogTitle"
        :visible.sync="isUserDialog"
        :before-close="handleColse"
    >
        <el-form
            :inline="true"
            :model="userForm"
            ref="userForm"
        >
            <el-form-item
                prop="username"
                label="用户名称"
                :rules="{required: true, message: '请输入用户名称'}"
                style="width:200px"
            >
                <el-input v-model="userForm.username"></el-input>
                </el-form-item>
                <el-form-item
                prop="password"
                label="密码"
                :rules="{required: true, message: '请输入密码'}"
                style="width:200px"
            >
                <el-input v-model="userForm.password"></el-input>
                </el-form-item>
                <el-form-item
                prop="enabled"
                label="是否启用"
                :rules="{required: true, message: '是否启用'}"
                style="width:200px"
            >
                <el-switch v-model="userForm.enabled"></el-switch>
                </el-form-item>
                <el-form-item
                prop="templateId"
                label="用户模板"
                style="width:200px"
            >
                    <el-select v-model="userForm.templateId">
                                    <el-option
                                        v-for="item in templateList"
                                        :key="item.id"
                                        :label="item.templateName"
                                        :value="item.id"
                                    >
                                        </el-option>
                                </el-select>
                </el-form-item>
                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="handleTemplate('userForm')">确定</el-button>
      </span>
                                                                        </el-dialog>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import {
  userTemplateQuery,
  userInsert,
  userUpdate,
  userDelete,
  userQuery } from '@/api/login'
import {
  Message
} from 'element-ui'
export default {
  name: 'userManagement',
  data() {
    return ({
      userList: null,
      inputUserName: '',
      userForm: {
        username: '',
        password: '',
        enabled: true,
        templateId: ''
      },
      isUserDialog: false,
      isUserUpdate: false,
      userDialogTitle: '用户添加',
      isQuery: false,
      listLoading: false,
      disableflag: false,
      templateList: null

    })
  },
  computed: {
    ...mapGetters([
      'permission_routers'
    ])
  },
  created() {
    this.getUserList()
    this.getTemplateList()
  },
  activated() {
    this.getUserList()
    this.getTemplateList()
  },
  watch: {
    isUserUpdate() {
      if (this.isUserUpdate) this.userDialogTitle = '用户修改'
      else this.userDialogTitle = '用户添加'
    }
  },
  methods: {
    changeClass({ row, rowIndex }) {
    //   console.log('backgroud!!!!!!!!!!!', row.errorCode !== 0)
      if (!row.enabled) return 'background: darkgray;'
      else return 'background: floralwhite;'
    },
    getTemplateList() {
      userTemplateQuery('').then(response => {
        console.log('response:', response)
        if (response.code === 0) {
          this.templateList = response.data.templateList.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
          console.log('templateList:', this.templateList)
        } else {
          console.log('templateList is empty')
        }
      })
    },
    handleUserDelete(rows) {
      let userId = ''
      const row = Object.assign({}, rows)
      if (rows.roles && rows.roles.length > 0) {
        console.log('roles:')
        userId = row.roles.pop()
      } else {
        Message.error('缺少用户id')
        return
      }
      return new Promise((resolve, reject) => {
        userDelete(userId).then(response => {
          console.log(response)
          this.listLoading = false
          if (response.code === 0) {
            Message.success('删除用户成功')
            this.inputUserName = ''
            this.getUserList()
            this.$refs['userForm'].resetFields()
            resolve(response)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        })
      })
    },
    handleUserUpdate(rows) {
      this.userForm = Object.assign({}, rows)
      this.isUserDialog = true
      this.isUserUpdate = true
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.isUserDialog = false
          this.isUserUpdate = false
          this.$refs['userForm'].resetFields()
          done()
        })
        .catch(_ => {})
    },
    handleTemplate(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$confirm('确认提交?')
            .then(_ => {
              this.listLoading = true
              console.log('form:', this.userForm)
              if (this.isUserUpdate) {
                userUpdate(this.userForm).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  this.isUserUpdate = false
                  if (responseS.code === 0) {
                    Message.success('修改用户成功！')
                    this.inputUserName = this.userForm.username
                    this.getUserList()
                    this.$refs['userForm'].resetFields()
                    this.isUserDialog = false
                  } else {
                    Message.error(responseS.code + ':' + responseS.info)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              } else {
                userInsert(this.userForm).then(function(responseS) {
                  this.isQuery = false
                  this.listLoading = false
                  this.isUserUpdate = false
                  if (responseS.code === 0) {
                    Message.success('添加用户成功！')
                    this.inputUserName = this.userForm.username
                    this.getUserList()
                    this.$refs['userForm'].resetFields()
                    this.isUserDialog = false
                  } else {
                    Message.error(responseS.code + ':' + responseS.info)
                    // this.$message.error(responseS.errorCode || responseS.messageInfo)
                  }
                }.bind(this))
              }
            })
            .catch(_ => {
            })
        } else {
          console.log('error submit!')
        }
      })
    },
    getUserList() {
      userQuery(this.inputUserName).then(response => {
        console.log('response:', response)
        if (response.code === 0) {
          this.userList = response.data.userList.map(v => {
            this.$set(v, 'deleteFlag', false)
            return v
          })
          console.log('userList:', this.userList)
        } else {
          console.log('userList is empty')
        }
      })
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>

