<template>
  <div class="app-wrapper" :class="{hideSidebar:!sidebar.opened}">
    <sidebar class="sidebar-container"></sidebar>
    <div class="main-container" >
      <header :class="sidebar.opened?'header':'header2'" >
      
      <tags-view></tags-view>
      <navbar></navbar>
      </header>
      <app-main style="margin-top:65px;"></app-main>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain, TagsView } from '@/views/layout/components'
import sticky from '@/components/Sticky'
export default {
  name: 'layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    TagsView,
    sticky
  },
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
*{
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
@import "src/styles/mixin.scss";
.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
}
.header{
  position: fixed;
  top:0;
  width: 90%;
  z-index:1;
}
.header2{
  position: fixed;
  top:0;
  width: 97%;
  z-index:1;
}
</style>
