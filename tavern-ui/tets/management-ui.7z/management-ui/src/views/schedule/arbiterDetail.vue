<template>
    <div class="app-container">
        <el-card>
            <el-form :inline="true" v-loading.body="listLoading" v-if="jobStatuesData.jobInfo !=undefined">
                <el-form-item label="任务名称">{{jobName}}</el-form-item>
                <el-form-item label="开始时间">{{jobStatuesData.jobInfo.startTime}}</el-form-item>
                <el-form-item label="结束时间">{{jobStatuesData.jobInfo.endTime}}</el-form-item>
                <el-form-item label="任务状态">
                    <el-tag :type="ExeStatusMap[jobStatuesData.jobInfo.status]=='成功'?'success':ExeStatusMap[jobStatuesData.jobInfo.status]=='失败'?'danger':ExeStatusMap[jobStatuesData.jobInfo.status]=='未知'||jobStatuesData.jobInfo.status==null?'info':'warning'">
                                    {{jobStatuesData.jobInfo.status==null?'未知':ExeStatusMap[jobStatuesData.jobInfo.status]}}
                                </el-tag>
                </el-form-item>
                <el-form-item label="子任务状态说明">
                    <span class="word"><span class="disable">■</span>禁用</span><span class="word"><span class="undone">■</span>未执行</span><span class="word"><span class="processing">■</span>执行中</span><span class="word"><span class="unknown">■</span>未知</span><span  class="word"><span class="failed">■</span>失败</span><span  class="word"><span class="success">■</span>成功</span>
                </el-form-item>
            </el-form>
            <el-card>
                       <div  class="treeContainer" v-for="item in jobStructData" :key="item[0]">
                    <div class="card-title">
                        <div style="color:white;" class="innerBoxs">step{{item[0]}}</div>
                    </div>      
                    <div class="card-panel" v-for="items in item[1]" :key="items.taskName">
                        <div v-if="items.part!=1" class="innerBox" v-for="subtask in items.subTask" :key="subtask.seq">
                            <el-popover
                            placement="bottom-start"
                            title="任务详情"
                            trigger="hover">
                            <jsonViewer
                             style="height:auto;width:100%;float:left;"
                            :json="subtask"
                            ></jsonViewer>
                            <div slot="reference" :style="statusFunctionForSubtask(items,subtask)" class="finnal">{{items.taskName}}:分片{{subtask.description.seq}}</div>
                            </el-popover>
                            </div>
                        <div v-if="items.part==1" class="innerBox">
                            <el-popover
                            placement="bottom-start"
                            title="任务详情"
                            trigger="hover">
                            <jsonViewer
                             style="height:auto;width:100%;float:left;"
                            :json="items.subTask"
                            ></jsonViewer>
                            <div slot="reference" :style="statusFunctionForSingleTask(items)" class="finnal">{{items.taskName}}</div>
                            </el-popover>
                            </div>
                        
                    </div>
                </div> 
            </el-card>
        </el-card>
    </div>
</template>
<script>
import {
  Message
} from 'element-ui'
import { getArbiterJobStructure,
  getArbiterJobDetail } from '@/api/schedule'
import jsonViewer from '@/components/JsonView'
export default {
  name: 'arbiterDetail',
  data() {
    return {
      listLoading: false,
      jobName: '',
      jobId: '',
      jobStructData: new Map(),
      jobStatuesData: {},
      ExeStatusMap: {
        1: '成功',
        2: '失败',
        3: '未知',
        4: '执行中',
        5: '未执行'
      }
    }
  },
  components: {
    jsonViewer
  },
  created() {
    if (this.$route.params.taskId !== undefined) {
      this.jobId = this.$route.params.taskId
    }
    if (this.$route.params.taskName !== undefined) {
      this.jobName = this.$route.params.taskName
    }
    this.getStructure()
    this.getArbiterJobDetail()
  },
  methods: {
    statusFunctionForSubtask(items, subtask) {
      if (items.status === 2) return 'background-color: rgba(71, 68, 75, 0.651);'
      else {
        if (subtask.status === 1) return 'background-color: rgba(93, 255, 29, 0.651);'
        if (subtask.status === 2) return 'background-color: rgba(255, 0, 0, 0.651);'
        if (subtask.status === 3 || items.subTask[0].status === null) return 'background-color: rgba(195, 8, 212, 0.651);'
        if (subtask.status === 4) return 'background-color: rgba(224, 221, 4, 0.651);'
        if (subtask.status === 5) return 'background-color: rgba(241, 122, 11, 0.651);'
      }
    },
    statusFunctionForSingleTask(items) {
      if (items.status === 2) return 'background-color: rgba(71, 68, 75, 0.651);'
      else if (items.status === 0) return 'background-color: rgba(241, 122, 11, 0.651);'
      else {
        if (items.subTask[0].status === 1) return 'background-color: rgba(93, 255, 29, 0.651);'
        if (items.subTask[0].status === 2) return 'background-color: rgba(255, 0, 0, 0.651);'
        if (items.subTask[0].status === 3 || items.subTask[0].status === null) return 'background-color: rgba(195, 8, 212, 0.651);'
        if (items.subTask[0].status === 4) return 'background-color: rgba(224, 221, 4, 0.651);'
      }
    },
    getStructure() {
      this.listLoading = true
      getArbiterJobStructure(this.jobName).then(response => {
        this.listLoading = false
        if (response.code === 0) {
          console.log('getArbiterJobStructure', response)
          const compare = function(obj1, obj2) {
            //   console.log('conpare', obj1, obj2)
          // const val1 = obj1.metric
          // const val2 = obj2.metric
          // if (val1 > val2) return 1
          // else if (val1 < val2) return -1
          // else return 0
            if (obj1.step > obj2.step) return 1
            if (obj1.step === obj2.step) return obj1.jobName.localeCompare(obj2.jobName)
            if (obj1.step < obj2.step) return -1
          }
          this.jobStructData = response.data.items.sort(compare)
          const stepMark = new Map()
          for (const i of this.jobStructData) {
            i.subTask = {}
            if (parseInt(i.part) > 1) {
              for (let j = 0; j < parseInt(i.part); j++) {
                // console.log('subTask', j)
                i.subTask[j] = { description: { seq: j },
                  status: 5 }
              }
            }
            if (i.status !== 2)i.status = 0
            if (stepMark.has(i.step)) {
              stepMark.get(i.step).push(i)
            } else {
              stepMark.set(i.step, [i])
            }
          }
          this.jobStructData = [...stepMark]
          console.log('jobStructData', this.jobStructData, stepMark)
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch((error) => {
        this.listLoading = false
        Message.error(error)
      })
    },
    getArbiterJobDetail() {
      this.listLoading = true
      getArbiterJobDetail(this.jobId).then(response => {
        this.listLoading = false
        if (response.code === 0) {
          console.log('getArbiterJobDetail', response)
          this.jobStatuesData = response.data
          this.jobStatuesData.taskInfo.map(v => {
            v.description = JSON.parse(v.description)
            for (const i of this.jobStructData) {
              for (const j of i[1]) {
                if (j.taskName === v.name) {
                  j.status = 3
                  if (parseInt(j.part) > 1) {
                    j.subTask[v.description.seq] = v
                  } else {
                    j.subTask = [v]
                  }
                  break
                }
              }
            }
          })
          console.log('jobStatuesData', this.jobStatuesData, this.jobStructData)
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch((error) => {
        this.listLoading = false
        Message.error(error)
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
  
}
.treeContainer{
    display: flex;
    overflow: auto;
    margin: 2px auto;
    padding: 10px;
     border: 2px dashed black;
}
.card-panel{
    // width: 100%;
    flex-wrap: nowrap;
    flex-grow: 2;
    display: flex;
    // overflow: auto;
    line-height: 100px;
    text-align: center;
    margin: 3px  3px 3px 3px;
    border: 3px solid rgb(68, 33, 0);
    height: 100%;
        .innerBox{
            width: 100%;
            height: 100%;
            border: 1px dashed black;
        &:hover{
        .finnal{
        height: 100%;
        line-height: 100px;
        text-align: center;
        border: 2px solid black;
        // background: #f80606;
        // border-color: black;
        }
            }
}
            

        
    
}
.card-title{
     width: 60px;
    line-height: 100px;
    text-align: center;
    border: 1px solid black;
    min-height: 100px;
    background-color: rgba(121, 120, 122, 0.651);
    &:hover{
        .innerBoxs{
        height: 100%;
        // width: 100px;
        background-color: rgba(122, 122, 120, 0.651);
        line-height: 100px;
        text-align: center;
        border: 2px solid black;
        // background: #f80606;
        // border-color: black;
        }
        
    }
    
}
.success{
  
color:rgba(93, 255, 29, 0.651);
font-size:40px;

}
.failed{
  
  color:rgba(255, 0, 0, 0.651);
font-size:40px;
}
.unknown{

  color:rgba(195, 8, 212, 0.651);
font-size:40px;
}
.processing{

  color:rgba(224, 221, 4, 0.651);
font-size:40px;
}
.undone{

  color:rgba(241, 122, 11, 0.651);
font-size:40px;
}
.disable{

  color:rgba(71, 68, 75, 0.651);
font-size:40px;
}
.word{
  float: right;
}
</style>