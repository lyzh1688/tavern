<template>
    <div class="app-container">
      <el-card>
  <div class="wrapper-box" ref="wrapperBox">
    <el-form ref="ruleForm" :inline="true"  @submit.native.prevent>
      <div class="form-wrapper">
        <el-form-item class="form-wrapper-item form-item-query normal-width" label="任务名" label-width="100px" prop="includeCode">
          <el-input @keyup.enter.native="handleQuery()" v-model="formData.jobName" size="mini" placeholder="请输入任务名"></el-input>
        </el-form-item>
        <el-form-item class="form-wrapper-item form-item-query normal-width" label="" label-width="0">
          <el-button type="primary" @click="handleQuery()" :disabled="isQuery" size="mini">查询</el-button>
        </el-form-item>
      </div>
    </el-form>
  </div>
  <div>
    <span style="line-height: 20px; font-size: 15px;"><font color="red">* 点击"<i class="el-icon el-icon-arrow-right"></i>"可查看更多</font></span>
  </div>
  <section class="table-container">
    <div class="table-toolbox">
      <el-button v-if="hasPermission()" :disabled="disableflag" type="default" size="mini" class="tool-item" @click="handleAdd">
        <i class="el-icon-edit">添加</i>
      </el-button>
    </div>
    <el-table
            ref="singleTable"
            :data="list"
            highlight-current-row
            style="width: 100%"
            :border="true"
            :stripe="true"
            resizable>
      <el-table-column type="expand">
        <template slot-scope="scope">
          <el-form class="table-inner" :inline="true">
            <div class="form-wrapper">
              <el-form-item label="任务Id" label-width="110px" class="form-wrapper-item form-item-three">
                <span>{{scope.row.taskId}}</span>
              </el-form-item>
              <el-form-item label="任务请求地址" label-width="110px" class="form-wrapper-item form-item-three">
                <span v-show="!scope.row.isEdit">{{scope.row.target}}</span>
                <el-input v-show="scope.row.isEdit" v-model="scope.row.target">{{scope.row.target}}</el-input>
              </el-form-item>
              <el-form-item label="时间表达式" label-width="110px" class="form-wrapper-item form-item-three">
                <span v-show="!scope.row.isEdit">{{scope.row.cronExpression}}</span>
                <el-input v-show="scope.row.isEdit" v-model="scope.row.cronExpression">{{scope.row.cronExpression}}</el-input>
              </el-form-item>
            </div>
            <div class="form-wrapper">
              <el-form-item label="任务请求参数" label-width="110px" class="form-wrapper-item form-item-one ">
                <span v-show="!scope.row.isEdit">{{scope.row.invokeBody}}</span>
                <el-input v-show="scope.row.isEdit" v-model="scope.row.invokeBody">{{scope.row.invokeBody}}</el-input>
              </el-form-item>
            </div>
            <div class="form-wrapper">
              <el-form-item label="任务开始时间" label-width="110px" class="form-wrapper-item form-item-three">
                <span>{{scope.row.startTime}}</span>
              </el-form-item>
              <el-form-item label="任务结束时间" label-width="110px" class="form-wrapper-item form-item-three">
                <span v-show="!scope.row.isEdit">{{scope.row.endTime}}</span>
                <el-date-picker v-show="scope.row.isEdit" v-model="scope.row.endAt" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
              </el-form-item>
            </div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column type="index" width="40%" align="center"></el-table-column>
      <el-table-column label="任务组"   align="center" class="form-wrapper-item form-item-10-percent" width="80%" >
        <template slot-scope="scope">
          <p v-show="!scope.row.isEdit">{{scope.row.jobGroup}}</p>
          <el-input v-show="scope.row.isEdit" v-model="scope.row.jobGroup">{{scope.row.jobGroup}}</el-input>
        </template>
      </el-table-column>
      <el-table-column property="jobName" label="任务名"  align="center"  class="form-wrapper-item form-item-10-percent" width="300%"></el-table-column>
      <el-table-column label="任务说明"  align="center" class="form-wrapper-item form-item-15-percent" width="410%">
        <template slot-scope="scope">
          <p v-show="!scope.row.isEdit">{{scope.row.remark}}</p>
          <el-input v-show="scope.row.isEdit" v-model="scope.row.remark">{{scope.row.remark}}</el-input>
        </template>
      </el-table-column>
      <el-table-column property="prevFireTime" label="上次执行时间"  align="center"  class="form-wrapper-item form-item-10-percent" width="160%"></el-table-column>
      <el-table-column property="nextFireTime" label="下次执行时间"  align="center"  class="form-wrapper-item form-item-10-percent" width="160%"></el-table-column>
      <el-table-column property="triggerState" label="任务状态"  align="center"  class="form-wrapper-item form-item-10-percent" width="100%"></el-table-column>
      <el-table-column v-if="hasPermission()" fixd="right" label="操作" align="center" class="form-wrapper-item form-item-20-percent">
        <template slot-scope="scope">
          <el-button   v-show="!scope.row.isEdit" type="default" size="mini" class="tool-item" @click="handleTrigger(scope.$index,list)">
            <i class="el-icon-edit">执行</i>
          </el-button>
          <el-button  v-show="!scope.row.isEdit" type="default" size="mini" class="tool-item" @click="handlePause(scope.$index,list)">
            <i class="el-icon-edit">暂停</i>
          </el-button>
          <el-button  v-show="!scope.row.isEdit" type="default" size="mini" class="tool-item" @click="handleResume(scope.$index,list)">
            <i class="el-icon-edit">恢复</i>
          </el-button>
          <el-button  v-show="!scope.row.isEdit" type="warning" size="mini" class="tool-item" @click="handleModify(scope.$index,list)">
            <i class="el-icon-edit">修改</i>
          </el-button>
          <el-button  v-show="!scope.row.isEdit" type="danger" size="mini" class="tool-item" @click="handleDel(scope.$index,list)">
            <i class="el-icon-edit">删除</i>
          </el-button>
          <el-button v-show="scope.row.isEdit" type="danger" size="mini" class="tool-item" @click="handleModifySave(scope.$index,list)"   >
            <i class="el-icon-edit">保存</i>
          </el-button>
          <el-button v-show="scope.row.isEdit" type="primary" size="mini" class="tool-item" @click="handleModifyCancel(scope.$index,list)"   >
            <i class="el-icon-edit">取消</i>
          </el-button>

        </template>
      </el-table-column>
    </el-table>
  </section>
  </el-card>
  <el-dialog title="新增定时任务" :visible.sync="isAddDialog">
      <el-form class="dialog-form" ref="ruleForm" :rules="rule"  :model="formData">
        <el-form-item  class="form-item" label="任务名称" label-width="100px" prop="jobName">
          <el-input v-model="formData.jobName" size="mini" ></el-input>
        </el-form-item>
        <el-form-item  class="form-item" label="任务组名称" label-width="100px" prop="jobGroup">
          <el-input v-model="formData.jobGroup" size="mini"></el-input>
        </el-form-item>
        <el-form-item  class="form-item" label="任务请求参数" label-width="100px" prop="invokeBody">
          <el-input v-model="formData.invokeBody" size="mini"></el-input>
        </el-form-item>
        <el-form-item  class="form-item" label="时间表达式" label-width="100px" prop="cron">
          <el-input v-model="formData.cron" size="mini"></el-input>
        </el-form-item>
        <el-form-item  class="form-item" label="任务说明" label-width="100px" prop="remark">
          <el-input v-model="formData.remark" size="mini"></el-input>
        </el-form-item>
        <el-form-item  class="form-item" label="任务请求地址" label-width="100px" prop="target">
          <el-input v-model="formData.target" size="mini"></el-input>
        </el-form-item>
        <el-form-item class="form-wrapper-item form-item-query normal-width" label="开始时间" label-width="100px" prop="startAt">
          <el-date-picker v-model="formData.startAt" type="datetime" size="mini" @change="formatstartAt"></el-date-picker>
        </el-form-item>
        <el-form-item class="form-wrapper-item form-item-query normal-width" label="结束时间" label-width="100px" prop="endAt">
          <el-date-picker v-model="formData.endAt" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
        </el-form-item>
      </el-form>

      <div class="dialog-button-wrapper pb10">
        <el-button type="primary" @click="handleDialogCommit('ruleForm')" :disabled="isQuery" size="small">确定</el-button>
      </div>
  </el-dialog>
    </div>
</template>





<script>
import { dateTimeFormat } from '@/store/date'
import { getSchedulerList,
  deleteTask,
  trigerTask,
  pauseTask,
  resumeTask,
  updateTask,
  createTask } from '@/api/schedule'
import { mapGetters } from 'vuex'
import {
  Message
} from 'element-ui'
export default {
  name: 'schedule',
  data: function() {
    var that = this
    // 校验规则
    var _rulestartAt = (rule, value, callback) => {
      if (that.formData.startAt === '') {
        callback(new Error('请选择开始时间!'))
      } else {
        if (that.formData.endAt !== '' && that.formData.endAt != null) {
          if (Date.parse(that.formData.endAt) < Date.parse(that.formData.startAt)) {
            callback(new Error('开始时间必须小于结束时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    var _rulecron = (rule, value, callback) => {
      if (that.formData.cron === '') {
        callback(new Error('请输入时间格式!例如0 0 0 * * ?'))
      } else {
        callback()
      }
    }

    var _ruleJobName = function(rule, value, callback) {
      if (that.formData.jobName !== '' && that.formData.jobName != null) {
        if (that.formData.jobName.trim() === '') {
          callback(new Error('请填写任务名称!'))
        }
        const jobs = that.list
        jobs.forEach(job => {
          // console.log(that.jobName,job.jobName,that.jobName == job.jobName)
          if (that.formData.jobName.trim() === job.jobName.trim()) {
            callback(new Error('任务名称已存在!'))
          }
        })
        callback()
      } else {
        callback(new Error('请填写任务名称!'))
      }
    }
    var _ruleTarget = function(rule, value, callback) {
      if (that.formData.target.indexOf('http://') === -1) {
        callback(new Error('目标地址出错!请包含“http://”'))
      } else {
        if (that.formData.target.split('http://')[0] !== '') {
          callback(new Error('请以“http://”开头'))
        } else {
          callback()
        }
      }
    }
    return {
      isEdit: false,
      isQuery: false,
      isModify: false,
      isDialog: false,
      list: [],
      funcNo: '',
      user: '',
      includeCode: '',
      excludeCode: '',
      info: '',
      deviceId: '',
      ver: '',
      params: '',
      disableflag: false,
      addTitle: '',
      isAddDialog: false,
      formData: {
        jobName: '',
        jobGroup: '',
        invokeBody: '',
        cron: '',
        remark: '',
        target: '',
        startAt: '',
        endAt: '',
        taskId: ''
      },
      rule: {
        startAt: [{ validator: _rulestartAt, trigger: 'blur' }],
        cron: [{ validator: _rulecron, trigger: 'blur' }],
        jobName: [{ validator: _ruleJobName, trigger: 'blur' }],
        target: [{ validator: _ruleTarget, trigger: 'blur' }]
      }
    }
  },
  watch: {
    isDialog: function() {
      if (!this.isDialog) {
        this.isProAdd = false
        this.isProModify = false
      }
    }
  },
  created: function() {
    this.initstartAt()
    this.getList()
    // console.log('roles:', this.hasPermission())
  },
  computed: {
    iframeHeight: function() {
      var height = window.innerHeight * 0.75
      return height
    },
    dialogTitle: function() {
      if (this.isProAdd) return '新增定时任务'
    },
    ...mapGetters([
      'roles'
    ])
  },
  // mounted: function() {
  //   this.$el.className = 'show'
  // },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'scheduleButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    formatstartAt(val) {
      if (val !== undefined) {
        this.formData.startAt = dateTimeFormat(val)
      }
      console.log('bug', this.formData.startAt)
    },
    formatEndTime(val) {
      if (val !== undefined) {
        this.formData.endAt = dateTimeFormat(val)
      }
    },
    initstartAt() {
      var nowTime = new Date()
      this.formData.startAt = dateTimeFormat(nowTime)
    },
    // handleQuery: function() {
    //   var that = this
    //   that.getList()
    // },
    handleDel: function(index, row) {
      var that = this
      var job = row[index]
      this.$confirm('确认删除该任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        deleteTask({
          jobName: job.jobName,
          jobGroup: job.jobGroup,
          invokeBody: job.invokeBody,
          cron: job.cronExpression,
          target: job.target,
          remark: job.remark,
          startAt: job.startTime,
          endAt: job.endTime,
          taskId: job.taskId
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            that.$message({
              message: '删除成功！',
              type: 'success'
            })
            that.getList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handleTrigger: function(index, row) {
      var that = this
      var job = row[index]
      this.$confirm('确认立即执行该任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        trigerTask({
          jobName: job.jobName,
          jobGroup: job.jobGroup,
          invokeBody: job.invokeBody,
          cron: job.cronExpression,
          target: job.target,
          remark: job.remark,
          startAt: job.startTime,
          endAt: job.endTime,
          taskId: job.taskId
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            that.$message({
              message: '执行成功！',
              type: 'success'
            })
            that.getList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handlePause: function(index, row) {
      var that = this
      var job = row[index]
      this.$confirm('确认暂停该任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        pauseTask({
          jobName: job.jobName,
          jobGroup: job.jobGroup,
          invokeBody: job.invokeBody,
          cron: job.cronExpression,
          target: job.target,
          remark: job.remark,
          startAt: job.startTime,
          endAt: job.endTime,
          taskId: job.taskId
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            that.$message({
              message: '执行成功！',
              type: 'success'
            })
            that.getList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handleResume: function(index, row) {
      var that = this
      var job = row[index]
      this.$confirm('确认恢复任务?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(function() {
        console.log(row[index])
        resumeTask({
          jobName: job.jobName,
          jobGroup: job.jobGroup,
          invokeBody: job.invokeBody,
          cron: job.cronExpression,
          target: job.target,
          remark: job.remark,
          startAt: job.startTime,
          endAt: job.endTime,
          taskId: job.taskId
        }).then(function(response) {
          console.log(response)
          if (response.payload.code === 0) {
            that.isAddDialog = false
            that.$message({
              message: '执行成功！',
              type: 'success'
            })
            that.getList()
          } else {
            Message.error(response.payload.code + response.payload.info)
          }
        })
      }).catch(function() {

      })
    },
    handleDialogCommit(ruleForm) {
      var that = this
      this.$refs[ruleForm].validate((valid) => {
        if (valid) {
          console.log(that.list)
          createTask({
            jobName: that.formData.jobName.replace(/^\s*$/, ''),
            jobGroup: that.formData.jobGroup.replace(/^\s*$/, ''),
            invokeBody: that.formData.invokeBody.replace(/^\s*$/, ''),
            cron: that.formData.cron.replace(/^\s*$/, ''),
            target: that.formData.target.replace(/^\s*$/, ''),
            remark: that.formData.remark.replace(/^\s*$/, ''),
            startAt: that.formData.startAt,
            endAt: that.formData.endAt
          }).then(function(response) {
            console.log(response)
            if (response.payload.code === 0) {
              that.isAddDialog = false
              that.$message({
                message: '添加成功！',
                type: 'success'
              })
              that.getList()
            } else {
              Message.error(response.payload.code + response.payload.info)
            }
          })
        } else {
          return false
        }
      })
    },
    handleSelectRow: function(row) {
      var that = this
      this.selectedRowData = row
      this.list.forEach(function(el) {
        if (row === el) {
          that.$refs.singleTable.toggleRowSelection(row)
        } else {
          that.$refs.singleTable.toggleRowSelection(el, false)
        }
      })
    },
    getList: function() {
      var that = this
      that.isQuery = true
      getSchedulerList(that.formData.jobName)
        .then(function(response) {
          console.log('response:', response)
          that.isQuery = false
          if (response.code === 0) {
            const d = response.data[0].schedulerTaskBOs
            d.forEach(item => {
              item['isEdit'] = false
            })
            that.list = d
          } else {
            that.$message.error(response.data[0].errorInfo || '系统异常')
          }
        })
    },
    handleAdd: function() {
      this.isAddDialog = true
    },
    handleQuery: function() {
      var that = this
      that.getList()
    },
    handleSlideUpCtrl: function(e) {
      var target = e.target
      target.classList.toggle('slideUp')
      var wrapperBox = this.$refs['wrapperBox']
      wrapperBox.classList.toggle('slideUp')
    },
    Modify: function(row) {
      var that = this
      var nowTime = new Date()
      var _endTime = (row.endAt && row.endAt !== '') ? dateTimeFormat(row.endAt) : row.endAt
      var _startAt = dateTimeFormat(nowTime)
      console.log(row)
      updateTask({
        jobName: row.jobName,
        jobGroup: row.jobGroup,
        invokeBody: row.invokeBody,
        cron: row.cronExpression,
        target: row.target,
        remark: row.remark,
        startAt: _startAt,
        endAt: _endTime
      }).then(function(response) {
        console.log(response)
        if (response.payload.code === 0) {
          that.getList()
          that.$message({
            message: '修改成功！',
            type: 'success'
          })
        } else {
          Message.error(response.payload.code + response.payload.info)
        }
      })
    },
    handleModify: function(index, row) {
      row[index].isEdit = true
    },
    handleModifySave: function(index, row) {
      row[index].isEdit = false
      this.Modify(row[index])
    },
    handleModifyCancel: function(index, row) {
      row[index].isEdit = false
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>