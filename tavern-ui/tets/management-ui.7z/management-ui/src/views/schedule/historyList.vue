<template>
    <div class="app-container">
        <el-card>
            <span>{{taskName}}</span>
            <el-form :inline="true" @submit.native.prevent v-loading.body="listLoading">
                        <el-form-item  label="开始时间" label-width="120px" prop="startTime">
                            <el-date-picker v-model="formData.startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
                        </el-form-item>
                        <el-form-item  label="结束时间" label-width="100px" prop="endTime">
                            <el-date-picker v-model="formData.endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
                        </el-form-item>
                <el-form-item  label="执行状态"  prop="info">
                    <el-select v-model="lastExeStatus" size="mini">
                        <el-option
                            v-for="item in lastExeStatusTable"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="handleQuery">查询</el-button>
                </el-form-item>
            </el-form>
            <el-form :inline="true">
                <el-form-item label="总执行次数" v-if="historyAggData.times!=null">{{historyAggData.times}}</el-form-item>
                <el-form-item label="总执行次数" v-if="historyAggData.totalCnt!=null">{{historyAggData.totalCnt}}</el-form-item>
                <el-form-item label="成功次数">{{historyAggData.successCnt}}</el-form-item>
                <el-form-item label="失败次数">{{historyAggData.failedCnt}}</el-form-item>
                <el-form-item label="平均耗时" v-if="historyAggData.avgSuccessCost!=null">{{historyAggData.avgSuccessCost}}</el-form-item>
                <el-form-item label="平均耗时" v-if="historyAggData.timeCost!=null">{{historyAggData.timeCost.split(':')[0]}}时{{historyAggData.timeCost.split(':')[1]}}分{{historyAggData.timeCost.split(':')[2]}}秒</el-form-item> 
            </el-form>
            <el-table
             v-if="taskType=='scheduler'"
            :data="historyData"
            size="mini"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                :stripe="true">
                <el-table-column
                type="index"
                width="50px"
                align="center"
                ></el-table-column>
                 <el-table-column prop="seqId" label="流水Id">
<template slot-scope="scope">
    <span class="link-type" @click="openTraceLog(scope.row.seqId)">{{scope.row.seqId}}</span>
</template>
                 </el-table-column>
                 <el-table-column prop="description" label="执行参数">
                        </el-table-column>
                        <el-table-column prop="startTime" label="开始时间"></el-table-column>
                        <el-table-column prop="duration" width="60%" label="耗时"></el-table-column>
                        <el-table-column prop="status" label="执行状态"  width="90%" >
                            <template slot-scope="status">
                                <el-tag :type="ExeStatusMap[status.row.status]=='成功'?'success':ExeStatusMap[status.row.status]=='失败'?'danger':ExeStatusMap[status.row.status]=='未知'||status.row.status==null?'info':'warning'">
                                    {{status.row.status==null?'未知':ExeStatusMap[status.row.status]}}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="retCode" width="80%" label="返回码">
                        </el-table-column>
                        <el-table-column prop="retInfo" label="返回信息">
                        </el-table-column>
                        
                </el-table>
                <el-table
             v-if="taskType=='arbiter'"
            :data="historyData"
            size="mini"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                :stripe="true">
                <el-table-column
                type="index"
                width="50px"
                align="center"
                ></el-table-column>
                 <el-table-column prop="jobId" label="任务id">
<template slot-scope="scope">
    <span class="link-type" @click="openArbiter(scope.row.jobId,taskName)">{{scope.row.jobId}}</span>
</template>
                 </el-table-column>
                 <el-table-column prop="description" label="任务描述">
                        </el-table-column>
                        <el-table-column prop="startTime" label="开始时间"></el-table-column>
                        <el-table-column prop="timeCost" width="60%" label="耗时"></el-table-column>
                        <el-table-column prop="status" label="执行状态"  width="90%" >
                            <template slot-scope="status">
                                <el-tag :type="ExeStatusMap[status.row.status]=='成功'?'success':ExeStatusMap[status.row.status]=='失败'?'danger':ExeStatusMap[status.row.status]=='未知'||status.row.status==null?'info':'warning'">
                                    {{status.row.status==null?'未知':ExeStatusMap[status.row.status]}}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="retInfo" label="返回信息">
                        </el-table-column>
                        
                </el-table>
            		<div>
			<el-pagination
					@current-change="handleCurrentChange"
					:current-page="pageNum"
					:page-sizes="[20,40,60]"
					:page-size="pageSize"
					:total="totalPages"
					layout="total, prev, pager, next, jumper"></el-pagination>
		</div>
        </el-card>
    </div>
</template>
<script>
import { dateTimeFormat } from '@/store/date'
import {
  Message
} from 'element-ui'
import {
  schedulerHistoryAgg,
  schedulerHistory,
  arbiterHistoryAgg,
  arbiterHistory
} from '@/api/schedule'
import Axios from 'axios'
export default {
  name: 'historyList',
  data() {
    return {
      listLoading: false,
      formData: {
        startTime: '',
        endTime: ''
      },
      taskName: 'default',
      taskType: '',
      taskId: '',
      lastExeStatus: '',
      historyAggData: {},
      historyData: [],
      lastExeStatusTable: [{ value: '', name: '' }, { value: 1, name: '成功' }, { value: 2, name: '失败' }, { value: 3, name: '未知' }, { value: 4, name: '执行中' }],
      pageNum: 1,
      pageSize: 20,
      totalPages: 0,
      ExeStatusMap: {
        1: '成功',
        2: '失败',
        3: '未知',
        4: '执行中',
        5: '未执行'
      }
    }
  },
  created() {
    if (this.$route.params.type !== undefined) {
      this.taskType = this.$route.params.type
    }
    if (this.$route.params.taskId !== undefined) {
      this.taskId = this.$route.params.taskId
    }
    if (this.$route.params.taskName !== undefined) {
      this.taskName = this.$route.params.taskName
    }
    this.initStartTime()
    this.initEndTime()
    this.handleQuery()
  },
  methods: {
    openArbiter(jobId, jobName) {
    //   const startTime = this.formData.startTime
    //   const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/schedule/arbiterDetail/' + jobId + '/' + jobName)
      this.$router.push({ path: '/schedule/arbiterDetail/' + jobId + '/' + jobName })
    //   const seqUrl = '/biz/es/tracelog/ui?seq=' + seq + '&startTime=' + startTime + '&endTime=' + endTime
    //   console.log(seqUrl)
    //   const title = '业务日志查询'
    //   window.parent.addTab(title, seqUrl)
    },
    openTraceLog(seq) {
      const startTime = this.formData.startTime
      const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/Log/traceLog/' + seq, { seq: seq, startTime: startTime, endTime: endTime })
      this.$router.push({ path: '/Log/traceLog/' + seq, query: { seq: seq, startTime: startTime, endTime: endTime }})
    },
    handleCurrentChange(val) {
      this.pageNum = val
      if (this.pageNum <= this.totalPages && this.taskType === 'arbiter') this.handleArbiterQuery()
      if (this.pageNum <= this.totalPages && this.taskType === 'scheduler') this.handleSchedulerQuery()
    },
    handleQuery() {
    //   console.log('taskType', this.taskType, this.taskType === 'scheduler')
      if (this.taskType === 'arbiter') this.handleArbiterQuery()
      if (this.taskType === 'scheduler') this.handleSchedulerQuery()
    },
    formatStartTime(val) {
      this.formData.startTime = dateTimeFormat(val)
    },
    formatEndTime(val) {
      this.formData.endTime = dateTimeFormat(val)
    },
    initStartTime() {
      var nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.formData.startTime = dateTimeFormat(nowTime)
    },
    initEndTime() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.formData.endTime = dateTimeFormat(nowTime)
    },
    handleArbiterQuery() {
      this.listLoading = true
      const requestGroup = []
      requestGroup.push(
        arbiterHistoryAgg(this.taskName, this.formData.startTime, this.formData.endTime).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            console.log('arbiterHistoryAgg', response)
            this.historyAggData = response.data
            console.log('historyAggData', this.historyAggData)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        }).catch((error) => {
          this.listLoading = false
          Message.error(error)
        })
      )
      requestGroup.push(
        arbiterHistory(this.formData.startTime, this.formData.endTime, this.lastExeStatus, this.taskName, this.pageNum - 1, this.pageSize).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            console.log('arbiterHistory', response)
            this.historyData = response.data.items
            this.totalPages = response.data.totalNum
            console.log('historyData', this.historyData)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        }).catch((error) => {
          console.log(error)
          this.listLoading = false
        //   Message.error(error)
        })
      )
      Axios.all(requestGroup).then(response => {
        this.listLoading = false
      })
    //   console.log('taskForm', this.taskForm)
    },
    handleSchedulerQuery() {
      this.listLoading = true
      const requestGroup = []
      requestGroup.push(
        schedulerHistoryAgg(this.taskId, this.formData.startTime, this.formData.endTime).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            console.log('schedulerHistoryAgg', response)
            this.historyAggData = response.data[0]
            console.log('historyAggData', this.historyAggData)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        }).catch((error) => {
          this.listLoading = false
          Message.error(error)
        })
      )
      requestGroup.push(
        schedulerHistory(this.formData.startTime, this.formData.endTime, this.lastExeStatus, this.taskId, this.pageNum - 1, this.pageSize).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            console.log('schedulerHistory', response)
            this.historyData = JSON.parse(JSON.stringify(response.data[0].items))
            this.totalPages = response.data[0].total
            console.log('historyData', this.historyData)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        }).catch((error) => {
          this.listLoading = false
          Message.error(error)
        })
      )
      Axios.all(requestGroup).then(response => {
        this.listLoading = false
      })
    //   console.log('taskForm', this.taskForm)
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
  
}
</style>