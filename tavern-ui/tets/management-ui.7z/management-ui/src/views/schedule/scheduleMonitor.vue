<template>
    <div class="app-container">
        <el-card >
            <el-form :inline="true" @submit.native.prevent v-loading.body="listLoading">
                <el-form-item label="任务名称">
                    <el-input @keyup.enter.native="handleQuery()" v-model="taskForm.jobName" size="mini" placeholder="请输入任务名"></el-input>
                </el-form-item>
                <el-form-item  label="任务状态" prop="info">
                    <el-select v-model="taskForm.jobStatus" size="mini">
                        <el-option
                            v-for="item in jobStatusTable"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item  label="最近一次执行状态"  prop="info">
                    <el-select v-model="taskForm.lastExeStatus" size="mini">
                        <el-option
                            v-for="item in lastExeStatusTable"
                            :key="item.value"
                            :label="item.name"
                            :value="item.value"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="handleQuery">查询</el-button>
                </el-form-item>
            </el-form>
            <el-table
            :data="jobList"
            size="mini"
                v-loading.body="listLoading"
                element-loading-text="Loading"
                border
                fit
                :stripe="true">
                <el-table-column type="expand">
                    <template slot-scope="scope">
                       <el-table
                        :data="scope.row.jobItem"
                        size="mini"
                        v-loading.body="listLoading"
                        element-loading-text="Loading"
                        border
                        fit
                        :stripe="true">
                        <el-table-column
                            type="index"
                            width="50px"
                            align="center"
                        ></el-table-column>
                        <el-table-column prop="jobName" label="任务名称"></el-table-column>
                        <el-table-column prop="executionId" label="最近一次任务id">
<template slot-scope="scopes" >
    <span v-if="scope.row.taskTypeMark==='scheduler'" class="link-type" @click="openScheduler(scopes.row.executionId)">{{scopes.row.executionId}}</span>
    <span v-if="scope.row.taskTypeMark==='arbiter'" class="link-type" @click="openArbiter(scopes.row.executionId,scopes.row.jobName)">{{scopes.row.executionId}}</span>
</template>
                        </el-table-column>
                        <el-table-column prop="remark" label="任务说明"></el-table-column>
                        <el-table-column prop="jobOwner" label="任务负责人"></el-table-column>
                        <el-table-column prop="startTime" label="最近一次执行时间"></el-table-column>
                        <el-table-column prop="cycle" label="下次执行时间">
                            <template slot-scope="status">
                                <span v-if="status.row.cycle!=null&&status.row.cycle!=undefined&&status.row.startTime!=null&&status.row.startTime!=undefined">{{parserCron(status.row.startTime,status.row.cycle)}}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="costTime" label="预计耗时">
                            <template slot-scope="time">
                                <span v-if="scope.row.taskTypeMark === 'scheduler'&&time.row.costTime!=null">{{time.row.costTime}}毫秒</span>
                                <span v-if="scope.row.taskTypeMark === 'arbiter'&&time.row.costTime!=null">{{time.row.costTime.split(':')[0]}}时{{time.row.costTime.split(':')[1]}}分{{time.row.costTime.split(':')[2]}}秒</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="exeStatus" label="最近一次执行状态">
                            <template slot-scope="status">
                                <el-tag :type="lastExeStatusMap[status.row.exeStatus]=='成功'?'success':lastExeStatusMap[status.row.exeStatus]=='失败'?'danger':lastExeStatusMap[status.row.exeStatus]=='未知'||status.row.exeStatus==null?'info':'warning'">
                                    {{status.row.exeStatus==null?'未知':lastExeStatusMap[status.row.exeStatus]}}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="jobStatus" label="任务状态">
                            <template slot-scope="status">
                                <el-tag :type="jobStatusMap[status.row.jobStatus]=='启用'?'success':status.row.jobStatus===null?'info':'danger'">
                                    {{status.row.jobStatus==null?'未知':jobStatusMap[status.row.jobStatus]}}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column label="历史查询">
                             <template slot-scope="operation">
                        <el-button class="tool-item" type="primary" size="mini" @click="open(scope.row.taskTypeMark,operation.row.jobId,operation.row.jobName)">
                            历史详情
                        </el-button>
                            </template>    
                        </el-table-column>
                        <el-table-column width="50%" v-if="hasPermission()">
                            <template slot-scope="operation">
                        <el-popover
                        
                            placement="left"
                            trigger="click">
                            <el-form ref="ruleForm" @submit.native.prevent>
                                <div class="form-wrapper">
                                    <div class="title">操作</div>
                                <el-button @click="jobTriger(operation.row.jobName,operation.row.jobActionUrl,operation.row.jobActionType,operation.row.jobActionParam,scope.row.taskTypeMark,operation.row.jobId)"  slot="reference" class="tool-item" type="danger" size="mini">
                                    触发
                                </el-button>
                                <el-button v-if="scope.row.taskTypeMark==='arbiter'" @click="jobReset(operation.row.jobName)" slot="reference" class="tool-item" type="warning" size="mini">
                                    重置
                                </el-button>
                                <el-button v-if="operation.row.jobStatus==1" @click="jobStop(scope.row.taskTypeMark,operation.row.jobName,operation.row.jobId,operation.row.jobActionUrl,operation.row.jobActionParam)" slot="reference" class="tool-item" type="info" size="mini">
                                    停用
                                </el-button>
                                <el-button v-else slot="reference" @click="jobStart(scope.row.taskTypeMark,operation.row.jobName,operation.row.jobId,operation.row.jobActionUrl,operation.row.jobActionParam)" class="tool-item" type="success" size="mini">
                                    启用
                                </el-button>
                                </div>
                            </el-form>
                            <el-button slot="reference" class="tool-item" type="text" size="mini">
                                <i class="el-icon-edit"></i>
                            </el-button>
                        </el-popover>
                    </template>    
                        </el-table-column>
                        
                        </el-table>
                    </template>
                </el-table-column>
                <el-table-column
                type="index"
                width="50px"
                align="center"
                ></el-table-column>
                <el-table-column prop="groupName" label="任务组"></el-table-column>
                <el-table-column  prop="status" label="状态">
                    <template slot-scope="status">
                                <el-tag style="min-width:100px;text-align: center;" :type="status.row.status==='正常'?'success':status.row.status==='存在问题'?'danger':'warning'">
                                    {{status.row.status}}
                                </el-tag>
                            </template>
                </el-table-column>
                <el-table-column prop="taskTypeMark" label="任务所属"></el-table-column>
                <el-table-column width="50%" v-if="hasPermission()">
                    <template slot-scope="operation">
                        <el-popover
                        v-if="operation.row.taskTypeMark==='arbiter'"
                            placement="left"
                            trigger="click">
                            <el-form ref="ruleForm" @submit.native.prevent >
                                <div class="form-wrapper">
                                    <div class="title">操作</div>
                                <el-button slot="reference" class="tool-item" type="danger" size="mini" @click="groupTriger(operation.row.groupName,operation.row.groupActionUrl,operation.row.groupActionType)">
                                    触发
                                </el-button>
                                <el-button slot="reference" class="tool-item" type="warning" size="mini" @click="groupReset(operation.row.groupName)">
                                    重置
                                </el-button>
                                </div>
                            </el-form>
                            <el-button slot="reference" class="tool-item" type="text" size="mini">
                                <i class="el-icon-edit"></i>
                            </el-button>
                        </el-popover>
                    </template>     
                </el-table-column>
            </el-table>
        </el-card>
        <el-dialog
        :title="trigerForm.name"
        :visible.sync="isdalog"
        :before-close="handleColse"
    >
        <el-form
        
            :model="trigerForm"
            ref="trigerForm"
        >
            <el-form-item
                prop="url"
                label="任务执行地址"
                :rules="{required: true, message: '请输入任务执行地址'}"
            >
                <el-input style="width:100%;" v-model="trigerForm.url"></el-input>
                </el-form-item>
                            <el-form-item
                            
                                prop="actType"
                                label="执行方式"
                            >
                                <el-input style="width:100%;" v-model="trigerForm.actType"></el-input>
                                </el-form-item>
                <el-form-item
                    prop="args"
                    label="执行参数"
                    :rules="[
          {required: true, message: '请输入执行参数'}
          ]"
                    
                    v-if="trigerForm.jobType!=='group'"
                >
                    <el-input stye="overflow:auto;" v-model="trigerForm.args" @change="doJsonParser(trigerForm.args)"></el-input>

                    </el-form-item>
                    <el-form-item label="参数预览"
                     v-if="trigerForm.jobType!=='group'">
                                        <jsonViewer
                      style="height:auto;width:100%;float:left;"
                      :json="josnViewData">
                      </jsonViewer>
                    </el-form-item>


                                                                        </el-form>
                                                                        <span slot="footer">
          <el-button type="primary" @click="handleColse">取消</el-button>
          <el-button type="primary" @click="trigerForm.jobType=='group'?doGroupTriger():doTriger()">确定</el-button>
      </span>
                                                                        </el-dialog>

    </div>
</template>
<script>
import cronparser from 'cron-parser'
import { dateTimeFormat } from '@/store/date'
import {
  getSchedulerListV2,
  getArbitList,
  groupReset,
  groupTrigger,
  arbiterJobTrigger,
  arbiterJobReset,
  arbiterJobDisable,
  arbiterJobEnable,
  schedulerOperation
} from '@/api/schedule'
import { mapGetters } from 'vuex'
import {
  Message
} from 'element-ui'
import Axios from 'axios'
import jsonViewer from '@/components/JsonView'
export default {
  name: 'scheduleMonitor',
  data() {
    return {
      listLoading: false,
      taskForm: {
        jobName: '',
        jobStatus: '',
        lastExeStatus: ''
      },
      isdalog: false,
      jobList: [],
      jobStatusTable: [{ value: '', name: '' }, { value: 1, name: '启用' }, { value: 2, name: '停用' }],
      lastExeStatusTable: [{ value: '', name: '' }, { value: 1, name: '成功' }, { value: 2, name: '失败' }, { value: 3, name: '未知' }, { value: 4, name: '执行中' }],
      jobStatusMap: {
        1: '启用',
        2: '停用'
      },
      trigerForm: {
        name: '',
        url: '',
        args: '',
        actType: '',
        jobType: '',
        taskId: ''
      },
      lastExeStatusMap: {
        1: '成功',
        2: '失败',
        3: '未知',
        4: '执行中',
        5: '未执行'
      },
      josnViewData: {}
    }
  },
  components: {
    jsonViewer
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  methods: {
    openScheduler(seq) {
    //   const startTime = this.formData.startTime
    //   const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/Log/traceLog/' + seq, { seq: seq })
      this.$router.push({ path: '/Log/traceLog/' + seq, query: { seq: seq }})
    //   const seqUrl = '/biz/es/tracelog/ui?seq=' + seq + '&startTime=' + startTime + '&endTime=' + endTime
    //   console.log(seqUrl)
    //   const title = '业务日志查询'
    //   window.parent.addTab(title, seqUrl)
    },
    openArbiter(jobId, jobName) {
    //   const startTime = this.formData.startTime
    //   const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/schedule/arbiterDetail/' + jobId + '/' + jobName)
      this.$router.push({ path: '/schedule/arbiterDetail/' + jobId + '/' + jobName })
    //   const seqUrl = '/biz/es/tracelog/ui?seq=' + seq + '&startTime=' + startTime + '&endTime=' + endTime
    //   console.log(seqUrl)
    //   const title = '业务日志查询'
    //   window.parent.addTab(title, seqUrl)
    },
    open(type, id, name) {
    //   const startTime = this.formData.startTime
    //   const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/schedule/historyList/' + type + '/' + id + '/' + name)
      this.$router.push({ path: '/schedule/historyList/' + type + '/' + id + '/' + name })
    //   const seqUrl = '/biz/es/tracelog/ui?seq=' + seq + '&startTime=' + startTime + '&endTime=' + endTime
    //   console.log(seqUrl)
    //   const title = '业务日志查询'
    //   window.parent.addTab(title, seqUrl)
    },
    doJsonParser(val) {
      if (val !== '') {
        try {
        //   const a = String().valueOf(val)
          // if (val.split('$')[0] !== val) this.$message({ type: 'warning', message: '存在未填写参数，请检查！' })
          this.josnViewData = JSON.parse(val)
          return JSON.parse(val)
        } catch (error) {
          this.$message({ type: 'error', message: '参数Json解析失败！' })
        }
      }
    },
    doGroupTriger() {
      if (this.trigerForm.args.split('$')[0] === this.trigerForm.args && this.trigerForm.url.split('$')[0] === this.trigerForm.url) {
        this.$confirm('确认触发?')
          .then(_ => {
            this.listLoading = true
            groupTrigger(this.trigerForm.url, this.trigerForm.actType).then(response => {
              this.listLoading = false
              if (response.code === 0) {
                Message.success('触发成功！')
                this.handleQuery()
              } else {
                Message.error('触发失败！' + response.code + ':' + response.info)
              }
              this.trigerForm = {
                name: '',
                url: '',
                args: '',
                actType: '',
                jobType: '',
                taskId: ''
              }
              this.isdalog = false
            }).catch((error) => {
              this.listLoading = false
              this.trigerForm = {
                name: '',
                url: '',
                args: '',
                actType: '',
                jobType: '',
                taskId: ''
              }
              this.isdalog = false
              Message.error(error)
            })
          })
          .catch(_ => {

          })
      } else {
        this.$message({ type: 'warning', message: '存在未填写参数，请检查！' })
      }
    },
    doTriger() {
      if (this.trigerForm.args.split('$')[0] === this.trigerForm.args && this.trigerForm.url.split('$')[0] === this.trigerForm.url) {
        this.$confirm('确认触发?')
          .then(_ => {
            this.listLoading = true
            if (this.trigerForm.jobType === 'arbiter') {
              arbiterJobTrigger(this.trigerForm.url, this.trigerForm.args, this.trigerForm.actType).then(response => {
                this.listLoading = false
                if (response.code === 0) {
                  Message.success('触发成功！')
                  this.handleQuery()
                } else {
                  Message.error('触发失败！' + response.code + ':' + response.info)
                }
                this.trigerForm = {
                  name: '',
                  url: '',
                  args: '',
                  actType: '',
                  jobType: '',
                  taskId: ''
                }
                this.isdalog = false
              }).catch((error) => {
                this.listLoading = false
                this.trigerForm = {
                  name: '',
                  url: '',
                  args: '',
                  actType: '',
                  jobType: '',
                  taskId: ''
                }
                this.isdalog = false
                Message.error(error)
              })
            } else {
              schedulerOperation(this.trigerForm.taskId, 2, this.trigerForm.url, this.trigerForm.args).then(response => {
                this.listLoading = false
                if (response.payload.code === 0) {
                  Message.success('触发成功！')
                  this.handleQuery()
                } else {
                  Message.error('触发失败！' + response.payload.code + ':' + response.payload.info)
                }
                this.trigerForm = {
                  name: '',
                  url: '',
                  args: '',
                  actType: '',
                  jobType: '',
                  taskId: ''
                }
                this.isdalog = false
              }).catch((error) => {
                this.listLoading = false
                this.trigerForm = {
                  name: '',
                  url: '',
                  args: '',
                  actType: '',
                  jobType: '',
                  taskId: ''
                }
                this.isdalog = false
                Message.error(error)
              })
            }
          })
          .catch(_ => {

          })
      } else {
        this.$message({ type: 'warning', message: '存在未填写参数，请检查！' })
      }
    },
    handleColse(done) {
      this.$confirm('确认关闭?')
        .then(_ => {
          this.trigerForm = {
            name: '',
            url: '',
            args: '',
            actType: '',
            jobType: '',
            taskId: ''
          }
          this.isdalog = false
          done()
        })
        .catch(_ => {})
    },
    groupTriger(name, url, actType) {
      this.$confirm('此请求会立即触发整体任务执行，需考虑此任务组中是否还有执行中任务，若强制执行，可能会发生任务重复执行，并发执行问题。\n建议：先查看任务组中任务是否全部执行完成，或者任务中有任务失败造成其他任务无法按循环周期正常执行。\n当任务组所有任务全部执行完成后，或者有任务失败，方可触发此请求！', '注意', {
        confirmButtonText: '确认触发',
        type: 'warning'
      }).then(
        _ => {
          this.trigerForm = {
            name: name,
            url: url,
            args: '',
            actType: actType,
            jobType: 'group',
            taskId: ''
          }
          this.isdalog = true
        }
      ).catch(_ => {})
    },
    groupReset(name) {
      this.$confirm('此请求会立即重置任务组中所有任务的状态为准备执行状态，需考虑此任务组中是否还有执行中任务，若强制重置，若轮询周期恰好到达，会触发此任务执行，可能会发生任务重复执行，并发执行问题。\n' +
                    '建议：先查看任务组中任务是否全部执行完成，或者任务中有任务失败造成其他任务无法按循环周期正常执行。\n' +
                    '当任务组所有任务全部执行完成后，或者有任务失败，方可触发此请求！', '注意', {
        confirmButtonText: '确认重置',
        type: 'warning'
      }).then(
        _ => {
          this.listLoading = true
          groupReset(name).then(response => {
            this.listLoading = false
            if (response.code === 0) {
              Message.success('重置成功！')
              this.handleQuery()
            } else {
              Message.error('重置失败！' + response.code + ':' + response.info)
            }
          }).catch((error) => {
            this.listLoading = false
            Message.error(error)
          })
        //   console.log('comfirm', name)
        }
      ).catch(_ => {})
    },
    jobTriger(name, url, actType, args, type, taskId) {
      this.$confirm('此请求会立即触发整体任务执行，需考虑此任务组中是否还有执行中任务，若强制执行，可能会发生任务重复执行，并发执行问题。\n建议：先查看任务组中任务是否全部执行完成，或者任务中有任务失败造成其他任务无法按循环周期正常执行。\n当任务组所有任务全部执行完成后，或者有任务失败，方可触发此请求！', '注意', {
        confirmButtonText: '确认触发',
        type: 'warning'
      }).then(
        _ => {
          this.trigerForm = {
            name: name,
            url: url,
            args: args,
            actType: actType,
            jobType: type,
            taskId: taskId
          }
          this.isdalog = true
          this.doJsonParser(this.trigerForm.args)
          console.log('trigerForm', this.trigerForm)
        //   if (type === 'arbiter') console.log('comfirm', name, process.env.zt_arbiter_url.split('/arbiter')[0] + url, actType, args)
        //   else console.log('comfirm', name, url, actType, args)
        }
      ).catch(_ => {})
    },
    jobReset(name) {
      this.$confirm('此请求会立即重置任务组中所有任务的状态为准备执行状态，需考虑此任务组中是否还有执行中任务，若强制重置，若轮询周期恰好到达，会触发此任务执行，可能会发生任务重复执行，并发执行问题。\n' +
                    '建议：先查看任务组中任务是否全部执行完成，或者任务中有任务失败造成其他任务无法按循环周期正常执行。\n' +
                    '当任务组所有任务全部执行完成后，或者有任务失败，方可触发此请求！', '注意', {
        confirmButtonText: '确认重置',
        type: 'warning'
      }).then(
        _ => {
          this.listLoading = true
          arbiterJobReset(name).then(response => {
            this.listLoading = false
            if (response.code === 0) {
              Message.success('重置成功！')
              this.handleQuery()
            } else {
              Message.error('重置失败！' + response.code + ':' + response.info)
            }
          }).catch((error) => {
            this.listLoading = false
            Message.error(error)
          })
        }
      ).catch(_ => {})
    },
    jobStart(type, jobName, jobId, url, args) {
      this.$confirm('该操作会立即启用该项定时任务，并根据设定的定时周期进行调度', '注意', {
        confirmButtonText: '确认启用',
        type: 'warning'
      }).then(
        _ => {
          this.listLoading = true
          if (type === 'arbiter') {
            arbiterJobEnable(jobName).then(response => {
              this.listLoading = false
              if (response.code === 0) {
                Message.success('启用成功！')
                this.handleQuery()
              } else {
                Message.error('启用失败！' + response.code + ':' + response.info)
              }
            }).catch((error) => {
              this.listLoading = false
              Message.error(error)
            })
          } else {
            schedulerOperation(jobId, 1, url, args).then(response => {
              this.listLoading = false
              if (response.payload.code === 0) {
                Message.success('启用成功！')
                this.handleQuery()
              } else {
                Message.error('启用失败！' + response.payload.code + ':' + response.payload.info)
              }
            }).catch((error) => {
              this.listLoading = false
              Message.error(error)
            })
          }
        }
      ).catch(_ => {})
    },
    jobStop(type, jobName, jobId, url, args) {
      this.$confirm('该操作会立即停止这项定时任务，之后需要重新启用才会继续定时执行。', '注意', {
        confirmButtonText: '确认停用',
        type: 'warning'
      }).then(
        _ => {
          this.listLoading = true
          if (type === 'arbiter') {
            arbiterJobDisable(jobName).then(response => {
              this.listLoading = false
              if (response.code === 0) {
                Message.success('禁用成功！')
                this.handleQuery()
              } else {
                Message.error('禁用失败！' + response.code + ':' + response.info)
              }
            }).catch((error) => {
              this.listLoading = false
              Message.error(error)
            })
          } else {
            schedulerOperation(jobId, 0, url, args).then(response => {
              this.listLoading = false
              if (response.payload.code === 0) {
                Message.success('禁用成功！')
                this.handleQuery()
              } else {
                Message.error('禁用失败！' + response.payload.code + ':' + response.payload.info)
              }
            }).catch((error) => {
              this.listLoading = false
              Message.error(error)
            })
          }
        }
      ).catch(_ => {})
    },
    parserCron(time, str) {
      if (time === null || time === '') return ''

      //   console.log('parserTime',new Date(time))
      const option = {
        currentDate: new Date(time),
        startDate: new Date(time),
        utc: false,
        tz: 'Asia/shanghai'
      }
      try {
        const timen = cronparser.parseExpression(str, option)
        // console.log('time', new Date(dateTimeFormat(new Date(new Date(timen.next())+8*60*60000))), str)
        //   timen.next()
        return dateTimeFormat(new Date(new Date(timen.next()) + 8 * 60 * 60000))
      } catch (e) {
        return '定时解析失败！'
      }
    },
    hasPermission() {
      const ROLES = ['admin', 'scheduleMonitorButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    handleQuery() {
      this.listLoading = true
      const requestGroup = []
      let jobListSchedule = []
      let jobListArbiter = []
      requestGroup.push(
        getSchedulerListV2(this.taskForm.jobName, this.taskForm.jobStatus, this.taskForm.lastExeStatus).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            jobListSchedule = response.data[0].items.map(v => {
              if (v.jobItem.length !== 0) {
                let dangerFlag = false
                let processingFlag = false
                for (const i of v.jobItem) {
                  if (
                    i.jobStatus !== 2 && (i.exeStatus === 2 || i.exeStatus === 3 || i.exeStatus === null || i.exeStatus === '')
                  ) {
                    dangerFlag = true
                    break
                  }
                  // const timemark = this.parserCron(i.startTime, i.cycle)
                  // //   console.log('timemark', new Date() > timemark)
                  // if (new Date() > new Date(timemark)) {
                  //   i.exeStatus = 5
                  //   if (i.jobStatus !== 2) dangerFlag = true
                  // }
                  if (
                    i.jobStatus !== 2 && i.exeStatus === 4
                  ) {
                    processingFlag = true
                  }
                }

                if (dangerFlag) {
                  this.$set(v, 'status', '存在问题')
                } else {
                  if (processingFlag) {
                    this.$set(v, 'status', '部分处理中')
                  } else {
                    this.$set(v, 'status', '正常')
                  }
                }
              }
              this.$set(v, 'taskTypeMark', 'scheduler')
              return v
            })
            console.log('jobListSchedule', jobListSchedule)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        }).catch((error) => {
          this.listLoading = false
          Message.error(error)
        })
      )
      requestGroup.push(
        getArbitList(this.taskForm.jobName, this.taskForm.jobStatus, this.taskForm.lastExeStatus).then(response => {
          this.listLoading = false
          if (response.code === 0) {
            jobListArbiter = response.data.items.map(v => {
              if (v.jobItem.length !== 0) {
                let dangerFlag = false
                let processingFlag = false
                for (const i of v.jobItem) {
                  if (
                    i.jobStatus !== 2 && (i.exeStatus === 2 || i.exeStatus === 3 || i.exeStatus === '')
                  ) {
                    dangerFlag = true
                    break
                  }
                  // const timemark = this.parserCron(i.startTime, i.cycle)
                  // //   console.log('timemark', timemark)
                  // if (new Date() > new Date(timemark)) {
                  //   i.exeStatus = 5
                  //   if (i.jobStatus !== 2) dangerFlag = true
                  // }
                  if (
                    i.jobStatus !== 2 && i.exeStatus === 4
                  ) {
                    processingFlag = true
                  }
                }
                if (dangerFlag) {
                  this.$set(v, 'status', '存在问题')
                } else {
                  if (processingFlag) {
                    this.$set(v, 'status', '部分处理中')
                  } else {
                    this.$set(v, 'status', '正常')
                  }
                }
              }
              this.$set(v, 'taskTypeMark', 'arbiter')
              return v
            })
            console.log('jobListArbiter', jobListArbiter)
          } else {
            Message.error(response.code + ':' + response.info)
          }
        }).catch((error) => {
          this.listLoading = false
          Message.error(error)
        })
      )
      Axios.all(requestGroup).then(response => {
        const jobListtmp = []
        if (jobListSchedule.length !== 0) jobListtmp.push(...jobListSchedule)
        if (jobListArbiter.length !== 0) jobListtmp.push(...jobListArbiter)
        const compare = function(obj1, obj2) {
        //   console.log('conpare', obj1, obj2)
          // const val1 = obj1.metric
          // const val2 = obj2.metric
          // if (val1 > val2) return 1
          // else if (val1 < val2) return -1
          // else return 0
          return obj1.groupName.localeCompare(obj2.groupName)
        }
        this.jobList = jobListtmp.sort(compare)
        console.log('jobList', this.jobList)
      })
      console.log('taskForm', this.taskForm)
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
  
}
</style>