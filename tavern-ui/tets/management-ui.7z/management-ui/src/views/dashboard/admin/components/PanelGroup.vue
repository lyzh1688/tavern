<template>
    <el-card class="outsideContainer">
    <div> <span class="theme-title">{{themeName}}</span>
<el-tag type="warning">是否启用业务域筛选<el-switch v-model="doFilter"></el-switch></el-tag>
    </div>
        <el-row class="panel-group" :gutter="20">
            
            <el-col :xs="8" :sm="8" :lg="8"  class="card-panel-col">
    
                <div class='card-panel' @click="handleViewAlarm">
    
                    <div class="card-panel-icon-wrapper icon-warning">
    
                        <svg-icon icon-class="warning" class-name="card-panel-icon" />
    
                    </div>
    
                    <div class="card-panel-description">
    
                        <div class="card-panel-text">告警事件</div>
    
                        <count-to class="card-panel-num-service-warning" :startVal="0" :endVal="alarmNumber" :duration="3000"></count-to>
    
                    </div>
    
                </div>
    
            </el-col>
    
            <el-col :xs="8" :sm="8" :lg="8" class="card-panel-col">
    
                <div class="card-panel" @click="handleViewModuleStatus">
    
                    <div class="card-panel-icon-wrapper icon-module">
    
                        <svg-icon icon-class="module2" class-name="card-panel-icon" />
    
                    </div>
    
                    <div class="card-panel-description">
    
                        <div class="card-panel-text">监控脱机</div>
    
                        <count-to class="card-panel-num-service-uncaculate" :startVal="0" :endVal="unknownNumber" :duration="3000"></count-to>
    
                    </div>
    
                    <div class="card-panel-description">
    
                        <div class="card-panel-text">正常</div>
    
                        <count-to class="card-panel-num-service-health" :startVal="0" :endVal="safeNumber" :duration="3000"></count-to>
    
                    </div>
    
                    <div class="card-panel-description">
    
                        <div class="card-panel-text">告警</div>
    
                        <count-to class="card-panel-num-service-warning" :startVal="0" :endVal="ModulealarmNumber" :duration="3000"></count-to>
    
                    </div>
    
                </div>
    
            </el-col>
            <el-col :xs="8" :sm="8" :lg="8"  class="card-panel-col">
    
                <div class='card-panel' @click="handleViewAlarm">
    
                    <div class="card-panel-icon-wrapper icon-trade">
    
                        <svg-icon icon-class="international" class-name="card-panel-icon" />
    
                    </div>
    
                    <div class="card-panel-description">
    
                        <div class="card-panel-text">服务状态</div>
    
                        <count-to class="card-panel-num-service-warning" :startVal="0" :endVal="ServiceErrorNumber" :duration="3000"></count-to>
                        <span>/</span>
                        <count-to class="card-panel-num-service-health" :startVal="0" :endVal="serviceNumber - ServiceErrorNumber" :duration="3000"></count-to>
                    </div>
    
                </div>
    
            </el-col>
    
        </el-row>
    <el-row class="panel-group" :gutter="20" v-if="zookeeperList!=null">
    
            <el-col :xs="12" :sm="12" :lg="24/zookeeperList.length" class="card-panel-col" v-for="item in zookeeperList" :key=item.clusterName>
    
                <div class="card-panel">
    
                    <div class="card-panel-icon-wrapper icon-cluster">
    
                        <svg-icon icon-class="cluster" class-name="card-panel-icon" />
    
                    </div>
    
                    <div class="card-panel-descriptions">
    
                        <div class="card-panel-text">{{item.clusterName}}</div>
    
                    </div>
                    
    
                </div>
                    <div class='zk-container'>
    
                    <el-button
                        :type="itemB.status === '正常' ? 'success': (itemB.status === '未采集数据' ? 'warning':(itemB.status === '未启用监控' ? 'info':'danger'))"
                        v-for="itemB in item.instances"
                        :key="itemB.instanceId"
                        size="mini"
                        class="selectButton"
                        @click="handleDetailInfo(itemB.instanceId,itemB.serverIp,moduleId,'ZooKeeper')">
                        {{itemB.serverIp}}
                        </el-button>    
    
                    </div>
            </el-col>
    
        </el-row>
        <!-- <el-row class="panel-group" :gutter="20">
    
            <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
    
                <div class="card-panel" @click="handleSetLineChartData('spxexchangertradeRequest','集中交易请求速率')">
    
                    <div class="card-panel-header">
    
                        <div class="card-panel-icon-wrapper icon-trade">
    
                            <svg-icon icon-class="trade" class-name="card-panel-icon" />
    
                        </div>
    
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">集中交易请求速率</div>
    
    
    
                        </div>
    
                    </div>
    
                    <div class='chart-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData.spxexchangertradeRequest"></innerBarChart>
    
                    </div>
    
                </div>
    
            </el-col>
    
            <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
    
                <div class="card-panel" @click="handleSetLineChartData('spxexchangercreditRequest','融资融券请求速率')">
    
                    <div class="card-panel-header">
    
                        <div class="card-panel-icon-wrapper icon-trade">
    
                            <svg-icon icon-class="trade" class-name="card-panel-icon" />
    
                        </div>
    
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">融资融券请求速率</div>
    
    
    
                        </div>
    
                    </div>
    
                    <div class='chart-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData.spxexchangercreditRequest"></innerBarChart>
    
                    </div>
    
                </div>
    
            </el-col>
    
            <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
    
                <div class="card-panel" @click="handleSetLineChartData('gwuserRequest','user网关请求速率')">
    
                    <div class="card-panel-header">
    
                        <div class="card-panel-icon-wrapper icon-gateway">
    
                            <svg-icon icon-class="gateway" class-name="card-panel-icon" />
    
                        </div>
    
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">user网关请求速率</div>
    
                        </div>
    
                    </div>
    
                    <div class='chart-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData.gwuserRequest"></innerBarChart>
    
                    </div>
    
    
    
                </div>
    
            </el-col>
    
            <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
    
                <div class="card-panel" @click="handleSetLineChartData('gwrouterRequest','router网关请求速率')">
    
                    <div class="card-panel-header">
    
                        <div class="card-panel-icon-wrapper icon-gateway">
    
                            <svg-icon icon-class="gateway" class-name="card-panel-icon" />
    
                        </div>
    
                        <div class="card-panel-descriptions">
    
                            <div class="card-panel-text">router网关请求速率</div>
    
                        </div>
    
                    </div>
    
                    <div class='chart-container'>
    
                        <innerBarChart height='100%' width='100%' :chart-data="functionData.gwrouterRequest"></innerBarChart>
    
                    </div>
    
                </div>
    
    
    
            </el-col>
    
        </el-row> -->
    
        
    
    </el-card>
</template>


<script>
    import CountTo from 'vue-count-to'
    
    import {
      queryInstance,
      getModuleStatusUpdate,
    
      getAlarmStatus,
    
      getModuleStatus,

      queryServiceStatus
    
    } from '@/api/monitor'
    
    import innerBarChart from '@/components/Charts/innerBarchart'
    
    export default {
    
      props: {
    
        functionData: {
    
          type: Object,
    
          default: null
    
        },
        themeName: {
    
          type: String,
    
          default: '未知名称主题'
    
        }
    
      },
    
      components: {
    
        CountTo,
    
        innerBarChart
    
      },
    
      data() {
        return {
    
          list: [],
    
          updateList: null,
    
          zookeeperList: null,
    
          timeOut: '30',
    
          unknownNumber: 0,
    
          safeNumber: 0,
    
          ModulealarmNumber: 0,
    
          UnmonitorNumber: 0,
    
          alarmNumber: 0,
    
          ref: null,
    
          chartListData: null,
    
          ServiceErrorNumber: 0,
          serviceNumber: 0,
          serviceStatusList: [1],

          moduleId: null,
          doFilter: true,
          IdList: [],
          listAll: []
        }
      },
    
      created() {
        this.fetchDatas()
    
        this.updateStatus()
        this.fetchServiceStatus()
        this.fetchZKList()
        this.fetchInstanceList()
    
        this.chartListData = this.chartListData
    
        console.log('functionData:', this.functionData)
    
        var that = this
    
        this.ref = setInterval(function() {
          that.fetchDatas()
          that.fetchServiceStatus()
          that.updateStatus()
        }, 20000)
      },
      watch: {
        // 适应自选业务域进行数据统计
        doFilter(val) {
          this.unknownNumber = 0
          this.ServiceErrorNumber = 0
          this.serviceNumber = 0
          this.ModulealarmNumber = 0
    
          this.safeNumber = 0
    
          this.UnmonitorNumber = 0
          // console.log(val)
          if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
            // new Array().includes
            let alarmCounter = 0
            this.IdList = []
            for (const i of this.list) {
              if (this.$store.state.user.preferModules.includes(i.objectName)) {
                if (i['status'] === '告警')alarmCounter = alarmCounter + 1
              }
              // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            }
            for (const i of this.listAll) {
              if (this.$store.state.user.preferModules.includes(i.instanceName)) {
                this.IdList.push(i.id)
              }
              // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            }
            this.alarmNumber = alarmCounter
            console.log('this.IdList', this.IdList)
            for (const i of this.updateList) {
              if (this.IdList.includes(i.instanceId)) {
                if (i.status === '未采集数据') this.unknownNumber++
    
                if (i.status === '未启用监控') this.UnmonitorNumber++
    
                if (i.status === '正常') this.safeNumber++
    
                if (i.status === '告警') this.ModulealarmNumber++
              }
            }
            for (const i of this.serviceStatusList) {
              // console.log(this.IdList.includes(i.instanceId),i.instanceId)
              if (this.$store.state.user.preferModules.includes(i.message)) {
                // console.log('service:', i.message,this.$store.state.user.preferModules)
                this.serviceNumber = this.serviceNumber + 1
                if (i.status === '告警') {
                  this.ServiceErrorNumber = this.ServiceErrorNumber + 1
                }
              }
            }
          } else {
            let alarmCounter = 0
            for (const i of this.list) {
              if (i['status'] === '告警')alarmCounter = alarmCounter + 1
              // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            }
            this.alarmNumber = alarmCounter
            for (const i of this.updateList) {
              if (i.status === '未采集数据') this.unknownNumber++
    
              if (i.status === '未启用监控') this.UnmonitorNumber++
    
              if (i.status === '正常') this.safeNumber++
    
              if (i.status === '告警') this.ModulealarmNumber++
            }
            this.serviceNumber = this.serviceStatusList.length
            for (const i of this.serviceStatusList) {
              if (i.status === '告警') {
                this.ServiceErrorNumber = this.ServiceErrorNumber + 1
              }
            }
          }
        },
        list(val) {
          if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
            // new Array().includes
            let alarmCounter = 0
            this.IdList = []
            for (const i of this.list) {
              if (this.$store.state.user.preferModules.includes(i.objectName)) {
                if (i['status'] === '告警')alarmCounter = alarmCounter + 1
                this.IdList.push(i.objectId)
              }
              // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            }
            this.alarmNumber = alarmCounter
            // console.log('this.IdList', this.IdList)
          } else {
            let alarmCounter = 0
            for (const i of this.list) {
              if (i['status'] === '告警')alarmCounter = alarmCounter + 1
              // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            }
            this.alarmNumber = alarmCounter
          }
        },
        updateList(val) {
          this.unknownNumber = 0
    
          this.ModulealarmNumber = 0
    
          this.safeNumber = 0
    
          this.UnmonitorNumber = 0
          if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
            // new Array().includes
            this.IdList = []
            for (const i of this.listAll) {
              if (this.$store.state.user.preferModules.includes(i.instanceName)) {
                this.IdList.push(i.id)
              }
              // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            }
            // console.log('this.IdList', this.IdList)
            for (const i of this.updateList) {
              if (this.IdList.includes(i.instanceId)) {
                if (i.status === '未采集数据') this.unknownNumber++
    
                if (i.status === '未启用监控') this.UnmonitorNumber++
    
                if (i.status === '正常') this.safeNumber++
    
                if (i.status === '告警') this.ModulealarmNumber++
              }
            }
          } else {
            for (const i of this.updateList) {
              if (i.status === '未采集数据') this.unknownNumber++
    
              if (i.status === '未启用监控') this.UnmonitorNumber++
    
              if (i.status === '正常') this.safeNumber++
    
              if (i.status === '告警') this.ModulealarmNumber++
            }
          }
        },
        serviceStatusList(val) {
          this.ServiceErrorNumber = 0
          this.serviceNumber = 0
          if (this.doFilter && this.$store.state.user.preferModules[0] !== 'ALL') {
            // new Array().includes
            // this.IdList = []
            // for (const i of this.listAll) {
            //   if (this.$store.state.user.preferModules.includes(i.message)) {
            //     this.IdList.push(i.id)
            //   }
            //   // console.log('include',this.$store.state.user.preferModules.includes(i.moduleName))
            // }
            // console.log('this.IdList', this.IdList)
            for (const i of this.serviceStatusList) {
              if (this.$store.state.user.preferModules.includes(i.message)) {
                this.serviceNumber = this.serviceNumber + 1
                if (i.status === '告警') {
                  this.ServiceErrorNumber = this.ServiceErrorNumber + 1
                }
              }
            }
          } else {
            this.serviceNumber = this.serviceStatusList.length
            for (const i of this.serviceStatusList) {
              if (i.status === '告警') {
                this.ServiceErrorNumber = this.ServiceErrorNumber + 1
              }
            }
          }
        }
  },
      methods: {
        fetchInstanceList() {
          // 获取所有实例状态
          queryInstance('', true).then(response => {
            console.log('queryInstance:', response)
            this.listAll = response.data.instanceList
          })
        },
        fetchServiceStatus() {
          queryServiceStatus('').then(response => {
            console.log('queryServiceStatus', response)
            this.ServiceErrorNumber = 0
            this.serviceNumber = response.data.serviceStatus.length
            this.serviceStatusList = response.data.serviceStatus
            for (const i of response.data.serviceStatus) {
              if (i.status === '告警') {
                this.ServiceErrorNumber = this.ServiceErrorNumber + 1
              }
            }
          })
        },
        fetchZKList() {
          getModuleStatus().then(response => {
            for (const i of response.data.moduleInstance) {
              if (i.moduleName === 'ZooKeeper') {
                this.moduleId = i.moduleId
                this.zookeeperList = [...i.clusters]
    
                break
              }
            }
    
            getModuleStatusUpdate(this.timeOut).then(response => {
              this.updateList = response.data.monitorStatus
    
              //   console.log('statusLIst:', this.updateList)
    
              for (const tmp of this.updateList) {
                let markFlag = 0
    
                for (let value = 0; value < this.zookeeperList.length; value++) {
                  if (markFlag === 1) break
    
                  for (let value1 = 0; value1 < this.zookeeperList[value].instances.length; value1++) {
                    if (this.zookeeperList[value].instances[value1].instanceId === tmp.instanceId) {
                      this.zookeeperList[value].instances[value1].status = tmp.status
                      if (tmp.message != null && tmp.message.zkrole !== undefined) { this.zookeeperList[value].instances[value1].serverIp = this.zookeeperList[value].instances[value1].serverIp + ':' + tmp.message.zkrole }
    
                      markFlag = 1
    
                    //   console.log(this.zookeeperList[value].instances[value1].status)
                    }
                  }
                }
              }
    
            //   console.log('ZKList:', this.zookeeperList)
            })
          })
        },
    
        handleSetLineChartData(type, name) {
          this.$emit('handleSetLineChartData', type, name)
        },
    
        handleViewAlarm() {
        //   this.$router.push('/alarm/alarmStatus')
          this.$router.push({ path: '/alarm/alarmStatus', query: {
            doFilter: this.doFilter
          }})
        },
    
        handleViewModuleStatus() {
          this.$router.push({ path: '/monitor/moduleStatus', query: {
            doFilter: this.doFilter
          }})
        },
    
        fetchDatas() {
          getAlarmStatus(1, '', '').then(response => {
            console.log('alarmList:', response)
    
            this.list = response.data.alarmList
    
            // console.log(this.list)
            let alarmCounter = 0
            for (const i of this.list) {
              if (i['status'] === '告警')alarmCounter = alarmCounter + 1
            }
            this.alarmNumber = alarmCounter
          })
        },
    
        updateStatus() {
          this.unknownNumber = 0
    
          this.ModulealarmNumber = 0
    
          this.safeNumber = 0
    
          this.UnmonitorNumber = 0
    
          getModuleStatusUpdate(this.timeOut).then(response => {
            console.log('getModuleStatusUpdate', response)
    
            this.updateList = response.data.monitorStatus
    
            for (const i of this.updateList) {
              if (i.status === '未采集数据') this.unknownNumber++
    
              if (i.status === '未启用监控') this.UnmonitorNumber++
    
              if (i.status === '正常') this.safeNumber++
    
              if (i.status === '告警') this.ModulealarmNumber++
            }
          })
        },
        handleDetailInfo: function(instanceID, serverIP, moduleId, moduleName) {
          // let queryStatus = ''
          // if (Status === '正常') {
          //   queryStatus = '0'
          // } else if (Status === '告警') {
          //   queryStatus = '1'
          // } else if (Status === '未采集数据') {
          //   queryStatus = '-1'
          // } else if (Status === '未启用监控') {
          //   queryStatus = '-1'
          // }
          // console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
          // this.$router.push('/monitor/instanceStatus/' + -1 + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
          console.log('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
          this.$router.push('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + moduleName + ':' + serverIP.replace(new RegExp(/\./g), '_'))
          // window.parent.addTab(title, seqUrl)
        }
    
      },
    
      destroyed: function() {
        clearInterval(this.ref)
      }
    
    }
</script>


<style lang="scss" scoped>
.outsideContainer{
    margin-bottom: 20px;
    }
.theme-title{
    line-height: 18px;
    
                    color: rgba(1, 101, 141, 0.6);
    
                    font-size: 26px;
    
                    margin-bottom: 12px;
}

    .panel-group {
    
        margin-top: 0px;

    

    
        .card-panel-col {
    
            margin-bottom: 10px;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.1);
            .chart-container {
    
                height: 200px;
    
                position: relative;
    
                display: flex;
    
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
            }
            .zk-container {
    
                height: auto;
    
                position: relative;
    
                display: block;

                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
                .selectButton {
                    margin-left: 10px;
                     width: 180px;
                     margin-bottom: 10px;
                }
    
            }
    
        }
        
        .card-panel-header {
    
            height: auto;
    
            cursor: pointer;
    
            font-size: 12px;
    
            position: relative;
    
            overflow: hidden;
    
            color: #666;
    
            background: #fff;
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
            border-color: rgba(0, 0, 0, .05);
    
        }
    
        .card-panel {
    
            height: auto;
    
            cursor: pointer;
    
            font-size: 12px;
    
            position: relative;
    
            overflow: hidden;
    
            color: #666;
    
            background: #fff;
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
            border-color: rgba(0, 0, 0, .05);
    
            &:hover {
    
                .card-panel-icon-wrapper {
    
                    color: #fff;
    
                }
    
                .icon-warning {
    
                    background: #f80606;
    
                }
    
                .icon-module {
    
                    background: #f0be1d;
    
                }
    
                .icon-gateway {
    
                    background: #2109f7;
    
                }
    
                .icon-trade {
    
                    background: #34bfa3;
    
                }
    
                .icon-credit {
    
                    background: #f518e2;
    
                }
    
                .icon-router {
    
                    background: #3f0186;
    
                }
                .icon-cluster{
    
                    background: #015313;
    
                }
    
            }
    
            .icon-warning {
    
                color: #f80606;
    
            }
    
            .icon-module {
    
                color: #f0be1d;
    
            }
    
            .icon-gateway {
    
                color: #2109f7;
    
            }
    
            .icon-trade {
    
                color: #34bfa3;
    
            }
    
            .icon-credit {
    
                color: #f518e2;
    
            }
    
            .icon-router {
    
                color: #3f0186;
    
            }
            .icon-cluster{
    
                    color: #015313;
    
            }
    
            .card-panel-icon-wrapper {
    
                float: left;
    
                margin: 14px 0 10px 14px;
    
                padding: 16px;
    
                transition: all 0.38s ease-out;
    
                border-radius: 6px;
    
            }
    
            .card-panel-icon {
    
                float: left;
    
                font-size: 48px;
    
            }
    
            .card-panel-description {
    
                float: right;
    
                font-weight: bold;
    
                margin: 26px;
    
                margin-left: 0px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
            .card-panel-descriptions {
    
                float: left;
    
                font-weight: bold;
    
                margin: 26px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
        }
    
    }
.card-panel-num-service-warning{
    font-size: 20px;
    color: #f80606
}
.card-panel-num-service-health{
    font-size: 20px;
    color: #268102
}
.card-panel-num-service-uncaculate{
    font-size: 20px;
    color: #bb6a00
}
</style>
