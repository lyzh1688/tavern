<template>
    <el-card class="outsideContainer">
    <div> <span class="theme-title">{{themeName}}</span></div>
        <el-row class="panel-group" :gutter="30" >
            <div class="warp-group">
                <div class='card-panelA' v-for="moduleItem in zookeeperList" :key="moduleItem.moduleId" :style="moduleItem.clusters!=undefined?moduleItem.clusters[0].instances!=undefined&&moduleItem.clusters[0].instances[0].metric!=undefined?'order:' + (moduleItem.clusters.length*100+moduleItem.clusters[0].instances.length*10+moduleItem.clusters[0].instances[0].metric.length):'order:' + (moduleItem.clusters.length*100):'order:0'">

    
                    <div class="card-panel-description">
    
                        <div class="card-panel-text">{{moduleItem.moduleName}}</div>
                        <div  v-for="clusters in moduleItem.clusters" :key="clusters.clusterName">
                            <div class="card-panel-text">{{clusters.clusterName}}</div>
                <div class='zk-container'
                            v-for="itemB in clusters.instances"
                                    :key="itemB.instanceId">
                                    <div   class="card-panel-cols">
                                <el-button
                                    :type="itemB.status === '正常' ? 'success': (itemB.status === '未采集数据' ? 'warning':(itemB.status === '未启用监控' ? 'info':'danger'))"
                                    size="mini"
                                    class="selectButton"
                                    @click="handleDetailInfo(itemB.instanceId,itemB.serverIp,moduleItem.moduleId,moduleItem.moduleName)">
                                    {{itemB.serverIp}}
                                </el-button> 
                                </div>
                              <div   class="card-panel-cols" 
                v-for="itmeMetric in itemB.metric"
                :key="itmeMetric.id">  
                <div class='card-panel'  v-if="itmeMetric.metricType=='counter'||itmeMetric.metricType=='gauge'" 
                                :key="itmeMetric.id">
                  <div class="card-panel-icon-wrapper icon-gateway">
    
                           <div class="MetricsContainer">
    
                        <div v-if="itmeMetric.nickname == null||itmeMetric.nickname == ''" class="card-panel-textA"><span>{{itmeMetric.metric}}</span></div>
                        <div v-else class="card-panel-textA"><span>{{itmeMetric.nickname}}</span></div>
                        <div class="card-panel-num">{{itmeMetric[itmeMetric.metric]}}</div>
    
                    </div>
    
                </div>
                    
    
                </div>
                <div class='card-panel' v-if="itmeMetric.metricType=='timer'||itmeMetric.metricType=='meter'" 
                                :key="itmeMetric.id">
                  <div class="card-panel-icon-wrapper icon-gateway">
    
                           <div class="MetricsContainer">
    
                        <div v-if="itmeMetric.nickname == null||itmeMetric.nickname == ''" class="card-panel-textA"><span>{{itmeMetric.metric}}</span></div>
                        <div v-else class="card-panel-textA"><span>{{itmeMetric.nickname}}</span></div>
                        <count-to v-if="itmeMetric[itmeMetric.metric]!=undefined" class="card-panel-num" :startVal="0" :endVal="itmeMetric[itmeMetric.metric].m1Rate" :duration="3000"></count-to>
    
                    </div>
    
                </div>
                    
    
                </div>
                </div>
    
            </div>
                            </div>
                        </div>
                    </div>
                    </div>
    
    
    
        </el-row>
    </el-card>
</template>


<script>
    import CountTo from 'vue-count-to'
    
    import {
    
      // getModuleStatusUpdate,
    
      // getModuleStatus,

      // // queryServiceStatus,

      // getMetricsGaugesLatest,

      // getMetricsTimerLatest,
    
      // queryinstanceMetrics,
      modulesGroupQuery,
      statusGroupQuery,
      groupMetricsLatest
    
    } from '@/api/monitor'
//     import {
//   formatDate
// } from '@/store/date'
// import {
//   Message
// } from 'element-ui'
    import innerBarChart from '@/components/Charts/innerBarchart'
// import Axios from 'axios'

export default {
    
      props: {
    
        functionData: {
    
          type: Array,
    
          default: null
    
        },
        themeName: {
    
          type: String,
    
          default: '未知名称主题'
    
        }
    
      },
    
      components: {
    
        CountTo,
    
        innerBarChart
    
      },
    
      data() {
        return {
          list: null,
    
          updateList: null,
    
          zookeeperList: [],
    
          timeOut: '30',
    
          unknownNumber: 0,
    
          safeNumber: 0,
    
          ModulealarmNumber: 0,
    
          UnmonitorNumber: 0,
    
          alarmNumber: 0,
    
          ref: null,
    
          chartListData: null,
    
          ServiceErrorNumber: 0,

          serviceStatusList: [1],
          updateMetricsList: {}
    
        }
      },
    
      created() {
        console.log('functionData:', this.functionData)
        this.fetchZKList()
        var that = this
    
        this.ref = setInterval(function() {
          that.updateInfo()
        }, 20000)
      },
      methods: {
        // fetchServiceStatus() {
        //   queryServiceStatus('').then(response => {
        //     this.ServiceErrorNumber = 0
        //     this.serviceStatusList = response.data.serviceStatus
        //     for (const i of response.data.serviceStatus) {
        //       if (i.status === '告警') {
        //         this.ServiceErrorNumber = this.ServiceErrorNumber + 1
        //       }
        //     }
        //   })
        // },
        fetchZKList() {
          const requestgroup = []
          this.zookeeperList = []
          if (this.functionData.length > 0) {
            for (const module of this.functionData) {
              if (module !== '') {
                // console.log('module.split()[0]', module.split(':')[0])
                requestgroup.push(module.split(':')[0])
              }
            }
            modulesGroupQuery(requestgroup).then(response => {
              const compare = function(obj1, obj2) {
                let val1 = 0
                let val2 = 0
                let counter = 0
                let flag1 = true
                let flag2 = true
                for (const i of this.functionData) {
                  if (obj1.moduleName === i.split(':')[0]) {
                    flag1 = false
                    val1 = counter
                  }
                  if (obj2.moduleName === i.split(':')[0]) {
                    flag2 = false
                    val2 = counter
                  }
                  if (!(flag1 || flag2)) break
                  counter = counter + 1
                }
                // console.log('compare:', val1, val2)
                if (val1 > val2) return 1
                else if (val1 < val2) return -1
                else return 0
              }.bind(this)
              const isntanceIdList = []
              if (response.code === 0) {
                this.zookeeperList = JSON.parse(JSON.stringify(response.data.moduleInstance.sort(compare)))
                for (const p of this.zookeeperList) {
                  if (p.clusters === undefined) continue
                  for (const q of p.clusters) {
                    if (q.instances === undefined) continue
                    for (const s of q.instances) {
                      isntanceIdList.push(s.instanceId)
                    }
                  }
                }
              }
              statusGroupQuery(this.timeOut, isntanceIdList).then(responses => {
                this.updateList = responses.data.monitorStatus
                console.log('this.updateList', this.updateList)
                const compare = function(obj1, obj2) {
                  // // console.log('conpare', obj1, obj2)
                  // const val1 = obj1.metric
                  // const val2 = obj2.metric
                  // if (val1 > val2) return 1
                  // else if (val1 < val2) return -1
                  // else return 0
                  return -obj1.metric.localeCompare(obj2.metric)
                }
                groupMetricsLatest(isntanceIdList).then(responsess => {
                  this.updateMetricsList = responsess.data.groupInstanceMetrics
                  console.log('this.updateMetricsList', this.updateMetricsList)
                  // const requestgroup2 = []
                  // const requestgroup3 = []
                  for (const tmp of this.updateList) {
                    const markFlag = 0
                    for (let value = 0; value < this.zookeeperList.length; value++) {
                      if (markFlag === 1) break
                      // console.log(' this.zookeeperList[value]', this.zookeeperList[value])
                      for (let value1 = 0; value1 < this.zookeeperList[value].clusters.length; value1++) {
                        if (markFlag === 1) break
                        for (let value2 = 0; value2 < this.zookeeperList[value].clusters[value1].instances.length; value2++) {
                          if (markFlag === 1) break
                          if (this.zookeeperList[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
                            this.zookeeperList[value].clusters[value1].instances[value2].status = tmp.status
                            this.zookeeperList[value].clusters[value1].instances[value2].remark = tmp.message
                            if (this.updateMetricsList[this.zookeeperList[value].clusters[value1].instances[value2].instanceId] !== undefined) this.zookeeperList[value].clusters[value1].instances[value2]['metric'] = this.updateMetricsList[this.zookeeperList[value].clusters[value1].instances[value2].instanceId].sort(compare)
                          }
                        }
                      }
                    }
                  }
                  this.zookeeperList = JSON.parse(JSON.stringify(this.zookeeperList))
                  console.log('finalList:', this.zookeeperList)
                })
              })
              //     getModuleStatusUpdate(this.timeOut).then(response => {
              //       this.updateList = response.data.monitorStatus
    
              //       //   console.log('statusLIst:', this.updateList)
              //       const requestgroup2 = []
              //       // const requestgroup3 = []
              //       for (const tmp of this.updateList) {
              //         let markFlag = 0
              //         for (let value = 0; value < this.zookeeperList.length; value++) {
              //           if (markFlag === 1) break
              //           // console.log(' this.zookeeperList[value]', this.zookeeperList[value])
              //           for (let value1 = 0; value1 < this.zookeeperList[value].clusters.length; value1++) {
              //             if (markFlag === 1) break
              //             for (let value2 = 0; value2 < this.zookeeperList[value].clusters[value1].instances.length; value2++) {
              //               if (markFlag === 1) break
              //               if (this.zookeeperList[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
              //                 this.zookeeperList[value].clusters[value1].instances[value2].status = tmp.status
              //                 this.zookeeperList[value].clusters[value1].instances[value2].remark = tmp.message
              //                 requestgroup2.push(
              //                   queryinstanceMetrics(this.zookeeperList[value].clusters[value1].instances[value2].instanceId).then(response => {
              //                     console.log(response)
              //                     this.zookeeperList[value].clusters[value1].instances[value2]['metric'] = response.data.instanceMetrics.map(v => {
              //                       // console.log('v', v)
              //                       if (v.metricType === 'counter' || v.metricType === 'gauge') {
              //                         this.$set(v, v.metric, { data: NaN })
              //                       }
              //                       if (v.metricType === 'timer' || v.metricType === 'meter') {
              //                         this.$set(v, v.metric, { m1Rate: NaN, m5Rate: NaN, m15Rate: NaN })
              //                       }
              //                       // this.$set(v, 'deleteFlag', false)
              //                       return v
              //                     })
              //                     if (response.data.instanceMetrics.length > 0) {
              //                       for (const metric of this.zookeeperList[value].clusters[value1].instances[value2]['metric']) {
              //                         var nowTime = new Date()
              //                         // nowTime.setDate(21)
              //                         nowTime.setHours(0)
              //                         nowTime.setMinutes(0)
              //                         nowTime.setSeconds(0)
              //                         const startTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
              //                         nowTime = new Date()
              //                         // nowTime.setDate(21)
              //                         nowTime.setHours(23)
              //                         nowTime.setMinutes(59)
              //                         nowTime.setSeconds(59)
              //                         const endTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
              //                         if (metric.metricType === 'counter' || metric.metricType === 'gauge') {
              //                           if (metric[metric.metric] === undefined) metric[metric.metric] = { data: NaN }
              //                           getMetricsGaugesLatest(this.zookeeperList[value].clusters[value1].instances[value2].instanceId, metric.metric, startTime, endTime).then(response => {
              //                             if (response.data.metricsGauges !== null) {
              //                               if (metric[metric.metric] === undefined) metric[metric.metric] = { data: NaN }
              //                               metric[metric.metric] = {
              //                                 data: response.data.metricsGauges.data
              //                               }
              //                               this.zookeeperList = Object.assign({}, this.zookeeperList)
              //                             } else {
              //                               Message.error(metric.metric + '无数据')
              //                             }
              //                           })
              //                         }
              //                         if (metric.metricType === 'timer' || metric.metricType === 'meter') {
              //                           if (metric[metric.metric] === undefined) metric[metric.metric] = { m1Rate: NaN, m5Rate: NaN, m15Rate: NaN }
              //                           getMetricsTimerLatest(this.zookeeperList[value].clusters[value1].instances[value2].instanceId, metric.metric, startTime, endTime).then(response => {
              //                             if (response.data.metricsTimer !== null) {
              //                               if (metric[metric.metric] === undefined) metric[metric.metric] = { m1Rate: NaN, m5Rate: NaN, m15Rate: NaN }
              //                               metric[metric.metric] = {
              //                                 m1Rate: response.data.metricsTimer.m1Rate,
              //                                 m5Rate: response.data.metricsTimer.m5Rate,
              //                                 m15Rate: response.data.metricsTimer.m15Rate
              //                               }
              //                               this.zookeeperList = Object.assign({}, this.zookeeperList)
              //                             } else {
              //                               Message.error(metric.metric + '无数据')
              //                             }
              //                           })
              //                         }
              //                         if (metric.metricType === 'histogram')Message.error('暂不支持histogram数据')
              //                       }
              //                     }
              //                   }))
              //                 markFlag = 1
              //                 console.log(this.zookeeperList[value].clusters[value1].instances[value2].status)
              //               }
              //             }
              //           }
              //         }
              //       }
              //       Axios.all(requestgroup2).then(function() {
              //         console.log('finalTableData:', this.zookeeperList)
              //         this.zookeeperList = Object.assign({}, this.zookeeperList)
              //       }.bind(this))
              //       //   console.log('ZKList:', this.zookeeperList)
            })
            // }.bind(this))
          }
        },
        updateInfo() {
          const isntanceIdList = []
          for (const p of this.zookeeperList) {
            if (p.clusters === undefined) continue
            for (const q of p.clusters) {
              if (q.instances === undefined) continue
              for (const s of q.instances) {
                isntanceIdList.push(s.instanceId)
              }
            }
          }
          statusGroupQuery(this.timeOut, isntanceIdList).then(responses => {
            this.updateList = responses.data.monitorStatus
            console.log('this.updateList', this.updateList)
            const compare = function(obj1, obj2) {
              // // console.log('conpare', obj1, obj2)
              // const val1 = obj1.metric
              // const val2 = obj2.metric
              // if (val1 > val2) return 1
              // else if (val1 < val2) return -1
              // else return 0
              return -obj1.metric.localeCompare(obj2.metric)
            }
            groupMetricsLatest(isntanceIdList).then(responsess => {
              this.updateMetricsList = responsess.data.groupInstanceMetrics
              console.log('this.updateMetricsList', this.updateMetricsList)
              // const requestgroup2 = []
              // const requestgroup3 = []
              for (const tmp of this.updateList) {
                const markFlag = 0
                for (let value = 0; value < this.zookeeperList.length; value++) {
                  if (markFlag === 1) break
                  // console.log(' this.zookeeperList[value]', this.zookeeperList[value])
                  for (let value1 = 0; value1 < this.zookeeperList[value].clusters.length; value1++) {
                    if (markFlag === 1) break
                    for (let value2 = 0; value2 < this.zookeeperList[value].clusters[value1].instances.length; value2++) {
                      if (markFlag === 1) break
                      if (this.zookeeperList[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
                        this.zookeeperList[value].clusters[value1].instances[value2].status = tmp.status
                        this.zookeeperList[value].clusters[value1].instances[value2].remark = tmp.message
                        if (this.updateMetricsList[this.zookeeperList[value].clusters[value1].instances[value2].instanceId] !== undefined) this.zookeeperList[value].clusters[value1].instances[value2]['metric'] = this.updateMetricsList[this.zookeeperList[value].clusters[value1].instances[value2].instanceId].sort(compare)
                      }
                    }
                  }
                }
              }
              this.zookeeperList = JSON.parse(JSON.stringify(this.zookeeperList))
              console.log('updatefinalList:', this.zookeeperList)
            })
          })
          // getModuleStatusUpdate(this.timeOut).then(response => {
          //   this.updateList = response.data.monitorStatus
          //   //   console.log('statusLIst:', this.updateList)
          //   // const requestgroup2 = []
          //   // const requestgroup3 = []
          //   for (const tmp of this.updateList) {
          //     let markFlag = 0
          //     for (let value = 0; value < Object.getOwnPropertyNames(this.zookeeperList).length - 1; value++) {
          //       if (markFlag === 1) break
          //       // console.log(' this.zookeeperList[value]', this.zookeeperList[value])
          //       for (let value1 = 0; value1 < this.zookeeperList[value].clusters.length; value1++) {
          //         if (markFlag === 1) break
          //         for (let value2 = 0; value2 < this.zookeeperList[value].clusters[value1].instances.length; value2++) {
          //           if (markFlag === 1) break
          //           if (this.zookeeperList[value].clusters[value1].instances[value2].instanceId === tmp.instanceId) {
          //             this.zookeeperList[value].clusters[value1].instances[value2].status = tmp.status
          //             this.zookeeperList[value].clusters[value1].instances[value2].remark = tmp.message
          //             if (this.zookeeperList[value].clusters[value1].instances[value2]['metric'].length > 0) {
          //               for (const metric of this.zookeeperList[value].clusters[value1].instances[value2]['metric']) {
          //                 var nowTime = new Date()
          //                 // nowTime.setDate(21)
          //                 nowTime.setHours(0)
          //                 nowTime.setMinutes(0)
          //                 nowTime.setSeconds(0)
          //                 const startTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
          //                 nowTime = new Date()
          //                 // nowTime.setDate(21)
          //                 nowTime.setHours(23)
          //                 nowTime.setMinutes(59)
          //                 nowTime.setSeconds(59)
          //                 const endTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
          //                 if (metric.metricType === 'counter' || metric.metricType === 'gauge') {
          //                   getMetricsGaugesLatest(this.zookeeperList[value].clusters[value1].instances[value2].instanceId, metric.metric, startTime, endTime).then(response => {
          //                     if (response.data.metricsGauges !== null) {
          //                       // metric[metric.metric] = []
          //                       metric[metric.metric] = {
          //                         data: response.data.metricsGauges.data
          //                       }
          //                       this.zookeeperList = Object.assign({}, this.zookeeperList)
          //                     } else {
          //                       Message.error(metric.metric + '无数据')
          //                     }
          //                   })
          //                 }
          //                 if (metric.metricType === 'timer' || metric.metricType === 'meter') {
          //                   getMetricsTimerLatest(this.zookeeperList[value].clusters[value1].instances[value2].instanceId, metric.metric, startTime, endTime).then(response => {
          //                     if (response.data.metricsTimer !== null) {
          //                       // metric[metric.metric] = []
          //                       metric[metric.metric] = {
          //                         m1Rate: response.data.metricsTimer.m1Rate,
          //                         m5Rate: response.data.metricsTimer.m5Rate,
          //                         m15Rate: response.data.metricsTimer.m15Rate
          //                       }
          //                       this.zookeeperList = Object.assign({}, this.zookeeperList)
          //                     } else {
          //                       Message.error(metric.metric + '无数据')
          //                     }
          //                   })
          //                 }
          //                 if (metric.metricType === 'histogram')Message.error('暂不支持histogram数据')
          //               }
          //             }
          //             markFlag = 1
          //             console.log(this.zookeeperList[value].clusters[value1].instances[value2].status)
          //           }
          //         }
          //       }
          //     }
          //   }
          //   // Axios.all(requestgroup2).then(function() {
          //   //   console.log('finalTableData:', this.zookeeperList)
          //   //   this.zookeeperList = Object.assign({}, this.zookeeperList)
          //   // }.bind(this))
          //   //   console.log('ZKList:', this.zookeeperList)
          // })
        },
        handleDetailInfo: function(instanceID, serverIP, moduleId, moduleName) {
          // let queryStatus = ''
          // if (Status === '正常') {
          //   queryStatus = '0'
          // } else if (Status === '告警') {
          //   queryStatus = '1'
          // } else if (Status === '未采集数据') {
          //   queryStatus = '-1'
          // } else if (Status === '未启用监控') {
          //   queryStatus = '-1'
          // }
          // console.log('/monitor/instanceStatus/' + serverIP.replace(new RegExp(/\./g), '_'))
          // this.$router.push('/monitor/instanceStatus/' + -1 + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
          console.log('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + serverIP.replace(new RegExp(/\./g), '_'))
          this.$router.push('/monitor/instanceDetail/' + moduleId + '/' + instanceID + '/' + moduleName + ':' + serverIP.replace(new RegExp(/\./g), '_'))
          // window.parent.addTab(title, seqUrl)
        }
  },
      destroyed: function() {
        clearInterval(this.ref)
      }
    
    }
</script>


<style lang="scss" scoped>
.warp-group{
    display: -webkit-flex;
    display: flex;
    // flex-direction: row;
    flex-wrap: wrap;
}
.outsideContainer{
    margin-bottom: 20px;
    }
.theme-title{
    line-height: 18px;
    
                    color: rgba(1, 101, 141, 0.6);
    
                    font-size: 26px;
    
                    margin-bottom: 12px;
}
.zk-container{
    margin-top: 10px;
    padding: 10px;
    display: -webkit-flex;
    display: flex;
    // flex-direction: row;
    flex-wrap: nowrap;
}
.card-panelA{
                // height: auto;
            // flex: auto;
            cursor: pointer;
            flex-grow: 1;
            min-height: 150px;
            font-size: 12px;
            // position: relative;
            padding: 5px;
            margin-left:10px;
            margin-top: 5px;
            overflow: auto;
            vertical-align: top;
            color: #666;
    
            background: rgb(255, 255, 255);
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.233);
    
            border-color: rgba(0, 0, 0, .05);
            .card-panel-description {
    
                // display: flex;
                // flex-wrap: wrap;
    
                font-weight: bold;
    
                
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
}
.selectButton {
                    margin-left: 10px;
                     width: 140px;
                     margin-bottom: 10px;
                }
.MetricsContainer{
    
                
    
                font-weight: bold;
    
                
    
                margin-left: 0px;
    
                .card-panel-textA {
                    line-height: 18px;
    
                    // color: rgba(0, 0, 0, 0.45);
    
                    font-size: 20px;
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 10px;
    
                }
}
    .panel-group {
    
        margin-top: 0px;
        width: 100%;
        // display: flex;
        .card-panel-col {
            display: inline-block;
            margin-bottom: 10px;
 box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.1);
    
            .chart-container {
    
                height: 200px;

                position: relative;
    
                display: flex;
    
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
            }
            
    
        }
        
        .card-panel-header {
    
            height: auto;
    
            cursor: pointer;
    
            font-size: 12px;
    
            position: relative;
    
            overflow: hidden;
    
            color: #666;
    
            background: #fff;
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
            border-color: rgba(0, 0, 0, .05);
    
        }
    
        .card-panel {
            
            height: auto;

            cursor: pointer;

            margin-bottom: 10px;
    
            font-size: 12px;
            
            float: right;
    
            overflow: hidden;
    
            color: #666;
    
            background: #fff;
    
            box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
            border-color: rgba(0, 0, 0, .05);
    
            &:hover {
    
                .card-panel-icon-wrapper {
    
                    color: #fff;
    
                }
    
                .icon-warning {
    
                    background: #f80606;
    
                }
    
                .icon-module {
    
                    background: #f0be1d;
    
                }
    
                .icon-gateway {
    
                    background: #2109f7;
    
                }
    
                .icon-trade {
    
                    background: #34bfa3;
    
                }
    
                .icon-credit {
    
                    background: #f518e2;
    
                }
    
                .icon-router {
    
                    background: #3f0186;
    
                }
                .icon-cluster{
    
                    background: #015313;
    
                }
    
            }
    
            .icon-warning {
    
                color: #f80606;
    
            }
    
            .icon-module {
    
                color: #f0be1d;
    
            }
    
            .icon-gateway {
    
                color: #2109f7;
    
            }
    
            .icon-trade {
    
                color: #34bfa3;
    
            }
    
            .icon-credit {
    
                color: #f518e2;
    
            }
    
            .icon-router {
    
                color: #3f0186;
    
            }
            .icon-cluster{
    
                    color: #015313;
    
            }
    
            .card-panel-icon-wrapper {
    
                float: left;
                margin-right: 5px;

                
    
                padding: 2px;
    
                transition: all 0.38s ease-out;
    
                border-radius: 6px;
    
            }
    
            .card-panel-icon {
    
                float: left;
    
                font-size: 48px;
    
            }
    
            .card-panel-description {
    
                float: left;
                min-height: 150px;
                font-weight: bold;
    
                margin: 26px;
    
                margin-left: 0px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                    margin-bottom: 12px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
            .card-panel-descriptions {
    
                float: left;
    
                font-weight: bold;
    
                margin: 26px;
    
                .card-panel-text {
    
                    line-height: 18px;
    
                    color: rgba(0, 0, 0, 0.45);
    
                    font-size: 16px;
    
                }
    
                .card-panel-num {
    
                    font-size: 20px;
    
                }
    
            }
    
        }
    
    }
.card-panel-num-service-warning{
    font-size: 20px;
    color: #f80606
}
.card-panel-num-service-health{
    font-size: 20px;
    color: #268102
}
.card-panel-num-service-uncaculate{
    font-size: 20px;
    color: #bb6a00
}
.card-panel-cols{
  width: auto;
}
</style>
