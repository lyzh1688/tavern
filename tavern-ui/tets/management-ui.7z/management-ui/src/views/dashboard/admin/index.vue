<template>
<div class="dashboard-editor-container">
  <div v-for="theme in themeList"
  :key="theme.themeName"
  >
    <panel-group
    v-if="theme.themeType=='envStatus'&&theme.showInPages.search('dashboard')!=-1"
        :functionData="functionData"
        :themeName="theme.themeName"
        @handleSetLineChartData="handleSetLineChartData"
    ></panel-group>
    <moduleTheme
    v-if="theme.themeType=='moduleTheme'&&theme.showInPages.search('dashboard')!=-1"
        :functionData="theme.itemsId.split(',')"
        :themeName="theme.themeName"
        @handleSetLineChartData="handleSetLineChartData"
    ></moduleTheme>
</div>
        <el-row
            v-show="isShow == true"
            style="background:#fff;padding:16px 16px 0;margin-bottom:32px;margin-top:-12px;"
        >
            <div class='chart-container'>
                <chart
                    height='100%'
                    width='100%'
                    :chart-data="lineChartData"
                    :className="classname"
                ></chart>
            </div>
            </el-row>
            <!-- <el-row  style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
        <div class='chart-container'>
     <innerBarChart height='100%' width='100%' :chartData="functionData.gwuserRequest" :className="classname"></innerBarChart>
       </div>
    </el-row> -->

</div>
</template>


<script>
import PanelGroup from './components/PanelGroup'
import Chart from '@/components/Charts/mixChart'
import innerBarChart from '@/components/Charts/innerBarchart'
import RaddarChart from './components/RaddarChart'
import PieChart from './components/PieChart'
import BarChart from './components/BarChart'
import TodoList from './components/TodoList'
import moduleTheme from './components/moduleTheme'
import {
  getMetricsTimer,
  getModuleList,
  queryInstance,
  queryThemeByName
} from '@/api/monitor'
import {
  formatDate
} from '@/store/date'
import axios from 'axios'
import {
  Message
} from 'element-ui'
// import { getModuleList } from '@/api/monitor'
const lineChartData = {
  gwuserRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }]
  },
  gwrouterRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }]
  },
  // 从普适性考虑名字改成如下模式，分别代表 gw-user,gw-router,spx-exchanger-trade,spx-exchanger-credit
  spxexchangertradeRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }]
  },
  spxexchangercreditRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }]
  }
}

export default {
  name: 'dashboard-admin',
  components: {
    PanelGroup,
    RaddarChart,
    Chart,
    PieChart,
    BarChart,
    TodoList,
    innerBarChart,
    moduleTheme
  },
  data() {
    return {
      lineChartData: null,
      classname: 'http请求数性能指标',
      list: null,
      themeList: null,
      keyword: 'request',
      isShow: false,
      ref: null,
      functionData: {
        gwuserRequest: lineChartData.gwuserRequest.functionData,
        gwrouterRequest: lineChartData.gwrouterRequest.functionData,
        spxexchangertradeRequest: lineChartData.spxexchangertradeRequest.functionData,
        spxexchangercreditRequest: lineChartData.spxexchangercreditRequest.functionData
      },
      history: '',
      themeNameList: ['envStatus', 'moduleTheme'],
      pageNameList: ['dashboard', 'test']
    }
  },
  created() {
    // console.log('dashboard Created!', this.$store.state.user.roles)
    // // gw-user,gw-router,spx-exchanger-trade,spx-exchanger-credit
    // this.formGrapData('gw-user', this.keyword)
    // this.formGrapData('gw-router', this.keyword)
    // this.formGrapData('spx-exchanger-trade', this.keyword)
    // this.formGrapData('spx-exchanger-credit', this.keyword)
    // this.formGrapData('gw-user', this.keyword)
    // this.formGrapData('gw-router', this.keyword)
    // this.formGrapData('spx-exchanger-trade', this.keyword)
    // this.formGrapData('spx-exchanger-credit', this.keyword)
    this.fetchThemeData()
    this.$store.dispatch('setThemeNameList', this.themeNameList)
    this.$store.dispatch('setPageNameList', this.pageNameList)
    // const that = this
    // this.ref = setInterval(function() {
    //   that.formGrapData('gw-user', that.keyword)
    //   that.formGrapData('gw-router', that.keyword)
    //   that.formGrapData('spx-exchanger-trade', that.keyword)
    //   that.formGrapData('spx-exchanger-credit', that.keyword)
    // }, 300000)
  },
  methods: {
    fetchThemeData() {
      this.listLoading = true
      queryThemeByName('', this.$store.state.user.name).then(response => {
        console.log(response)
        this.themeList = response.data.ThemeList
        console.log('themeList', this.themeList)
        this.listLoading = false
      }).catch(() => {
        this.listLoading = false
      })
    },
    handleSetLineChartData(type, name) {
      if (this.history === name) this.isShow = !this.isShow
      else {
        this.isShow = true
        this.history = name
      }
      this.lineChartData = lineChartData[type]
      this.classname = name
      console.log('type:' + type)
    },
    formGrapData(secction, keyword) {
      console.log(secction.replace(new RegExp(/-/g), '') + 'Request')
      getModuleList(secction, '', '', true, '', '').then(response => {
        this.list = response.data.ModuleList
        console.log('list:', this.list)
        var instancelist = []
        var requestGroup = []
        for (const i of this.list) {
          requestGroup.push(queryInstance(i['id'], true).then(response => {
            instancelist.push(...response.data.instanceList)
          }))
        }
        axios.all(requestGroup).then(function() {
          var nowTime = new Date()
          // nowTime.setDate(21)
          nowTime.setHours(0)
          nowTime.setMinutes(0)
          nowTime.setSeconds(0)
          const startTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
          nowTime = new Date()
          // nowTime.setDate(21)
          nowTime.setHours(23)
          nowTime.setMinutes(59)
          nowTime.setSeconds(59)
          const endTime = formatDate(nowTime, 'yyyy-MM-dd hh:mm:ss')
          requestGroup = []
          lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].xdata = []
          lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].ydata = []
          lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].namedata = []
          lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData = []
          for (const i of instancelist) {
            getMetricsTimer(i.id, keyword, startTime, endTime).then(response => {
              if (response.data.metricsTimer.length !== 0) {
                const tempx = []
                const tempy = []
                let mark = true
                for (const s of response.data.metricsTimer) {
                  if (mark) {
                    lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData.push({
                      name: i.serverIp,
                      m1Rate: s.m1Rate,
                      m5Rate: s.m5Rate,
                      m15Rate: s.m15Rate
                    })
                    // for (let test = 1; test < 10; test++) {
                    //   lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData.push({
                    //     name: (i.serverIp + test),
                    //     m1Rate: s.m1Rate + test,
                    //     m5Rate: s.m5Rate + test,
                    //     m15Rate: s.m15Rate + test
                    //   })
                    // }

                    mark = false
                  }
                  tempx.push(s.ts.substr(0, 4) + '' + s.ts.substr(4, 2) + '-' + s.ts.substr(6, 2) + ' ' + s.ts.substr(8, 2) + ':' + s.ts.substr(10, 2) + ':' + s.ts.substr(12, 2))
                  tempy.push(s.m1Rate)
                }
                lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].xdata.push(tempx.reverse())
                lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].ydata.push(tempy.reverse())
                lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].namedata.push(i.instanceName + ':' + i.serverIp)
              } else {
                Message.error(i.instanceName + ':' + i.serverIp + '无数据')
              }
            })
          }

          axios.all(requestGroup).then(function() {
            this.functionData[secction.replace(new RegExp(/-/g), '') + 'Request'] = lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'].functionData
            console.log(secction.replace(new RegExp(/-/g), '') + 'Request:', lineChartData[secction.replace(new RegExp(/-/g), '') + 'Request'])
          }.bind(this))
        }.bind(this))
      })
    }
  }
}
</script>


<style lang="scss" scoped>
.dashboard-editor-container {
    padding: 32px;
    background-color: rgb(240, 242, 245);
    .chart-wrapper {
        background: #fff;
        padding: 16px 16px 0;
        margin-bottom: 32px;
    }
}

.chart-container {
    // margin-top: -40px;
    padding: 20px;
    width: 100%;
    height: 45vh;
}
</style>
