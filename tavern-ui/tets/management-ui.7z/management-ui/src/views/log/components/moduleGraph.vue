<template>
  <div :class="className" :style="{height:height,width:width}"></div>
</template>

<script>
import echarts from 'echarts'
import resize from './mixins/resize'
require('echarts/theme/infographic') // echarts theme
import { debounce } from '@/utils'
import {
  graphTopology
} from '@/api/log'

export default {
  name: 'moduleGraph',
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '100%'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    autoResizeFlag: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      seq: '20180625110305561392',
      startTime: '2018-06-25 00:00:00',
      endTime: '2018-06-25 23:59:59',
      chart: null,
      retData: null,
      retLinks: null
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        if (val !== undefined) this.initChart()
        // if (this.chart !== null) this.chart.resize()
        // this.initChart(val)
        console.log('watch!')
      }
    },
    autoResizeFlag: {
      deep: true,
      handler(val) {
        var that = this
        setTimeout(() => {
          that.chart.resize()
          that.initChartGraph()
        }, 100)
      }
    }
  },
  mounted() {
    this.initChart()
    if (this.autoResize) {
      this.__resizeHanlder = debounce(() => {
        if (this.chart) {
          this.initChartGraph()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHanlder)
    }

    // 监听侧边栏的变化
    // const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    // sidebarElm.addEventListener('transitionend', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHanlder)
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'infographic')
      graphTopology(this.chartData.seq, this.chartData.startTime, this.chartData.endTime).then(response => {
        console.log('graphTopology ret :{}', response)
        this.retData = response.data.data

        this.retLinks = response.data.links
        this.initChartGraph()
      })
    },
    initChartGraph() {
      var moduleData = []
      var moduleLink = []
      var gatewayMarker = {}
      var labelStyle = {
        normal: {
          show: true
        }
      }

      var lineStyle1 = {
        normal: {
          color: 'rgba(21, 4, 253, 0.87)',
          lineSize: 20,
          curveness: 0 }
      }
      var lineStyle2 = {
        normal: {
          color: 'rgba(21, 4, 253, 0.87)',
          curveness: 0.3 }
      }
      for (var index1 in this.retData) {
        var data = this.retData[index1]
        if (data.type === 'GATEWAY' || data.type === 'METHOD') {
          let flag = true
          if (data.type === 'GATEWAY')gatewayMarker[data.name] = data.moduleName
          for (const i of moduleData) {
            if (i.moduleName === data.moduleName) {
              flag = false
              let flags = true
              for (const n in i['FuncName'].split(',')) {
                if (data.name.split('(')[0].trim() === i['FuncName'].split(',')[n].trim()) flags = false
              }
              if (flags)i['FuncName'] = i['FuncName'] + ',' + data.name.split('(')[0]
            }
          }
          if (flag) {
            const datas = Object.assign({}, data)
            if (datas['FuncName'] === undefined) datas['FuncName'] = datas.name.split('(')[0]
            datas.name = datas.moduleName
            // console.log('moduleName', datas.moduleName, datas.name)
            moduleData.push(datas)
          }
        }
      }

      for (var index2 in this.retLinks) {
        var link = this.retLinks[index2]
        if (link['sid'].split(',').length > 0) {
          link['id'] = link['protocol'] + ' X ' + link['sid'].split(',').length
        } else {
          link['id'] = link['protocol'] + ' X 1'
        }
        // link['id'] = link['sid']
        if (link['isSameLevel'])link['lineStyle'] = lineStyle2
        else link['lineStyle'] = lineStyle1
        link['label'] = labelStyle
        if (link.relationship === 'INVOKE_SPI') {
          let flag = true
          for (const i of moduleLink) {
            if (i.source.split('(').pop().split(')').shift() === link.source.split('(').pop().split(')').shift() && i.target.split('(').pop().split(')').shift() === link.target.split('(').pop().split(')').shift()) {
              const number = parseInt(i.id.split(' X ').pop()) + link['sid'].split(',').length
              i.id = i.protocol + ' X ' + number
              flag = false
            } else if (i.sid === link.source.split('(').pop().split(')').shift() && i.target.split('(').pop().split(')').shift() === link.target.split('(').pop().split(')').shift()) {
              const number = parseInt(i.id.split(' X ').pop()) + link['sid'].split(',').length
              i.id = i.protocol + ' X ' + number
              flag = false
            } else if (i.source === gatewayMarker[link.source] && i.target === link.target.split('(').pop().split(')').shift()) {
              const number = parseInt(i.id.split(' X ').pop()) + link['sid'].split(',').length
              i.id = i.protocol + ' X ' + number
              flag = false
            }
          }
          if (flag) {
            const links = Object.assign({}, link)
            if (links.source.split('(').pop() === links.source) {
              links.sid = links.source
              links.source = gatewayMarker[links.source]
            } else {
              links.source = links.source.split('(').pop().split(')').shift()
            }
            links.target = links.target.split('(').pop().split(')').shift()
            moduleLink.push(links)
          }
        }
        if (link.relationship === 'INVOKE_GATEWAY_INNER') {
          let flag = true
          for (const i of moduleLink) {
            if (i.source === gatewayMarker[link.source] && i.target === gatewayMarker[link.target]) {
              const number = parseInt(i.id.split(' X ').pop()) + link['sid'].split(',').length
              i.id = i.protocol + ' X ' + number
              flag = false
            }
          }
          if (flag) {
            const links = Object.assign({}, link)
            if (links.source.split('(').pop() === links.source) {
              links.sid = links.source
              links.source = gatewayMarker[links.source]
            } else {
              links.source = links.source.split('(').pop().split(')').shift()
            }
            links.target = gatewayMarker[links.target]
            moduleLink.push(links)
          }
        }
      }
      let nginxCount = 0
      let gatewayCount = 0
      let methodCount = 0
      let backendCount = 0
      let gatewayCountmark = 0
      for (const i of moduleData) {
        if (i.type === 'GATEWAY') { gatewayCount++ } else if (i.type === 'NGINX') { nginxCount++ } else if (i.type === 'METHOD') { methodCount++ } else if (i.type === 'BACKEND') { backendCount++ }
      }
      let methodCountmark = methodCount
      let nginxCountmark = nginxCount
      let backendCountmark = backendCount
      for (const i of moduleData) {
        if (i.type === 'GATEWAY') {
          i.y = (gatewayCountmark / gatewayCount) * 2000
          i.x = 600
          gatewayCountmark++
        } else if (i.type === 'NGINX') {
          nginxCountmark--
          i.y = (nginxCountmark / nginxCount) * 2000
          i.x = 100
        } else if (i.type === 'METHOD') {
          methodCountmark--
          i.y = (methodCountmark / methodCount) * 2000
          i.x = 2000
        } else if (i.type === 'BACKEND') {
          backendCountmark--
          i.y = (backendCountmark / backendCount) * 2000
          i.x = 3000
        }
      }
      console.log('moduleData :{} , moduleLink :{} ', moduleData, moduleLink)
      this.chart.clear()
      this.chart.setOption({
        backgroundColor: 'rgba(124, 124, 124, 0.5)',
        title: {
          text: '模块依赖',
          top: 'bottom',
          left: 'left'
        },
        tooltip: {
          formatter: function(data) {
            if (data['dataType'] === 'node') {
              if (data['data']['type'] === 'NGINX') {
                return 'NGINX IP: ' + data['name']
              } else if (data['data']['type'] === 'GATEWAY' || data['data']['type'] === 'METHOD') {
                if (data['data']['ext'] !== '') {
                  var parsedInfo = data['data']['ext'].split('@')
                  return [
                    '方法名称: '.concat(data['data']['FuncName']),
                    '模块名称: '.concat(parsedInfo[0]),
                    'IP地址: '.concat(parsedInfo[1]),
                    '进程号: '.concat(parsedInfo[2])].join('\n')
                } else {
                  return '接口: ' + data['name']
                }
              } else if (data['data']['type'] === 'BACKEND') {
                if (data['data']['ext'] !== undefined && data['data']['ext'] !== '') {
                  if (data['data']['ext'].split('http://')[1] !== undefined) {
                    return ['接口: ' + data['name'],
                      'ip地址: ' + data['data']['ext'].split('http://')[1].split('/')[0]
                    ]
                  } else {
                    return ['接口: ' + data['name'],
                      'ip地址: ' + data['data']['ext'].split(':')[0],
                      'IP端口: ' + data['data']['ext'].split(':')[1]
                    ]
                  }
                } else {
                  return '接口: ' + data['name']
                }

                // 解析mbserver的ip地址，添加spx项检查
              }
            }
          }
        },
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',
        series: [
          {
            type: 'graph',
            layout: 'none',
            symbolSize: 30,
            roam: true,
            focusNodeAdjacency: true,
            itemStyle:
            {
              normal: {
                color: function(val) {
                  if (val.data.type === 'GATEWAY') { return 'rgba(124, 241, 130, 0.795)' } else if (val.data.type === 'METHOD') { return 'rgba(30, 173, 216, 0.767)' }
                },
                borderColor: 'rgba(215, 222, 253, 0.692)',
                borderWidth: 4,
                shadowBlur: 20,
                shadowColor: 'rgba(215, 222, 253, 0.3)'
              }
            },
            label: {
              normal: {
                wordWarp: true,
                position: 'top',
                show: true,
                textStyle: {
                  fontSize: 15,
                  color: '#4a86e8'
                },
                formatter: function(val) {
                  return val.name.split('(').join('\n(')
                }
              }
            },
            edgeSymbol: ['none', 'arrow'],
            edgeSymbolSize: [15, 15],
            edgeLabel: {
              normal: {
                textStyle: {
                  fontSize: 25,
                  color: 'rgb(0, 105, 0)'
                }
              },
              emphasis: {
                textStyle: {
                  fontSize: 25,
                  color: 'rgb(34, 0, 187)',
                  fontWeight: 'bolder'
                }
              }
            },
            emphasis: {
              lineStyle: {
                width: 8
              }
            },
            data: moduleData,
            links: moduleLink

          }
        ]
      }, true)
    }
  }
}
</script>
<style scoped>
.test{
  color: rgb(34, 0, 187)
}
</style>

