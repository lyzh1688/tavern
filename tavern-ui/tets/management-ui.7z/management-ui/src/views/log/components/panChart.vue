<template>
  <div :class="className" :id="id" :style="{height:height,width:width}"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'
import { debounce } from '@/utils'
// import { Message } from 'element-ui'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      default: null
    },
    onresize: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      chart: null,
      XSerise: [],
      YSerise: [],
      NameSerise: null
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setDataSet()
        // this.initChart(val)
        if (this.chart !== null) this.chart.resize()
        console.log('watch!')
      }
    },
    onresize: {
      deep: true,
      handler(val) {
        this.chart.resize()
      }
    }
  },
  mounted() {
    this.setDataSet()
    if (this.autoResize) {
      this.__resizeHanlder = debounce(() => {
        if (this.chart) {
          this.chart.resize()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHanlder)
    }

    // 监听侧边栏的变化
    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.addEventListener('transitionend', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    if (this.autoResize) {
      window.removeEventListener('resize', this.__resizeHanlder)
    }

    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.removeEventListener('transitionend', this.__resizeHanlder)

    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart(Xdata, ydata, namedata) {
      this.chart = echarts.init(this.$el, 'macarons')
      // const xData = (function() {
      //   const data = []
      //   for (let i = 1; i < expectedData.length; i++) {
      //     data.push(i + 'month')
      //   }
      //   return data
      // }())
      const option = {
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        legend: {
          x: '5%',
          icon: 'rect',
          itemWidth: 14,
          itemHeight: 5,
          itemGap: 13,
          data: namedata
        },
        series: [
          {
            name: 'code',
            type: 'pie',
            selectedMode: 'single',
            radius: [0, '30%'],

            label: {
              normal: {
                position: 'inner'
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: Xdata
          },
          {
            name: 'codeInfo',
            type: 'pie',
            radius: ['40%', '55%'],
            label: {
              normal: {
                formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
                backgroundColor: '#eee',
                borderColor: '#aaa',
                borderWidth: 1,
                borderRadius: 4,
                // shadowBlur:3,
                // shadowOffsetX: 2,
                // shadowOffsetY: 2,
                // shadowColor: '#999',
                // padding: [0, 7],
                rich: {
                  a: {
                    color: '#999',
                    lineHeight: 22,
                    align: 'center'
                  },
                  // abg: {
                  //     backgroundColor: '#333',
                  //     width: '100%',
                  //     align: 'right',
                  //     height: 22,
                  //     borderRadius: [4, 4, 0, 0]
                  // },
                  hr: {
                    borderColor: '#aaa',
                    width: '100%',
                    borderWidth: 0.5,
                    height: 0
                  },
                  b: {
                    fontSize: 16,
                    lineHeight: 33
                  },
                  per: {
                    color: '#eee',
                    backgroundColor: '#334455',
                    padding: [2, 4],
                    borderRadius: 2
                  }
                }
              }
            },
            data: ydata
          }
        ]
      }
      this.chart.clear()
      this.chart.setOption(option, true)
      this.chart.resize()
    },
    setDataSet() {
      console.log('chartInputData:', this.chartData)
      if (this.chartData === null || this.chartData.length < 3 || this.chartData.namedata.length === 0 || this.chartData.xdata.length === 0 || this.chartData.ydata.length === 0) {
        // Message.error('图表输入数据不足，无法绘制')
      } else {
        this.NameSerise = this.chartData.namedata
        this.XSerise = this.chartData.xdata
        this.YSerise = this.chartData.ydata
        console.log('chartData:', this.XSerise, this.YSerise, this.NameSerise)
        this.initChart(this.XSerise, this.YSerise, this.NameSerise)
      }
    }
  }
}
</script>