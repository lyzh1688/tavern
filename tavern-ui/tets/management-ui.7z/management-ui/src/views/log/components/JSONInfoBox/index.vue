<template>
<el-form :inline="true" class="formBox">
        <el-form-item  class="formBox2" :label="String(name)+':'" v-if="name!= null&&typeof model != 'object'&&name!='status'">
            {{model}}
        </el-form-item>
        <el-form-item  class="formBox1" :label="String(name)+':'" v-else-if="name!= null&&name!='status'">
        </el-form-item>
        <el-form-item  v-if="model!= null&&typeof model == 'object'" class="infobox" >
		<template  v-for="(models,index) in model" >
		<instanceItem
        class="instanceItem"
		:name = "index"
        :model="models"
        :key="index">
        </instanceItem>
		
	</template>
        </el-form-item>
</el-form>
</template>
<script>
// import instanceItem from '@/components/JSONInfoBox'
export default {
  name: 'instanceItem',
  props: {
    model: null,
    name: { default: null }
  },
  data: function() {
    // console.log('modle:', this.model, typeof this.model, ',', this.name, typeof this.name, typeof [])
    return {
    }
  },
  methods: {
  }
}
</script>
<style <style lang="scss" scoped>
.infobox{
    // width: 100%;
    margin-top: 5px;
    margin-bottom: 5px;
 border-style: solid;
  border-color: snow;
  border-width: 5px;
  outline-style: outset;
  outline-width: 2px;
  outline-color: rgb(150, 135, 135);
}
.formBox{
    // width: 100%;
    float: left;
    clear: right;
}
.formBox1{
    // width: 50%;
    float: left;
    clear: right;
}
.formBox2{
    // width: 100%;
    float: left;
    clear: right;
}
</style>



