<template>
  <div :class="className" :id="id" :style="{height:height,width:width}"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'
import { debounce } from '@/utils'
// import { Message } from 'element-ui'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      default: null
    },
    onresize: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      chart: null,
      XSerise: [],
      YSerise: [],
      NameSerise: null
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setDataSet()
        // this.initChart(val)
        if (this.chart !== null) this.chart.resize()
        console.log('watch!')
      }
    },
    onresize: {
      deep: true,
      handler(val) {
        if (this.chart !== null && this.chart !== undefined) this.chart.resize()
      }
    }
  },
  mounted() {
    this.setDataSet()
    if (this.autoResize) {
      this.__resizeHanlder = debounce(() => {
        if (this.chart) {
          if (this.chart !== null && this.chart !== undefined) this.chart.resize()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHanlder)
    }

    // 监听侧边栏的变化
    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.addEventListener('transitionend', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    if (this.autoResize) {
      window.removeEventListener('resize', this.__resizeHanlder)
    }

    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.removeEventListener('transitionend', this.__resizeHanlder)

    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart(Xdata, ydata, namedata) {
      this.chart = echarts.init(this.$el, 'macarons')
      // const xData = (function() {
      //   const data = []
      //   for (let i = 1; i < expectedData.length; i++) {
      //     data.push(i + 'month')
      //   }
      //   return data
      // }())
      const option = {

        backgroundColor: '#344b58',
        title: {
          text: this.className,
          x: '20',
          top: '10',
          textStyle: {
            color: '#fff',
            fontSize: '22'
          },
          subtextStyle: {
            color: '#90979c',
            fontSize: '16'
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            textStyle: {
              color: '#fff'
            }
          },
          formatter: function(val) {
            // console.log('val', val)
            if (val.length === 0) return ''
            let ans = '<div style="font-size:20px;color:yellow;"><p>时间:' + val[0].axisValueLabel + '</p></div>'
            const tmp = {}
            for (const i of val) {
              if (i.seriesId.split('/')[1] === 'maxduration' || i.seriesId.split('/')[1] === 'avgduration') {
                // if (i.data !== '-')ans += '<div><p>设备:' + i.seriesId + ':  ' + i.data.toFixed(2) + '</p></div>'
                // else ans += '<div><p>设备:' + i.seriesId + ':  ' + i.data + '</p></div>'
                if (tmp[i.seriesId.split('/')[0]] === undefined) {
                  tmp[i.seriesId.split('/')[0]] = '<div><span>设备:</span>'
                  tmp[i.seriesId.split('/')[0]] += '<span style="color:#8fff44;">' + i.seriesId.split('/')[0] + '</span>'
                  tmp[i.seriesId.split('/')[0]] += '<span style="color:yellow;">[' + i.seriesId.split('/')[1] + ':</span>'
                  if (i.data !== '-')tmp[i.seriesId.split('/')[0]] += '<span style="color:#00fff2;">' + i.data.toFixed(2) + ',</span>'
                  else tmp[i.seriesId.split('/')[0]] += '<span style="color:#00fff2;">' + i.data + ',</span>'
                } else {
                  tmp[i.seriesId.split('/')[0]] += '<span style="color:yellow;">' + i.seriesId.split('/')[1] + ':</span>'
                  if (i.data !== '-')tmp[i.seriesId.split('/')[0]] += '<span style="color:#00fff2;">' + i.data.toFixed(2) + ',</span>'
                  else tmp[i.seriesId.split('/')[0]] += '<span style="color:#00fff2;">' + i.data + ',</span>'
                }
              }

              // for(let j of i)
              // if (i.seriesName === '指数') {
              //   ans += '<span style="color:white;"> ● </span><span>' + i.seriesName + ':' + i.data + '</span><br/>'
              // }
              // if (i.seriesName === '均价') {
              //   ans += '<span style="color:yellow;"> ● </span><span>' + i.seriesName + ':' + i.data + '</span><br/>'
              // }
              // if (i.seriesName === '涨跌幅') {
              //   if (i.data >= 0) {
              //     ans += '<span style="color:red;"> ● </span><span>' + i.seriesName + ':' + i.data + '</span><br/>'
              //   } else {
              //     ans += '<span style="color:green;"> ● </span><span>' + i.seriesName + ':' + i.data + '</span><br/>'
              //   }
              // }
              // if (i.seriesName === '成交量') {
              //   ans += '<span style="color:' + i.color + ';"> ● </span><span>' + i.seriesName + ':' + i.data + '</span><br/>'
              // }
              // if (i.seriesName === '成交额') {
              //   ans += '<span style="color:' + i.color + ';"> ● </span><span>' + i.seriesName + ':' + i.data + '</span><br/>'
              // }
            }
            for (const i in tmp) {
              tmp[i] += '<span style="color:yellow;">]</span></div>'
              ans += tmp[i]
            }

            return ans
          }
        },
        grid: {
          borderWidth: 0,
          top: 110,
          bottom: 95,
          textStyle: {
            color: '#fff'
          }
        },
        legend: {
          x: '5%',
          top: '10%',
          icon: 'rect',
          itemWidth: 14,
          itemHeight: 5,
          itemGap: 13,
          data: namedata,
          selected: {
            '线程数': false,
            '物理内存使用率': false,
            '五分钟速率': false,
            '十五分钟速率': false,
            'successRate': false,
            // 'AllCount': false,
            'OK': false,
            'maxduration': false
          },
          textStyle: {
            fontSize: 12,
            color: '#F1F1F3'
          }
        },
        calculable: true,
        xAxis: Xdata,
        yAxis: [{
          type: 'value',
          splitLine: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            interval: 0
          },
          splitArea: {
            show: false
          }
        },
        {
          type: 'value',
          show: false,
          splitLine: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            interval: 0
          },
          splitArea: {
            show: false
          }
        }],
        // dataZoom: [{
        //   show: true,
        //   height: 30,
        //   xAxisIndex: [
        //     0
        //   ],
        //   bottom: 30,
        //   start: 30,
        //   end: 100,
        //   handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
        //   handleSize: '110%',
        //   handleStyle: {
        //     color: '#d3dee5'

        //   },
        //   textStyle: {
        //     color: '#fff' },
        //   borderColor: '#90979c'

        // }, {
        //   type: 'inside',
        //   show: true,
        //   height: 15,
        //   start: 1,
        //   end: 35
        // }],
        series: ydata
      }
      if (this.chart !== null && this.chart !== undefined) this.chart.clear()
      this.chart.setOption(option, true)
      if (this.chart !== null && this.chart !== undefined) this.chart.resize()
    },
    setDataSet() {
      console.log('chartInputData:', this.chartData)
      if (this.chartData === null || this.chartData.length < 3 || this.chartData.namedata.length === 0 || this.chartData.xdata.length === 0 || this.chartData.ydata.length === 0) {
        // Message.error('图表输入数据不足，无法绘制')
        if (this.chart !== null && this.chart !== undefined) this.chart.clear()
      } else {
        const tempx = []
        const tempy = []
        const names = []
        // for (const i in this.chartData.xdata) {
        //   if (this.chartData.xdata[i].length !== 0) {

        //   }
        // }
        tempx.push({
          type: 'category',
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: true
          },
          splitArea: {
            show: true
          },
          axisLabel: {
            interval: 'auto',
            rotate: 90
          },
          inverse: true,
          data: this.chartData.xdata
        })
        // 隐藏数据用坐标轴
        tempx.push({
          type: 'category',
          show: false,
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: true
          },
          splitArea: {
            show: true
          },
          axisLabel: {
            interval: 'auto',
            rotate: 90
          },
          inverse: true,
          data: this.chartData.xdata
        })
        // for (const i in this.chartData.ydata) {
        //   console.log('for-chardata:', this.chartData.ydata[i].length)
        //   if (this.chartData.ydata[i].length !== 0) {
        //     // const colorRandom = '#' + ('fffff' + ((Math.random() * 16777215 + 0.5) >> 0).toString(16)).slice(-6)
        //     // let R, G, B, Flag
        //     // while (Flag > 1) {
        //     //   R = Math.random() * 255
        //     //   G = Math.random() * 255
        //     //   B = Math.random() * 255
        //     //   Flag = R * 0.299 + G * 0.587 + B * 0.114
        //     //   if (R * 0.299 + G * 0.587 + B * 0.114 > 110) break
        //     // }
        //     // const colorRandom = 'rgb(' + R + ',' + G + ',' + B + ')'
        //     if (this.chartData.namedata[i] === 'AllCount') {
        //       names.push(this.chartData.namedata[i])
        //       tempy.push({
        //         name: this.chartData.namedata[i],
        //         type: 'bar',
        //         yAxisIndex: 1,
        //         itemStyle: {
        //           normal: {
        //             color: 'rgba(255, 241, 150, 0.5)',
        //             barBorderRadius: 0,
        //             label: {
        //               show: false,
        //               position: 'top',
        //               formatter(p) {
        //                 return p.value > 0 ? p.value : ''
        //               }
        //             }
        //           }
        //         },
        //         data: this.chartData.ydata[i]
        //       })
        //       break
        //     }
        //   }
        // }
        for (const i in this.chartData.ydata) {
          const that = this
          // console.log('for-chardata:', i)

          if (this.chartData.ydataDuration[i] !== undefined) {
            names.push('one')
            tempy.push({
              name: 'one',
              type: 'bar',
              stack: i + 'avgduration',
              id: i + '/' + 'one',
              itemStyle: {
                normal: {
                  color: '#3cff00',
                  barBorderRadius: {
                  },
                  label: {
                    show: false,
                    position: 'top',
                    formatter(p) {
                      // console.log('p', that.chartData.namedata)

                      return that.chartData.namedata[p.dataIndex]
                    }
                  }
                }
              },
              data: this.chartData.ydataDuration[i]['one']
            })
            names.push('fiv')
            tempy.push({
              name: 'fiv',
              type: 'bar',
              stack: i + 'avgduration',
              id: i + '/' + 'fiv',
              itemStyle: {
                normal: {
                  color: '#00ffb3',
                  barBorderRadius: {
                  },
                  label: {
                    show: false,
                    position: 'top',
                    formatter(p) {
                      // console.log('p', that.chartData.namedata)

                      return that.chartData.namedata[p.dataIndex]
                    }
                  }
                }
              },
              data: this.chartData.ydataDuration[i]['fiv']
            })
            names.push('threeT')
            tempy.push({
              name: 'threeT',
              type: 'bar',
              stack: i + 'avgduration',
              id: i + '/' + 'threeT',
              itemStyle: {
                normal: {
                  color: '#ffae00',
                  barBorderRadius: {
                  },
                  label: {
                    show: false,
                    position: 'top',
                    formatter(p) {
                      // console.log('p', that.chartData.namedata)

                      return that.chartData.namedata[p.dataIndex]
                    }
                  }
                }
              },
              data: this.chartData.ydataDuration[i]['threeT']
            })
            names.push('above')
            tempy.push({
              name: 'above',
              type: 'bar',
              stack: i + 'avgduration',
              id: i + '/' + 'above',
              itemStyle: {
                normal: {
                  color: '#ff0000',
                  barBorderRadius: {
                  },
                  label: {
                    show: false,
                    position: 'top',
                    formatter(p) {
                      // console.log('p', that.chartData.namedata)

                      return that.chartData.namedata[p.dataIndex]
                    }
                  }
                }
              },
              data: this.chartData.ydataDuration[i]['above']
            })
            names.push('maxduration')
            tempy.push({
              name: 'maxduration',
              type: 'bar',
              stack: i + 'maxduration',
              id: i + '/' + 'maxduration',
              itemStyle: {
                normal: {
                  color: '#ff008c',
                  barBorderRadius: {
                  },
                  label: {
                    show: false,
                    position: 'maxduration',
                    formatter(p) {
                      // console.log('p', that.chartData.namedata)

                      return that.chartData.namedata[p.dataIndex]
                    }
                  }
                }
              },
              data: this.chartData.ydataDuration[i]['maxduration']
            })
            tempy.push({
              name: 'avgduration',
              type: 'bar',
              yAxisIndex: 1,
              xAxisIndex: 1,
              id: i + '/' + 'avgduration',
              itemStyle: {
                normal: {
                  opacity: 0.0,
                  barBorderRadius: {
                  },
                  label: {
                    show: false,
                    position: 'maxduration',
                    formatter(p) {
                      // console.log('p', that.chartData.namedata)

                      return that.chartData.namedata[p.dataIndex]
                    }
                  }
                }
              },
              data: this.chartData.ydataDuration[i]['avgduration']
            })
            // for (const j in this.chartData.ydataDuration[i]) {
            //   console.log('for-chardata:', this.chartData.ydataDuration[i][j].length)
            //   if (this.chartData.ydataDuration[i][j].length !== 0) {
            //     if (j !== 'maxduration' && j !== 'avgduration') {
            //       names.push(j)
            //       tempy.push({
            //         name: j,
            //         type: 'bar',
            //         stack: 'avgduration',
            //         id: i + ':' + j,
            //         itemStyle: {
            //           normal: {
            //           // color: colorRandom,

            //             barBorderRadius: {

            //             },
            //             label: {
            //               show: false,
            //               position: 'top',
            //               formatter(p) {
            //               // console.log('p', that.chartData.namedata)

            //                 return that.chartData.namedata[p.dataIndex]
            //               }
            //             }
            //           }
            //         },
            //         data: this.chartData.ydataDuration[i][j]
            //       })
            //     }
            //     if (j === 'maxduration') {
            //       names.push(j)
            //       tempy.push({
            //         name: j,
            //         type: 'bar',
            //         stack: 'maxduration',
            //         id: i + ':' + j,
            //         itemStyle: {
            //           normal: {
            //           // color: colorRandom,

            //             barBorderRadius: {

            //             },
            //             label: {
            //               show: false,
            //               position: 'top',
            //               formatter(p) {
            //               // console.log('p', that.chartData.namedata)

            //                 return that.chartData.namedata[p.dataIndex]
            //               }
            //             }
            //           }
            //         },
            //         data: this.chartData.ydataDuration[i][j]
            //       })
            //     }
            //   }
            // }
            // const colorRandom = '#' + ('fffff' + ((Math.random() * 16777215 + 0.5) >> 0).toString(16)).slice(-6)
            // let R, G, B, Flag
            // while (Flag > 1) {
            //   R = Math.random() * 255
            //   G = Math.random() * 255
            //   B = Math.random() * 255
            //   Flag = R * 0.299 + G * 0.587 + B * 0.114
            //   if (R * 0.299 + G * 0.587 + B * 0.114 > 110) break
            // }
            // const colorRandom = 'rgb(' + R + ',' + G + ',' + B + ')'
          }
        }
        this.NameSerise = names
        this.XSerise = tempx
        this.YSerise = tempy
        console.log('chartData:', this.XSerise, this.YSerise, this.chartData.ydata)
        this.initChart(this.XSerise, this.YSerise, this.NameSerise)
      }
    }
  }
}
</script>
