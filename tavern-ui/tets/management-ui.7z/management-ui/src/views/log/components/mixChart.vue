<template>
  <div :class="className" :id="id" :style="{height:height,width:width}"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'
import { debounce } from '@/utils'
// import { Message } from 'element-ui'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      default: null
    },
    onresize: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      chart: null,
      XSerise: [],
      YSerise: [],
      NameSerise: null
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setDataSet()
        // this.initChart(val)
        if (this.chart !== null) this.chart.resize()
        console.log('watch!')
      }
    },
    onresize: {
      deep: true,
      handler(val) {
        this.chart.resize()
      }
    }
  },
  mounted() {
    this.setDataSet()
    if (this.autoResize) {
      this.__resizeHanlder = debounce(() => {
        if (this.chart) {
          this.chart.resize()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHanlder)
    }

    // 监听侧边栏的变化
    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.addEventListener('transitionend', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    if (this.autoResize) {
      window.removeEventListener('resize', this.__resizeHanlder)
    }

    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.removeEventListener('transitionend', this.__resizeHanlder)

    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart(Xdata, ydata, namedata) {
      this.chart = echarts.init(this.$el, 'macarons')
      // const xData = (function() {
      //   const data = []
      //   for (let i = 1; i < expectedData.length; i++) {
      //     data.push(i + 'month')
      //   }
      //   return data
      // }())
      const option = {

        backgroundColor: '#344b58',
        title: {
          text: this.className,
          x: '20',
          top: '10',
          textStyle: {
            color: '#fff',
            fontSize: '22'
          },
          subtextStyle: {
            color: '#90979c',
            fontSize: '16'
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            textStyle: {
              color: '#fff'
            }
          }
        },
        grid: {
          borderWidth: 0,
          top: 110,
          bottom: 95,
          textStyle: {
            color: '#fff'
          }
        },
        legend: {
          x: '5%',
          top: '10%',
          icon: 'rect',
          itemWidth: 14,
          itemHeight: 5,
          itemGap: 13,
          data: namedata,
          selected: {
            '线程数': false,
            '物理内存使用率': false,
            '五分钟速率': false,
            '十五分钟速率': false,
            'max': false
          },
          textStyle: {
            fontSize: 12,
            color: '#F1F1F3'
          }
        },
        calculable: true,
        xAxis: Xdata,
        yAxis: [{
          type: 'value',
          splitLine: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            interval: 0
          },
          splitArea: {
            show: false
          }
        }],
        // dataZoom: [{
        //   show: true,
        //   height: 30,
        //   xAxisIndex: [
        //     0
        //   ],
        //   bottom: 30,
        //   start: 30,
        //   end: 100,
        //   handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
        //   handleSize: '110%',
        //   handleStyle: {
        //     color: '#d3dee5'

        //   },
        //   textStyle: {
        //     color: '#fff' },
        //   borderColor: '#90979c'

        // }, {
        //   type: 'inside',
        //   show: true,
        //   height: 15,
        //   start: 1,
        //   end: 35
        // }],
        series: ydata
      }
      this.chart.clear()
      this.chart.setOption(option, true)
      this.chart.resize()
    },
    setDataSet() {
      console.log('chartInputData:', this.chartData)
      if (this.chartData === null || this.chartData.length < 3 || this.chartData.namedata.length === 0 || this.chartData.xdata.length === 0 || this.chartData.ydata.length === 0) {
        // Message.error('图表输入数据不足，无法绘制')
      } else {
        const tempx = []
        const tempy = []
        const names = []
        // 防止pvuv数据量不一致导致的坐标错位
        let maxLengthMark = 0
        let maxLengthCount = 0
        for (const i in this.chartData.xdata) {
          if (this.chartData.xdata[i].length >= maxLengthMark) {
            maxLengthMark = this.chartData.xdata[i].length
            maxLengthCount = i
          }
        }
        tempx.push({
          type: 'category',
          axisLine: {
            lineStyle: {
              color: '#90979c'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          splitArea: {
            show: false
          },
          axisLabel: {
            interval: 0,
            rotate: 45

          },
          data: this.chartData.xdata[maxLengthCount]
        })
        names.push(this.chartData.namedata[maxLengthCount])
        tempy.push({
          name: this.chartData.namedata[maxLengthCount],
          type: 'bar',
          itemStyle: {
            normal: {
              // color: colorRandom,
              barBorderRadius: 0,
              label: {
                show: false,
                position: 'top',
                formatter(p) {
                  return p.value > 0 ? p.value : ''
                }
              }
            }
          },
          data: this.chartData.ydata[maxLengthCount]
        })
        for (const i in this.chartData.xdata) {
          if (this.chartData.xdata[i].length !== 0) {
            if (i !== maxLengthCount) {
              tempx.push({
                type: 'category',
                axisLine: {
                  lineStyle: {
                    color: '#90979c'
                  }
                },
                splitLine: {
                  show: false
                },
                axisTick: {
                  show: false
                },
                splitArea: {
                  show: false
                },
                axisLabel: {
                  show: false

                },
                data: this.chartData.xdata[i]
              })
            }
          }
        }
        for (const i in this.chartData.ydata) {
          console.log('for-chardata:', this.chartData.ydata[i].length)
          if (this.chartData.ydata[i].length !== 0 && i !== maxLengthCount) {
            // const colorRandom = '#' + ('fffff' + ((Math.random() * 16777215 + 0.5) >> 0).toString(16)).slice(-6)
            // let R, G, B, Flag
            // while (Flag > 1) {
            //   R = Math.random() * 255
            //   G = Math.random() * 255
            //   B = Math.random() * 255
            //   Flag = R * 0.299 + G * 0.587 + B * 0.114
            //   if (R * 0.299 + G * 0.587 + B * 0.114 > 110) break
            // }
            // const colorRandom = 'rgb(' + R + ',' + G + ',' + B + ')'
            // 补全没有的数据
            const temTempy = []
            for (const ii of this.chartData.xdata[maxLengthCount]) {
              let checkFlag = true
              let CountFlagCount = 0
              for (const jj in this.chartData.xdata[i]) {
                if (this.chartData.xdata[i][jj] === ii) {
                  checkFlag = false
                  CountFlagCount = jj
                }
              }
              if (checkFlag)temTempy.push(0)
              else temTempy.push(this.chartData.ydata[i][CountFlagCount])
            }
            names.push(this.chartData.namedata[i])
            tempy.push({
              name: this.chartData.namedata[i],
              type: 'bar',
              itemStyle: {
                normal: {
                  // color: colorRandom,
                  barBorderRadius: 0,
                  label: {
                    show: false,
                    position: 'top',
                    formatter(p) {
                      return p.value > 0 ? p.value : ''
                    }
                  }
                }
              },
              data: temTempy
            })
          }
        }
        this.NameSerise = names
        this.XSerise = tempx
        this.YSerise = tempy
        console.log('chartData:', this.XSerise, this.YSerise, this.chartData.ydata)
        this.initChart(this.XSerise, this.YSerise, this.NameSerise)
      }
    }
  }
}
</script>
