<template>
    <div class="app-container">
    <el-card>
        <div>
    
            <span style="line-height: 15px; font-size: 10px;"><h3 color="00bfff"> 查询条件</h3></span>
    
        </div>
    
        <div class="wrapper-box" ref="wrapperBox" style="height: 75px;">
    
            <el-form ref="ruleForm" :rules="rule" :inline="true" :model="formData" @submit.native.prevent>
    
                <div class="form-wrapper">
    
                    <el-form-item class="form-wrapper-item" label="序列号" label-width="75px" prop="mobile">
    
                        <el-input @keyup.enter.native="handleQuery('ruleForm')"  v-model="formData.seq" size="mini"></el-input>
    
                    </el-form-item>
    
                    <el-form-item class="form-wrapper-item" label="开始时间" label-width="75px" prop="startTime">
    
                        <el-date-picker v-model="formData.startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
    
                    </el-form-item>
    
                    <el-form-item class="form-wrapper-item" label="结束时间" label-width="75px" prop="endTime">
    
                        <el-date-picker v-model="formData.endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
    
                    </el-form-item>
    
                    <el-form-item class="form-wrapper-item" label="" label-width="0">
    
                        <el-button type="primary" @click="handleQuery('ruleForm')" :disabled="isQuery" size="mini">查询</el-button>
    
                    </el-form-item>
                     <el-form-item class="form-wrapper-item" label="" label-width="0">
    
                        <el-button type="primary" @click="isShowGraph=!isShowGraph" :disabled="isQuery" size="mini">拓扑展示</el-button>
    
                    </el-form-item>
    
    
    
                </div>
    
            </el-form>
    
        </div>
        <span v-if="OB_FLAG&&loglistob4.length>0" style="line-height: 20px; font-size: 15px;"><h3 > <font color="00bfff">日志时间：{{loglistob4[0].logTime}}</font></h3></span>        
        <div :class="zoom1?'chart-containerA':'chart-containerB'"  v-if="isShowGraph&&!zoom2">
          <el-button type="info"  @click="zoom1=!zoom1" style="height='10%';width:100%;">缩放</el-button>
          <linkGraph class="Link_graph" height='90%' width="100%" v-if="!zoom2" :autoResizeFlag="zoom1"  :chart-data="formData" @highlightRow="highlightRow"></linkGraph>
        </div>
        <div :class="zoom2?'chart-containerA':'chart-containerB'" v-if="isShowGraph&&!zoom1" >
          <el-button type="info" @click="zoom2=!zoom2" style="height='10%';width:100%;">缩放</el-button>
          <moduleGraph class="Link_graph" height='90%' width="100%" v-if="!zoom1" :autoResizeFlag="zoom2" :chart-data="formData"></moduleGraph>
        </div>
        
        <div class="table-container" hidden="hidden" id="ob4table">
    
            <div>
    
                <div style="line-height: 20px; font-size: 15px;"><h3 > <font color="00bfff">OBGEAR4 BIZ LOG </font></h3></div>
                
            </div>
    
            <el-table ref="loglistob4Table" :data="loglistob4" highlight-current-row @current-change="handleCurrentChange" :row-style="changeClass" style="width: 100%" :border="true"  resizable>
    
                <!-- <el-table-column type="index" width="30px" align="left"></el-table-column> -->
                <el-table-column type="expand" >
    
                    <template slot-scope="scope">
    
    					<el-form class="table-inner" :inline="true" v-if="scope.row.category==='trace-log-4'">
    
    						<div class="form-wrapper">
    
    							<el-form-item label="请求" label-width="95px" class="form-wrapper-item">
    
    								<span>{{scope.row.request}}</span>
                   
    							</el-form-item>
                   
    						</div>
                 <el-button v-if="hasPermission()" type="primary" style="width:100%;" @click="translatePBFile(scope.row.request,true)">解析请求</el-button>
                <el-dialog
                title="请求解析结果"
                :visible.sync="PBDialogFlagA">
                <el-card>
                      <jsonViewer
                      :json="PBFile">
                      </jsonViewer>
                      </el-card>
                </el-dialog>
                
    						<div class="form-wrapper">
    
    							<el-form-item label="响应" label-width="95px" class="form-wrapper-item ">
    
    								<span>{{scope.row.reply}}</span>
                    
    
    							</el-form-item>
    
    						</div>
                <el-button v-if="hasPermission()" type="primary" style="width:100%;" @click="translatePBFile(scope.row.reply,false)">解析响应</el-button>
                <el-dialog
                class="JSONVIEW"
                title="响应解析结果"
                :visible.sync="PBDialogFlagB">
                <span class="JSONVIEW">
                  <jsonViewer
                  class="JSONVIEW"
                      :json="PBFile"
                      >
                      </jsonViewer>
                      </span>
                
                </el-dialog>
    						<!-- <%--<div class="form-wrapper">--%>
    
    							<%--<el-form-item label="seq" label-width="95px" class="form-wrapper-item form-item-three">--%>
    
    								<%--<p>{{scope.row.seq}}</p>--%>
    
    							<%--</el-form-item>--%>
    
    							<%--<el-form-item label="父序号" label-width="95px" class="form-wrapper-item form-item-three">--%>
    
    								<%--<p>{{scope.row.pid}}</p>--%>
    
    							<%--</el-form-item>--%>
    
    							<%--<el-form-item label="子序号" label-width="95px" class="form-wrapper-item form-item-three">--%>
    
    								<%--<p>{{scope.row.sid}}</p>--%>
    
    							<%--</el-form-item>--%>
    
    						<%--</div>--%> -->
    
    						<div class="form-wrapper">
    
    							<el-form-item label="操作站点" label-width="95px" class="form-wrapper-item form-item-three">
    
    								<span>{{scope.row.opStation}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="父序号" label-width="95px" class="form-wrapper-item form-item-three">
    
    								<span>{{scope.row.pid}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="category" label-width="95px" class="form-wrapper-item form-item-three">
    
    								<span>{{scope.row.category}}</span>
    
    							</el-form-item>
    
    						</div>
    
    					</el-form >

                  					<el-form  :inline="true" v-if="scope.row.category==='access-log'">
    
    						<div >
    
    							<el-form-item label="入参" label-width="95px" >
    
    								<span>{{scope.row.params}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="query" label-width="95px" >
    
    								<span>{{scope.row.query}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="ua" label-width="95px" >
    
    								<span>{{scope.row.ua}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="调用IP" label-width="95px" >
    
    								<span>{{scope.row.invokerIp}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="token" label-width="95px" >
    
    								<span>{{scope.row.sessionId}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="type" label-width="95px" >
    
    								<span>{{scope.row.type}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="渠道" label-width="95px" >
    
    								<span>{{scope.row.channel}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="category" label-width="95px" >
    
    								<span>{{scope.row.category}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="版本" label-width="95px" >
    
    								<span>{{scope.row.ver}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="target" label-width="95px" >
    
    								<span>{{scope.row.target}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="APPId" label-width="95px" >
    
    								<span>{{scope.row.appId}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="操作站点" label-width="95px" >
    
    								<span>{{scope.row.opStation}}</span>
    
    							</el-form-item>
    
    						</div>
    
    
    
    						<div >
    
    							<el-form-item label="客户端IP" label-width="95px" >
    
    								<span>{{scope.row.clientIp}}</span>
    
    							</el-form-item>
    						</div>
    
    					</el-form>
</template>
			</el-table-column>

			<!-- <%--<el-table-column property="module"          label="模块"            align="left"></el-table-column>--%>
			<%--<el-table-column property="seq"     label="seq"    header-align="center"   align="left"  width="190px"></el-table-column>--%>
			<%--<el-table-column property="pid"      label="父序号"        align="left"  width="50px"></el-table-column>--%> -->
			<el-table-column property="sid"        label="序号"  header-align="center"         align="left">
        <template slot-scope="scope">
          <span v-if="scope.row.category==='access-log'">{{scope.row.sid}}</span>
           <span v-if="scope.row.category==='trace-log-4'">{{scope.row.sid}}</span>
        </template>
      </el-table-column>

			<el-table-column property="invoker"     label="调用方" header-align="center"      align="left"  width="100px">
        <template slot-scope="scope">
          <span v-if="scope.row.category==='access-log'">{{scope.row.invokerIp}}</span>
           <span v-if="scope.row.category==='trace-log-4'">{{scope.row.invoker}}</span>
        </template>
      </el-table-column>
			<el-table-column property="answer"      label="应答方"   header-align="center"     align="left"  width="270px"></el-table-column>
			<el-table-column property="protocol"        label="协议"  header-align="center"        align="left"></el-table-column>
			<el-table-column property="target"        label="服务"   header-align="center"       align="left" width="300px"></el-table-column>
			<el-table-column property="moduleName"        label="模块名"   header-align="center"       align="left" width="100px"></el-table-column>
			<el-table-column property="method"        label="方法"   header-align="center"       align="left" width="160px">
        
        <template slot-scope="scope">
          <span v-if="scope.row.category==='access-log'">{{scope.row.funcNo}}</span>
           <span v-if="scope.row.category==='trace-log-4'">{{scope.row.method}}</span>
        </template>
      </el-table-column>
			<el-table-column property="remark"      label="描述"   header-align="center"     align="left"  width="200px"></el-table-column>
			<el-table-column property="errorCode"          label="返回码"   header-align="center"         align="left">
         <template slot-scope="scope">
          <span v-if="scope.row.category==='access-log'">{{scope.row.code}}</span>
           <span v-if="scope.row.category==='trace-log-4'">{{scope.row.errorCode}}</span>
        </template>
      </el-table-column>
			<el-table-column property="errorInfo"          label="返回信息"  header-align="center"          align="left"  >
        <template slot-scope="scope">
          <span v-if="scope.row.category==='access-log'">{{scope.row.info}}</span>
           <span v-if="scope.row.category==='trace-log-4'">{{scope.row.errorInfo}}</span>
        </template>
      </el-table-column>

<!-- 			<el-table-column property="opStation"     label="操作站点"       align="left"></el-table-column> -->
<!-- 			<el-table-column property="channel"       label="渠道"         align="left"></el-table-column> -->
			<el-table-column property="elapsed"       label="耗时"   header-align="center"      align="left">
        <template slot-scope="scope">
          <span v-if="scope.row.category==='access-log'">{{scope.row.duration}}</span>
           <span v-if="scope.row.category==='trace-log-4'">{{scope.row.elapsed}}</span>
        </template>
      </el-table-column>
<!-- 			<el-table-column property="invokerIp"     label="调用IP"       align="left"></el-table-column> -->
<!-- 			<el-table-column property="clientIp"      label="客户端IP"        align="left"></el-table-column> -->
<!-- 			<el-table-column property="category"      label="category"        align="left"></el-table-column> -->
		</el-table>
	</div>
<span v-if="!OB_FLAG&&loglistob3.length>0" style="line-height: 20px; font-size: 15px;"><h3 > <font color="00bfff">日志时间：{{loglistob3[0].lonTime}}</font></h3></span>
	<div class="table-container" hidden="hidden" id="ob3table">
		<div>
			<span style="line-height: 20px; font-size: 15px;"><h3 > <font color="00bfff">OBGEAR3 BIZ LOG </font></h3></span>
      </div>
		<el-table
				ref="loglistob3Table"
				:data="loglistob3"
				highlight-current-row
				style="width: 100%"
				:border="true"
				:stripe="true"
				resizable>
			<!-- <el-table-column type="index" width="30px" header-align="center"  align="left"></el-table-column> -->
			<el-table-column type="expand">
<template slot-scope="scope">
    <el-form class="table-inner">
    
        <div class="form-wrapper">
    
            <el-form-item label="操作站点" label-width="95px" class="form-wrapper-item form-item-three">
    
                <p>{{scope.row.opStation}}</p>
    
            </el-form-item>
    
            <el-form-item label="渠道" label-width="95px" class="form-wrapper-item form-item-three">
    
                <p>{{scope.row.channel}}</p>
    
            </el-form-item>
    
            <el-form-item label="category" label-width="95px" class="form-wrapper-item form-item-three">
    
                <p>{{scope.row.category}}</p>
    
            </el-form-item>
    
        </div>
    
        <div class="form-wrapper">
    
            <el-form-item label="调用IP" label-width="95px" class="form-wrapper-item form-item-three">
    
                <p>{{scope.row.invokerIp}}</p>
    
            </el-form-item>
    
            <el-form-item label="客户端IP" label-width="95px" class="form-wrapper-item form-item-three">
    
                <p>{{scope.row.clientIp}}</p>
    
            </el-form-item>
    
    
    
        </div>
    
    </el-form>
</template>
			</el-table-column>
			<el-table-column property="seq"           label="序号"             header-align="center"  align="left"></el-table-column>
			<el-table-column property="logTime"       label="日志时间"         header-align="center"  align="left" @format="formatLogTime"></el-table-column>
			<el-table-column property="sid"           label="子序号"             header-align="center"  align="left"></el-table-column>
			<el-table-column property="user"          label="用户名"            header-align="center"  align="left"></el-table-column>
			<el-table-column property="method"        label="功能"          header-align="center"  align="left"></el-table-column>
			<el-table-column property="code"          label="返回码"            header-align="center"  align="left"></el-table-column>
			<el-table-column property="info"          label="返回信息"            header-align="center"  align="left" width="300px"></el-table-column>
			<!-- 			<el-table-column property="opStation"     label="操作站点"       header-align="center"  align="left"></el-table-column> -->
			<!-- 			<el-table-column property="channel"       label="渠道"         header-align="center"  align="left"></el-table-column> -->
			<el-table-column property="elapsed"       label="耗时"         header-align="center"  align="left"></el-table-column>
			<!-- 			<el-table-column property="invokerIp"     label="调用IP"       header-align="center"  align="left"></el-table-column> -->
			<!-- 			<el-table-column property="clientIp"      label="客户端IP"        header-align="center"  align="left"></el-table-column> -->
			<!-- 			<el-table-column property="category"      label="category"        header-align="center"  align="left"></el-table-column> -->
		</el-table>
	</div>
  </el-card>
    </div>
</template>

<script>
import { dateTimeFormat } from '@/store/date'
import { queryTraceLog,
  PBTranslation } from '@/api/log'
import instanceItem from './components/JSONInfoBox'
import linkGraph from './components/linkGraph'
import moduleGraph from './components/moduleGraph'
import {
  Message
} from 'element-ui'
import { mapGetters } from 'vuex'
import jsonViewer from '@/components/JsonView'
export default {
  name: 'traceLog',
  components: {
    linkGraph,
    moduleGraph,
    instanceItem,
    jsonViewer
  },
  data: function() {
    var that = this
    // 校验规则
    var _ruleStartTime = (rule, value, callback) => {
      if (that.formData.startTime === '') {
        callback(new Error('请选择开始时间!'))
      } else {
        if (that.formData.endTime !== '' && that.formData.endTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('开始时间必须小于结束时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    var _ruleEndTime = (rule, value, callback) => {
      if (that.formData.endTime === '') {
        callback(new Error('请选择结束时间!'))
      } else {
        if (that.formData.startTime !== '' && that.formData.startTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('结束时间必须大于开始时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    return {
      isQuery: false,
      list: [],
      loglistob3: [],
      loglistob4: [],
      formData: {
        seq: '',
        category: '',
        startTime: '',
        endTime: ''
      },
      isShowGraph: false,
      pageNum: 1,
      pageSize: 100,
      totalPages: 0,
      zoom1: false,
      zoom2: false,
      rule: {
        startTime: [{ validator: _ruleStartTime, trigger: 'blur' }],
        endTime: [{ validator: _ruleEndTime, trigger: 'blur' }]
      },
      PBFile: '',
      PBDialogFlagA: false,
      PBDialogFlagB: false,
      currentRow: null,
      OB_FLAG: true
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'name'
    ])
  },
  created: function() {
    if (this.$route.query.seq !== undefined) {
      this.formData.seq = this.$route.query.seq
    }
    if (this.$route.query.category) {
      this.formData.category = this.$route.query.category
    }
    if (this.$route.query.startTime !== undefined) {
      this.formData.startTime = this.$route.query.startTime
    } else {
      this.initStartTime()
    }
    if (this.$route.query.endTime !== undefined) {
      this.formData.endTime = this.$route.query.endTime
    } else {
      this.initEndTime()
    }
    // console.log('create:', this.formData)
    if (this.formData.seq !== '') {
      this.getList()
    }
  },
  // mounted: function() {
  //   this.$el.className = 'show'
  // },
  activated() {
    // this.fetchData(this.moduleName)
    console.log('actived!')
    this.formData = Object.assign({}, this.formData)
  },
  methods: {
    hasPermission() {
      const ROLES = ['admin', 'traceLogButton']
      return this.roles.some(role => {
        for (const p of ROLES) {
          // console.log('check:', role, typeof role, p, typeof p, p.trim() === role.trim())
          if (p.trim() === role.trim()) return true
        }
        return false
        // route.meta.roles.indexOf(role) >= 0
      })
    },
    changeClass({ row, rowIndex }) {
      // console.log('backgroud!!!!!!!!!!!', row.errorCode !== 0)
      if (row.errorCode !== 0 && row.errorCode !== '0' && row.category === 'trace-log-4') return 'background: gold;'
      else if (row.code !== 0 && row.code !== '0' && row.category === 'access-log') return 'background: gold;'
      else return 'background: floralwhite;'
    },
    highlightRow(row) {
      let CurrentRow
      for (const i of this.loglistob4) {
        if (i.sid === row.sid && i.protocol === row.protocol)CurrentRow = i
      }
      // console.log('current Row:', CurrentRow)
      this.$refs.loglistob4Table.setCurrentRow(CurrentRow)
    },
    translatePBFile(JsonString, flag) {
      try {
        JSON.parse(JsonString)
      } catch (err) {
        Message.error('JSON parser failed!')
        this.PBFile = ''
      }
      PBTranslation(JSON.parse(JsonString).type_url, JSON.parse(JsonString).value, JSON.parse(JsonString).version).then(function(response) {
        console.log('response:', response)
        this.PBFile = JSON.parse(response)
        if (flag) this.PBDialogFlagA = true
        else this.PBDialogFlagB = true
      }.bind(this))
      console.log(JSON.parse(JsonString))
    },
    formatStartTime: function(val) {
      if (val !== undefined) this.formData.startTime = dateTimeFormat(val)
    },
    formatEndTime: function(val) {
      if (val !== undefined) { this.formData.endTime = dateTimeFormat(val) }
    },
    initStartTime: function() {
      var nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.formData.startTime = dateTimeFormat(nowTime)
    },
    initEndTime: function() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.formData.endTime = dateTimeFormat(nowTime)
    },
    handleCurrentChange(val) {
      this.currentRow = val
      // this.pageNum = val
      // if (!this.isQuery && this.pageNum <= this.totalPages) this.getList()
    },
    getList: function() {
      var that = this
      that.isQuery = true
      return new Promise((resolve, reject) => {
        queryTraceLog(that.formData.seq, that.formData.category, that.formData.startTime, that.formData.endTime, that.pageNum - 1, that.pageSize)
          .then(function(response) {
            console.log('response:', response)
            that.isQuery = false
            var _data = response
            if (_data !== undefined) {
              if (_data.bizLogOB3[0].logList.length > 0) {
                that.loglistob3 = _data.bizLogOB3[0].logList
                that.OB_FLAG = false
                document.getElementById('ob3table').removeAttribute('hidden')
              }

              if (_data.bizLogOB4[0].logList.length > 0) {
                that.OB_FLAG = true
                that.loglistob4 = _data.bizLogOB4[0].logList
                document.getElementById('ob4table').removeAttribute('hidden')
              }
            } else {
              that.$message.error(response.data.resultDTO.errorInfo || '系统异常')
            }
          }).catch((error) => {
            that.isQuery = false
            this.listLoading = false
            reject(error)
          })
      })
    },
    handleQuery: function(ruleForm) {
      var that = this
      document.getElementById('ob3table').setAttribute('hidden', true)
      document.getElementById('ob4table').setAttribute('hidden', true)
      this.$refs[ruleForm].validate(function(valid) {
        if (valid) {
          that.getList()
        }
      })
    },
    formatLogTime: function(row, col) {
      return dateTimeFormat(row.sendTime)
    },
    handleSlideUpCtrl: function(e) {
      var target = e.target
      target.classList.toggle('slideUp')
      var wrapperBox = this.$refs['wrapperBox']
      wrapperBox.classList.toggle('slideUp')
    }
  }
}
</script>
<style scoped>

.chart-container {

                height: 500px;

                width: 100%;

                position: relative;
    
                display: flex;
                
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
            }
.chart-containerA {

                height: 800px;
                width: 100%;

                float: left;
                
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    
                border-color: rgba(0, 0, 0, .05);
            }
.chart-containerB {
  margin-left: 2px;

                height: 500px;

                width: 49%;

                float: left;
                
                color: #666;
    
                background: #fff;
    
                box-shadow: 4px 4px 40px rgba(0, 0, 0, 0.05);
    
                border-color: rgba(0, 0, 0, .05);
            }
.el-table .rowA{
  background: gold;
 
}
.el-table .rowB{
  background: floralwhite;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
.JSONVIEW{
  overflow: auto;
}
</style>
