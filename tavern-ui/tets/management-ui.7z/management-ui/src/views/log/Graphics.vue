<template>
  <div class="app-container">
    <el-card >
          <el-popover
          placement="left"
          trigger="click">
           <el-form ref="ruleForm">
        <div class="form-wrapper">
          <el-form-item class="form-wrapper-item" label="轮询时间" label-width="160px">
            <el-select v-model="countertime" placeholder="轮询间隔时间" >
              <el-option
                      v-for="item in timeTable"
                      :key="item.value"
                      :label="item.value"
                      :value="item.time">
              </el-option>
            </el-select>
            <el-button :type = "timerStatus === '开始轮询' ? 'primary' : 'danger' " @click="stopQuery" v-loading.body="listLoading" size="mini">{{timerStatus}}</el-button>
          </el-form-item>
        </div>
      </el-form>
                <el-button slot="reference" style="float: left" type="text">操作按钮</el-button>
          </el-popover>
    <el-table :data="list" v-loading.body="listLoading" element-loading-text="Loading" border fit highlight-current-row
    :stripe="true"
    class="outTable">
    
     <!-- <el-table-column align="center" label='NO.' width="95">
        <template slot-scope="scope">
          {{scope.$index}}
        </template>
      </el-table-column> -->
      <el-table-column label="模块名" width=150>
        <template slot-scope="scope">
          {{scope.row.moduleName}}
        </template>
      </el-table-column>
      <el-table-column >
        <template slot-scope="scope">
          <el-table :data="scope.row.clusters" v-loading.body="listLoading" element-loading-text="Loading" border fit highlight-current-row
          :show-header="false" 
          :stripe="true"
          class="innerTable"> 
          <el-table-column width=150>
            <template slot-scope="scope1">
              {{scope1.row.clusterName}}
            </template>
          </el-table-column>
          <el-table-column>
            <template slot-scope="scope1">
              <el-button :type= "item.status === '正常' ? 'success': (item.status === '未采集数据' ? 'warning':(item.status === '未启用监控' ? 'info':'danger'))"
              v-for = "item in scope1.row.instances" 
              :key = "item.instanceId"  
              size="mini"
              class="selectButton"
              @click="handleDetailInfo(item.instanceId,item.serverIp,item.status)"
              v-loading.body="listLoading">
                {{item.serverIp}}:{{item.status}}
              </el-button>
            </template>
          </el-table-column>
          </el-table>
        </template>
      </el-table-column>
    </el-table>
    </el-card>
  </div>
</template>