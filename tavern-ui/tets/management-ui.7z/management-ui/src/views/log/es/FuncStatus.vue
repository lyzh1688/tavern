<template>
   <div class="app-container">
     <el-card>
       <el-card class="title" v-loading.body="listLoading">
            <el-form :inline="true" :rules="rule" @submit.native.prevent v-loading.body="listLoading"> 
                <!-- <el-form-item label="关键字：">
                    <el-select v-model="keyword">
                        <el-option
                            v-for="item in keywordList"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                </el-form-item> -->
                <el-form-item label="查询数量：" label-width="120px">
                    <el-input @keyup.enter.native="getList" v-model="formData.size" size="mini"></el-input> 
                </el-form-item>
                        <el-form-item  label="接口类型" label-width="120px" prop="info">
    
                            <!-- <el-input v-model="formData.type" size="mini"></el-input> -->
                             <el-select v-model="formData.type" size="mini">
                                                            <el-option
                                                                v-for="item in typeTable"
                                                                :key="item"
                                                                :label="item"
                                                                :value="item"
                                                            >
                                                                </el-option>
                                                        </el-select>
                        </el-form-item>
                        <el-form-item  label="环境" label-width="120px" prop="info">
    
                            <!-- <el-input v-model="formData.type" size="mini"></el-input> -->
                             <el-select v-model="formData.env" size="mini">
                                                            <el-option
                                                                v-for="item in envTable"
                                                                :key="item"
                                                                :label="item"
                                                                :value="item"
                                                            >
                                                                </el-option>
                                                        </el-select>
                        </el-form-item>
                        <el-form-item  label="应用版本" label-width="120px" prop="info">
    
                            <!-- <el-input v-model="formData.type" size="mini"></el-input> -->
                             <el-select v-model="formData.appType" size="mini">
                                                            <el-option
                                                                v-for="item in appTypeList"
                                                                :key="item"
                                                                :label="item"
                                                                :value="item"
                                                            >
                                                                </el-option>
                                                        </el-select>
                        </el-form-item>
                        <div>
                  <el-form-item  label="开始时间" label-width="120px" prop="startTime">
                    <el-date-picker v-model="formData.startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
                  </el-form-item>
                  <el-form-item  label="结束时间" label-width="120px" prop="endTime">
                    <el-date-picker v-model="formData.endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
                  </el-form-item>
                  <el-button @click="getList" type="primary" size="mini">查询</el-button>
                  <!-- <el-button @click="getListOB3" type="primary">查询OB3调用</el-button> -->
                  <span class="word"><span class="_3s">■</span>3s以上</span><span class="word"><span class="_500ms_3s">■</span>500ms到3s</span><span class="word"><span class="_100ms_500ms">■</span>100到500ms</span><span  class="word"><span class="_100ms">■</span>100ms以下</span>
           
                        </div>
                
                <!-- <el-button @click="isShowMetric = !isShowMetric">test</el-button> -->
                  </el-form>
           	</el-card>
             <el-card>
        <el-table
        :data="list"
        size="mini"
        :stripe="true"
        v-loading.body="listLoading"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="功能号"
        prop="funcNo"
        width="110%">
        <template slot-scope="scope">
          <transition enter-active-class="fadeInLeft"
           leave-active-class="fadeOutRight">
         <el-button v-show="isShowMetric==false" style="width:100%;font-color:black;" size="mini" type="primary"  @click="open(scope.row.funcNo)">{{scope.row.funcNo}}</el-button>
          </transition>
        </template>
        </el-table-column>
        <el-table-column
        label="功能号描述"
        prop="FuncName">
        <template slot-scope="scope">
          <el-button v-show="isShowMetric==false&&!scope.row.editFlag" size="mini" type="info" style="width:100%;color:white;" class="box animated" @click="funcNameMark = scope.row.FuncName,scope.row.editFlag=true">{{scope.row.FuncName}}</el-button>
          <el-input v-if="scope.row.editFlag" v-model="scope.row.FuncName" @blur="handleInfoEdit(scope.row)"></el-input>
        </template>
        </el-table-column>
        <el-table-column
        label="调用次数"
        prop="allCount">
        <template slot-scope="scope">
          <transition enter-active-class="fadeInLeft"
           leave-active-class="fadeOutRight">
          <el-tooltip class="tool animated" v-show="isShowMetric==false" effect="dark" :content="String(scope.row.allCount)" placement="left">
            <div class="processContainer">
              <div class="process" :style="{ width:Math.round(scope.row.allCount*100)/(maxCount)+'%',
              background:'rgba(255, 241, 50, 0.5)'}">
                <span style="display:inline-block"></span>
              </div>
              <span>{{scope.row.allCount}}</span>
            </div>
          </el-tooltip>
          </transition>
        </template>
        </el-table-column>
        <el-table-column
        v-if="OB3Flag"
        label="总调用次数"
        prop="SubCounter">
        <template slot-scope="scope">
          <transition enter-active-class="fadeInLeft"
           leave-active-class="fadeOutRight">
          <el-tooltip class="tool animated" v-show="isShowMetric==false" effect="dark" :content="String(scope.row.Number)" placement="left">
            <div class="processContainer">
              <div class="process" :style="{ width:Math.round(scope.row.SubCounter*100)/(maxCount)+'%',
              background:'rgba(255, 241, 50, 0.5)'}">
                <span style="display:inline-block"></span>
              </div>
              <span>{{scope.row.SubCounter}}</span>
            </div>
          </el-tooltip>
          </transition>
        </template>
        </el-table-column>
        <el-table-column
        label="成功率" 
        prop="successRate">
        
        <!-- <template slot-scope="scope">
           <span>{{Math.round(scope.row.successRate*10000)/100.00}}%</span>
        </template> -->
        <template slot-scope="scope">
           <transition enter-active-class="fadeInLeft"
           leave-active-class="fadeOutRight">
          <el-tooltip class="tool animated" v-show="isShowMetric==false" effect="dark" :content="String((scope.row.successCount*100/scope.row.allCount).toFixed(2)+'%')" placement="left">
            <div class="processContainer">
              <div class="process" :style="{ width:(scope.row.successCount*100/scope.row.allCount).toFixed(2)+'%',
              background:(scope.row.successCount*100/scope.row.allCount).toFixed(2)<50?'rgba(233,0,0,.5)':'rgba(56, 240, 81, 0.5)'}">
                <span style="display:inline-block"></span>
              </div>
              <span>{{(scope.row.successCount*100/scope.row.allCount).toFixed(2)}}%</span>
            </div>
          </el-tooltip>
          </transition>
        </template>
        
        </el-table-column>
        <el-table-column
        label="平均响应时间及分布"
        prop="avgDuration">
        <template slot-scope="scope">
          
          <transition enter-active-class="fadeInLeft"
           leave-active-class="fadeOutRight">
           
       <div>
          <el-tooltip class="tool animated" v-show="isShowMetric==false" effect="dark" :content="String((scope.row.avgDuration).toFixed(2)+'ms')" placement="left">
            
            <div class="processContainer">
              <div class="process" :style="{ width:(scope.row.avgDuration*100/maxDuration).toFixed(2)+'%',
              background:(scope.row.avgDuration).toFixed(2)>3000?'rgba(233,0,0,.5)':'rgba(56, 240, 81, 0.5)'}">
                <span style="display:inline-block"></span>
              </div>
              <span>{{(scope.row.avgDuration).toFixed(2)}}ms</span>
            </div>
          </el-tooltip>
          </div>
          </transition>
          <div style="height:40px;">
         <funcDuration height="100%" :chartData="[scope.row.oneHundredMsCount*100/scope.row.allCount,scope.row.fiveHundredMsCount*100/scope.row.allCount,scope.row.threeThousandMsCount*100/scope.row.allCount,scope.row.aboveThreeThousandMsCount*100/scope.row.allCount,scope.row.funcNo]"></funcDuration>
       </div>
        </template>
        </el-table-column>
        </el-table>
        </el-card>
        </el-card>
   </div>
</template>
<script>
import { dateTimeFormat } from '@/store/date'
import {
  topFuncNoOB3,
  funcdetail,
  topQuery,
  updateFuncNoDesc,
  appTypeListQuery } from '@/api/log'
import { Message } from 'element-ui'
import funcDuration from '../components/funcDuration'
export default {
  name: 'FuncStatus',
  data() {
    var that = this
    // 校验规则
    var _ruleStartTime = (rule, value, callback) => {
      if (that.formData.startTime === '') {
        callback(new Error('请选择开始时间!'))
      } else {
        if (that.formData.endTime !== '' && that.formData.endTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('开始时间必须小于结束时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    var _ruleEndTime = (rule, value, callback) => {
      if (that.formData.endTime === '') {
        callback(new Error('请选择结束时间!'))
      } else {
        if (that.formData.startTime !== '' && that.formData.startTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('结束时间必须大于开始时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    return {
      date: '',
      topList: {},
      lineChartData: '',
      isShowMetric: true,
      resizeFlag: false,
      method: 'day',
      timePicker: '',
      keyword: 'user',
      maxDuration: 0,
      maxCount: 0,
      keywordList: [{ value: 'user' }, { value: 'deviceId' }],
      methodList: [{ value: 'day' }, { value: 'hour' }, { value: 'month' }],
      rule: {
        startTime: [{ validator: _ruleStartTime, trigger: 'blur' }],
        endTime: [{ validator: _ruleEndTime, trigger: 'blur' }]
      },
      formData: {
        size: 50,
        startTime: '',
        endTime: '',
        type: 'OB5',
        env: '',
        appType: ''
      },
      list: null,
      nameList: null,
      listLoading: false,
      OB3Flag: false,
      appTypeList: [],
      typeTable: ['OB3', 'OB5'],
      envTable: process.env.zt_log_type,
      funcNameMark: ''
    }
  },
  created() {
    this.initStartTime()
    this.initEndTime()
    // this.getList()
    this.getAppTypeList()
  },
  components: {
    funcDuration
  },
  methods: {
    handleInfoEdit(row) {
      if (row.FuncName !== this.funcNameMark) {
        this.$confirm('是否修改功能号描述？', '提示', {
          confirmButtonText: '确认',
          type: 'warning'
        }).then(
          _ => {
            row.editFlag = false
            console.log('trigerForm', row.FuncName, this.funcNameMark)
            this.listLoading = true
            updateFuncNoDesc(row.funcNo, row.FuncName).then(response => {
              this.listLoading = false
              console.log('updateFuncNoDesc:', response)
              if (response.code === 0) {
                Message.success('修改完成！')
              } else {
                Message.error(response.code + ':' + response.info)
                row.FuncName = this.funcNameMark
              }
            }).catch((error) => {
              Message.error('修改失败:' + error)
              row.FuncName = this.funcNameMark
              this.listLoading = false
            })
            //   if (type === 'arbiter') console.log('comfirm', name, process.env.zt_arbiter_url.split('/arbiter')[0] + url, actType, args)
            //   else console.log('comfirm', name, url, actType, args)
          }
        ).catch(_ => {
          row.editFlag = false
          row.FuncName = this.funcNameMark
        })
      } else {
        row.editFlag = false
      }
    },
    // iniDate() {
    //   const data = new Date(Date.now())
    //   if ((data.getMonth + 1) >= 10) this.date = data.getFullYear() + '.' + (data.getMonth() + 1)
    //   else this.date = data.getFullYear() + '.0' + (data.getMonth() + 1)
    //   if ((data.getDay) >= 10) this.date = this.date + '.' + data.getDate()
    //   else this.date = this.date + '.0' + data.getDate()
    // },
    getAppTypeList() {
      this.listLoading = true
      appTypeListQuery('').then(response => {
        this.listLoading = false
        console.log('appTypeList:', response.data.appTypeList)
        if (response.code === 0) {
          this.appTypeList = response.data.appTypeList
          this.appTypeList.push('')
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch((error) => {
        Message.error('获取app类型失败:' + error)
        this.listLoading = false
      })
    },
    formatStartTime: function(val) {
      if (val !== undefined) { this.formData.startTime = dateTimeFormat(val) }
    },
    formatEndTime: function(val) {
      if (val !== undefined) { this.formData.endTime = dateTimeFormat(val) }
    },
    initStartTime: function() {
      var nowTime = new Date(new Date())
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.formData.startTime = dateTimeFormat(nowTime)
    },
    initEndTime: function() {
      var nowTime = new Date(new Date())
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.formData.endTime = dateTimeFormat(nowTime)
    },
    getList: function() {
      var that = this
      that.OB3Flag = false
      that.isQuery = true
      that.listLoading = true
      that.maxDuration = 0
      that.maxCount = 0
      topQuery(that.formData.size, that.formData.startTime, that.formData.endTime, that.formData.type, that.formData.env, that.formData.appType)
        .then(function(response) {
          console.log('topQuery:', response)
          that.isQuery = false
          that.nameList = []
          if (response.code === 0) {
            that.list = response.data.topList
            for (const i of response.data.topList) {
              if (i.avgDuration > that.maxDuration)that.maxDuration = i.avgDuration
              if (i.allCount > that.maxCount)that.maxCount = i.allCount
              that.nameList.push(i.funcNo)
            }
            if (that.nameList.length !== 0) {
              funcdetail(that.nameList).then(function(response2) {
                if (response2.data[0] !== undefined && response2.data[0] != null) {
                  console.log('funcdetail', response2)
                  that.list = that.list.map(v => {
                    that.$set(v, 'FuncName', String(response2.data[0].funcDetail[v.funcNo]))
                    that.$set(v, 'editFlag', false)
                    return v
                  })
                }
                console.log('list:', that.list)
                that.listLoading = false
                that.isShowMetric = true
                setTimeout(function() {
                  that.isShowMetric = false
                }, 200)
              }).catch(() => {
                that.listLoading = false
              })
            } else {
              that.listLoading = false
            }
          } else {
            that.listLoading = true
            that.$message.error(response.data.errorInfo || '系统异常')
          }
        }).catch(() => {
          that.listLoading = false
        })
    },
    getListOB3: function() {
      var that = this
      that.OB3Flag = true
      that.isQuery = true
      that.listLoading = true
      that.maxDuration = 0
      that.maxCount = 0
      topFuncNoOB3(that.formData.size, that.formData.startTime, that.formData.endTime)
        .then(function(response) {
          console.log('response:', response)
          that.isQuery = false
          that.nameList = []
          if (response.data[0] !== undefined && response.data[0] != null) {
            that.list = response.data[0].logList
            for (const i of response.data[0].logList) {
              if (i.avgDuration > that.maxDuration)that.maxDuration = i.avgDuration
              if (i.Number > that.maxCount)that.maxCount = i.Number
              that.nameList.push(i.item)
            }
            funcdetail(that.nameList).then(function(response2) {
              if (response2.data[0] !== undefined && response2.data[0] != null) {
                that.list = that.list.map(v => {
                  that.$set(v, 'FuncName', String(response2.data[0].funcDetail[v.item]))
                  return v
                })
              }
              console.log('list:', that.list)
              that.listLoading = false
              that.isShowMetric = true
              setTimeout(function() {
                that.isShowMetric = false
              }, 200)
            }).catch(() => {
              that.listLoading = false
            })
          } else {
            that.listLoading = true
            that.$message.error(response.data.errorInfo || '系统异常')
          }
        }).catch(() => {
          that.listLoading = false
        })
    },
    open(item) {
      const startTime = this.formData.startTime
      const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/Log/funcDetail/' + item, { item: item, startTime: startTime, endTime: endTime })
      this.$router.push({ path: '/Log/funcDetail/' + item, query: { item: item, startTime: startTime, endTime: endTime }})
    //   const seqUrl = '/biz/es/tracelog/ui?seq=' + seq + '&startTime=' + startTime + '&endTime=' + endTime
    //   console.log(seqUrl)
    //   const title = '业务日志查询'
    //   window.parent.addTab(title, seqUrl)
    }
  }
}
</script>
<style scoped>
@import '../../../styles/animate.css';
.chartData-container {
 /* margin-top: -40px; */
    padding: 20px;
    width: 100%;
    height: 500px;
    float: left;
}
.topTable{
    width: 100%;
    float: left;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
._100ms{
  
color:#3cff00;
font-size:40px;

}
._100ms_500ms{
  
  color:#00ffb3;
font-size:40px;
}
._500ms_3s{

  color:#ffae00;
font-size:40px;
}
._3s{

  color:#ff0000;
font-size:40px;
}
.word{
  
  float: right;
}

</style>