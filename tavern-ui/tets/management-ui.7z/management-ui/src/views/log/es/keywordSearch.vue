<template>
   <div class="app-container" v-loading.body="listLoading">
     <el-card>
       <div>
            <el-form :inline="true">
                <!-- <el-form-item label="关键字：">
                    <el-select v-model="keyword">
                        <el-option
                            v-for="item in keywordList"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                </el-form-item> -->
                <el-form-item label="时间方式：">
                    <el-select v-model="method">
                        <el-option
                            v-for="item in methodList"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>  
                </el-form-item>
                 <el-form-item v-if="method=='hour'" label="时间" >
                    <el-date-picker v-model="date"></el-date-picker>
                </el-form-item>
                <el-form-item v-if="method!='hour'" label="月份" >
                    <el-date-picker type="month" v-model="month"></el-date-picker>
                </el-form-item>
                <!-- <el-form-item label="活跃用户数：" >
                    <el-select v-model="topSize">
                        <el-option
                            v-for="item in topSizeList"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>  
                </el-form-item> -->
                <el-button @click="getList" type="primary">查询</el-button>
                 <el-form-item label="数据图表切换">
                <el-switch v-model="isShowMetric"></el-switch>
                 </el-form-item>
                
            </el-form>
            
		</div>
        <span v-show="isShowMetric == false">user</span>
        <el-table
        v-show="isShowMetric == false"
        :data="list.user"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="date"
        prop="date"></el-table-column>
        <el-table-column
        label="Number"
        prop="UserNumber"></el-table-column>
        </el-table>
        <span v-show="isShowMetric == false">deviceId</span>
        <el-table
        v-show="isShowMetric == false"
        :data="list.deviceId"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="date"
        prop="date"></el-table-column>
        <el-table-column
        label="Number"
        prop="UserNumber"></el-table-column>
        </el-table>
          <div
            v-show="isShowMetric == true"
            style="background:#fff;padding:16px 16px 0;"
        >
            <div class='chartData-container' v-show="isShowMetric == true">
                <chart
                v-show="isShowMetric == true"
                    height='100%'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData.chartData"
                    className="UV与PV图"
                ></chart>
            </div>
            </div>
            <!-- <div class="topTable">
            <span v-show="isShowMetric == true">user</span>
            <el-table
        v-show="isShowMetric == true"
        :data="topList.user"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="用户:名称"
        prop="item"></el-table-column>
        <el-table-column
        :label="'用户:活跃'+method+'数，即每'+method+'至少登陆一次'"
        prop="Number"></el-table-column>
        </el-table>
        </div>
        <div class="topTable">
        <span v-show="isShowMetric == true">deviceId</span>
<el-table
        v-show="isShowMetric == true"
        :data="topList.deviceId"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="设备：id"
        prop="item"></el-table-column>
        <el-table-column
        :label="'设备：活跃'+method+'数，即每'+method+'至少登陆一次'"
        prop="Number"></el-table-column>
        </el-table>
        </div> -->
    </el-card>
   </div>
</template>
<script>
import { keywordSearch,
  topSearch } from '@/api/log'
import Chart from '../components/mixChart'
import Axios from 'axios'
const lineChartData = {
  gwuserRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }],
    listLoading: false
  }
}
export default {
  name: 'keywordSearch',
  data() {
    return {
      date: '',
      topList: {},
      lineChartData: '',
      topSize: 5,
      isShowMetric: true,
      resizeFlag: false,
      method: 'day',
      month: '',
      timePicker: '',
      keyword: 'user',
      listLoading: false,
      keywordList: [{ value: 'user' }, { value: 'deviceId' }],
      methodList: [{ value: 'day' }, { value: 'hour' }, { value: 'month' }],
      topSizeList: [{ value: 5 }, { value: 10 }],
      list: null
    }
  },
  components: {
    Chart
  },
  created() {
    this.getList()
  },
  methods: {
    // iniDate() {
    //   const data = new Date(Date.now())
    //   if ((data.getMonth + 1) >= 10) this.date = data.getFullYear() + '.' + (data.getMonth() + 1)
    //   else this.date = data.getFullYear() + '.0' + (data.getMonth() + 1)
    //   if ((data.getDay) >= 10) this.date = this.date + '.' + data.getDate()
    //   else this.date = this.date + '.0' + data.getDate()
    // },
    getTop() {
      var that = this
      that.listLoading = true
      that.topList = {}
      let dateString = ''
      if (that.date !== '') {
        const dateMark = new Date(that.date)
        if ((dateMark.getMonth() + 1) >= 10) dateString = dateMark.getFullYear() + '.' + (dateMark.getMonth() + 1)
        else dateString = dateMark.getFullYear() + '.0' + (dateMark.getMonth() + 1)
        if ((dateMark.getDate()) >= 10) dateString = dateString + '.' + dateMark.getDate()
        else dateString = dateString + '.0' + dateMark.getDate()
      }
      if (dateString === '1970.01.01')dateString = ''
      if (that.method === 'month') {
        that.topList = {}
        return
      }
      const requestGroup1 = []
      for (const i of ['user', 'deviceId']) {
        requestGroup1.push(topSearch(i, that.method, dateString, that.topSize)
          .then(function(response) {
            console.log('response:', response)
            that.listLoading = false
            if (response.data[0] !== undefined && response.data[0] != null) {
              that.topList[i] = response.data[0].logList
              console.log('topList:', that.topList)
            } else {
              that.$message.error(response.data.errorInfo || '系统异常')
            }
          }).catch(() => {
          }))
      }
      Axios.all(requestGroup1).then(function() {
        that.listLoading = false
        that.topList = Object.assign({}, that.topList)
      })
    },
    getList: function() {
      var that = this
      that.listLoading = true
      that.list = []
      let dateString = ''
      let monthString = ''
      if (that.date !== '') {
        const dateMark = new Date(that.date)
        if ((dateMark.getMonth() + 1) >= 10) dateString = dateMark.getFullYear() + '.' + (dateMark.getMonth() + 1)
        else dateString = dateMark.getFullYear() + '.0' + (dateMark.getMonth() + 1)
        if ((dateMark.getDate()) >= 10) dateString = dateString + '.' + dateMark.getDate()
        else dateString = dateString + '.0' + dateMark.getDate()
      }
      if (that.month !== '') {
        const dateMark = new Date(that.month)
        if ((dateMark.getMonth() + 1) >= 10) monthString = dateMark.getFullYear() + '.' + (dateMark.getMonth() + 1)
        else monthString = dateMark.getFullYear() + '.0' + (dateMark.getMonth() + 1)
      }
      if (dateString === '1970.01.01')dateString = ''
      if (that.method === 'month') {
        that.list = {}
        lineChartData['chartData'] = {}
        lineChartData['chartData']['xdata'] = [0]
        lineChartData['chartData']['ydata'] = [0]
        lineChartData['chartData']['namedata'] = ['month']
        that.lineChartData = Object.assign({}, lineChartData)
        return
      }
      const requestGroup = []
      lineChartData['chartData'] = {}
      lineChartData['chartData']['xdata'] = []
      lineChartData['chartData']['ydata'] = []
      lineChartData['chartData']['namedata'] = []
      that.list = {}
      for (const i of ['user', 'deviceId']) {
        requestGroup.push(
          keywordSearch(i, that.method, dateString, monthString)
            .then(function(response) {
              console.log('response:', response)
              that.listLoading = false
              that.nowEnv = that.env
              if (response.data[0] !== undefined && response.data[0] != null) {
                that.list[i] = response.data[0].logList
                console.log('list:', that.list)
                //					that.pageNum=response.data.pageNum*1+1;
                const tempx = []
                const tempym1Rate = []
                for (const s of response.data[0].logList) {
                  tempx.push(s.date)
                  tempym1Rate.push(s.UserNumber)
                }
                if (that.method === 'day') {
                  lineChartData['chartData']['xdata'].push(tempx.reverse())
                  lineChartData['chartData']['ydata'].push(tempym1Rate.reverse())
                } else if (that.method === 'hour') {
                  lineChartData['chartData']['xdata'].push(tempx)
                  lineChartData['chartData']['ydata'].push(tempym1Rate)
                }
                lineChartData['chartData']['namedata'].push(i)
              } else {
                that.$message.error(response.data.errorInfo || '系统异常')
              }
            }).catch(() => {
              that.nowEnv = that.env
              that.tablelist = []
            }))
      }
      Axios.all(requestGroup).then(function() {
        that.listLoading = false
        // that.getTop()
        that.lineChartData = Object.assign({}, lineChartData)
        console.log('lineChartData:', that.lineChartData)
      })
    }
  }
}
</script>
<style scoped>
.chartData-container {
 /* margin-top: -40px; */
    padding: 20px;
    width: 100%;
    height: 700px;
}
.topTable{
    width: 48%;
    float: left;
}
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>

