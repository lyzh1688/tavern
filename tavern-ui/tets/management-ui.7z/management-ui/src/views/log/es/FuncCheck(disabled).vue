<template>
   <div class="app-container">
       <div>
            <el-form :inline="true" :rules="rule">
                <!-- <el-form-item label="关键字：">
                    <el-select v-model="keyword">
                        <el-option
                            v-for="item in keywordList"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                </el-form-item> -->
                <el-form-item label="funcNo：">
                    <el-input v-model="formData.funcNo" size="mini"></el-input> 
                </el-form-item>
                 <el-form-item class="form-wrapper-item form-item-query normal-width" label="开始时间" label-width="120px" prop="startTime">
    
                            <el-date-picker v-model="formData.startTime" type="date" size="mini" @change="formatStartTime"></el-date-picker>
    
                        </el-form-item>
    
                        <el-form-item class="form-wrapper-item form-item-query normal-width" label="结束时间" label-width="100px" prop="endTime">
    
                            <el-date-picker v-model="formData.endTime" type="date" size="mini" @change="formatEndTime"></el-date-picker>
    
                        </el-form-item>
                <el-button @click="getList" type="primary">查询</el-button>
                
            </el-form>
            
		</div>
        <!-- <span v-show="isShowMetric == false">user</span>
        <el-table
        v-show="isShowMetric == false"
        :data="list.user"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="date"
        prop="date"></el-table-column>
        <el-table-column
        label="Number"
        prop="UserNumber"></el-table-column>
        </el-table>
        <span v-show="isShowMetric == false">deviceId</span>
        <el-table
        v-show="isShowMetric == false"
        :data="list.deviceId"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="date"
        prop="date"></el-table-column>
        <el-table-column
        label="Number"
        prop="UserNumber"></el-table-column>
        </el-table> -->
          <div
            v-show="isShowMetric == true"
            style="background:#fff;padding:16px 16px 0;"
        >
            <div class='chartData-container' v-show="isShowMetric == true">
                <panChart
                v-show="isShowMetric == true"
                    height='100%'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData.chartData"
                    className="UV与PV图"
                ></panChart>
            </div>
            </div>
            <div
            v-show="isShowMetric == true"
            style="background:#fff;padding:16px 16px 0;"
        >
            <div class='chartData-container' v-show="isShowMetric == true">
                <Chart
                v-show="isShowMetric == true"
                    height='100%'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData.infodata"
                    className="响应时间"
                ></Chart>
            </div>
            </div>
   </div>
</template>
<script>
import { funcNoStatus } from '@/api/log'
import { dateTimeFormat } from '@/store/date'
import panChart from '../components/panChart'
import Chart from '../components/mixChart'
const lineChartData = {
  gwuserRequest: {
    xdata: [0],
    ydata: [0],
    namedata: [0],
    functionData: [{
      name: 0,
      m1Rate: 0,
      m5Rate: 0,
      m15Rate: 0
    }]
  }
}
export default {
  name: 'funcCheck',
  data() {
    var that = this
    // 校验规则
    var _ruleStartTime = (rule, value, callback) => {
      if (that.formData.startTime === '') {
        callback(new Error('请选择开始时间!'))
      } else {
        if (that.formData.endTime !== '' && that.formData.endTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('开始时间必须小于结束时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    var _ruleEndTime = (rule, value, callback) => {
      if (that.formData.endTime === '') {
        callback(new Error('请选择结束时间!'))
      } else {
        if (that.formData.startTime !== '' && that.formData.startTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('结束时间必须大于开始时间!'))
          } else if (Date.parse(that.formData.endTime) > Date.now()) {
            callback(new Error('结束时间必须小于等于今天!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    return {
      date: '',
      topList: {},
      lineChartData: '',
      topSize: 5,
      isShowMetric: true,
      resizeFlag: false,
      formData: {
        funcNo: '',
        startTime: '',
        endTime: ''
      },
      list: null,
      rule: {
        startTime: [{ validator: _ruleStartTime, trigger: 'blur' }],
        endTime: [{ validator: _ruleEndTime, trigger: 'blur' }]
      }
    }
  },
  components: {
    panChart,
    Chart
  },
  created() {
    this.initStartTime()
    this.initEndTime()
  },
  methods: {
    // iniDate() {
    //   const data = new Date(Date.now())
    //   if ((data.getMonth + 1) >= 10) this.date = data.getFullYear() + '.' + (data.getMonth() + 1)
    //   else this.date = data.getFullYear() + '.0' + (data.getMonth() + 1)
    //   if ((data.getDay) >= 10) this.date = this.date + '.' + data.getDate()
    //   else this.date = this.date + '.0' + data.getDate()
    // },
    formatStartTime: function(val) {
      if (val !== undefined) { this.formData.startTime = dateTimeFormat(val) }
    },
    formatEndTime: function(val) {
      if (val !== undefined) { this.formData.endTime = dateTimeFormat(val) }
    },
    initStartTime: function() {
      var nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.formData.startTime = dateTimeFormat(nowTime)
    },
    initEndTime: function() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.formData.endTime = dateTimeFormat(nowTime)
    },
    getList: function() {
      var that = this
      that.isQuery = true
      funcNoStatus(that.formData.funcNo, that.formData.startTime, that.formData.endTime)
        .then(function(response) {
          console.log('response:', response)
          that.isQuery = false
          that.nowEnv = that.env
          if (response.code === 0) {
            that.list = response.data.mapping

            //					that.pageNum=response.data.pageNum*1+1;
            const tempx = []
            const tempy = []
            const name = []
            lineChartData['chartData'] = {}
            lineChartData['chartData']['xdata'] = []
            lineChartData['chartData']['ydata'] = []
            lineChartData['chartData']['namedata'] = []
            lineChartData['infodata'] = {}
            lineChartData['infodata']['xdata'] = []
            lineChartData['infodata']['ydata'] = []
            lineChartData['infodata']['namedata'] = []
            for (const s in that.list) {
              name.push(s)
              console.log('s', s !== 'info')
              if (s !== 'info') {
                for (const n in that.list[s]) {
                  if (n === 'count') {
                    tempx.push({ value: that.list[s][n], name: s })
                  } else {
                    tempy.push({ name: n, value: that.list[s][n] })
                    name.push(n)
                  }
                }
              } else {
                lineChartData['infodata']['xdata'].push(['Duration'])
                lineChartData['infodata']['ydata'].push([that.list[s]['avgDuration']])
                lineChartData['infodata']['namedata'].push('avg')
                lineChartData['infodata']['xdata'].push(['Duration'])
                lineChartData['infodata']['ydata'].push([that.list[s]['maxDuration']])
                lineChartData['infodata']['namedata'].push('max')
              }
            }
            console.log('list:', that.list)
            lineChartData['chartData']['xdata'] = tempx
            lineChartData['chartData']['ydata'] = tempy
            lineChartData['chartData']['namedata'] = name
            // lineChartData['infodata']['xdata'] = infoName
            // lineChartData['infodata']['ydata'] = infox
            // lineChartData['infodata']['namedata'] = infoName
            that.lineChartData = Object.assign({}, lineChartData)
            console.log('lineChartData', lineChartData)
          } else {
            that.$message.error(response.data.errorInfo || '系统异常')
          }
        }).catch(() => {
          that.nowEnv = that.env
          that.tablelist = []
        })
    }
  }
}
</script>
<style scoped>
.chartData-container {
 /* margin-top: -40px; */
 float: left;
    padding: 20px;
    width: 50%;
    height: 500px;
}
.topTable{
    width: 48%;
    float: left;
}
</style>

