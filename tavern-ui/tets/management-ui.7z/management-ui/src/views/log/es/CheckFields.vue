<template>
   <div class="app-container">
     <el-card>
       <div>
			<span style="line-height: 20px; font-size: 15px;"><h3 > <font color="00bfff">es_Field详情,环境：{{nowEnv}} </font></h3></span>
            <el-form :inline="true">
                <el-form-item label="环境：">
                    <el-select v-model="env">
                        <el-option
                            v-for="item in envlist"
                            :key="item.name"
                            :label="item.name"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                    <el-button @click="getList" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
            
		</div>
        <el-table
        :data="curentpage"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="name"
        prop="name"></el-table-column>
        <el-table-column
        label="type"
        prop="type"></el-table-column>
        <el-table-column
        label="searchable"
        prop="searchable">
        <template slot-scope="scop">
        <el-tag
        :type="scop.row.searchable==true?'success':'warning'">{{scop.row.searchable}}
        </el-tag>
        </template>
        </el-table-column>
        <el-table-column
        label="aggregatable"
        prop="aggregatable">
        <template slot-scope="scop">
        <el-tag v-show="scop.row.aggregatable"
        :type="scop.row.aggregatable==true?'success':'warning'">{{scop.row.aggregatable}}
        </el-tag>
        </template>
        </el-table-column>
        </el-table>
        <div class="pagination-wrapper">
			<el-pagination
					@current-change="handleCurrentChange"
					:current-page="pageNum"
					:page-sizes="[20,40,60]"
					:page-size="pageSize"
					:total="totalPages"
					layout="total, prev, pager, next, jumper"></el-pagination>
		</div>
    </el-card>
   </div>
</template>
<script>
import { getMapping } from '@/api/log'
export default {
  name: 'esMapping',
  data() {
    return {
      dataBaseName: 'kafka-log-',
      date: '2018.06.28',
      env: 'dev2',
      nowEnv: 'dev2',
      envlist: [{ name: process.env.zt_config_gw_url1_env, value: process.env.zt_config_gw_url1_env }, { name: process.env.zt_config_gw_url2_env, value: process.env.zt_config_gw_url2_env }],
      pageNum: 1,
      pageSize: 20,
      totalPages: 0,
      curentpage: null,
      list: null,
      tablelist: []
    }
  },
  created() {
    this.iniDate()
    this.getList()
  },
  methods: {
    handleCurrentChange: function(val) {
      this.pageNum = val
      if (!this.isQuery && this.pageNum <= this.totalPages) this.curentpage = this.tablelist.slice((this.pageNum - 1) * this.pageSize, this.pageNum * this.pageSize)
    },
    iniDate() {
      const data = new Date(Date.now())
      if ((data.getMonth() + 1) >= 10) this.date = data.getFullYear() + '.' + (data.getMonth() + 1)
      else this.date = data.getFullYear() + '.0' + (data.getMonth() + 1)
      if ((data.getDate()) >= 10) this.date = this.date + '.' + data.getDate()
      else this.date = this.date + '.0' + data.getDate()
    },
    getList: function() {
      var that = this
      that.isQuery = true
      that.tablelist = []
      that.list = []
      that.pageNum = 1
      that.totalPages = 0
      that.curentpage = []
      return new Promise((resolve, reject) => {
        getMapping(that.dataBaseName + that.date, that.env, that.pageNum - 1, that.pageSize)
          .then(function(response) {
            console.log('response:', response)
            that.isQuery = false
            that.nowEnv = that.env
            if (response.data !== undefined && response.data != null) {
              that.list = response.data.mapping.properties
              console.log('list:', that.list)
              //					that.pageNum=response.data.pageNum*1+1;
              that.tablelist = []
              for (const key in that.list) {
                if (that.list[key]['properties'] !== undefined) {
                  for (const prop in that.list[key]['properties']) {
                    if (that.list[key]['properties'][prop]['type'] !== 'text') {
                      if (that.list[key]['properties'][prop]['type'] === 'long')that.tablelist.push({ name: (key + '.' + prop), type: 'number', searchable: true, aggregatable: true })
                      else that.tablelist.push({ name: (key + '.' + prop), type: that.list[key]['properties'][prop]['type'], searchable: true, aggregatable: true })
                    } else {
                      that.tablelist.push({ name: (key + '.' + prop), type: 'String', searchable: true, aggregatable: false })
                      if (that.list[key]['keyword'] !== undefined || that.list[key]['keyword'] !== null) {
                        that.tablelist.push({ name: ((key + '.' + prop) + '.keyword'), type: 'String', searchable: true, aggregatable: true })
                      }
                    }
                  }
                } else {
                  if (that.list[key]['type'] !== 'text') {
                    if (that.list[key]['type'] === 'long')that.tablelist.push({ name: key, type: 'number', searchable: true, aggregatable: true })
                    else that.tablelist.push({ name: key, type: that.list[key]['type'], searchable: true, aggregatable: true })
                    if (key === '@timestamp') {
                      that.tablelist.push({ name: '_id', type: 'String', searchable: true, aggregatable: false })
                      that.tablelist.push({ name: '_index', type: 'String', searchable: true, aggregatable: true })
                      that.tablelist.push({ name: '_score', type: 'number', searchable: true, aggregatable: false })
                      that.tablelist.push({ name: '_source', type: '_source', searchable: true, aggregatable: false })
                      that.tablelist.push({ name: '_type', type: 'String', searchable: true, aggregatable: true })
                    }
                  } else {
                    that.tablelist.push({ name: key, type: 'String', searchable: true, aggregatable: false })
                    if (that.list[key]['keyword'] !== undefined || that.list[key]['keyword'] !== null) {
                      that.tablelist.push({ name: (key + '.keyword'), type: 'String', searchable: true, aggregatable: true })
                    }
                  }
                }
              }
              that.totalPages = that.tablelist.length
              that.handleCurrentChange(1)
              console.log('tablelist:', that.tablelist, that.date, that.totalPages)
            } else {
              that.$message.error(response.data.errorInfo || '系统异常')
            }
            resolve(response)
          }).catch((error) => {
            that.nowEnv = that.env
            that.tablelist = []
            reject(error)
          })
      })
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color: #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
