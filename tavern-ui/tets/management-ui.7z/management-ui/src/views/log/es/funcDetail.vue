<template>
   <div class="app-container">
     <el-card>
       <div>
            <el-form :inline="true" :rules="rule" @submit.native.prevent>
                <!-- <el-form-item label="关键字：">
                    <el-select v-model="keyword">
                        <el-option
                            v-for="item in keywordList"
                            :key="item.value"
                            :label="item.value"
                            :value="item.value"
                        >
                            </el-option>
                    </el-select>
                </el-form-item> -->
                <el-form-item label="funcNo：">
                    <el-input @change="getAppTypeList()" @keyup.enter.native="getList" v-model="formData.funcNo" size="mini"></el-input> 
                </el-form-item>
                        <el-form-item  label="查询方式" label-width="120px" prop="info">
    
                            <!-- <el-input v-model="formData.type" size="mini"></el-input> -->
                             <el-select v-model="formData.TimeType" size="mini">
                                                            <el-option
                                                                v-for="item in TimeTypeTable"
                                                                :key="item.value"
                                                                :label="item.name"
                                                                :value="item.value"
                                                            >{{item.name}}
                                                                </el-option>
                                                        </el-select>
                        </el-form-item>
                 <el-form-item v-if="formData.TimeType!='minute'" class="form-wrapper-item form-item-query normal-width" label="开始时间" label-width="120px" prop="startTime">
    
                            <el-date-picker v-model="formData.startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
    
                        </el-form-item>
    
                        <el-form-item v-if="formData.TimeType!='minute'" class="form-wrapper-item form-item-query normal-width" label="结束时间" label-width="100px" prop="endTime">
    
                            <el-date-picker v-model="formData.endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
    
                        </el-form-item>
                <el-form-item label="查看环境">
                  <el-checkbox-group
                      v-model="pickedEnv">
                                <div 
                                style="padding:10px;">
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item'
                                        v-for='item in envTable'
                                        v-if="item!==''"
                                        :label="item"
                                        :border="true"
                                        size="mini"
                                    >{{item}}</el-checkbox>
                                </div>
                  </el-checkbox-group>
                </el-form-item>
                <el-form-item label="查看环境">
                  <el-checkbox-group
                      v-model="formData.appType">
                                <div 
                                style="padding:10px;">
                                     <el-checkbox
                                    class="checkBox"
                                        :key='item'
                                        v-for='item in appTypeList'
                                        v-if="item!==''"
                                        :label="item"
                                        :border="true"
                                        size="mini"
                                    >{{item}}</el-checkbox>
                                </div>
                  </el-checkbox-group>
                </el-form-item>
                <el-button @click="getList" type="primary">查询</el-button>
                
            </el-form>
            
		</div>
        <!-- <span v-show="isShowMetric == false">user</span>
        <el-table
        v-show="isShowMetric == false"
        :data="list.user"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="date"
        prop="date"></el-table-column>
        <el-table-column
        label="Number"
        prop="UserNumber"></el-table-column>
        </el-table>
        <span v-show="isShowMetric == false">deviceId</span>
        <el-table
        v-show="isShowMetric == false"
        :data="list.deviceId"
        >
        <el-table-column
        type="index"
        width="50px"
        align="center"
    ></el-table-column>
        <el-table-column
        label="date"
        prop="date"></el-table-column>
        <el-table-column
        label="Number"
        prop="UserNumber"></el-table-column>
        </el-table> -->
            <!-- <div class='chartData-container' v-show="isShowMetric == true">
                <stackChart
                v-show="isShowMetric == true"
                    height='100%'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData.countData"
                    className="调用次数分布"
                ></stackChart>
            </div> -->
            <el-card class='chartData-container' v-show="isShowMetric == true">
              <el-container>
              <el-aside style="display:block;width:15%;">
                <div>返回码对应信息</div>
                <el-table
                  :data="[...codeInfoMap]"
                  size="mini"
                  :stripe="true"
                  >
                  <el-table-column
                  width="60%"
                  label="返回码">
                    <template slot-scope="scope">
                      {{scope.row[0]}}
                    </template>
                  </el-table-column>
                  <el-table-column
                  label="说明">
                    <template slot-scope="scope">
                      {{scope.row[1]}}
                    </template>
                  </el-table-column>
                  </el-table>
              </el-aside>
              <el-main>
                <stackChartV2
                v-for="item in envTable"
                :key="item"
                v-show="pickedEnv.indexOf(item) !== -1&&lineChartData[item]!=null&&lineChartData[item].namedata.length!=0"
                    height='400px'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData[item]"
                    :className="item + '环境调用次数及错误率分布图'"
                ></stackChartV2> 
              </el-main>
              </el-container>
              
            </el-card>
            <el-card class='chartData-container' v-show="isShowMetric == true">
              <el-container>
              <el-aside style="display:block;width:15%;">
                <div>图例</div>
                <el-table
                  :data="durationInfoTable"
                  size="mini"
                  :stripe="true"
                  >
                  <el-table-column
                  width="60%"
                  label="图标">
                    <template slot-scope="scope">
                      {{scope.row[0]}}
                    </template>
                  </el-table-column>
                  <el-table-column
                  label="说明">
                    <template slot-scope="scope">
                      {{scope.row[1]}}
                    </template>
                  </el-table-column>
                  </el-table>
              </el-aside>
              <el-main>
                <stackChartDuration
                v-for="item in envTable"
                :key="item"
                v-show="pickedEnv.indexOf(item) !== -1&&lineChartData[item]!=null&&lineChartData[item].namedata.length!=0"
                    height='400px'
                    width='100%'
                    :onresize="resizeFlag"
                    :chartData="lineChartData[item]"
                    :className="item + '响应时间'"
                ></stackChartDuration>
              </el-main>
              </el-container>
                
            </el-card>
            </el-card>
   </div>
</template>
<script>
// export function detailQuery(TimeType, beginTime, endTime, funcNo, env, appType)
import { detailQuery,
  appTypeListQuery } from '@/api/log'
import stackChartV2 from '../components/stackChartV2'
import stackChartDuration from '../components/stackChartDuration'
import { dateTimeFormat } from '@/store/date'
import stackChart from '../components/stackChart'
import Chart from '../components/mixChart'
import { Message } from 'element-ui'
export default {
  name: 'funcDetail',
  data() {
    var that = this
    // 校验规则
    var _ruleStartTime = (rule, value, callback) => {
      if (that.formData.startTime === '') {
        callback(new Error('请选择开始时间!'))
      } else {
        if (that.formData.endTime !== '' && that.formData.endTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('开始时间必须小于结束时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    var _ruleEndTime = (rule, value, callback) => {
      if (that.formData.endTime === '') {
        callback(new Error('请选择结束时间!'))
      } else {
        if (that.formData.startTime !== '' && that.formData.startTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('结束时间必须大于开始时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    return {
      date: '',
      listLoading: false,
      topList: {},
      lineChartData: {
      },
      topSize: 5,
      isShowMetric: true,
      resizeFlag: false,
      formData: {
        funcNo: 'IF096001',
        startTime: '',
        endTime: '',
        TimeType: 'hour',
        appType: []
      },
      list: null,
      appTypeList: [],
      rule: {
        startTime: [{ validator: _ruleStartTime, trigger: 'blur' }],
        endTime: [{ validator: _ruleEndTime, trigger: 'blur' }]
      },
      TimeTypeTable: [{ value: 'hour', name: '历史' }, { value: 'minute', name: '实时' }],
      pickedEnv: [process.env.zt_log_type[0]],
      envTable: process.env.zt_log_type,
      codeInfoMap: new Map(),
      durationInfoTable: [['one', '100ms以下'], ['fiv', '100ms到500ms之间'], ['threeT', '500ms到3s之间'], ['above', '3s以上']]
    }
  },
  components: {
    stackChart,
    Chart,
    stackChartV2,
    stackChartDuration
  },
  activated() {
    this.resizeFlag = !this.resizeFlag
  },
  created() {
    this.initStartTime()
    this.initEndTime()
    if (this.$route.query.item !== undefined) {
      this.formData.funcNo = this.$route.query.item
    }
    if (this.$route.query.category) {
      this.formData.category = this.$route.query.category
    }
    if (this.$route.query.startTime !== undefined) {
      this.formData.startTime = this.$route.query.startTime
    } else {
      this.initStartTime()
    }
    if (this.$route.query.endTime !== undefined) {
      this.formData.endTime = this.$route.query.endTime
    } else {
      this.initEndTime()
    }
    // console.log('create:', this.formData)
    if (this.formData.funcNo !== '') {
      this.getAppTypeList()
    }
  },
  watch: {
    pickedEnv(val) {
      this.resizeFlag = !this.resizeFlag
    }
  },
  methods: {
    getAppTypeList() {
      this.listLoading = true
      appTypeListQuery(this.formData.funcNo).then(response => {
        this.listLoading = false
        console.log('appTypeList:', response.data.appTypeList)
        if (response.code === 0) {
          this.formData.appType = []
          let count = 0
          this.appTypeList = response.data.appTypeList
          if (this.appTypeList.length !== 0) {
            for (const i of this.appTypeList) {
              if (count > 3) break
              this.formData.appType.push(i)
              count++
            }
          }
          // this.appTypeList.push('')
          this.getList()
        } else {
          Message.error(response.code + ':' + response.info)
        }
      }).catch((error) => {
        Message.error('获取app类型失败:' + error)
        this.listLoading = false
      })
    },
    // iniDate() {
    //   const data = new Date(Date.now())
    //   if ((data.getMonth + 1) >= 10) this.date = data.getFullYear() + '.' + (data.getMonth() + 1)
    //   else this.date = data.getFullYear() + '.0' + (data.getMonth() + 1)
    //   if ((data.getDay) >= 10) this.date = this.date + '.' + data.getDate()
    //   else this.date = this.date + '.0' + data.getDate()
    // },
    formatStartTime: function(val) {
      if (val !== undefined) { this.formData.startTime = dateTimeFormat(val) }
    },
    formatEndTime: function(val) {
      if (val !== undefined) { this.formData.endTime = dateTimeFormat(val) }
    },
    initStartTime: function() {
      var nowTime = new Date(new Date() - 5 * 24 * 60 * 60 * 1000)
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.formData.startTime = dateTimeFormat(nowTime)
    },
    initEndTime: function() {
      var nowTime = new Date(new Date())
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.formData.endTime = dateTimeFormat(nowTime)
    },
    getList: function() {
      var that = this
      if (that.formData.TimeType === 'minute') {
        var nowTime = new Date(new Date())
        nowTime.setHours(0)
        nowTime.setMinutes(0)
        nowTime.setSeconds(0)
        that.formData.startTime = dateTimeFormat(nowTime)
        that.initEndTime()
      }
      that.isQuery = true
      that.listLoading = true
      // console.log('that.formData.TimeType:', that.formData.TimeType)
      detailQuery(that.formData.TimeType, that.formData.startTime, that.formData.endTime, that.formData.funcNo, '', that.formData.appType).then(function(response) {
        that.listLoading = false
        that.isQuery = false
        console.log('detailQuery:', response)
        if (response.code === 0) {
          that.codeInfoMap = new Map()
          that.list = response.data.detailList
          const detailDataMap = new Map()
          const nameSet = new Set()
          if (response.data.detailList.length === 0) {
            console.log('empty list!')
            that.lineChartData = {}
          }
          for (const i of response.data.detailList) {
            // console.log('i.logtime', i.logtime)
            if (detailDataMap.has(i.logtime)) {
              if (detailDataMap.get(i.logtime)[i.env] !== undefined) {
                if (detailDataMap.get(i.logtime)[i.env][i.appType] !== undefined) {
                  nameSet.add(i.code)
                  that.codeInfoMap.set(i.code, i.info)
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code] = {}
                  detailDataMap.get(i.logtime)[i.env][i.appType]['totle'] = parseInt(i.counts) + parseInt(detailDataMap.get(i.logtime)[i.env][i.appType]['totle'])
                  detailDataMap.get(i.logtime)[i.env][i.appType]['avgD'] = parseFloat(i.avgduration) * parseInt(i.counts) + parseFloat(detailDataMap.get(i.logtime)[i.env][i.appType]['avgD'])
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['info'] = i.info
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['counts'] = i.counts
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['maxduration'] = i.maxduration
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['avgduration'] = i.avgduration
                } else {
                  nameSet.add(i.code)
                  that.codeInfoMap.set(i.code, i.info)
                  detailDataMap.get(i.logtime)[i.env][i.appType] = {}
                  detailDataMap.get(i.logtime)[i.env][i.appType]['totle'] = i.counts
                  detailDataMap.get(i.logtime)[i.env][i.appType]['avgD'] = parseFloat(i.avgduration) * parseInt(i.counts)
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code] = {}
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['info'] = i.info
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['counts'] = i.counts
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['maxduration'] = i.maxduration
                  detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['avgduration'] = i.avgduration
                }
              } else {
                nameSet.add(i.code)
                that.codeInfoMap.set(i.code, i.info)
                detailDataMap.get(i.logtime)[i.env] = {}
                detailDataMap.get(i.logtime)[i.env][i.appType] = {}
                detailDataMap.get(i.logtime)[i.env][i.appType]['totle'] = i.counts
                detailDataMap.get(i.logtime)[i.env][i.appType]['avgD'] = parseFloat(i.avgduration) * parseInt(i.counts)
                detailDataMap.get(i.logtime)[i.env][i.appType][i.code] = {}
                detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['info'] = i.info
                detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['counts'] = i.counts
                detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['maxduration'] = i.maxduration
                detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['avgduration'] = i.avgduration
              }
            } else {
              nameSet.add(i.code)
              that.codeInfoMap.set(i.code, i.info)
              detailDataMap.set(i.logtime, {})
              detailDataMap.get(i.logtime)[i.env] = {}
              detailDataMap.get(i.logtime)[i.env][i.appType] = {}
              detailDataMap.get(i.logtime)[i.env][i.appType]['totle'] = i.counts
              detailDataMap.get(i.logtime)[i.env][i.appType]['avgD'] = parseFloat(i.avgduration) * parseInt(i.counts)
              detailDataMap.get(i.logtime)[i.env][i.appType][i.code] = {}
              detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['info'] = i.info
              detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['counts'] = i.counts
              detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['maxduration'] = i.maxduration
              detailDataMap.get(i.logtime)[i.env][i.appType][i.code]['avgduration'] = i.avgduration
            }
          }
          const xdata = []
          const ydata = {}
          const ydataDuration = {}
          const namedata = {}
          for (const i of detailDataMap.entries()) {
            // console.log('time', i[0])
            xdata.push(i[0])
          }
          for (const i of that.envTable) {
            if (i !== '') {
              ydata[i] = {}
              // for (const m of nameSet) {
              //   ydata[i][m] = []
              // }
              namedata[i] = []
              ydataDuration[i] = {
              }
            }
          }
          // const durationDataList = {}
          // console.log('detailDataMap', detailDataMap)
          for (const i of detailDataMap.entries()) {
            // console.log('time', i[0])
            for (const j in detailDataMap.get(i[0])) {
              // console.log('env', j)
              for (const n in detailDataMap.get(i[0])[j]) {
                // console.log('app', n, nameSet)
                namedata[j].push(n)
                // const tmp = []
                let one = 0
                let fiv = 0
                let threeT = 0
                let above = 0
                // console.log('xdata.find(i)',xdata.indexOf(i[0]),i[0],xdata[0])
                if (ydata[j][n] === undefined) {
                  ydata[j][n] = {}
                  // ydataDuration[j][n] = {}

                  for (const m of nameSet) {
                    ydata[j][n][m] = []
                    // console.log('xdata.find(i)',xdata.find(i))
                    for (let ii = 0; ii < xdata.length; ii++) {
                      ydata[j][n][m].push('-')
                    }
                  }
                }
                if (ydataDuration[j][n] === undefined) {
                  ydataDuration[j][n] = {
                    maxduration: [],
                    avgduration: [],
                    one: [],
                    fiv: [],
                    threeT: [],
                    above: [] }
                  for (let ii = 0; ii < xdata.length; ii++) {
                    ydataDuration[j][n]['maxduration'].push('-')
                    ydataDuration[j][n]['avgduration'].push('-')
                    ydataDuration[j][n]['one'].push('-')
                    ydataDuration[j][n]['fiv'].push('-')
                    ydataDuration[j][n]['threeT'].push('-')
                    ydataDuration[j][n]['above'].push('-')
                  }
                }
                // console.log('ydataDuration', ydataDuration)
                for (const m of nameSet) {
                  // const tmptmp = [m]

                  if (detailDataMap.get(i[0])[j][n][m] !== undefined) {
                    if (parseFloat(detailDataMap.get(i[0])[j][n][m]['avgduration']) <= 100.0) {
                      one += parseInt(detailDataMap.get(i[0])[j][n][m]['counts'])
                    } else if (parseFloat(detailDataMap.get(i[0])[j][n][m]['avgduration']) > 100.0 && parseFloat(detailDataMap.get(i[0])[j][n][m]['avgduration']) <= 500.0) {
                      fiv += parseInt(detailDataMap.get(i[0])[j][n][m]['counts'])
                    } else if (parseFloat(detailDataMap.get(i[0])[j][n][m]['avgduration']) > 500.0 && parseFloat(detailDataMap.get(i[0])[j][n][m]['avgduration']) <= 3000.0) {
                      threeT += parseInt(detailDataMap.get(i[0])[j][n][m]['counts'])
                    } else if (parseFloat(detailDataMap.get(i[0])[j][n][m]['avgduration']) > 3000.0) {
                      above += parseInt(detailDataMap.get(i[0])[j][n][m]['counts'])
                    }
                    // console.log('xdata.find(i)',xdata.find(i))
                    ydata[j][n][m][xdata.indexOf(i[0])] = detailDataMap.get(i[0])[j][n][m]['counts']
                  }
                  // else ydata[j][n][m].push('-')
                  // tmp.push(tmptmp)
                  // console.log('error', m)
                }
                const avgDu = parseFloat(detailDataMap.get(i[0])[j][n]['avgD']) / parseInt(detailDataMap.get(i[0])[j][n]['totle'])
                ydataDuration[j][n]['avgduration'][xdata.indexOf(i[0])] = avgDu
                if (detailDataMap.get(i[0])[j][n]['0'] !== undefined)ydataDuration[j][n]['maxduration'][xdata.indexOf(i[0])] = parseFloat(detailDataMap.get(i[0])[j][n]['0']['maxduration'])
                ydataDuration[j][n]['one'][xdata.indexOf(i[0])] = one * avgDu / parseInt(detailDataMap.get(i[0])[j][n]['totle'])
                ydataDuration[j][n]['fiv'][xdata.indexOf(i[0])] = fiv * avgDu / parseInt(detailDataMap.get(i[0])[j][n]['totle'])
                ydataDuration[j][n]['threeT'][xdata.indexOf(i[0])] = threeT * avgDu / parseInt(detailDataMap.get(i[0])[j][n]['totle'])
                ydataDuration[j][n]['above'][xdata.indexOf(i[0])] = above * avgDu / parseInt(detailDataMap.get(i[0])[j][n]['totle'])
                // ydata[j].push(tmp)
              }
            }
          }
          const tmpChartData = {}
          for (const i of that.envTable) {
            if (i !== '') {
              //  console.log('i', i)
              tmpChartData[i] = {
                xdata: xdata,
                ydata: ydata[i],
                ydataDuration: ydataDuration[i],
                namedata: namedata[i]
              }
              // console.log('lineChartData', that.lineChartData)
            }
          }
          that.lineChartData = JSON.parse(JSON.stringify(tmpChartData))
          that.codeInfoMap = JSON.parse(JSON.stringify(that.codeInfoMap))
          console.log('lineChartData', that.lineChartData, detailDataMap, that.codeInfoMap)
        } else {
          that.$message.error(response.data.errorInfo || '系统异常')
        }
      }).catch(() => {
        that.listLoading = false
        that.isQuery = false
      })
      // funcNoStatus(that.formData.funcNo, that.formData.startTime, that.formData.endTime)
      //   .then(function(response) {
      //     // console.log('response:', response)
      //     // that.isQuery = false
      //     // that.nowEnv = that.env
      //     // if (response.code === 0) {
      //     //   that.list = response.data[0].logList
      //     //   const nameSet = new Set()
      //     //   for (const i in response.data[0].logList) {
      //     //     if (Number(i) === (response.data[0].logList.length - 1)) break
      //     //     for (const j in response.data[0].logList[i]) {
      //     //       if (j !== 'indexTime') {
      //     //         for (const k in response.data[0].logList[i][j]) {
      //     //           if (k !== 'funcNo' && k !== 'count') {
      //     //             nameSet.add(k)
      //     //           }
      //     //         }
      //     //       }
      //     //     }
      //     //   }
      //     //   // console.log('nameSet:', nameSet)
      //     //   const array = new Array((response.data[0].logList[response.data[0].logList.length - 1].indexsList).length).fill(0)
      //     //   const dataMap = new Map()
      //     //   for (const i of nameSet) {
      //     //     dataMap.set(i, [...array])
      //     //   }
      //     //   // console.log('dataMap:', dataMap)
      //     //   for (const s in response.data[0].logList[response.data[0].logList.length - 1].indexsList) {
      //     //     for (const i in response.data[0].logList) {
      //     //       if (Number(i) === (response.data[0].logList.length - 1)) break
      //     //       for (const j in response.data[0].logList[i]) {
      //     //       //   console.log('111', response.data[0].logList[i][j], response.data[0].logList[response.data[0].logList.length - 1].indexsList[s].split('funcdata-')[1])
      //     //         if (response.data[0].logList[i][j] === response.data[0].logList[response.data[0].logList.length - 1].indexsList[s].split('funcdata-')[1]) {
      //     //           for (const jk in response.data[0].logList[i]) {
      //     //             if (jk !== 'indexTime') {
      //     //               for (const k in response.data[0].logList[i][jk]) {
      //     //                 if (k !== 'funcNo' && k !== 'count') {
      //     //                   if (k !== 'AllCount' && k !== 'successRate' && k !== 'avgDuration' && k !== 'maxDuration') {
      //     //                     const tmp = dataMap.get(k)
      //     //                     // tmp[s] = (Number(response.data[0].logList[i][jk][k]) * 1.0) / Number(response.data[0].logList[i]['info']['AllCount'])
      //     //                     tmp[s] = response.data[0].logList[i][jk][k]
      //     //                   } else {
      //     //                     const tmp = dataMap.get(k)
      //     //                     tmp[s] = response.data[0].logList[i][jk][k]
      //     //                   }
      //     //                 }
      //     //               }
      //     //             }
      //     //           }
      //     //           break
      //     //         }
      //     //       }
      //     //     }
      //     //   }
      //     //   dataMap.set('timeTable', response.data[0].logList[response.data[0].logList.length - 1].indexsList.map(v => {
      //     //     v = v.split('funcdata-')[1]
      //     //     return v
      //     //   }))
      //     //   console.log('dataMap:', dataMap)
      //     //   const tempx = []
      //     //   const tempy = []
      //     //   const name = []
      //     //   const lineChartData = {}
      //     //   lineChartData['chartData'] = {}
      //     //   lineChartData['chartData']['xdata'] = []
      //     //   lineChartData['chartData']['ydata'] = []
      //     //   lineChartData['chartData']['namedata'] = []
      //     //   lineChartData['infodata'] = {}
      //     //   lineChartData['infodata']['xdata'] = []
      //     //   lineChartData['infodata']['ydata'] = []
      //     //   lineChartData['infodata']['namedata'] = []
      //     //   lineChartData['countData'] = {}
      //     //   lineChartData['countData']['xdata'] = []
      //     //   lineChartData['countData']['ydata'] = []
      //     //   lineChartData['countData']['namedata'] = []

      //     //   for (const s of dataMap.keys()) {
      //     //     if (s !== 'NineThousand' && s !== 'avgDuration' && s !== 'maxDuration' && s !== 'timeTable' && s !== 'successRate') {
      //     //       name.push(s)
      //     //       tempx.push(dataMap.get('timeTable'))
      //     //       tempy.push(dataMap.get(s))
      //     //     } else if (s !== 'timeTable') {
      //     //       lineChartData['infodata']['xdata'] = [dataMap.get('timeTable'), dataMap.get('timeTable')]
      //     //       lineChartData['infodata']['ydata'] = [dataMap.get('avgDuration'), dataMap.get('maxDuration')]
      //     //       lineChartData['infodata']['namedata'] = ['avg', 'max']
      //     //       lineChartData['countData']['xdata'] = [dataMap.get('timeTable')]
      //     //       lineChartData['countData']['ydata'] = [dataMap.get('AllCount')]
      //     //       lineChartData['countData']['namedata'] = ['AllCount']
      //     //     }
      //     //   }
      //     //   console.log('list:', that.list)
      //     //   lineChartData['chartData']['xdata'] = tempx
      //     //   lineChartData['chartData']['ydata'] = tempy
      //     //   lineChartData['chartData']['namedata'] = name
      //     //   // lineChartData['infodata']['xdata'] = infoName
      //     //   // lineChartData['infodata']['ydata'] = infox
      //     //   // lineChartData['infodata']['namedata'] = infoName
      //     //   that.lineChartData = Object.assign({}, lineChartData)
      //     //   console.log('lineChartData', lineChartData)
      //     //   that.listLoading = false
      //     //   //					that.pageNum=response.data.pageNum*1+1;
      //     // } else {
      //     //   that.$message.error(response.data.errorInfo || '系统异常')
      //     // }
      //   }).catch(() => {
      //     that.nowEnv = that.env
      //     that.tablelist = []
      //   })
    }
  }
}
</script>
<style scoped>
.chartData-container {
 /* margin-top: -40px; */
 overflow: auto;
 float: left;
    padding: 5px;
    width:100%;
    /* height: 500px; */
    float: left;
}
.topTable{
    padding: 5px;
    width: 100%;
    float: left;
}
.app-container{
  background-color: #f2f5f0;
  padding: 30px;
  overflow: auto;
  min-height: calc(100vh - 84px);
}
</style>
/**const */
