<template>
    <div class="app-container">
    <el-card>
            <div >
    
                <el-form ref="ruleForm" :rules="rule" :inline="true" :model="formData" @submit.native.prevent>  
    
                    <div>
    
                        <el-form-item  label="功能号列表" label-width="120px" prop="funcNo">
    
                            <el-input v-model="formData.funcNo" size="mini" @keyup.enter.native="handleQuery('ruleForm')" placeholder="输入多个功能号请用英文逗号隔开"></el-input>
    
                        </el-form-item>
    
                        <el-form-item  label="用户列表" label-width="120px" prop="user">
    
                            <el-input v-model="formData.user" size="mini" @keyup.enter.native="handleQuery('ruleForm')" placeholder="输入多个用户请用英文逗号隔开"></el-input>
    
                        </el-form-item>
    
                        <el-form-item  label="设备号" label-width="120px" prop="deviceId">
    
                            <el-input v-model="formData.deviceId" @keyup.enter.native="handleQuery('ruleForm')" size="mini"></el-input>
    
                        </el-form-item>
    
                        <el-form-item  label="版本号" label-width="120px" prop="ver">
    
                            <el-input v-model="formData.ver" @keyup.enter.native="handleQuery('ruleForm')" size="mini"></el-input>
    
                        </el-form-item>
                    </div>
    
                    <div>
                            <el-form-item  label="入参" label-width="120px" prop="params">
    
                            <el-input v-model="formData.params" @keyup.enter.native="handleQuery('ruleForm')" size="mini"></el-input>
    
                        </el-form-item>
                        <el-form-item  label="token" label-width="120px" prop="token">
    
                            <el-input v-model="formData.token" @keyup.enter.native="handleQuery('ruleForm')" size="mini"></el-input>
    
                        </el-form-item>
                        <el-form-item  label="返回码包含列表" label-width="120px" prop="includeCode">
    
                            <el-input v-model="formData.includeCode" @keyup.enter.native="handleQuery('ruleForm')" size="mini" placeholder="输入多个返回码请用英文逗号隔开"></el-input>
    
                        </el-form-item>
    
                        <el-form-item  label="返回码排除列表" label-width="120px" prop="excludeCode">
    
                            <el-input v-model="formData.excludeCode" @keyup.enter.native="handleQuery('ruleForm')" size="mini" placeholder="输入多个返回码请用英文逗号隔开"></el-input>
    
                        </el-form-item>
    
                    </div>
                    <div>
                      <el-form-item  label="请求目标" label-width="120px" prop="excludeCode">
    
                            <el-input v-model="formData.target" @keyup.enter.native="handleQuery('ruleForm')" size="mini" placeholder="输入请求目标"></el-input>
    
                        </el-form-item>
                        <el-form-item  label="客户端Ip" label-width="120px" prop="excludeCode">
    
                            <el-input v-model="formData.clientIp" @keyup.enter.native="handleQuery('ruleForm')" size="mini" placeholder="输入客户端Ip"></el-input>
    
                        </el-form-item>
                        <el-form-item  label="日志类型" label-width="120px" prop="info">
    
                            <!-- <el-input v-model="formData.type" size="mini"></el-input> -->
                             <el-select v-model="formData.type">
                                                            <el-option
                                                                v-for="item in logType"
                                                                :key="item"
                                                                :label="item"
                                                                :value="item"
                                                            >
                                                                </el-option>
                                                        </el-select>
                        </el-form-item>
                    </div>
                    <div >
    
                        <el-form-item  label="开始时间" label-width="120px" prop="startTime">
    
                            <el-date-picker v-model="formData.startTime" type="datetime" size="mini" @change="formatStartTime"></el-date-picker>
    
                        </el-form-item>
    
                        <el-form-item  label="结束时间" label-width="100px" prop="endTime">
    
                            <el-date-picker v-model="formData.endTime" type="datetime" size="mini" @change="formatEndTime"></el-date-picker>
    
                        </el-form-item>
    
                        <el-form-item  label="" label-width="0">
    
                            <el-button type="primary" @click="handleQuery('ruleForm')" :disabled="isQuery" size="mini">查询</el-button>
    
                        </el-form-item>
    
                    </div>
    
                </el-form>
    
            </div>
    
            <div>
    
                <span style="line-height: 30px; font-size: 15px;"><font color="red">* 点击"<i class="el-icon el-icon-arrow-right"></i>"可查看更多</font></span>
    
            </div>
            
                <el-table ref="singleTable" :data="list" highlight-current-row style="width: 100%" :border="true" :stripe="true" resizable size="mini">
    
                    <el-table-column type="index" width="50%" header-align="center" align="left"></el-table-column>
    
                    <el-table-column type="expand">
    
                        <template slot-scope="scope">
    
    					<el-form  :inline="true">
    
    						<div >
    
    							<el-form-item label="入参" label-width="95px" >
    
    								<span>{{scope.row.params}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="query" label-width="95px" >
    
    								<span>{{scope.row.query}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="ua" label-width="95px" >
    
    								<span>{{scope.row.ua}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="调用IP" label-width="95px" >
    
    								<span>{{scope.row.invokerIp}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="token" label-width="95px" >
    
    								<span>{{scope.row.sessionId}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="type" label-width="95px" >
    
    								<span>{{scope.row.type}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="渠道" label-width="95px" >
    
    								<span>{{scope.row.channel}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="category" label-width="95px" >
    
    								<span>{{scope.row.category}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="版本" label-width="95px" >
    
    								<span>{{scope.row.ver}}</span>
    
    							</el-form-item>
    
    						</div>
    
    						<div >
    
    							<el-form-item label="target" label-width="95px" >
    
    								<span>{{scope.row.target}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="APPId" label-width="95px" >
    
    								<span>{{scope.row.appId}}</span>
    
    							</el-form-item>
    
    							<el-form-item label="操作站点" label-width="95px" >
    
    								<span>{{scope.row.opStation}}</span>
    
    							</el-form-item>
    
    						</div>
    
    
    
    						<div >
    
    							<el-form-item label="客户端IP" label-width="95px" >
    
    								<span>{{scope.row.clientIp}}</span>
    
    							</el-form-item>
    						</div>
    
    					</el-form>
</template>
			</el-table-column>
			<el-table-column label="序号" header-align="center"  align="left" width="180px" >
<template slot-scope="scope">
    <span class="link-type" @click="open(scope.row.seq,scope.row.target)">{{scope.row.seq}}</span>
</template>
			</el-table-column>
			<el-table-column property="logTime" label="日志时间"   header-align="center"  align="left" @format="formatLogTime"  width="170px"></el-table-column>
			<el-table-column property="user" label="用户名"  header-align="center"  align="left" width="100px"></el-table-column>
			<!-- <%--<el-table-column property="opStation" label="操作站点"   header-align="center"  align="left"></el-table-column>--%> -->
			<el-table-column property="deviceId" label="设备"   header-align="center"  align="left" width="260px"></el-table-column>
			<el-table-column property="funcNo" label="功能号" header-align="center"  align="left" width="100px"></el-table-column>
			<el-table-column property="funcDesc" label="接口描述" header-align="center"  align="left" width="200px"></el-table-column>
			<!-- <%--<el-table-column property="query" label="query"   header-align="center"  align="left" width="50px"></el-table-column>--%> -->
			<el-table-column property="code" label="返回码"   header-align="center"  align="left" width="70px"></el-table-column>
			<el-table-column property="info" label="返回信息"   header-align="center"  align="left" ></el-table-column>
			<el-table-column property="duration" label="耗时"   header-align="center"  align="left" width="50px"></el-table-column>
<!-- 			<el-table-column property="target" label="target"   header-align="center"  align="left" show-overflow-tooltip></el-table-column> -->
<!-- 			<el-table-column property="opStation" label="操作站点" header-align="center"  align="left" show-overflow-tooltip></el-table-column> -->
<!-- 			<el-table-column property="ua" label="ua" header-align="center"  align="left" show-overflow-tooltip></el-table-column> -->
<!-- 			<el-table-column property="query" label="query"   header-align="center"  align="left" show-overflow-tooltip></el-table-column> -->
<!-- 			<el-table-column property="channel" label="渠道"   header-align="center"  align="left"></el-table-column> -->
<!-- 			<el-table-column property="category" label="category"   header-align="center"  align="left"></el-table-column> -->
		</el-table>
		<div>
			<el-pagination
					@current-change="handleCurrentChange"
					:current-page="pageNum"
					:page-sizes="[20,40,60]"
					:page-size="pageSize"
					:total="totalPages"
					layout="total, prev, pager, next, jumper"></el-pagination>
		</div>
  </el-card>
    </div>
</template>

<script>
import { dateTimeFormat } from '@/store/date'
import { queryAccessLog } from '@/api/log'
export default {
  name: 'accesslog',
  data() {
    var that = this
    // 校验规则
    var _ruleStartTime = (rule, value, callback) => {
      if (that.formData.startTime === '') {
        callback(new Error('请选择开始时间!'))
      } else {
        if (that.formData.endTime !== '' && that.formData.endTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('开始时间必须小于结束时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    var _ruleEndTime = (rule, value, callback) => {
      if (that.formData.endTime === '') {
        callback(new Error('请选择结束时间!'))
      } else {
        if (that.formData.startTime !== '' && that.formData.startTime != null) {
          if (Date.parse(that.formData.endTime) < Date.parse(that.formData.startTime)) {
            callback(new Error('结束时间必须大于开始时间!'))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }
    return {
      isQuery: false,
      list: [],
      formData: {
        funcNo: '',
        user: '',
        includeCode: '',
        excludeCode: '',
        deviceId: '',
        ver: '',
        params: '',
        token: '',
        type: '',
        startTime: '',
        endTime: '',
        target: '',
        clientIp: ''
      },
      category: '',
      pageNum: 1,
      pageSize: 20,
      totalPages: 0,
      logType: process.env.zt_log_type,
      rule: {
        startTime: [{ validator: _ruleStartTime, trigger: 'blur' }],
        endTime: [{ validator: _ruleEndTime, trigger: 'blur' }]
      }
    }
  },
  created: function() {
    this.initStartTime()
    this.initEndTime()
    // this.getList()
  },
  methods: {
    formatStartTime: function(val) {
      this.formData.startTime = dateTimeFormat(val)
    },
    formatEndTime: function(val) {
      this.formData.endTime = dateTimeFormat(val)
    },
    initStartTime: function() {
      var nowTime = new Date()
      nowTime.setHours(0)
      nowTime.setMinutes(0)
      nowTime.setSeconds(0)
      this.formData.startTime = dateTimeFormat(nowTime)
    },
    initEndTime: function() {
      var nowTime = new Date()
      nowTime.setHours(23)
      nowTime.setMinutes(59)
      nowTime.setSeconds(59)
      this.formData.endTime = dateTimeFormat(nowTime)
    },
    handleCurrentChange: function(val) {
      this.pageNum = val
      if (!this.isQuery && this.pageNum <= this.totalPages) this.getList()
    },
    open(seq, target) {
      const startTime = this.formData.startTime
      const endTime = this.formData.endTime
      // if(target.indexOf("/api/app/gateway")>=0 ||target.indexOf("/api/apps/gateway")>=0 ){
      //	category = "trace-log"
      //	let seqUrl = "/biz/es/tracelog/ui?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }else{
      //	category = "trace-log-4"
      //	let seqUrl = "/biz/es/tracelog/ui4?seq=" + seq + "&category=" + category +"&startTime=" + startTime + "&endTime=" + endTime;
      //	console.log(seqUrl)
      //	let title = '业务日志查询'
      //	window.parent.addTab(title, seqUrl)
      // }
      console.log('pushto:', '/Log/traceLog/' + seq, { seq: seq, startTime: startTime, endTime: endTime })
      this.$router.push({ path: '/Log/traceLog/' + seq, query: { seq: seq, startTime: startTime, endTime: endTime }})
    //   const seqUrl = '/biz/es/tracelog/ui?seq=' + seq + '&startTime=' + startTime + '&endTime=' + endTime
    //   console.log(seqUrl)
    //   const title = '业务日志查询'
    //   window.parent.addTab(title, seqUrl)
    },
    getList: function() {
      var that = this
      that.isQuery = true
      return new Promise((resolve, reject) => {
        queryAccessLog(that.formData.funcNo.trim(), that.formData.user.trim(), that.formData.deviceId.trim(), that.formData.ver.trim(), that.formData.includeCode.trim(), that.formData.excludeCode.trim(), that.formData.type.trim(), that.formData.params.trim().split(':').join('.?.?.?').split(',').join('.?.?.?'), that.formData.startTime.trim(), that.formData.endTime.trim(), that.pageNum - 1, that.pageSize, that.formData.clientIp.trim(), that.formData.target.trim(), that.formData.token.trim())
          .then(function(response) {
            console.log('response:', response)
            that.isQuery = false
            if (response.data !== undefined && response.data.length > 0) {
              that.list = response.data[0].logList
              that.totalPages = response.data[0].total
            //					that.pageNum=response.data.pageNum*1+1;
            } else {
              that.$message.error(response.data.errorInfo || '系统异常')
            }
            resolve(response)
          }).catch((error) => {
            that.isQuery = false
            this.listLoading = false
            reject(error)
          })
      })
    },
    handleQuery: function(ruleForm) {
      var that = this
      this.$refs[ruleForm].validate(function(valid) {
        if (valid) {
          that.pageNum = 1
          that.getList()
        }
      })
    },
    formatLogTime: function(row, col) {
      return dateTimeFormat(row.sendTime)
    },
    handleSlideUpCtrl: function(e) {
      var target = e.target
      target.classList.toggle('slideUp')
      var wrapperBox = this.$refs['wrapperBox']
      wrapperBox.classList.toggle('slideUp')
    }
  }
}
</script>
<style scoped>
.app-container{
  background-color:  #f0f2f5;
  padding: 30px;
  min-height: calc(100vh - 84px);
}
</style>
