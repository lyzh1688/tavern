<template>
  <div :class="className" :id="id" :style="{height:height,width:width}"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/infographic') // echarts theme
import resize from './mixins/resize'
import { debounce } from '@/utils'
// import { Message } from 'element-ui'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      chart: null,
      XSerise: [],
      YSerise1: [],
      YSerise2: [],
      YSerise3: [],
      NameSerise: []
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setDataSet()
        // this.initChart(val)
        console.log('gauge watch!')
      }
    }
  },
  mounted() {
    // this.setDataSet()
    if (this.autoResize) {
      this.__resizeHanlder = debounce(() => {
        if (this.chart) {
          this.chart.resize()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHanlder)
    }

    // 监听侧边栏的变化
    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.addEventListener('transitionend', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    if (this.autoResize) {
      window.removeEventListener('resize', this.__resizeHanlder)
    }

    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.removeEventListener('transitionend', this.__resizeHanlder)

    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart(name, value, valueName) {
      this.chart = echarts.init(this.$el, 'infographic')
      const option = {
        tooltip: {
          formatter: '{a}<br/>{b}:{c}%'
        },
        // toolbox: {
        //   show: 'true',
        //   feature: {
        //     mark: { show: 'true' },
        //     restore: { show: 'true' },
        //     saveAsImage: { show: 'true' }
        //   }
        // },
        series: [
          {
            name: name,
            type: 'gauge',
            startAngle: 180,
            endAngle: 0,
            detail: { formatter: '{value}%' },
            data: [{ value: value, name: valueName }]
          }
        ]
      }
      this.chart.setOption(option, true)
    },
    setDataSet() {
      if (this.chartData === null || this.chartData.name === undefined || this.chartData.length === 0) {
        // Message.error('图表输入数据不足，无法绘制')
      } else {
        // console.log('gaugechartData:', this.chartData.name, this.chartData.value, this.chartData.valueName)
        this.initChart(this.chartData.name, Math.round(this.chartData.value * 100) / 100, this.chartData.valueName)
      }
    }
  }
}
</script>