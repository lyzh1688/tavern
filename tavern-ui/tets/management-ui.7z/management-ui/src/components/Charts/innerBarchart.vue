<template>
  <div :class="className" :id="id" :style="{height:height,width:width}"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'
import { debounce } from '@/utils'
const animationDuration = 6000
// import { Message } from 'element-ui'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    id: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '200px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      chart: null,
      XSerise: [],
      YSerise1: [],
      YSerise2: [],
      YSerise3: [],
      NameSerise: []
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        if (val !== undefined) this.setDataSet()
        if (this.chart !== null) this.chart.resize()
        // this.initChart(val)
        console.log('watch!')
      }
    }
  },
  mounted() {
    this.setDataSet()
    if (this.autoResize) {
      this.__resizeHanlder = debounce(() => {
        if (this.chart) {
          this.chart.resize()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHanlder)
    }

    // 监听侧边栏的变化
    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.addEventListener('transitionend', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    if (this.autoResize) {
      window.removeEventListener('resize', this.__resizeHanlder)
    }

    const sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    sidebarElm.removeEventListener('transitionend', this.__resizeHanlder)

    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart(Xdata, ydata1, ydata2, ydata3, namedata) {
      this.chart = echarts.init(this.$el, 'macarons')
      // const xData = (function() {
      //   const data = []
      //   for (let i = 1; i < expectedData.length; i++) {
      //     data.push(i + 'month')
      //   }
      //   return data
      // }())
      const option = {
        // backgroundColor: '#0E2A43',
        legend: {
          x: '5%',
          top: '10%',
          icon: 'rect',
          itemWidth: 14,
          itemHeight: 5,
          itemGap: 13,
          data: ['m15Rate', 'm5Rate', 'm1Rate'],
          textStyle: {
            fontSize: 12,
            color: '#000'
          }
        },
        grid: {
          left: '3%',
          right: '10%',
          bottom: '3%',
          containLabel: true
        },

        tooltip: {
          show: 'true',
          trigger: 'axis',
          axisPointer: { // 坐标轴指示器，坐标轴触发有效
            type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        xAxis: {
          type: 'value',
          axisTick: {
            show: false
          },
          axisLine: {
            show: false,
            lineStyle: {
              color: '#000'
            }
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            interval: 0
          }
        },
        yAxis: [{
          type: 'category',
          axisTick: {
            show: true
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#000'
            }
          },
          boundaryGap: false,
          axisLabel: {
            showMaxLabel: true,
            // showMinLabel: true,
            interval: 0,
            margin: 10
          },
          data: namedata
        }
        // {
        //   type: 'category',
        //   axisLine: {
        //     show: false
        //   },
        //   axisTick: {
        //     show: false
        //   },
        //   axisLabel: {
        //     show: false
        //   },
        //   splitArea: {
        //     show: false
        //   },
        //   splitLine: {
        //     show: false
        //   },
        //   data: namedata
        // },
        // {
        //   type: 'category',
        //   axisLine: {
        //     show: false
        //   },
        //   axisTick: {
        //     show: false
        //   },
        //   axisLabel: {
        //     show: false
        //   },
        //   splitArea: {
        //     show: false
        //   },
        //   splitLine: {
        //     show: false
        //   },
        //   data: namedata
        // }

        ],
        series: [
        //   {
        //     name: 'm15Rate',
        //     type: 'bar',
        //     yAxisIndex: 2,
        //     itemStyle: {
        //       normal: {
        //         show: true,
        //         color: '#1309db',
        //         barBorderRadius: 50,
        //         borderWidth: 0,
        //         borderColor: '#333'
        //       }
        //     },
        //     barGap: '0%',
        //     barCategoryGap: '50%',
        //     data: ydata1
        //   },
        //   {
        //     name: 'm5Rate',
        //     type: 'bar',
        //     yAxisIndex: 1,
        //     itemStyle: {
        //       normal: {
        //         show: true,
        //         color: '#0995db',
        //         barBorderRadius: 50,
        //         borderWidth: 0,
        //         borderColor: '#333'
        //       }
        //     },
        //     barGap: '0%',
        //     barCategoryGap: '50%',
        //     data: ydata2
        //   },
          {
            name: 'm1Rate',
            type: 'bar',
            itemStyle: {
              normal: {
                show: true,
                color: '#1df2e4',
                barBorderRadius: 50,
                borderWidth: 0,
                borderColor: '#333',
                height: 'auto'
              }
            },
            label: {
              show: true,
              position: 'right',
              formatter(p) {
                return p.value > 0 ? p.value : ''
              }
            },
            barGap: '0%',
            barCategoryGap: '50%',
            data: ydata3,
            animationDuration
          }

        ]
      }
      console.log('innerchartInputData:', this.chartData)
      this.chart.setOption(option, true)
    },
    setDataSet() {
      if (this.chartData === null || this.chartData === undefined || this.chartData[0].name === undefined || this.chartData.length === 0) {
        // Message.error('图表输入数据不足，无法绘制')
      } else {
        const tempx = []
        const tempy1 = []
        const tempy2 = []
        const tempy3 = []
        const names = []
        for (const i in this.chartData) {
          names.push(this.chartData[i].name)
        }
        let firstMArk = true
        for (const i in this.chartData) {
          if (this.chartData[i] !== null) {
            if (firstMArk) {
              tempx.push({
                type: 'category',
                axisTick: {
                  show: false
                },
                axisLine: {
                  show: true,
                  lineStyle: {
                    color: '#000'
                  }
                },
                data: names
              })
              firstMArk = false
            } else {
              tempx.push({
                type: 'category',
                axisLine: {
                  show: false
                },
                axisTick: {
                  show: false
                },
                axisLabel: {
                  show: false
                },
                splitArea: {
                  show: false
                },
                splitLine: {
                  show: false
                },
                data: names
              })
            }
            tempy1.push(this.chartData[i].m15Rate)
            tempy2.push(this.chartData[i].m5Rate)
            tempy3.push(this.chartData[i].m1Rate)
          }
        }
        this.NameSerise = [...names]
        this.XSerise = [...tempx]
        this.YSerise1 = [...tempy1]
        this.YSerise2 = [...tempy2]
        this.YSerise3 = [...tempy3]
        console.log('innerchartData:', this.XSerise, this.YSerise1, this.YSerise2, this.YSerise3, this.NameSerise)
        this.initChart(this.XSerise, this.YSerise1, this.YSerise2, this.YSerise3, this.NameSerise)
      }
    }
  }
}
</script>