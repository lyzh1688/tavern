
import request from '@/utils/request'

export function PBTranslation(typeUrl, value, version) {
  console.log(process.env.zt_log_url, {
    typeUrl: typeUrl,
    value: value,
    version: version
  })
  return request({
    url: process.env.zt_log_url + '/translate',
    data: {
      typeUrl: typeUrl,
      value: value,
      version: version
    },
    method: 'post'
  })
}
export function graphTopology(seq, startTime, endTime) {
  console.log(process.env.zt_monitor_graph_url, {
    seq: seq,
    startTime: startTime,
    endTime: endTime
  })
  return request({
    url: process.env.zt_monitor_graph_url,
    data: {

      seq: seq,
      startTime: startTime,
      endTime: endTime
    },
    method: 'post'
  })
}
export function queryAccessLog(funcNo, user, deviceId, ver, includeCode, excludeCode, type, params, startTime, endTime, pageNum, pageSize, clientIp, target, token) {
  console.log(process.env.zt_es_access_gw_url, {
    funcNo: funcNo.split(','),
    user: user.split(','),
    deviceId: deviceId,
    ver: ver,
    token: token,
    includeCode: includeCode.split(','),
    excludeCode: excludeCode.split(','),
    type: type,
    params: params,
    startTime: startTime,
    endTime: endTime,
    pageNum: pageNum,
    pageSize: pageSize,
    clientIp: clientIp,
    target: target
  })
  const requestData = {
    startTime: startTime,
    endTime: endTime,
    pageNum: pageNum,
    pageSize: pageSize
  }
  if (funcNo == null || funcNo.length === 0 || funcNo === '') {
    funcNo = null
  } else {
    requestData['funcNo'] = funcNo.split(',')
  }
  if (user == null || user.length === 0 || user === '') {
    user = null
  } else {
    requestData['user'] = user.split(',')
  }
  if (deviceId == null || deviceId.length === 0 || deviceId === '') {
    deviceId = ''
  } else {
    requestData['deviceId'] = deviceId
  }
  if (ver == null || ver.length === 0 || ver === '') {
    ver = ''
  } else {
    requestData['ver'] = ver
  }
  if (includeCode == null || includeCode.length === 0 || includeCode === '') {
    includeCode = ''
  } else {
    requestData['includeCode'] = includeCode.split(',')
  }
  if (excludeCode == null || excludeCode.length === 0 || excludeCode === '') {
    excludeCode = ''
  } else {
    requestData['excludeCode'] = excludeCode.split(',')
  }
  if (type == null || type.length === 0 || type === '') {
    type = ''
  } else {
    requestData['type'] = type
  }
  if (params == null || params.length === 0 || params === '') {
    params = ''
  } else {
    requestData['params'] = params
  }
  if (token == null || token.length === 0 || token === '') {
    token = ''
  } else {
    requestData['token'] = token
  }
  if (clientIp == null || clientIp.length === 0 || clientIp === '') {
    clientIp = ''
  } else {
    requestData['clientIp'] = clientIp
  }
  if (target == null || target.length === 0 || target === '') {
    target = ''
  } else {
    requestData['target'] = target
  }
  return request({
    url: process.env.zt_es_access_gw_url,
    data: requestData,
    method: 'post'
  })
}
export function queryTraceLog(seq, category, startTime, endTime, pageNum, pageSize) {
  console.log(process.env.zt_es_biz_gw_url, {
    seq: seq,
    category: category,
    startTime: startTime,
    endTime: endTime,
    pageNum: pageNum,
    pageSize: pageSize
  })
  const requestData = {
    startTime: startTime,
    endTime: endTime,
    pageNum: pageNum,
    pageSize: pageSize
  }
  if (seq == null || seq.length === 0 || seq === '') {
    seq = null
  } else {
    requestData['seq'] = seq
  }
  if (category == null || category.length === 0 || category === '') {
    category = null
  } else {
    requestData['category'] = category
  }
  return request({
    url: process.env.zt_es_biz_gw_url,
    data: requestData,
    method: 'post'
  })
}

export function getMapping(dataBaseName, env, pageNum, pageSize) {
  console.log(process.env.zt_es_gw_url + '/getMapping', {
    dataBaseName: dataBaseName,
    env: env,
    pageNum: pageNum,
    pageSize: pageSize
  })
  const requestData = {
    dataBaseName: dataBaseName,
    env: env,
    pageNum: pageNum,
    pageSize: pageSize
  }
  return request({
    url: process.env.zt_es_gw_url + '/getMapping',
    data: requestData,
    method: 'post'
  })
}
/**
 * 关键字查询例如useｒ,deviceId等
 */
export function keywordSearch(keyword, method, date, month) {
  console.log(process.env.zt_es_gw_url + '/keywordSearch?keyword=' + keyword + '&method=' + method + '&date=' + date + '&month=' + month)
  return request({
    url: process.env.zt_es_gw_url + '/keywordSearch?keyword=' + keyword + '&method=' + method + '&date=' + date + '&month=' + month,
    method: 'get'
  })
}
export function topSearch(keyword, method, date, size) {
  console.log(process.env.zt_es_gw_url + '/topSearch?keyword=' + keyword + '&method=' + method + '&date=' + date + '&size=' + size)
  return request({
    url: process.env.zt_es_gw_url + '/topSearch?keyword=' + keyword + '&method=' + method + '&date=' + date + '&size=' + size,
    method: 'get'
  })
}
export function funcNoStatus(funcNo, startTime, endTime) {
  console.log(process.env.zt_es_gw_url + '/funcNoStatus?funcNo=' + funcNo + '&startTime=' + startTime + '&endTime=' + endTime)
  return request({
    url: process.env.zt_es_gw_url + '/funcNoStatus?funcNo=' + funcNo + '&startTime=' + startTime + '&endTime=' + endTime,
    method: 'get'
  })
}
export function topFuncNo(size, startTime, endTime) {
  console.log(process.env.zt_es_gw_url + '/topFuncNo?size=' + size + '&startTime=' + startTime + '&endTime=' + endTime + '&orderValue=AllCount')
  return request({
    url: process.env.zt_es_gw_url + '/topFuncNo?size=' + size + '&startTime=' + startTime + '&endTime=' + endTime + '&orderValue=AllCount',
    method: 'get'
  })
}
export function topFuncNoOB3(size, startTime, endTime) {
  console.log(process.env.zt_es_gw_url + '/topFuncNo?size=' + size + '&startTime=' + startTime + '&endTime=' + endTime + '&orderValue=NineThousand')
  return request({
    url: process.env.zt_es_gw_url + '/topFuncNo?size=' + size + '&startTime=' + startTime + '&endTime=' + endTime + '&orderValue=NineThousand',
    method: 'get'
  })
}
export function funcdetail(funcNames) {
  console.log(process.env.zt_es_gw_url + '/data/funcdetail/query')
  return request({
    url: process.env.zt_es_gw_url + '/data/funcdetail/query',
    data: {
      funcNames: funcNames
    },
    method: 'post'
  })
}
// 功能号调用查询
export function topQuery(topNumber, beginTime, endTime, type, env, appType) {
  console.log(process.env.zt_es_gw_url + '/funcNo/top?topNumber=' + topNumber + '&beginTime=' + beginTime + '&endTime=' + endTime + '&type=' + type + '&env=' + env + '&appType=' + appType)
  return request({
    url: process.env.zt_es_gw_url + '/funcNo/top?topNumber=' + topNumber + '&beginTime=' + beginTime + '&endTime=' + endTime + '&type=' + type + '&env=' + env + '&appType=' + appType,
    method: 'get'
  })
}
export function detailQuery(TimeType, beginTime, endTime, funcNo, env, appType) {
  console.log(process.env.zt_es_gw_url + '/funcNo/detail?TimeType=' + TimeType + '&funcNo=' + funcNo + '&beginTime=' + beginTime + '&endTime=' + endTime + '&env=' + env)
  return request({
    url: process.env.zt_es_gw_url + '/funcNo/detail?TimeType=' + TimeType + '&funcNo=' + funcNo + '&beginTime=' + beginTime + '&endTime=' + endTime + '&env=' + env,
    data: appType,
    method: 'post'
  })
}
export function appTypeListQuery(funcNO) {
  console.log(process.env.zt_es_gw_url + '/funcNo/appTypeList?funcNo=' + funcNO)
  return request({
    url: process.env.zt_es_gw_url + '/funcNo/appTypeList?funcNo=' + funcNO,
    method: 'get'
  })
}
export function updateFuncNoDesc(funcNo, desc) {
  console.log(process.env.zt_es_gw_url + '/funcNo/updateFuncNoDesc?funcNo=' + funcNo + '&desc=' + desc)
  return request({
    url: process.env.zt_es_gw_url + '/funcNo/updateFuncNoDesc?funcNo=' + funcNo + '&desc=' + desc,
    method: 'get'
  })
}

