import request from '@/utils/request'

export function getModuleStatus(moduleName, clusterName) {
  if (moduleName === undefined) moduleName = ''
  if (clusterName === undefined) clusterName = ''
  console.log(process.env.zt_api_alarm_gw_url + '/modules?moduleName=' + moduleName + '&clusterName=' + clusterName)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules?moduleName=' + moduleName + '&clusterName=' + clusterName,
    method: 'get'
  })
}
export function modulesGroupQuery(moduleName, clusterName) {
  if (moduleName === undefined) moduleName = ''
  if (clusterName === undefined) clusterName = ''
  console.log(process.env.zt_api_alarm_gw_url + '/modulesGroupQuery')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modulesGroupQuery',
    data: moduleName,
    method: 'post'
  })
}
export function statusGroupQuery(timeOut, instanceIds) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/statusGroupQuery?timeOut=' + timeOut)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/statusGroupQuery?timeOut=' + timeOut,
    data: instanceIds,
    method: 'post'
  })
}
export function groupMetricsLatest(instanceIds) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/groupMetricsLatest')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/groupMetricsLatest',
    data: instanceIds,
    method: 'post'
  })
}
export function getModuleStatusUpdate(timeOut) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/status?timeOut=' + timeOut)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/status?timeOut=' + timeOut,
    method: 'get'
  })
}
export function getAlarmStatus(queryStatus, monitorId, instanceId, timeOut = 30) {
  console.log(process.env.zt_api_alarm_gw_url + '/alarms?status=' + queryStatus + '&monitorId=' + monitorId + '&objectId=' + instanceId + '&timeOut=' + timeOut)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/alarms?status=' + queryStatus + '&monitorId=' + monitorId + '&objectId=' + instanceId + '&timeOut=' + timeOut,
    method: 'get'
  })
}
export function getAlarmEvents(MONITORID, INSTANCEID, startTime, endTime) {
  console.log(process.env.zt_api_alarm_gw_url + '/alarmEvents?monitorId=' + MONITORID + '&objectId=' + INSTANCEID + '&startTime=' + startTime + '&endTime=' + endTime)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/alarmEvents',
    data: { monitorId: MONITORID, objectId: INSTANCEID, startTime: startTime, endTime: endTime },
    method: 'post'
  })
}
/**
 * 模块列表查询接口
 * @param {*} moduleName 模块名称
 * @param {*} moduleType 模块类型
 * @param {*} artifactType 构件类型
 * @param {*} enableMonitor 是否监控
 * @param {*} templateId 模板Id
 * @param {*} artifactName 构件名称
 */
export function getModuleList(moduleName, moduleType, artifactType, enableMonitor, templateId, artifactName) {
  console.log('loglink:' + process.env.zt_api_alarm_gw_url + '/modules/list?moduleName=' + moduleName + '&moduleType=' + moduleType + '&artifactType=' + artifactType + '&enableMonitor=' + enableMonitor + '&templateId=' + templateId + '&artifactName=' + artifactName)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/list?moduleName=' + moduleName + '&moduleType=' + moduleType + '&artifactType=' + artifactType + '&enableMonitor=' + enableMonitor + '&templateId=' + templateId + '&artifactName=' + artifactName,
    method: 'get'
  })
}
export function insertModule(module) {
  console.log(module)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/insert',
    data: module,
    method: 'post'
  })
}
export function updateModule(module) {
  console.log(module)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/update',
    data: module,
    method: 'post'
  })
}
export function deleteModule(moduleId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/delete?moduleId=' + moduleId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/delete?moduleId=' + moduleId,
    method: 'post'
  })
}
export function findTemplate(templateId) {
  console.log(process.env.zt_api_alarm_gw_url + '/templates?templateId=' + templateId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templates?templateId=' + templateId,
    method: 'get'
  })
}
// export function queryTemplate() {
//   console.log(process.env.zt_api_alarm_gw_url + '/templates?templateId=')
//   return request({
//     url: process.env.zt_api_alarm_gw_url + '/templates?templateId=',
//     method: 'get'
//   })
// }
/**
 * 实例查询接口
 */
export function queryInstance(moduleId, isvalid) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instance?moduleId=' + moduleId + '&isvalid=' + isvalid)
  let mode
  if (!isvalid) mode = 'all'
  else mode = ''
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instance?moduleId=' + moduleId + '&isvalid=' + isvalid + '&mode=' + mode,
    method: 'get'
  })
}
export function instanceTable(instanceName, serverIp) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instanceTable?instanceName=' + instanceName + '&serverIp=' + serverIp)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instanceTable?instanceName=' + instanceName + '&serverIp=' + serverIp,
    method: 'get'
  })
}
export function queryInstanceByInstanceId(instanceId, isvalid) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instanceById?instanceId=' + instanceId + '&isvalid=' + isvalid)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instanceById?instanceId=' + instanceId + '&isvalid=' + isvalid,
    method: 'get'
  })
}
export function insertInstance(instance) {
  if (instance['created'] !== undefined || instance['created'] !== null) {
    instance['created'] = null
  }
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instance/insert' + instance)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instance/insert',
    data: instance,
    method: 'post'
  })
}
export function updateInstance(instance) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instance/update' + instance)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instance/update',
    data: instance,
    method: 'post'
  })
}
export function queryLocations() {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/locationList')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/locationList',
    method: 'get'
  })
}
export function queryClusters() {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/clusterList')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/clusterList',
    method: 'get'
  })
}
/**
 * 性能指标查询接口
 */
export function getMetricsGauges(OBJECTID, METRIC, startTime, endTime) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metricsGauges?objectId=' + OBJECTID + '&metric=' + METRIC + '&start=' + startTime + '&end=' + endTime)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metricsGauges',
    data: { objectId: OBJECTID, metric: METRIC, start: startTime, end: endTime },
    method: 'post'
  })
}
export function getMetricsTimer(OBJECTID, METRIC, startTime, endTime) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metricsTimer?objectId=' + OBJECTID + '&metric=' + METRIC + '&start=' + startTime + '&end=' + endTime)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metricsTimer',
    data: { objectId: OBJECTID, metric: METRIC, start: startTime, end: endTime },
    method: 'post'
  })
}
export function getMetricsGaugesLatest(OBJECTID, METRIC, startTime, endTime) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metricsGaugesLatest?objectId=' + OBJECTID + '&metric=' + METRIC + '&start=' + startTime + '&end=' + endTime)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metricsGaugesLatest',
    data: { objectId: OBJECTID, metric: METRIC, start: startTime, end: endTime },
    method: 'post'
  })
}
export function getMetricsTimerLatest(OBJECTID, METRIC, startTime, endTime) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metricsTimerLatest?objectId=' + OBJECTID + '&metric=' + METRIC + '&start=' + startTime + '&end=' + endTime)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metricsTimerLatest',
    data: { objectId: OBJECTID, metric: METRIC, start: startTime, end: endTime },
    method: 'post'
  })
}
export function querySnapshot(INSTANCEID, startTime, endTime) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metrics/snapshot?instanceId=' + INSTANCEID + '&startTime=' + startTime + '&endTime=' + endTime)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metrics/snapshot?instanceId=' + INSTANCEID + '&startTime=' + startTime + '&endTime=' + endTime,
    method: 'get'
  })
}
export function querySummary(INSTANCEID) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metrics/summary?instanceId=' + INSTANCEID)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metrics/summary?instanceId=' + INSTANCEID,
    method: 'get'
  })
}
/**
 *  远程模块操作接口
 */
export function queryModuleInstanceList2(name, serverIp) {
  console.log(process.env.zt_api_alarm_gw_url + '/moduleinstance/all')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/moduleinstance/all',
    data: { artifactType: 0, moduleName: name, serverIp: serverIp },
    method: 'post'
  })
}
export function moduleinstanceopStop(moduleName, serverIp, username, password, artifactName, artifactType, version) {
  console.log(process.env.zt_api_alarm_gw_url + '/ssh/exec', {
    targetModule: moduleName,
    targetIp: serverIp,
    username: username,
    password: password,
    artifactName: artifactName,
    artifactType: artifactType,
    version: version,
    operationType: 6 })
  return request({
    url: process.env.zt_api_alarm_gw_url + '/ssh/exec',
    data: {
      targetModule: moduleName,
      targetIp: serverIp,
      username: username,
      password: password,
      artifactName: artifactName,
      artifactType: artifactType,
      version: version,
      operationType: 6 },
    method: 'post'
  })
}
export function moduleinstanceopStart(moduleName, serverIp, username, password, artifactName, artifactType, version) {
  console.log(process.env.zt_api_alarm_gw_url + '/ssh/exec', {
    targetModule: moduleName,
    targetIp: serverIp,
    username: username,
    password: password,
    artifactName: artifactName,
    artifactType: artifactType,
    version: version,
    operationType: 4 })
  return request({
    url: process.env.zt_api_alarm_gw_url + '/ssh/exec',
    data: {
      targetModule: moduleName,
      targetIp: serverIp,
      username: username,
      password: password,
      artifactName: artifactName,
      artifactType: artifactType,
      version: version,
      operationType: 4 },
    method: 'post'
  })
}
/**
 * 模板增删改接口
 */
export function insertTemplate(templateName, remark) {
  console.log(process.env.zt_api_alarm_gw_url + '/templates/insert?templateName=' + templateName + '&remark=' + remark)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templates/insert?templateName=' + templateName + '&remark=' + remark,
    method: 'get'
  })
}
export function updateTemplate(id, templateName, remark) {
  console.log(process.env.zt_api_alarm_gw_url + '/templates/update?templateId=' + id + '&templateName=' + templateName + '&remark=' + remark)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templates/update?templateId=' + id + '&templateName=' + templateName + '&remark=' + remark,
    method: 'get'
  })
}
export function deleteTemplate(id, templateName) {
  console.log(process.env.zt_api_alarm_gw_url + '/templates/delete?templateId=' + id + '&templateName=' + templateName)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templates/delete?templateId=' + id + '&templateName=' + templateName,
    method: 'get'
  })
}
/**
 * 解析器增删改查
 */
export function queryParser(parserId, parserName) {
  console.log(process.env.zt_api_alarm_gw_url + '/parsers?parserId=' + parserId + '&parserName=' + parserName)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/parsers?parserId=' + parserId + '&parserName=' + parserName,
    method: 'get'
  })
}
export function insertParser(parser) {
  console.log(process.env.zt_api_alarm_gw_url + '/parsers/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/parsers/insert',
    data: parser,
    method: 'post'
  })
}
export function updateParser(parser) {
  console.log(process.env.zt_api_alarm_gw_url + '/parsers/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/parsers/update',
    data: parser,
    method: 'post'
  })
}
export function deleteParser(parserId) {
  console.log(process.env.zt_api_alarm_gw_url + '/parsers/delete?templateId=' + parserId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/parsers/delete?parserId=' + parserId,
    method: 'get'
  })
}
/**
 * 模板解析器关系增删改查
 */
export function findTemplateParser(templateId) {
  console.log(process.env.zt_api_alarm_gw_url + '/templateParsers?templateId=' + templateId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templateParsers?templateId=' + templateId,
    method: 'get'
  })
}
export function insertTemplateParser(templateParsers) {
  console.log(process.env.zt_api_alarm_gw_url + '/templateParsers/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templateParsers/insert',
    data: templateParsers,
    method: 'post'
  })
}
export function updateTemplateParser(templateParsers) {
  console.log(process.env.zt_api_alarm_gw_url + '/templateParsers/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templateParsers/update',
    data: templateParsers,
    method: 'post'
  })
}
export function deleteTemplateParser(templatesParserId) {
  console.log(process.env.zt_api_alarm_gw_url + '/templateParsers/delete?templatesParserId=' + templatesParserId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/templateParsers/delete?templatesParserId=' + templatesParserId,
    method: 'get'
  })
}
/**
 * 告警规则 增删改查
 */
export function findAlarmRules(ruleId, ruleName, parserId) {
  console.log(process.env.zt_api_alarm_gw_url + '/alarmRule?ruleId=' + ruleId + '&ruleName=' + ruleName + '&parserId=' + parserId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/alarmRule?ruleId=' + ruleId + '&ruleName=' + ruleName + '&parserId=' + parserId,
    method: 'get'
  })
}
export function insertAlarmRules(alarmRule) {
  console.log(process.env.zt_api_alarm_gw_url + '/alarmRule/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/alarmRule/insert',
    data: alarmRule,
    method: 'post'
  })
}
export function updateAlarmRules(alarmRule) {
  console.log(process.env.zt_api_alarm_gw_url + '/alarmRule/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/alarmRule/update',
    data: alarmRule,
    method: 'post'
  })
}
export function deleteAlarmRules(alarmRuleId) {
  console.log(process.env.zt_api_alarm_gw_url + '/alarmRule/delete?alarmRuleId=' + alarmRuleId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/alarmRule/delete?alarmRuleId=' + alarmRuleId,
    method: 'get'
  })
}
/**
 * 指标表格 增删改查
 */
export function findMetrics(parserId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metrics?parserId=' + parserId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metrics?parserId=' + parserId,
    method: 'get'
  })
}
export function insertMetrics(metricsRule) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metrics/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metrics/insert',
    data: metricsRule,
    method: 'post'
  })
}
export function updateMetrics(metricsRule) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metrics/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metrics/update',
    data: metricsRule,
    method: 'post'
  })
}
export function deleteMetrics(metricsId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metrics/delete?metricsId=' + metricsId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metrics/delete?metricsId=' + metricsId,
    method: 'get'
  })
}
/**
 * 代理列表增删改查
 */
export function queryProxy() {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/proxyList')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/proxyList',
    method: 'get'
  })
}
export function insertProxy(proxyList) {
  console.log(process.env.zt_api_alarm_gw_url + '/proxy/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/proxy/insert',
    data: proxyList,
    method: 'post'
  })
}
export function updateProxy(proxyList) {
  console.log(process.env.zt_api_alarm_gw_url + '/proxy/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/proxy/update',
    data: proxyList,
    method: 'post'
  })
}
export function deleteProxy(proxyId) {
  console.log(process.env.zt_api_alarm_gw_url + '/proxy/delete?instanceId=' + proxyId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/proxy/delete?instanceId=' + proxyId,
    method: 'get'
  })
}
/**
 * 实例独特指标增删查
 */
export function queryinstanceMetrics(instanceId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics?instanceId=' + instanceId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics?instanceId=' + instanceId,
    method: 'get'
  })
}
export function queryMetricsByInstanceId(instanceId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/metricsByInstanceId?instanceId=' + instanceId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/metricsByInstanceId?instanceId=' + instanceId,
    method: 'get'
  })
}
export function insertinstanceMetrics(instanceId, metricId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics/insert',
    data: {
      instanceId: instanceId,
      metricId: metricId
    },
    method: 'post'
  })
}
export function updateinstanceMetrics(id, instanceId, metricId, nickname) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics/update',
    data: {
      id: id,
      instanceId: instanceId,
      metricId: metricId,
      nickname: nickname
    },
    method: 'post'
  })
}
export function deleteinstanceMetrics(instanceMetricsId) {
  console.log(process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics/delete?instanceMetricsId=' + instanceMetricsId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules/instanceMetrics/delete?instanceMetricsId=' + instanceMetricsId,
    method: 'get'
  })
}
/**
 * 服务管理
 */
export function queryInstanceServices(instanceId, instanceName, serverIp) {
  console.log(process.env.zt_api_alarm_gw_url + '/instanceService', instanceId, instanceName, serverIp)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/instanceService',
    data: {
      instanceId: instanceId,
      instanceName: instanceName,
      serverIp: serverIp
    },
    method: 'post'
  })
}
export function queryServiceStatus(serviceName) {
  console.log(process.env.zt_api_alarm_gw_url + '/instanceService', serviceName)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/serviceStatus?serviceName=' + serviceName,
    method: 'get'
  })
}
export function queryServiceByName(serviceName) {
  console.log(process.env.zt_api_alarm_gw_url + '/service?serviceName=' + serviceName)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/service?serviceName=' + serviceName,
    method: 'get'
  })
}
export function insertService(serviceForm) {
  console.log(process.env.zt_api_alarm_gw_url + '/serviceinsert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/service/insert',
    data: serviceForm,
    method: 'post'
  })
}
export function updateService(serviceForm) {
  console.log(process.env.zt_api_alarm_gw_url + '/service/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/service/update',
    data: serviceForm,
    method: 'post'
  })
}
export function deleteService(serviceId) {
  console.log(process.env.zt_api_alarm_gw_url + '/service/delete?serviceId=' + serviceId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/service/delete?serviceId=' + serviceId,
    method: 'get'
  })
}
/**
 * 主题管理
 */
export function queryThemeByName(ThemeName, user) {
  console.log(process.env.zt_api_alarm_gw_url + '/theme?serviceName=' + ThemeName + '&user=' + user)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/theme?serviceName=' + ThemeName + '&user=' + user,
    method: 'get'
  })
}
export function insertTheme(ThemeForm) {
  // if (typeof ThemeForm.showInPages === typeof []) {
  //   if (ThemeForm.showInPages.length === 0)ThemeForm.showInPages = ''
  //   if (ThemeForm.showInPages.length === 1)ThemeForm.showInPages = ThemeForm.showInPages[0]
  //   if (ThemeForm.showInPages.length > 1)ThemeForm.showInPages = ThemeForm.showInPages.join(',')
  // }
  console.log(process.env.zt_api_alarm_gw_url + '/theme/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/theme/insert',
    data: ThemeForm,
    method: 'post'
  })
}
export function updateTheme(ThemeForm) {
  console.log(process.env.zt_api_alarm_gw_url + '/theme/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/theme/update',
    data: ThemeForm,
    method: 'post'
  })
}
export function deleteTheme(themeId) {
  console.log(process.env.zt_api_alarm_gw_url + '/theme/delete?themeId=' + themeId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/theme/delete?themeId=' + themeId,
    method: 'get'
  })
}
export function modulesUpdatePort(modulePort) {
  console.log(process.env.zt_api_alarm_gw_url + '/modulesUpdatePort')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modulesUpdatePort',
    data: modulePort,
    method: 'post'
  })
}
// 业务域账号管理
export function queryBizPreferByName(user) {
  console.log(process.env.zt_api_alarm_gw_url + '/bizPrefer?user=' + user)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/bizPrefer?&user=' + user,
    method: 'get'
  })
}
export function insertBizPrefer(bizPrefer) {
  // if (typeof ThemeForm.showInPages === typeof []) {
  //   if (ThemeForm.showInPages.length === 0)ThemeForm.showInPages = ''
  //   if (ThemeForm.showInPages.length === 1)ThemeForm.showInPages = ThemeForm.showInPages[0]
  //   if (ThemeForm.showInPages.length > 1)ThemeForm.showInPages = ThemeForm.showInPages.join(',')
  // }
  console.log(process.env.zt_api_alarm_gw_url + '/bizPrefer/insert')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/bizPrefer/insert',
    data: bizPrefer,
    method: 'post'
  })
}
export function updateBizPrefer(bizPrefer) {
  console.log(process.env.zt_api_alarm_gw_url + '/bizPrefer/update')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/bizPrefer/update',
    data: bizPrefer,
    method: 'post'
  })
}
export function deleteBizPrefer(bizPreferId) {
  console.log(process.env.zt_api_alarm_gw_url + '/bizPrefer/delete?bizPreferId=' + bizPreferId)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/bizPrefer/delete?bizPreferId=' + bizPreferId,
    method: 'get'
  })
}
// 功能号调用查询
export function topQuery(topNumber, beginTime, endTime, type, env, appType) {
  console.log(process.env.zt_api_alarm_gw_url + '/funcNo/top?topNumber=' + topNumber + '&beginTime=' + beginTime + '&endTime=' + endTime + '&type=' + type + '&env=' + env + '&appType=' + appType)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/funcNo/top?topNumber=' + topNumber + '&beginTime=' + beginTime + '&endTime=' + endTime + '&type=' + type + '&env=' + env + '&appType=' + appType,
    method: 'get'
  })
}
export function detailQuery(TimeType, beginTime, endTime, funcNo, env, appType) {
  console.log(process.env.zt_api_alarm_gw_url + '/funcNo/detail?TimeType=' + TimeType + '&funcNo=' + funcNo + '&beginTime=' + beginTime + '&endTime=' + endTime + '&env=' + env)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/funcNo/detail?TimeType=' + TimeType + '&funcNo=' + funcNo + '&beginTime=' + beginTime + '&endTime=' + endTime + '&env=' + env,
    data: appType,
    method: 'post'
  })
}
export function appTypeListQuery(funcNO) {
  console.log(process.env.zt_api_alarm_gw_url + '/funcNo/appTypeList?funcNo=' + funcNO)
  return request({
    url: process.env.zt_api_alarm_gw_url + '/funcNo/appTypeList?funcNo=' + funcNO,
    method: 'get'
  })
}
