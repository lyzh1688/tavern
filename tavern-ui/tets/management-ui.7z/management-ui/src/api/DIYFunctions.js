import request from '@/utils/request'
export function queryAccountList(fundAcctoun) {
  console.log(process.env.zt_gw_exchanger_url)
  return request({
    url: process.env.zt_gw_exchanger_url,
    data: {
      header: {
        funcNo: 'IF078233',
        opStation: 'quote-web',
        channel: '3',
        deviceId: 'quote-web' },
      payload: {
        fundAccount: fundAcctoun }
    },
    method: 'post'
  })
}
export function queryUserTagList(accountType, accountValue) {
  console.log(process.env.zt_gw_exchanger_url)
  return request({
    url: process.env.zt_gw_exchanger_url,
    data: {
      header: {
        funcNo: 'IF113011',
        opStation: 'quote-web',
        channel: '3',
        deviceId: 'quote-web' },
      payload: {
        accountType: accountType,
        accountValue: accountValue
      }
    },
    method: 'post'
  })
}
