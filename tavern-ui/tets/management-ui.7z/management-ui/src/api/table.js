import request from '@/utils/request'

export function getList() {
  console.log(process.env.zt_api_alarm_gw_url + '/modules')
  return request({
    url: process.env.zt_api_alarm_gw_url + '/modules',
    method: 'get'
  })
}

