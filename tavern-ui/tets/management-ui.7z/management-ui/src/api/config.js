import request from '@/utils/request'
export function ModulesDialog(moduleName) {
  console.log(process.env.zt_config_gw_url + '/ModulesDialog/' + moduleName)
  return request({
    url: process.env.zt_config_gw_url + '/ModulesDialog/' + moduleName,
    method: 'get'
  })
}
export function ModulesInsert(moduleName, domains, grpcServicePort, managementAgentPort, env, operator) {
  console.log(process.env.zt_config_gw_url + '/ModulesDialog/insert?env=' + env)
  return request({
    url: process.env.zt_config_gw_url + '/ModulesDialog/insert?env=' + env,
    data: {
      module_name: moduleName,
      domains: domains,
      grpcServicePort: grpcServicePort,
      managementAgentPort: managementAgentPort,
      operator: operator
    },
    method: 'post'
  })
}
export function domainDispatch(moduleNames, domains, operator, env) {
  console.log(process.env.zt_config_gw_url + '/ModulesDialog/domainDispatch')
  return request({
    url: process.env.zt_config_gw_url + '/ModulesDialog/domainDispatch',
    data: {
      moduleNames: moduleNames,
      domain: domains,
      operator: operator,
      env: env
    },
    method: 'post'
  })
}

export function ModulesUpdate(moduleName, domains, env, operator) {
  console.log(process.env.zt_config_gw_url + '/ModulesDialog/update?env=' + env)
  return request({
    url: process.env.zt_config_gw_url + '/ModulesDialog/update?env=' + env,
    data: {
      module_name: moduleName,
      domains: domains,
      grpcServicePort: 'none',
      managementAgentPort: 'none',
      operator: operator
    },
    method: 'post'
  })
}
export function ModulesDelete(moduleName) {
  console.log(process.env.zt_config_gw_url + '/ModulesDialog/delete/' + moduleName)
  return request({
    url: process.env.zt_config_gw_url + '/ModulesDialog/delete/' + moduleName,
    method: 'get'
  })
}
export function DomainsDialog(domainsName) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/' + domainsName)
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/' + domainsName,
    method: 'get'
  })
}
export function DomainsDialogEnv(domainsName, mod, env) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/' + domainsName + '/' + mod + '/' + env)
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/' + domainsName + '/' + mod + '/' + env,
    method: 'get'
  })
}
export function DomainsDialogModule(moduleName, env) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/moduleName/' + moduleName + '/' + env)
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/moduleName/' + moduleName + '/' + env,
    method: 'get'
  })
}
export function DomainsInsert(domain, env, remark, type, operator) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/insert')
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/insert',
    data: {
      domain: domain,
      env: env,
      remark: remark,
      type: type,
      operator: operator
    },
    method: 'post'
  })
}templateInsert
export function templateInsert(propertyPOs, domainName, domainType, remark, env, operator) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/templateInsert')
  for (const i of propertyPOs) {
    if (i.key != null || i.key !== undefined)i['name'] = i.key.trim()
    if (i.configType != null || i.configType !== undefined)i.configType = i.configType.trim()
    if (i.value != null || i.value !== undefined)i['configVal'] = i.value.trim()
    if (i.formatter != null || i.formatter !== undefined)i.formatter = i.formatter.trim()
    if (i.remark != null || i.remark !== undefined)i.remark = i.remark.trim()
  }
  if (domainName != null || domainName !== undefined)domainName = domainName.trim()
  if (remark != null || remark !== undefined)remark = remark.trim()
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/templateInsert',
    data: {
      propertyPOs: propertyPOs,
      domainName: domainName,
      domainType: domainType,
      remark: remark,
      env: env,
      operator: operator
    },
    method: 'post'
  })
}
export function DomainsUpdate(domain, env, remark, type, operator, id) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/updateById')
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/updateById',
    data: {
      domain: domain,
      env: env,
      remark: remark,
      type: type,
      id: id,
      operator: operator
    },
    method: 'post'
  })
}
export function DomainsDelete(domains, env) {
  console.log(process.env.zt_config_gw_url + '/DomainsDialog/delete/' + domains + '/' + env)
  return request({
    url: process.env.zt_config_gw_url + '/DomainsDialog/delete/' + domains + '/' + env,
    method: 'get'
  })
}
export function envDialog() {
  console.log(process.env.zt_config_gw_url + '/env')
  return request({
    url: process.env.zt_config_gw_url + '/env',
    method: 'get'
  })
}
export function PropertiesDialog(domainName, env) {
  console.log(process.env.zt_config_gw_url + '/domains_properties/' + domainName + '/' + env)
  return request({
    url: process.env.zt_config_gw_url + '/domains_properties/' + domainName + '/' + env,
    method: 'get'
  })
}
export function PropertiesInsert(domain, env, properties, operator) {
  console.log(process.env.zt_config_gw_url + '/domains/' + domain + '/' + env + '/properties/insert')
  if (properties.key != null || properties.key !== undefined)properties['name'] = properties.key.trim()
  if (properties.configType != null || properties.configType !== undefined)properties.configType = properties.configType.trim()
  if (properties.value != null || properties.value !== undefined)properties['configVal'] = properties.value.trim()
  if (properties.formatter != null || properties.formatter !== undefined)properties.formatter = properties.formatter.trim()
  if (properties.remark != null || properties.remark !== undefined)properties.remark = properties.remark.trim()
  properties['ProId'] = properties.id
  properties['operator'] = operator
  return request({
    url: process.env.zt_config_gw_url + '/domains/' + domain + '/' + env + '/properties/insert',
    data: properties,
    method: 'post'
  })
}
export function PropertiesUpdate(domain, env, properties, operator) {
  if (properties.key != null || properties.key !== undefined)properties['name'] = properties.key.trim()
  if (properties.configType != null || properties.configType !== undefined)properties.configType = properties.configType.trim()
  if (properties.value != null || properties.value !== undefined)properties['configVal'] = properties.value.trim()
  if (properties.formatter != null || properties.formatter !== undefined)properties.formatter = properties.formatter.trim()
  if (properties.remark != null || properties.remark !== undefined)properties.remark = properties.remark.trim()
  properties['ProId'] = properties.id
  properties['operator'] = operator
  console.log(process.env.zt_config_gw_url + '/domains/' + domain + '/' + env + '/properties/update', properties)
  return request({
    url: process.env.zt_config_gw_url + '/domains/' + domain + '/' + env + '/properties/update',
    data: properties,
    method: 'post'
  })
}
export function PropertiesDelete(domains, env, propertiesName) {
  console.log(process.env.zt_config_gw_url + '/domains/' + domains + '/' + env + '/properties/delete/' + propertiesName)
  return request({
    url: process.env.zt_config_gw_url + '/domains/' + domains + '/' + env + '/properties/delete/' + propertiesName,
    method: 'get'
  })
}
export function reverse(domains) {
  console.log(process.env.zt_config_gw_url + '/reverse/domain/' + domains)
  return request({
    url: process.env.zt_config_gw_url + '/reverse/domain/' + domains,
    method: 'get'
  })
}
export function actualModuleConfig(moduleNmae, env) {
  if (process.env.NODE_ENV === 'development') {
    if (env === 'dev') {
      console.log(process.env.zt_config_gw_url1 + '/modules/' + moduleNmae, env)
      return request({
        url: process.env.zt_config_gw_url1 + '/modules/' + moduleNmae,
        method: 'get'
      })
    } else {
      console.log(process.env.zt_config_gw_url2 + '/modules/' + moduleNmae, env)
      return request({
        url: process.env.zt_config_gw_url2 + '/modules/' + moduleNmae,
        method: 'get'
      })
    }
  } else {
    console.log(process.env.zt_config_gw_url + '/modules/' + moduleNmae, env)
    return request({
      url: process.env.zt_config_gw_url + '/modules/' + moduleNmae,
      method: 'get'
    })
  }
}
export function queryProperties(env, propName) {
  console.log(process.env.zt_config_gw_url + '/properties/' + env + '/' + propName)
  return request({
    url: process.env.zt_config_gw_url + '/properties/' + env + '/' + propName,
    method: 'get'
  })
}
// 字典管理
export function queryModuleDictionary(moduleName, dictionName) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/module?moduleName=' + moduleName + '&dictionaryName=' + dictionName)
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/module?moduleName=' + moduleName + '&dictionaryName=' + dictionName,
    method: 'get'
  })
}
export function insertModuleDictionary(moduleList, dictionList, operator) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/module/insert')
  const ans = { moduleList: [], dictionaryList: [], operator: operator }
  for (const i of moduleList) {
    ans.moduleList.push({
      name: i.label,
      key: i.ids
    })
  }
  for (const i of dictionList) {
    ans.dictionaryList.push({
      name: i.label,
      key: i.ids
    })
  }
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/module/insert',
    data: ans,
    method: 'post'
  })
}
export function deleteModuleDictionary(moduleList, dictionList, operator) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/module/delete')
  const ans = { moduleList: [], dictionaryList: [], operator: operator }
  for (const i of moduleList) {
    ans.moduleList.push({
      name: i.label,
      key: i.ids
    })
  }
  for (const i of dictionList) {
    ans.dictionaryList.push({
      name: i.label,
      key: i.ids
    })
  }
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/module/delete',
    data: ans,
    method: 'post'
  })
}
export function queryDictionaryGroup() {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/dicName')
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/dicName',
    method: 'get'
  })
}
export function queryDictionary(groupName, source, direction) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/dic?groupName=' + groupName + '&source=' + source + '&direction=' + direction)
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/dic?groupName=' + groupName + '&source=' + source + '&direction=' + direction,
    method: 'get'
  })
}
export function insertDictionary(dictionary) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/dic/insert')
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/dic/insert',
    data: dictionary,
    method: 'post'
  })
}
export function updateDictionary(dictionary) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/dic/update')
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/dic/update',
    data: dictionary,
    method: 'post'
  })
}
export function deletDictionary(dictionary) {
  console.log(process.env.zt_config_gw_url + '/dictionaryPart/dic/delete')
  return request({
    url: process.env.zt_config_gw_url + '/dictionaryPart/dic/delete',
    data: dictionary,
    method: 'post'
  })
}
export function PropertyChangeQuery(moduleName, env, startTime, endTime) {
  console.log(process.env.zt_config_gw_url + '/modification?env=' + env + '&startTime=' + startTime + '&endTime=' + endTime + '&moduleName=' + moduleName)
  return request({
    url: process.env.zt_config_gw_url + '/modification?env=' + env + '&startTime=' + startTime + '&endTime=' + endTime + '&moduleName=' + moduleName,
    method: 'get'
  })
}
export function managementAgentPortQuery() {
  console.log(process.env.zt_config_gw_url + '/managementAgentPort')
  return request({
    url: process.env.zt_config_gw_url + '/managementAgentPort',
    method: 'get'
  })
}
export function queryModuleGrpcService(moduleName, grpcServiceNickName, grpcServiceName, env) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryModuleGrpcService?moduleName=' + moduleName + '&grpcServiceNickName=' + grpcServiceNickName + '&grpcServiceName=' + grpcServiceName + '&env=' + env)
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryModuleGrpcService?moduleName=' + moduleName + '&grpcServiceNickName=' + grpcServiceNickName + '&grpcServiceName=' + grpcServiceName + '&env=' + env,
    method: 'get'
  })
}
export function moduleGrpcServiceInsert(moduleGrpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/moduleGrpcService/insert')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/moduleGrpcService/insert',
    data: moduleGrpcServiceBO,
    method: 'post'
  })
}
export function moduleGrpcServiceDelete(moduleGrpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/moduleGrpcService/delete')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/moduleGrpcService/delete',
    data: moduleGrpcServiceBO,
    method: 'post'
  })
}
export function queryGrpcService(port, host, grpcServiceNickName, grpcServiceName, name, env) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcService?port=' + port + '&grpcServiceNickName=' + grpcServiceNickName + '&grpcServiceName=' + grpcServiceName + '&host=' + host + '&name=' + name + '&env=' + env)
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcService?port=' + port + '&grpcServiceNickName=' + grpcServiceNickName + '&grpcServiceName=' + grpcServiceName + '&host=' + host + '&name=' + name + '&env=' + env,
    method: 'get'
  })
}
export function queryGrpcServiceDelete(grpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcService/delete')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcService/delete',
    data: grpcServiceBO,
    method: 'post'
  })
}
export function GrpcServiceDelete(GrpcServiceID) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcService/deleteService?id=' + GrpcServiceID)
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcService/deleteService?id=' + GrpcServiceID,
    method: 'get'
  })
}
export function queryGrpcServiceInsert(grpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcService/insert')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcService/insert',
    data: grpcServiceBO,
    method: 'post'
  })
}
export function queryGrpcServiceUpdate(grpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcService/update')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcService/update',
    data: grpcServiceBO,
    method: 'post'
  })
}
export function queryGrpcNodes(port, host, name, env) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes?port=' + port + '&host=' + host + '&name=' + name + '&env=' + env)
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes?port=' + port + '&host=' + host + '&name=' + name + '&env=' + env,
    method: 'get'
  })
}
export function queryGrpcNodesDelete(grpcNodesId) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes/delete?grpcNodesId=' + grpcNodesId)
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes/delete?grpcNodesId=' + grpcNodesId,
    method: 'get'
  })
}
export function queryGrpcNodesInsert(grpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes/insert')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes/insert',
    data: grpcServiceBO,
    method: 'post'
  })
}
export function queryGrpcNodesUpdate(grpcServiceBO) {
  console.log(process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes/update')
  return request({
    url: process.env.zt_config_gw_url + '/grpcService/queryGrpcNodes/update',
    data: grpcServiceBO,
    method: 'post'
  })
}
export function insertModuleBizRelationbyModuleList(bizId, ModuleDomainPOs, operator) {
  console.log(process.env.zt_config_gw_url + '/biz/insertBizRelationByModuleList?bizId=' + bizId + '&operator=' + operator)
  return request({
    url: process.env.zt_config_gw_url + '/biz/insertBizRelationByModuleList?bizId=' + bizId + '&operator=' + operator,
    data: ModuleDomainPOs,
    method: 'post'
  })
}
export function deleteModuleBizRelation(bizId, moduleIds) {
  console.log(process.env.zt_config_gw_url + '/biz/deleteModuleBizRelation?bizId=' + bizId)
  return request({
    url: process.env.zt_config_gw_url + '/biz/deleteModuleBizRelation?bizId=' + bizId,
    data: moduleIds,
    method: 'post'
  })
}
export function deleteModuleBizRelationForBizList(moduleId, bizIds) {
  console.log(process.env.zt_config_gw_url + '/biz/deleteModuleBizRelationForBizList?moduleId=' + moduleId)
  return request({
    url: process.env.zt_config_gw_url + '/biz/deleteModuleBizRelationForBizList?moduleId=' + moduleId,
    data: bizIds,
    method: 'post'
  })
}
export function insertModuleBizRelationByBizList(moduleId, moduleName, BizInformationTablePOs, operator) {
  console.log(process.env.zt_config_gw_url + '/biz/insertModuleBizRelationByBizList?moduleId=' + moduleId + '&moduleName=' + moduleName + '&operator=' + operator)
  return request({
    url: process.env.zt_config_gw_url + '/biz/insertModuleBizRelationByBizList?moduleId=' + moduleId + '&moduleName=' + moduleName + '&operator=' + operator,
    data: BizInformationTablePOs,
    method: 'post'
  })
}
export function insertBizInformationTable(bizName, nicname, ModuleDomainPOs, operator) {
  console.log(process.env.zt_config_gw_url + '/biz/insertBizInformationTable?bizName=' + bizName + '&nicname=' + nicname + '&operator=' + operator)
  return request({
    url: process.env.zt_config_gw_url + '/biz/insertBizInformationTable?bizName=' + bizName + '&nicname=' + nicname + '&operator=' + operator,
    data: ModuleDomainPOs,
    method: 'post'
  })
}
export function updateBizInformationTable(bizInformationTablePO, operator) {
  console.log(process.env.zt_config_gw_url + '/biz/updateBizInformationTable?operator=' + operator)
  return request({
    url: process.env.zt_config_gw_url + '/biz/updateBizInformationTable?operator=' + operator,
    data: bizInformationTablePO,
    method: 'post'
  })
}
export function deleteBizInformationTable(Id) {
  console.log(process.env.zt_config_gw_url + '/biz/deleteBizInformationTable?Id=' + Id)
  return request({
    url: process.env.zt_config_gw_url + '/biz/deleteBizInformationTable?Id=' + Id,
    method: 'post'
  })
}
export function getBizModuleList(moduleName, bizName) {
  console.log(process.env.zt_config_gw_url + '/biz/getBizModuleList?moduleName=' + moduleName + '&bizName=' + bizName)
  return request({
    url: process.env.zt_config_gw_url + '/biz/getBizModuleList?moduleName=' + moduleName + '&bizName=' + bizName,
    method: 'get'
  })
}
export function getBizList(bizName) {
  console.log(process.env.zt_config_gw_url + '/biz/getBizList?bizName=' + bizName)
  return request({
    url: process.env.zt_config_gw_url + '/biz/getBizList?bizName=' + bizName,
    method: 'get'
  })
}
export function getModuleBizList(moduleName, bizName) {
  console.log(process.env.zt_config_gw_url + '/biz/getModuleBizList?moduleName=' + moduleName + '&bizName=' + bizName)
  return request({
    url: process.env.zt_config_gw_url + '/biz/getModuleBizList?moduleName=' + moduleName + '&bizName=' + bizName,
    method: 'get'
  })
}

export function getModuleNameList(bizIds) {
  console.log(process.env.zt_config_gw_url + '/biz/getModuleNames')
  return request({
    url: process.env.zt_config_gw_url + '/biz/getModuleNames',
    data: bizIds,
    method: 'post'
  })
}
export function getSystemOfflineInfo(name) {
  console.log(process.env.zt_config_gw_url + '/system/offline/' + name)
  return request({
    url: process.env.zt_config_gw_url + '/system/offline/' + name,
    data: null,
    method: 'get'
  })
}
export function setSystemOfflineInfo(name, conf) {
  console.log(process.env.zt_config_gw_url + '/system/offline/' + name)
  return request({
    url: process.env.zt_config_gw_url + '/system/offline/' + name,
    data: conf,
    method: 'post'
  })
}
export function queryHistory(queryForm, beginTime, endTime) {
  console.log(process.env.zt_config_gw_url + '/queryHistory?beginTime=' + beginTime + '&endTime=' + endTime)
  return request({
    url: process.env.zt_config_gw_url + '/queryHistory?beginTime=' + beginTime + '&endTime=' + endTime,
    data: queryForm,
    method: 'post'
  })
}
