import request from '@/utils/request'

export function getSchedulerList(Name) {
  console.log(process.env.zt_scheduler_task_gw_url + '/sched/list')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/sched/list',
    data: {
      payload: { jobName: Name }
    },
    method: 'post'
  })
}
export function deleteTask(body) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/delete')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/delete',
    data: { payload: body },
    method: 'post'
  })
}
export function trigerTask(body) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/trigger')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/trigger',
    data: { payload: body },
    method: 'post'
  })
}
export function pauseTask(body) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/pause')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/pause',
    data: { payload: body },
    method: 'post'
  })
}
export function resumeTask(body) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/resume')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/resume',
    data: { payload: body },
    method: 'post'
  })
}
export function updateTask(body) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/update')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/update',
    data: { payload: body },
    method: 'post'
  })
}
export function createTask(body) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/create')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/create',
    data: { payload: body },
    method: 'post'
  })
}

// 一期监控接口
export function getSchedulerListV2(Name, status, excutStatus) {
  console.log(process.env.zt_scheduler_task_gw_url + '/es/schedulerlog/list')
  const data = {}
  if (Name !== '') {
    data['jobName'] = Name
  }
  if (status !== '') {
    data['jobStatus'] = status
  }
  if (excutStatus !== '') {
    data['lastExeStatus'] = excutStatus
  }
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/es/schedulerlog/list',
    data: data,
    method: 'post'
  })
}
export function getArbitList(Name, status, excutStatus) {
  console.log(process.env.zt_arbiter_url + '/job/execute/jobList?jobName=' + Name + '&jobStatus=' + status + '&lastExeStatus=' + excutStatus)
  return request({
    url: process.env.zt_arbiter_url + '/job/execute/jobList?jobName=' + Name + '&jobStatus=' + status + '&lastExeStatus=' + excutStatus,
    method: 'get'
  })
}
export function groupReset(Name) {
  console.log(process.env.zt_arbiter_url + '/trigger/reset/' + Name)
  return request({
    url: process.env.zt_arbiter_url + '/trigger/reset/' + Name,
    method: 'put'
  })
}
export function groupTrigger(url, type) {
  console.log(process.env.zt_arbiter_url.split('/arbiter')[0] + url)
  return request({
    url: process.env.zt_arbiter_url.split('/arbiter')[0] + url,
    method: type
  })
}
export function arbiterJobTrigger(url, args, actType) {
  console.log(process.env.zt_arbiter_url.split('/arbiter')[0] + url)
  return request({
    url: process.env.zt_arbiter_url.split('/arbiter')[0] + url,
    data: JSON.parse(args),
    method: actType
  })
}
export function arbiterJobReset(name) {
  console.log(process.env.zt_arbiter_url + '/job/reset/' + name)
  return request({
    url: process.env.zt_arbiter_url + '/job/reset/' + name,
    method: 'put'
  })
}
export function arbiterJobDisable(name) {
  console.log(process.env.zt_arbiter_url + '/job/update')
  return request({
    url: process.env.zt_arbiter_url + '/job/update',
    data: {
      jobName: name,
      status: 2
    },
    method: 'put'
  })
}
export function arbiterJobEnable(name) {
  console.log(process.env.zt_arbiter_url + '/job/update')
  return request({
    url: process.env.zt_arbiter_url + '/job/update',
    data: {
      jobName: name,
      status: 1
    },
    method: 'put'
  })
}

export function schedulerOperation(taskId, operationType, target, reqBody) {
  console.log(process.env.zt_scheduler_task_gw_url + '/api/task/operation')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/api/task/operation',
    data: {
      taskId: taskId,
      operationType: operationType,
      target: target,
      reqBody: reqBody
    },
    method: 'post'
  })
}
export function schedulerHistoryAgg(taskId, startTime, endTime) {
  console.log(process.env.zt_scheduler_task_gw_url + '/es/schedulerlog/task/statistic')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/es/schedulerlog/task/statistic',
    data: {
      taskId: taskId,
      startTime: startTime,
      endTime: endTime
    },
    method: 'post'
  })
}
export function schedulerHistory(startTime, endTime, exeStatus, taskId, pageNo, pageSize) {
  console.log(process.env.zt_scheduler_task_gw_url + '/es/schedulerlog/task/list')
  return request({
    url: process.env.zt_scheduler_task_gw_url + '/es/schedulerlog/task/list',
    data: {
      taskId: taskId,
      startTime: startTime,
      endTime: endTime,
      exeStatus: exeStatus,
      pageNo: pageNo,
      pageSize: pageSize
    },
    method: 'post'
  })
}
export function arbiterHistoryAgg(jobName, startDate, endDate) {
  console.log(process.env.zt_arbiter_url + '/log/history/sum/' + jobName + '/' + startDate + '/' + endDate)
  return request({
    url: process.env.zt_arbiter_url + '/log/history/sum/' + jobName + '/' + startDate + '/' + endDate,
    method: 'get'
  })
}
export function arbiterHistory(startTime, endTime, jobStatus, jobName, pageNo, pageSize) {
  console.log(process.env.zt_arbiter_url + '/log/history?startTime=' + startTime + '&endTime=' + endTime + '&jobStatus=' + jobStatus + '&jobName=' + jobName + '&pageNo=' + pageNo + '&pageSize=' + pageSize)
  return request({
    url: process.env.zt_arbiter_url + '/log/history?startTime=' + startTime + '&endTime=' + endTime + '&jobStatus=' + jobStatus + '&jobName=' + jobName + '&pageNo=' + pageNo + '&pageSize=' + pageSize,
    method: 'get'
  })
}
export function getArbiterJobStructure(jobName) {
  console.log(process.env.zt_arbiter_url + '/job/jobRel/' + jobName)
  return request({
    url: process.env.zt_arbiter_url + '/job/jobRel/' + jobName,
    method: 'get'
  })
}
export function getArbiterJobDetail(jobId) {
  console.log(process.env.zt_arbiter_url + '/log/detail/' + jobId)
  return request({
    url: process.env.zt_arbiter_url + '/log/detail/' + jobId,
    method: 'get'
  })
}
