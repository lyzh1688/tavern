import request from '@/utils/request'

export function login(username, password) {
  // console.log('login:', process.env.zt_api_alarm_auth_url + '/userInfo    ' + username + ':' + password)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/login',
    method: 'post',
    data: {
      username: username,
      password: password
    }
  })
}

export function getInfo(token) {
  // console.log('getInfo:', process.env.zt_api_alarm_auth_url + '/userInfo    ' + token)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/userInfo',
    method: 'post',
    data: { token: token }
  })
}

export function logout(token) {
  console.log('logout:', process.env.zt_api_alarm_auth_url + '/logout' + token)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/logout',
    method: 'post',
    data: { token: token }
  })
}
export function userTemplateQuery(templateName) {
  console.log('userTemplateQuery:', process.env.zt_api_alarm_auth_url + '/account/userTemplateQuery?templateName=' + templateName)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userTemplateQuery?templateName=' + templateName,
    method: 'get'
  })
}
export function userTemplateInsert(templateName, roleList, leafList) {
  console.log('userTemplateInsert:', process.env.zt_api_alarm_auth_url + '/account/userTemplateInsert?templateName=' + templateName + '&roleList=' + roleList + '&leafList=' + leafList)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userTemplateInsert?templateName=' + templateName + '&roleList=' + roleList + '&leafList=' + leafList,
    method: 'post'
  })
}
export function userTemplateUpdate(templateName, roleList, templateId, leafList) {
  console.log('userTemplateUpdate:', process.env.zt_api_alarm_auth_url + '/account/userTemplateUpdate?templateName=' + templateName + '&roleList=' + roleList + '&templateId=' + templateId + '&leafList=' + leafList)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userTemplateUpdate?templateName=' + templateName + '&roleList=' + roleList + '&templateId=' + templateId + '&leafList=' + leafList,
    method: 'post'
  })
}
export function userTemplateDelete(templateId) {
  console.log('userTemplateDelete:', process.env.zt_api_alarm_auth_url + '/account/userTemplateDelete?templateId=' + templateId)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userTemplateDelete?templateId=' + templateId,
    method: 'get'
  })
}
export function userQuery(userName) {
  console.log('userQuery:', process.env.zt_api_alarm_auth_url + '/account/userQuery?userName=' + userName)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userQuery?userName=' + userName,
    method: 'get'
  })
}
export function userInsert(userBO) {
  console.log('userInsert:', process.env.zt_api_alarm_auth_url + '/account/userInsert')
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userInsert',
    method: 'post',
    data: userBO
  })
}
export function userUpdate(userBO) {
  console.log('userUpdate:', process.env.zt_api_alarm_auth_url + '/account/userUpdate')
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userUpdate',
    method: 'post',
    data: userBO
  })
}
export function userDelete(userId) {
  console.log('userDelete:', process.env.zt_api_alarm_auth_url + '/account/userDelete?userId=' + userId)
  return request({
    url: process.env.zt_api_alarm_auth_url + '/account/userDelete?userId=' + userId,
    method: 'get'
  })
}
